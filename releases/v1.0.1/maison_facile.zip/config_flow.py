"""Config flow: single instance + installer options."""

from __future__ import annotations

import logging
import time
from typing import Any

import voluptuous as vol

from homeassistant.config_entries import (
    ConfigEntry,
    ConfigEntryState,
    ConfigFlow,
    ConfigFlowResult,
    OptionsFlow,
)
from homeassistant.core import callback
from homeassistant.helpers import selector

from . import commercial_rules as cr
from .const import DEFAULT_SETTINGS, DOMAIN, UPDATE_CHANNELS, MaisonFacileData
from .rules import KWH_PRICE_MAX, validate_settings
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)

OPTION_KEYS = (
    "installer_name",
    "installer_contact",
    "update_channel",
    "versions_url",
    "kwh_price",
    "notify_service",
    "commercial_mode",
    "shop_url",
)
# Installer code fields (never stored as entered: hashed, see commercial.py).
PIN_FIELD = "installer_pin"  # new code, empty = unchanged
CLEAR_PIN_FIELD = "clear_installer_pin"
CURRENT_PIN_FIELD = "current_installer_pin"
OPTIONS_LIMITER_KEY = "options_flow"


class MaisonFacileConfigFlow(ConfigFlow, domain=DOMAIN):
    """Single-instance config flow."""

    VERSION = 1

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        await self.async_set_unique_id(DOMAIN)
        self._abort_if_unique_id_configured()
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")
        if user_input is not None:
            return self.async_create_entry(title="Maison Facile", data={})
        return self.async_show_form(step_id="user", data_schema=vol.Schema({}))

    async def async_step_import(self, import_data: dict[str, Any] | None = None) -> ConfigFlowResult:
        """`maison_facile:` in configuration.yaml (box prepared by the installer)."""
        await self.async_set_unique_id(DOMAIN)
        self._abort_if_unique_id_configured()
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")
        return self.async_create_entry(title="Maison Facile", data={})

    @staticmethod
    @callback
    def async_get_options_flow(config_entry: ConfigEntry) -> OptionsFlow:
        return MaisonFacileOptionsFlow()


class MaisonFacileOptionsFlow(OptionsFlow):
    """Installer settings, written into the store settings."""

    def _current(self) -> dict[str, Any]:
        runtime = getattr(self.config_entry, "runtime_data", None)
        store = getattr(runtime, "store", None)
        settings = dict(DEFAULT_SETTINGS)
        if store is not None:
            settings.update(store.settings)
        return settings

    async def async_step_init(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        errors: dict[str, str] = {}
        current = self._current()
        if user_input is not None:
            raw = {key: user_input.get(key, "") for key in OPTION_KEYS}
            if "commercial_mode" not in user_input:
                raw.pop("commercial_mode")
            new_pin = str(user_input.get(PIN_FIELD) or "").strip()
            if new_pin:
                raw[PIN_FIELD] = new_pin
            changes, codes = validate_settings(raw)
            errors = dict(codes)
            runtime = getattr(self.config_entry, "runtime_data", None)
            store = getattr(runtime, "store", None)
            loaded = (
                self.config_entry.state is ConfigEntryState.LOADED
                and isinstance(runtime, MaisonFacileData)
                and store is not None
            )
            if store is None:
                # Entry not loaded: write straight into the storage file.
                store = MaisonFacileStore(self.hass)
                await store.async_load()
            if not errors:
                errors = await self._check_installer_code(store, changes, user_input)
            if not errors:
                pin = changes.pop(PIN_FIELD, None)
                old = dict(store.settings)
                await store.async_update_settings(changes)
                manager = getattr(runtime, "commercial", None) if loaded else None
                if pin or user_input.get(CLEAR_PIN_FIELD):
                    record = await self.hass.async_add_executor_job(cr.hash_pin, pin) if pin else None
                    store.data.setdefault("advanced", {})["pin"] = record
                    await store.async_save()
                if manager is not None and old.get("commercial_mode", True) != store.settings.get(
                    "commercial_mode", True
                ):
                    await manager.async_apply()
                if loaded:
                    # Same refresh as the settings/set websocket command.
                    from .websocket_api import async_settings_changed  # noqa: PLC0415

                    try:
                        await async_settings_changed(self.hass, runtime, old, changes)
                    except Exception:  # noqa: BLE001 - settings are saved anyway
                        _LOGGER.exception("Could not refresh automations after options change")
                # The store is the single source of truth; entry options stay empty
                # so they can never override settings changed from the panel.
                return self.async_create_entry(title="", data={})
            user_input = {k: v for k, v in user_input.items() if k not in (PIN_FIELD, CURRENT_PIN_FIELD)}
            current.update(user_input)

        schema = vol.Schema(
            {
                vol.Optional("installer_name", default=current.get("installer_name", "")): str,
                vol.Optional("installer_contact", default=current.get("installer_contact", "")): str,
                vol.Required("update_channel", default=current.get("update_channel", "stable")): selector.SelectSelector(
                    selector.SelectSelectorConfig(
                        options=list(UPDATE_CHANNELS),
                        translation_key="update_channel",
                        mode=selector.SelectSelectorMode.DROPDOWN,
                    )
                ),
                vol.Required("versions_url", default=current.get("versions_url", "")): str,
                vol.Required("kwh_price", default=float(current.get("kwh_price", 0.25))): selector.NumberSelector(
                    selector.NumberSelectorConfig(
                        min=0, max=KWH_PRICE_MAX, step=0.001, mode=selector.NumberSelectorMode.BOX, unit_of_measurement="€/kWh"
                    )
                ),
                vol.Required("notify_service", default=current.get("notify_service", "notify.notify")): str,
                vol.Required("commercial_mode", default=bool(current.get("commercial_mode", True))): bool,
                vol.Optional("shop_url", default=current.get("shop_url", "")): str,
                vol.Optional(PIN_FIELD, default=""): selector.TextSelector(
                    selector.TextSelectorConfig(type=selector.TextSelectorType.PASSWORD)
                ),
                vol.Optional(CLEAR_PIN_FIELD, default=False): bool,
                vol.Optional(CURRENT_PIN_FIELD, default=""): selector.TextSelector(
                    selector.TextSelectorConfig(type=selector.TextSelectorType.PASSWORD)
                ),
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema, errors=errors)

    async def _check_installer_code(
        self, store: MaisonFacileStore, changes: dict[str, Any], user_input: dict[str, Any]
    ) -> dict[str, str]:
        """With commercial mode on and a code set, turning it off or changing the
        code needs the current code (5 wrong codes / 5 min, like advanced/unlock)."""
        record = store.data.get("advanced", {}).get("pin")
        commercial_on = store.settings.get("commercial_mode", True) is not False
        sensitive = (
            changes.get("commercial_mode") is False
            or bool(changes.get(PIN_FIELD))
            or bool(user_input.get(CLEAR_PIN_FIELD))
        )
        if not (record and commercial_on and sensitive):
            return {}
        runtime = getattr(self.config_entry, "runtime_data", None)
        manager = getattr(runtime, "commercial", None)
        limiter = manager.limiter if manager is not None else cr.AttemptLimiter()
        now = time.monotonic()
        if limiter.retry_after(OPTIONS_LIMITER_KEY, now) > 0:
            return {CURRENT_PIN_FIELD: "too_many_attempts"}
        given = str(user_input.get(CURRENT_PIN_FIELD) or "")
        if await self.hass.async_add_executor_job(cr.verify_pin, given, record):
            limiter.reset(OPTIONS_LIMITER_KEY)
            return {}
        limiter.failure(OPTIONS_LIMITER_KEY, now)
        return {CURRENT_PIN_FIELD: "wrong_pin"}
