// Démo des recettes (Réglages > IA, Mes appareils > Smart Life / Tuya). Étapes copiées de
// recipes_rules.py (régénérées à la main si elles changent).
export const DEMO_FRIGATE_STEPS = [
  {
    "id": "mosquitto",
    "title": "Installer Mosquitto",
    "what": "Le « facteur » qui transporte les messages entre Frigate et Home Assistant.",
    "learn": "MQTT est une petite messagerie : un programme publie un message (« une personne à l'entrée »), les autres s'y abonnent. Mosquitto est le serveur de cette messagerie, il tourne sur la box.",
    "by": "box"
  },
  {
    "id": "mqtt",
    "title": "Relier Home Assistant à Mosquitto",
    "what": "Home Assistant s'abonne aux messages.",
    "learn": "Une « intégration » est la pièce de Home Assistant qui parle à un service. L'intégration MQTT est trouvée toute seule grâce au Supervisor : Maison Facile la confirme pour vous.",
    "by": "box"
  },
  {
    "id": "frigate_app",
    "title": "Installer l'application Frigate",
    "what": "Le logiciel qui regarde les images des caméras et reconnaît ce qui bouge.",
    "learn": "Une « application » (ou module complémentaire) est un programme à part, dans son propre conteneur, à côté de Home Assistant. Frigate analyse les images avec un petit modèle d'IA qui reconnaît des objets : personne, voiture, chien, chat.",
    "by": "box"
  },
  {
    "id": "frigate_config",
    "title": "Régler Frigate avec vos caméras",
    "what": "Maison Facile écrit le fichier de réglages de Frigate à partir de vos caméras.",
    "learn": "Frigate se règle avec un fichier texte au format YAML : une ligne par réglage, et le décalage (l'indentation) indique ce qui appartient à quoi. Vous pourrez voir ce fichier, commenté ligne par ligne.",
    "by": "box"
  },
  {
    "id": "frigate_module",
    "title": "Ajouter le module Frigate",
    "what": "Le module qui fait apparaître les caméras Frigate et leurs alertes dans Home Assistant.",
    "learn": "Ce module vient de la communauté (Marketplace) : il n'est pas encore dans Home Assistant de base. Une sauvegarde est faite avant, comme pour chaque installation.",
    "by": "page"
  },
  {
    "id": "restart",
    "title": "Redémarrer la box",
    "what": "Home Assistant charge le nouveau module au démarrage.",
    "learn": "Le code d'un module est lu une seule fois, quand Home Assistant démarre : un nouveau module demande donc un redémarrage (une à deux minutes).",
    "by": "you"
  },
  {
    "id": "frigate_integration",
    "title": "Relier Frigate à Home Assistant",
    "what": "Maison Facile indique à Home Assistant l'adresse de Frigate dans la box.",
    "learn": "Chaque application a une adresse interne dans la box (ici ccab4aaf-frigate). Le module s'y connecte pour lire les détections et les images.",
    "by": "box"
  }
];
const CONFIG = "# Réglages de Frigate écrits par Maison Facile (recette « Caméras intelligentes »).\n# Chaque ligne « clé: valeur » est un réglage ; le décalage indique à quoi il appartient.\n\n# La messagerie MQTT : Frigate y publie ses détections, Home Assistant les lit.\nmqtt:\n  enabled: true\n  host: core-mosquitto            # Mosquitto, dans la box\n  user: maison_facile_frigate\n  password: \"••••••••\"  # créé par Maison Facile, propre à Frigate\n\n# Photos des détections, gardées 7 jours. L'enregistrement vidéo continu est coupé :\n# il remplit vite le disque (à activer plus tard si vous le voulez).\nsnapshots:\n  enabled: true\n  retain:\n    default: 7\nrecord:\n  enabled: false\n\n# Ce que Frigate cherche dans les images (pas de reconnaissance des visages).\nobjects:\n  track:\n    - person\n    - car\n    - dog\n    - cat\n\n# Vos caméras : l'adresse de leur flux vidéo, et le rôle « detect » (analyser les images).\ncameras:\n  entree:                    # Entrée\n    ffmpeg:\n      inputs:\n        - path: \"rtsp://camera-entree.local:554/stream1\"\n          roles:\n            - detect\n    detect:\n      enabled: true\n  jardin:                    # Jardin\n    ffmpeg:\n      inputs:\n        - path: \"rtsp://camera-jardin.local:554/stream1\"\n          roles:\n            - detect\n    detect:\n      enabled: true\n";
const QR = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 41 41\" shape-rendering=\"crispEdges\" role=\"img\" aria-label=\"Code QR\"><rect width=\"100%\" height=\"100%\" fill=\"#FFFFFF\"/><path d=\"M4,4h1v1h-1zM5,4h1v1h-1zM6,4h1v1h-1zM7,4h1v1h-1zM8,4h1v1h-1zM9,4h1v1h-1zM10,4h1v1h-1zM18,4h1v1h-1zM19,4h1v1h-1zM20,4h1v1h-1zM22,4h1v1h-1zM23,4h1v1h-1zM25,4h1v1h-1zM26,4h1v1h-1zM30,4h1v1h-1zM31,4h1v1h-1zM32,4h1v1h-1zM33,4h1v1h-1zM34,4h1v1h-1zM35,4h1v1h-1zM36,4h1v1h-1zM4,5h1v1h-1zM10,5h1v1h-1zM12,5h1v1h-1zM16,5h1v1h-1zM17,5h1v1h-1zM19,5h1v1h-1zM20,5h1v1h-1zM21,5h1v1h-1zM23,5h1v1h-1zM24,5h1v1h-1zM25,5h1v1h-1zM26,5h1v1h-1zM27,5h1v1h-1zM30,5h1v1h-1zM36,5h1v1h-1zM4,6h1v1h-1zM6,6h1v1h-1zM7,6h1v1h-1zM8,6h1v1h-1zM10,6h1v1h-1zM13,6h1v1h-1zM16,6h1v1h-1zM19,6h1v1h-1zM23,6h1v1h-1zM26,6h1v1h-1zM27,6h1v1h-1zM28,6h1v1h-1zM30,6h1v1h-1zM32,6h1v1h-1zM33,6h1v1h-1zM34,6h1v1h-1zM36,6h1v1h-1zM4,7h1v1h-1zM6,7h1v1h-1zM7,7h1v1h-1zM8,7h1v1h-1zM10,7h1v1h-1zM13,7h1v1h-1zM14,7h1v1h-1zM16,7h1v1h-1zM17,7h1v1h-1zM21,7h1v1h-1zM27,7h1v1h-1zM30,7h1v1h-1zM32,7h1v1h-1zM33,7h1v1h-1zM34,7h1v1h-1zM36,7h1v1h-1zM4,8h1v1h-1zM6,8h1v1h-1zM7,8h1v1h-1zM8,8h1v1h-1zM10,8h1v1h-1zM12,8h1v1h-1zM14,8h1v1h-1zM17,8h1v1h-1zM21,8h1v1h-1zM25,8h1v1h-1zM26,8h1v1h-1zM30,8h1v1h-1zM32,8h1v1h-1zM33,8h1v1h-1zM34,8h1v1h-1zM36,8h1v1h-1zM4,9h1v1h-1zM10,9h1v1h-1zM13,9h1v1h-1zM16,9h1v1h-1zM17,9h1v1h-1zM18,9h1v1h-1zM25,9h1v1h-1zM26,9h1v1h-1zM27,9h1v1h-1zM28,9h1v1h-1zM30,9h1v1h-1zM36,9h1v1h-1zM4,10h1v1h-1zM5,10h1v1h-1zM6,10h1v1h-1zM7,10h1v1h-1zM8,10h1v1h-1zM9,10h1v1h-1zM10,10h1v1h-1zM12,10h1v1h-1zM14,10h1v1h-1zM16,10h1v1h-1zM18,10h1v1h-1zM20,10h1v1h-1zM22,10h1v1h-1zM24,10h1v1h-1zM26,10h1v1h-1zM28,10h1v1h-1zM30,10h1v1h-1zM31,10h1v1h-1zM32,10h1v1h-1zM33,10h1v1h-1zM34,10h1v1h-1zM35,10h1v1h-1zM36,10h1v1h-1zM13,11h1v1h-1zM14,11h1v1h-1zM15,11h1v1h-1zM17,11h1v1h-1zM18,11h1v1h-1zM20,11h1v1h-1zM21,11h1v1h-1zM22,11h1v1h-1zM24,11h1v1h-1zM25,11h1v1h-1zM27,11h1v1h-1zM4,12h1v1h-1zM6,12h1v1h-1zM8,12h1v1h-1zM10,12h1v1h-1zM14,12h1v1h-1zM16,12h1v1h-1zM19,12h1v1h-1zM20,12h1v1h-1zM21,12h1v1h-1zM23,12h1v1h-1zM24,12h1v1h-1zM25,12h1v1h-1zM32,12h1v1h-1zM35,12h1v1h-1zM12,13h1v1h-1zM14,13h1v1h-1zM19,13h1v1h-1zM20,13h1v1h-1zM24,13h1v1h-1zM28,13h1v1h-1zM30,13h1v1h-1zM6,14h1v1h-1zM7,14h1v1h-1zM9,14h1v1h-1zM10,14h1v1h-1zM12,14h1v1h-1zM13,14h1v1h-1zM15,14h1v1h-1zM16,14h1v1h-1zM17,14h1v1h-1zM21,14h1v1h-1zM24,14h1v1h-1zM29,14h1v1h-1zM31,14h1v1h-1zM32,14h1v1h-1zM33,14h1v1h-1zM34,14h1v1h-1zM35,14h1v1h-1zM36,14h1v1h-1zM4,15h1v1h-1zM5,15h1v1h-1zM6,15h1v1h-1zM7,15h1v1h-1zM13,15h1v1h-1zM14,15h1v1h-1zM15,15h1v1h-1zM19,15h1v1h-1zM20,15h1v1h-1zM23,15h1v1h-1zM24,15h1v1h-1zM25,15h1v1h-1zM26,15h1v1h-1zM27,15h1v1h-1zM31,15h1v1h-1zM35,15h1v1h-1zM5,16h1v1h-1zM8,16h1v1h-1zM10,16h1v1h-1zM11,16h1v1h-1zM15,16h1v1h-1zM19,16h1v1h-1zM24,16h1v1h-1zM28,16h1v1h-1zM29,16h1v1h-1zM30,16h1v1h-1zM33,16h1v1h-1zM35,16h1v1h-1zM4,17h1v1h-1zM6,17h1v1h-1zM8,17h1v1h-1zM9,17h1v1h-1zM11,17h1v1h-1zM12,17h1v1h-1zM16,17h1v1h-1zM17,17h1v1h-1zM19,17h1v1h-1zM21,17h1v1h-1zM23,17h1v1h-1zM26,17h1v1h-1zM27,17h1v1h-1zM28,17h1v1h-1zM29,17h1v1h-1zM31,17h1v1h-1zM33,17h1v1h-1zM34,17h1v1h-1zM36,17h1v1h-1zM5,18h1v1h-1zM6,18h1v1h-1zM7,18h1v1h-1zM10,18h1v1h-1zM11,18h1v1h-1zM13,18h1v1h-1zM24,18h1v1h-1zM25,18h1v1h-1zM30,18h1v1h-1zM32,18h1v1h-1zM33,18h1v1h-1zM34,18h1v1h-1zM35,18h1v1h-1zM36,18h1v1h-1zM5,19h1v1h-1zM9,19h1v1h-1zM11,19h1v1h-1zM13,19h1v1h-1zM16,19h1v1h-1zM17,19h1v1h-1zM18,19h1v1h-1zM19,19h1v1h-1zM21,19h1v1h-1zM22,19h1v1h-1zM24,19h1v1h-1zM25,19h1v1h-1zM26,19h1v1h-1zM27,19h1v1h-1zM28,19h1v1h-1zM29,19h1v1h-1zM30,19h1v1h-1zM33,19h1v1h-1zM35,19h1v1h-1zM7,20h1v1h-1zM8,20h1v1h-1zM9,20h1v1h-1zM10,20h1v1h-1zM13,20h1v1h-1zM14,20h1v1h-1zM15,20h1v1h-1zM18,20h1v1h-1zM20,20h1v1h-1zM21,20h1v1h-1zM23,20h1v1h-1zM25,20h1v1h-1zM29,20h1v1h-1zM30,20h1v1h-1zM35,20h1v1h-1zM36,20h1v1h-1zM4,21h1v1h-1zM6,21h1v1h-1zM13,21h1v1h-1zM15,21h1v1h-1zM16,21h1v1h-1zM19,21h1v1h-1zM20,21h1v1h-1zM21,21h1v1h-1zM24,21h1v1h-1zM25,21h1v1h-1zM28,21h1v1h-1zM30,21h1v1h-1zM33,21h1v1h-1zM34,21h1v1h-1zM35,21h1v1h-1zM5,22h1v1h-1zM6,22h1v1h-1zM8,22h1v1h-1zM10,22h1v1h-1zM13,22h1v1h-1zM15,22h1v1h-1zM16,22h1v1h-1zM22,22h1v1h-1zM30,22h1v1h-1zM31,22h1v1h-1zM32,22h1v1h-1zM33,22h1v1h-1zM34,22h1v1h-1zM35,22h1v1h-1zM36,22h1v1h-1zM5,23h1v1h-1zM6,23h1v1h-1zM8,23h1v1h-1zM11,23h1v1h-1zM13,23h1v1h-1zM14,23h1v1h-1zM15,23h1v1h-1zM16,23h1v1h-1zM19,23h1v1h-1zM20,23h1v1h-1zM21,23h1v1h-1zM22,23h1v1h-1zM24,23h1v1h-1zM25,23h1v1h-1zM27,23h1v1h-1zM28,23h1v1h-1zM32,23h1v1h-1zM35,23h1v1h-1zM36,23h1v1h-1zM4,24h1v1h-1zM5,24h1v1h-1zM7,24h1v1h-1zM9,24h1v1h-1zM10,24h1v1h-1zM12,24h1v1h-1zM15,24h1v1h-1zM18,24h1v1h-1zM20,24h1v1h-1zM22,24h1v1h-1zM23,24h1v1h-1zM24,24h1v1h-1zM27,24h1v1h-1zM28,24h1v1h-1zM30,24h1v1h-1zM31,24h1v1h-1zM32,24h1v1h-1zM35,24h1v1h-1zM5,25h1v1h-1zM6,25h1v1h-1zM8,25h1v1h-1zM9,25h1v1h-1zM14,25h1v1h-1zM15,25h1v1h-1zM17,25h1v1h-1zM19,25h1v1h-1zM20,25h1v1h-1zM22,25h1v1h-1zM23,25h1v1h-1zM24,25h1v1h-1zM25,25h1v1h-1zM27,25h1v1h-1zM28,25h1v1h-1zM29,25h1v1h-1zM30,25h1v1h-1zM34,25h1v1h-1zM36,25h1v1h-1zM4,26h1v1h-1zM8,26h1v1h-1zM10,26h1v1h-1zM11,26h1v1h-1zM12,26h1v1h-1zM14,26h1v1h-1zM15,26h1v1h-1zM16,26h1v1h-1zM18,26h1v1h-1zM19,26h1v1h-1zM20,26h1v1h-1zM21,26h1v1h-1zM25,26h1v1h-1zM28,26h1v1h-1zM29,26h1v1h-1zM30,26h1v1h-1zM31,26h1v1h-1zM33,26h1v1h-1zM34,26h1v1h-1zM35,26h1v1h-1zM36,26h1v1h-1zM5,27h1v1h-1zM6,27h1v1h-1zM9,27h1v1h-1zM11,27h1v1h-1zM12,27h1v1h-1zM14,27h1v1h-1zM16,27h1v1h-1zM17,27h1v1h-1zM18,27h1v1h-1zM20,27h1v1h-1zM21,27h1v1h-1zM23,27h1v1h-1zM24,27h1v1h-1zM25,27h1v1h-1zM26,27h1v1h-1zM29,27h1v1h-1zM32,27h1v1h-1zM36,27h1v1h-1zM4,28h1v1h-1zM6,28h1v1h-1zM7,28h1v1h-1zM9,28h1v1h-1zM10,28h1v1h-1zM11,28h1v1h-1zM12,28h1v1h-1zM13,28h1v1h-1zM14,28h1v1h-1zM15,28h1v1h-1zM19,28h1v1h-1zM20,28h1v1h-1zM21,28h1v1h-1zM22,28h1v1h-1zM25,28h1v1h-1zM28,28h1v1h-1zM29,28h1v1h-1zM30,28h1v1h-1zM31,28h1v1h-1zM32,28h1v1h-1zM34,28h1v1h-1zM36,28h1v1h-1zM12,29h1v1h-1zM13,29h1v1h-1zM16,29h1v1h-1zM17,29h1v1h-1zM19,29h1v1h-1zM20,29h1v1h-1zM22,29h1v1h-1zM27,29h1v1h-1zM28,29h1v1h-1zM32,29h1v1h-1zM33,29h1v1h-1zM35,29h1v1h-1zM4,30h1v1h-1zM5,30h1v1h-1zM6,30h1v1h-1zM7,30h1v1h-1zM8,30h1v1h-1zM9,30h1v1h-1zM10,30h1v1h-1zM14,30h1v1h-1zM15,30h1v1h-1zM16,30h1v1h-1zM17,30h1v1h-1zM20,30h1v1h-1zM21,30h1v1h-1zM24,30h1v1h-1zM25,30h1v1h-1zM27,30h1v1h-1zM28,30h1v1h-1zM30,30h1v1h-1zM32,30h1v1h-1zM33,30h1v1h-1zM34,30h1v1h-1zM35,30h1v1h-1zM36,30h1v1h-1zM4,31h1v1h-1zM10,31h1v1h-1zM14,31h1v1h-1zM19,31h1v1h-1zM20,31h1v1h-1zM24,31h1v1h-1zM25,31h1v1h-1zM26,31h1v1h-1zM27,31h1v1h-1zM28,31h1v1h-1zM32,31h1v1h-1zM36,31h1v1h-1zM4,32h1v1h-1zM6,32h1v1h-1zM7,32h1v1h-1zM8,32h1v1h-1zM10,32h1v1h-1zM12,32h1v1h-1zM13,32h1v1h-1zM14,32h1v1h-1zM16,32h1v1h-1zM23,32h1v1h-1zM24,32h1v1h-1zM28,32h1v1h-1zM29,32h1v1h-1zM30,32h1v1h-1zM31,32h1v1h-1zM32,32h1v1h-1zM33,32h1v1h-1zM34,32h1v1h-1zM35,32h1v1h-1zM4,33h1v1h-1zM6,33h1v1h-1zM7,33h1v1h-1zM8,33h1v1h-1zM10,33h1v1h-1zM13,33h1v1h-1zM14,33h1v1h-1zM18,33h1v1h-1zM19,33h1v1h-1zM23,33h1v1h-1zM24,33h1v1h-1zM29,33h1v1h-1zM31,33h1v1h-1zM32,33h1v1h-1zM34,33h1v1h-1zM36,33h1v1h-1zM4,34h1v1h-1zM6,34h1v1h-1zM7,34h1v1h-1zM8,34h1v1h-1zM10,34h1v1h-1zM12,34h1v1h-1zM13,34h1v1h-1zM15,34h1v1h-1zM16,34h1v1h-1zM18,34h1v1h-1zM26,34h1v1h-1zM27,34h1v1h-1zM31,34h1v1h-1zM32,34h1v1h-1zM36,34h1v1h-1zM4,35h1v1h-1zM10,35h1v1h-1zM14,35h1v1h-1zM15,35h1v1h-1zM16,35h1v1h-1zM17,35h1v1h-1zM19,35h1v1h-1zM21,35h1v1h-1zM22,35h1v1h-1zM25,35h1v1h-1zM26,35h1v1h-1zM30,35h1v1h-1zM32,35h1v1h-1zM35,35h1v1h-1zM4,36h1v1h-1zM5,36h1v1h-1zM6,36h1v1h-1zM7,36h1v1h-1zM8,36h1v1h-1zM9,36h1v1h-1zM10,36h1v1h-1zM12,36h1v1h-1zM13,36h1v1h-1zM15,36h1v1h-1zM17,36h1v1h-1zM18,36h1v1h-1zM20,36h1v1h-1zM23,36h1v1h-1zM24,36h1v1h-1zM25,36h1v1h-1zM27,36h1v1h-1zM28,36h1v1h-1zM29,36h1v1h-1zM30,36h1v1h-1zM32,36h1v1h-1zM34,36h1v1h-1zM35,36h1v1h-1zM36,36h1v1h-1z\" fill=\"#16181D\"/></svg>";

export function createDemoRecipes({ wait, wsError }) {
  const done = {};
  let running = null;
  const status = () => {
    let nextFound = false;
    const steps = DEMO_FRIGATE_STEPS.map((s) => {
      const state = done[s.id] ? "done" : running === s.id ? "running" : "todo";
      const next = state === "todo" && !nextFound;
      if (next) nextFound = true;
      return { ...s, state, next, error: null };
    });
    return { available: true, message: "", steps, complete: steps.every((s) => s.state === "done"), config: done.frigate_config ? CONFIG : "", cameras: [], module_repo: "blakeblackshear/frigate-hass-integration" };
  };
  let tuya = "code";
  return {
    "recipes/frigate": status,
    "recipes/frigate/run": ({ step }) => {
      running = step;
      setTimeout(() => { done[step] = true; running = null; }, 2500);
      return { started: true };
    },
    "recipes/tuya/start": async ({ user_code }) => {
      await wait(600);
      if (user_code.length < 4) return { state: "code", message: "Ce code n'a pas été accepté par Tuya. Vérifiez-le (majuscules et minuscules comptent) et réessayez." };
      tuya = "scan";
      return { state: "scan", qr_svg: QR, message: "" };
    },
    "recipes/tuya/check": async () => {
      await wait(600);
      if (tuya !== "scan") return { state: "code", message: "" };
      tuya = "done";
      return { state: "done", message: "C'est fait : vos appareils Smart Life arrivent dans Mes appareils." };
    },
    _markModule() { done.frigate_module = true; done.restart = true; },
  };
}
