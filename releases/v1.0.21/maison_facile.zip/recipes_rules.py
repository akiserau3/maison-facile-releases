"""Recettes : ce qu'il faut installer et régler pour qu'une fonction marche (logique pure).

Une recette = des étapes, chacune expliquée simplement (« J'apprends »). Maison Facile ne
lance rien sans l'accord de l'utilisateur ; chaque étape se refait sans risque (si elle est
déjà faite, elle est simplement cochée). Deux recettes :

- ``frigate`` (Réglages > IA > Caméras intelligentes) : Mosquitto, MQTT, l'application
  Frigate avec une configuration générée à partir des caméras connues de Home Assistant
  (détection de personnes, voitures, animaux ; pas de reconnaissance faciale), puis
  l'intégration Frigate (module du Marketplace) ;
- ``tuya`` (Réglages > Mes appareils) : l'intégration officielle Tuya / Smart Life, avec le
  code utilisateur et le QR code à scanner. Rien à installer.

Tests : tests/test_recipes_rules.py.
"""

from __future__ import annotations

import re
import secrets
import unicodedata
from collections.abc import Iterable, Mapping
from typing import Any

FRIGATE_SLUG = "ccab4aaf_frigate"
FRIGATE_REPOSITORY = "https://github.com/blakeblackshear/frigate-hass-addons"
FRIGATE_MODULE = "blakeblackshear/frigate-hass-integration"
MOSQUITTO_SLUG = "core_mosquitto"
MQTT_HOST = "core-mosquitto"
MQTT_USER = "maison_facile_frigate"
TRACKED = ("person", "car", "dog", "cat")

# id, titre, ce que fait l'étape, « J'apprends », qui la fait (box / page / vous).
FRIGATE_STEPS: tuple[dict[str, str], ...] = (
    {
        "id": "mosquitto",
        "title": "Installer Mosquitto",
        "what": "Le « facteur » qui transporte les messages entre Frigate et Home Assistant.",
        "learn": "MQTT est une petite messagerie : un programme publie un message (« une personne à l'entrée »), "
        "les autres s'y abonnent. Mosquitto est le serveur de cette messagerie, il tourne sur la box.",
        "by": "box",
    },
    {
        "id": "mqtt",
        "title": "Relier Home Assistant à Mosquitto",
        "what": "Home Assistant s'abonne aux messages.",
        "learn": "Une « intégration » est la pièce de Home Assistant qui parle à un service. L'intégration MQTT est "
        "trouvée toute seule grâce au Supervisor : Maison Facile la confirme pour vous.",
        "by": "box",
    },
    {
        "id": "frigate_app",
        "title": "Installer l'application Frigate",
        "what": "Le logiciel qui regarde les images des caméras et reconnaît ce qui bouge.",
        "learn": "Une « application » (ou module complémentaire) est un programme à part, dans son propre "
        "conteneur, à côté de Home Assistant. Frigate analyse les images avec un petit modèle d'IA qui "
        "reconnaît des objets : personne, voiture, chien, chat.",
        "by": "box",
    },
    {
        "id": "frigate_config",
        "title": "Régler Frigate avec vos caméras",
        "what": "Maison Facile écrit le fichier de réglages de Frigate à partir de vos caméras.",
        "learn": "Frigate se règle avec un fichier texte au format YAML : une ligne par réglage, et le décalage "
        "(l'indentation) indique ce qui appartient à quoi. Vous pourrez voir ce fichier, commenté ligne par ligne.",
        "by": "box",
    },
    {
        "id": "frigate_module",
        "title": "Ajouter le module Frigate",
        "what": "Le module qui fait apparaître les caméras Frigate et leurs alertes dans Home Assistant.",
        "learn": "Ce module vient de la communauté (Marketplace) : il n'est pas encore dans Home Assistant de base. "
        "Une sauvegarde est faite avant, comme pour chaque installation.",
        "by": "page",
    },
    {
        "id": "restart",
        "title": "Redémarrer la box",
        "what": "Home Assistant charge le nouveau module au démarrage.",
        "learn": "Le code d'un module est lu une seule fois, quand Home Assistant démarre : un nouveau module "
        "demande donc un redémarrage (une à deux minutes).",
        "by": "you",
    },
    {
        "id": "frigate_integration",
        "title": "Relier Frigate à Home Assistant",
        "what": "Maison Facile indique à Home Assistant l'adresse de Frigate dans la box.",
        "learn": "Chaque application a une adresse interne dans la box (ici ccab4aaf-frigate). Le module s'y "
        "connecte pour lire les détections et les images.",
        "by": "box",
    },
)

TUYA_STEPS: tuple[dict[str, str], ...] = (
    {
        "id": "user_code",
        "title": "Votre code utilisateur Smart Life",
        "what": "Dans l'application Smart Life (ou Tuya Smart) : Moi, puis l'engrenage Réglages, puis Compte et "
        "sécurité, puis « Code utilisateur ». Recopiez-le exactement (majuscules et minuscules comptent).",
        "learn": "Vos appareils Tuya sont reliés au « cloud » Tuya. L'intégration officielle de Home Assistant "
        "s'y connecte avec votre compte : le code utilisateur dit de quel compte il s'agit, sans mot de passe.",
        "by": "you",
    },
    {
        "id": "scan",
        "title": "Scanner le QR code",
        "what": "Dans Smart Life : le bouton « + » ou le scanner en haut à droite, puis visez le QR code. "
        "Validez la connexion dans l'application, puis appuyez sur « C'est fait ».",
        "learn": "Le QR code contient une clé à usage unique : en le scannant, vous autorisez Home Assistant à lire "
        "vos appareils. Vous pouvez retirer cette autorisation depuis Smart Life à tout moment.",
        "by": "you",
    },
    {
        "id": "done",
        "title": "Vos appareils arrivent",
        "what": "Vos appareils Smart Life apparaissent dans Mes appareils : rangez-les dans vos pièces.",
        "learn": "Les appareils Tuya passent par Internet : s'il est coupé, ils ne répondent plus. Pour des "
        "capteurs qui marchent sans Internet, préférez le Zigbee.",
        "by": "box",
    },
)

MSG = {
    "no_cameras": "Aucune caméra avec un flux vidéo (RTSP) n'a été trouvée dans Home Assistant. Ajoutez d'abord "
    "vos caméras (par exemple avec l'intégration ONVIF), puis revenez ici.",
    "not_haos": "Frigate s'installe seulement sur Home Assistant OS (la box Maison Facile).",
    "mqtt_failed": "Home Assistant n'a pas pu se relier à Mosquitto. Réessayez dans une minute.",
    "frigate_unreachable": "Frigate ne répond pas encore. Il démarre parfois lentement : réessayez dans une minute.",
    "frigate_rejected": "Frigate a refusé les réglages : {detail}",
    "integration_failed": "Le module Frigate n'a pas pu se relier à Frigate. Vérifiez que la box a bien redémarré.",
    "module_missing": "Le module Frigate n'est pas encore chargé : installez-le puis redémarrez la box.",
    "busy": "Une étape est déjà en cours. Patientez un instant.",
    "tuya_code": "Ce code n'a pas été accepté par Tuya. Vérifiez-le (majuscules et minuscules comptent) et réessayez.",
    "tuya_scan": "La connexion n'est pas encore validée. Scannez le nouveau QR code, validez dans Smart Life, puis réessayez.",
    "tuya_done": "C'est fait : vos appareils Smart Life arrivent dans Mes appareils.",
    "tuya_already": "Vos appareils Smart Life sont déjà reliés.",
}


def camera_name(friendly: str, taken: Iterable[str] = ()) -> str:
    """Nom de caméra pour Frigate : minuscules, chiffres et _ (« Entrée » -> « entree »)."""
    text = unicodedata.normalize("NFKD", friendly or "").encode("ascii", "ignore").decode().lower()
    name = re.sub(r"[^a-z0-9]+", "_", text).strip("_") or "camera"
    if name[0].isdigit():
        name = f"camera_{name}"
    used = set(taken)
    base, n = name, 2
    while name in used:
        name = f"{base}_{n}"
        n += 1
    return name


def is_stream(url: Any) -> bool:
    return isinstance(url, str) and url.lower().startswith(("rtsp://", "rtsps://", "rtmp://", "http://", "https://"))


def new_password() -> str:
    return secrets.token_urlsafe(18)


def _q(value: str) -> str:
    """Valeur YAML entre guillemets (adresse, mot de passe)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def frigate_config(cameras: list[Mapping[str, str]], mqtt_password: str) -> str:
    """Fichier de réglages de Frigate, commenté pour « J'apprends ».

    ``cameras`` = ``[{"name": "entree", "title": "Entrée", "url": "rtsp://…"}]``.
    """
    lines = [
        "# Réglages de Frigate écrits par Maison Facile (recette « Caméras intelligentes »).",
        "# Chaque ligne « clé: valeur » est un réglage ; le décalage indique à quoi il appartient.",
        "",
        "# La messagerie MQTT : Frigate y publie ses détections, Home Assistant les lit.",
        "mqtt:",
        "  enabled: true",
        f"  host: {MQTT_HOST}            # Mosquitto, dans la box",
        f"  user: {MQTT_USER}",
        f"  password: {_q(mqtt_password)}  # créé par Maison Facile, propre à Frigate",
        "",
        "# Photos des détections, gardées 7 jours. L'enregistrement vidéo continu est coupé :",
        "# il remplit vite le disque (à activer plus tard si vous le voulez).",
        "snapshots:",
        "  enabled: true",
        "  retain:",
        "    default: 7",
        "record:",
        "  enabled: false",
        "",
        "# Ce que Frigate cherche dans les images (pas de reconnaissance des visages).",
        "objects:",
        "  track:",
        *[f"    - {o}" for o in TRACKED],
        "",
        "# Vos caméras : l'adresse de leur flux vidéo, et le rôle « detect » (analyser les images).",
        "cameras:",
    ]
    for cam in cameras:
        lines += [
            f"  {cam['name']}:                    # {cam.get('title') or cam['name']}",
            "    ffmpeg:",
            "      inputs:",
            f"        - path: {_q(cam['url'])}",
            "          roles:",
            "            - detect",
            "    detect:",
            "      enabled: true",
        ]
    return "\n".join(lines) + "\n"


def mosquitto_logins(options: Mapping[str, Any], password: str) -> tuple[dict[str, Any], bool]:
    """Options de Mosquitto avec le compte de Frigate (ajouté ou mis à jour). (options, changé ?)"""
    opts = dict(options or {})
    logins = [dict(x) for x in (opts.get("logins") or []) if isinstance(x, Mapping)]
    for login in logins:
        if login.get("username") == MQTT_USER:
            if login.get("password") == password:
                return opts, False
            login["password"] = password
            break
    else:
        logins.append({"username": MQTT_USER, "password": password})
    opts["logins"] = logins
    return opts, True


def steps_payload(steps: tuple[dict[str, str], ...], done: Mapping[str, bool], running: str | None, errors: Mapping[str, str]) -> list[dict[str, Any]]:
    """Étapes d'une recette pour la page : état de chacune, la prochaine à faire."""
    out: list[dict[str, Any]] = []
    next_found = False
    for step in steps:
        state = "done" if done.get(step["id"]) else "running" if running == step["id"] else "todo"
        is_next = state == "todo" and not next_found
        if is_next:
            next_found = True
        out.append({**step, "state": state, "next": is_next, "error": errors.get(step["id"])})
    return out
