"""Websocket commands of the Maison Facile engine (CONTRACT §5)."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback

from . import audience, rules
from .const import DOMAIN, VERSION, MaisonFacileData
from .energy import async_energy_summary
from .onboarding import (
    async_assign_device,
    async_set_rooms,
    async_status,
    list_devices,
    person_entities,
)

_LOGGER = logging.getLogger(__name__)

ERR_NOT_READY = "not_ready"
ERR_NOT_FOUND = "not_found"
ERR_INVALID = "invalid_format"
ERR_FAILED = "failed"
ERR_LOCKED = "locked"

MSG_NOT_READY = "Maison Facile n'est pas encore prête. Réessayez dans quelques secondes."
MSG_FAILED = "Une erreur est survenue. Réessayez, ou utilisez la page Dépannage."
MSG_LOCKED = "Ouvrez d'abord les réglages avancés (mode installateur)."

# Settings keys that change the inputs of existing automations.
_SETTINGS_AFFECTING_AUTOMATIONS = {"night_mode", "night_time", "morning_time", "notify_service"}
# Settings used by the inputs of the ideas' automations (ideas.py).
_SETTINGS_AFFECTING_IDEAS = {"notify_service", "announce_media_player"}


# --------------------------------------------------------------------------- helpers


def _runtime(hass: HomeAssistant) -> MaisonFacileData | None:
    for entry in hass.config_entries.async_entries(DOMAIN):
        data = getattr(entry, "runtime_data", None)
        if isinstance(data, MaisonFacileData) and data.store is not None:
            return data
    return None


def _require_runtime(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> MaisonFacileData | None:
    data = _runtime(hass)
    if data is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
    return data


def _recommendation_items(hass: HomeAssistant, data: MaisonFacileData) -> list[dict[str, Any]]:
    store = data.store
    assert store is not None
    return rules.build_recommendations(
        list_devices(hass, store), person_entities(hass), store.settings, store.recommendations
    )


async def async_apply_recommendations(
    hass: HomeAssistant,
    data: MaisonFacileData,
    changes: list[dict[str, Any]] | None,
    resync_all: bool = False,
) -> list[dict[str, Any]]:
    """Persist choices and (re)create the automations in ONE write + reload.

    ``changes`` = ``[{id, enabled, options}]``. With ``None`` (or ``resync_all``),
    every recommendation already chosen by the user is re-synced as well.
    """
    store = data.store
    assert store is not None and data.automations is not None
    stored: dict[str, Any] = {k: dict(v) for k, v in store.recommendations.items()}
    settings = store.settings
    touched: list[str] = []

    if changes is None or resync_all:
        touched = [rid for rid in stored if rid in rules.BLUEPRINT_FILES]
    if changes is not None:
        for change in changes:
            rec_id = change["id"]
            entry = stored.get(rec_id, {})
            entry["enabled"] = bool(change["enabled"])
            options = rules.resolve_options(rec_id, settings, change.get("options") or entry.get("options"))
            entry["options"] = options
            entry.setdefault("automation_ids", [])
            stored[rec_id] = entry
            if rec_id not in touched:
                touched.append(rec_id)
            if rec_id == "mode_nuit_heure" and "night_time" in options and entry["enabled"]:
                await store.async_update_settings({"night_time": options["night_time"]})
                settings = store.settings

    if touched:
        devices = list_devices(hass, store)
        persons = person_entities(hass)
        plan: dict[str, list[dict[str, Any]]] = {}
        previous: dict[str, list[str]] = {}
        for rec_id in touched:
            entry = stored[rec_id]
            previous[rec_id] = list(entry.get("automation_ids", []))
            plan[rec_id] = (
                rules.build_instances(rec_id, devices, persons, settings, entry.get("options"))
                if entry.get("enabled")
                else []
            )
        created = await data.automations.async_sync(plan, previous)
        for rec_id, ids in created.items():
            stored[rec_id]["automation_ids"] = ids
        await store.async_set("recommendations", stored)
        _LOGGER.info(
            "Recommendations synced: %s",
            {rid: len(ids) for rid, ids in created.items()},
        )
    return _recommendation_items(hass, data)


async def async_settings_changed(
    hass: HomeAssistant, data: MaisonFacileData, old: dict[str, Any], changes: dict[str, Any]
) -> None:
    """Refresh the automations after a settings change (settings/set and options flow)."""
    store = data.store
    assert store is not None
    settings = store.settings
    if data.ideas is not None and any(
        old.get(k) != settings.get(k) for k in _SETTINGS_AFFECTING_IDEAS & set(changes)
    ):
        try:
            await data.ideas.async_refresh()
        except Exception:  # noqa: BLE001 - settings are saved anyway
            _LOGGER.exception("Could not refresh the ideas after a settings change")
    changed = {
        k for k in _SETTINGS_AFFECTING_AUTOMATIONS & set(changes) if old.get(k) != settings.get(k)
    }
    if not changed or data.automations is None:
        return
    night_change: list[dict[str, Any]] | None = None
    if changed & {"night_mode", "night_time"}:
        # The night-mode choice drives the mode_nuit_heure automation.
        saved = store.recommendations.get("mode_nuit_heure", {})
        if "night_mode" in changed:
            enabled = settings.get("night_mode") == "hour"
        else:
            enabled = bool(saved.get("enabled", settings.get("night_mode") == "hour"))
        night_change = [
            {
                "id": "mode_nuit_heure",
                "enabled": enabled,
                "options": {**saved.get("options", {}), "night_time": settings.get("night_time")},
            }
        ]
    # A single write of automations.yaml and a single reload.
    await async_apply_recommendations(hass, data, night_change, resync_all=True)


# --------------------------------------------------------------------------- commands


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/state/get"})
@websocket_api.async_response
async def ws_state_get(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    store = data.store
    assert store is not None
    devices = list_devices(hass, store)
    status = await async_status(hass, devices)
    settings = store.settings
    connection.send_result(
        msg["id"],
        {
            "version": VERSION,
            "onboarded": bool(store.data.get("onboarded")),
            "settings": settings,
            "rooms": store.rooms,
            "devices": devices,
            "status": status,
            # Who installed the box (texts) and « sans matériel » path (installer v1.4).
            "audience": audience.summary(settings),
            "discovery": audience.discovery_mode(
                settings.get("equipment"),
                bool(status.get("radio_found")),
                settings.get("radio_expected"),
                int(status.get("device_count") or 0),
            ),
            "heating_pauses": data.heating.summary() if data.heating is not None else {},
            "provision": (
                data.provision.summary()
                if data.provision is not None
                else {"active": False, "done": False}
            ),
            "advanced": (
                data.commercial.summary(connection.user)
                if data.commercial is not None
                else {"commercial_mode": False, "unlocked": False}
            ),
            **_ideas_summary(data, devices, admin=bool(connection.user and connection.user.is_admin)),
            "appearance": _appearance(store.settings),
            "cloud": _cloud(hass),
        },
    )


def _cloud(hass: HomeAssistant) -> list[dict[str, Any]]:
    """Cloud integrations (Tuya / Smart Life…): warning of the add-device page (ws_guide.py)."""
    try:
        from .ws_guide import cloud_integrations  # noqa: PLC0415

        return cloud_integrations(hass)
    except Exception:  # noqa: BLE001 - the home page must load anyway
        _LOGGER.exception("Could not list the cloud integrations")
        return []


def _appearance(settings: dict[str, Any]) -> dict[str, Any]:
    """Effective theme of the day (ws_appearance.py / theme_rules.py)."""
    from .ws_appearance import appearance_for  # noqa: PLC0415

    return appearance_for(settings)


def _ideas_summary(data: MaisonFacileData, devices: list[dict[str, Any]], admin: bool = True) -> dict[str, Any]:
    if data.ideas is None:
        return {"idea_tiles": [], "ideas_unseen": 0}
    try:
        summary = data.ideas.summary(devices)
        if not admin:
            # Birthday tiles: no SMS/WhatsApp links (phone numbers) for family accounts.
            from .birthdays_rules import family_tile  # noqa: PLC0415

            summary = {**summary, "idea_tiles": [family_tile(t) for t in summary["idea_tiles"]]}
        return summary
    except Exception:  # noqa: BLE001 - the home page must load anyway
        _LOGGER.exception("Could not compute the ideas summary")
        return {"idea_tiles": [], "ideas_unseen": 0}


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/rooms/set",
        vol.Required("rooms"): [
            vol.Schema(
                {
                    vol.Required("name"): vol.All(str, vol.Strip, vol.Length(min=1, max=50)),
                    vol.Optional("area_id"): vol.Any(None, str),
                },
                extra=vol.REMOVE_EXTRA,
            )
        ],
    }
)
@websocket_api.async_response
async def ws_rooms_set(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    assert data.store is not None
    try:
        rooms = await async_set_rooms(hass, data.store, msg["rooms"])
    except Exception:  # noqa: BLE001
        _LOGGER.exception("rooms/set failed")
        connection.send_error(msg["id"], ERR_FAILED, "Impossible d'enregistrer les pièces. Réessayez.")
        return
    connection.send_result(msg["id"], {"rooms": rooms})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/devices/assign",
        vol.Required("device_id"): str,
        vol.Required("area_id"): vol.Any(None, str),
    }
)
@websocket_api.async_response
async def ws_devices_assign(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    assert data.store is not None
    try:
        device = await async_assign_device(hass, data.store, msg["device_id"], msg["area_id"] or None)
    except ValueError as err:
        connection.send_error(msg["id"], ERR_NOT_FOUND, str(err))
        return
    # Rooms drive some automations (night light of the same room, heating of the room).
    if data.store.data.get("onboarded"):
        try:
            await async_apply_recommendations(hass, data, None)
        except Exception:  # noqa: BLE001 - the assignment itself succeeded
            _LOGGER.exception("Could not refresh automations after device assignment")
    connection.send_result(msg["id"], {"device": device})


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/recommendations/list"})
@websocket_api.async_response
async def ws_recommendations_list(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    connection.send_result(msg["id"], {"items": _recommendation_items(hass, data)})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/recommendations/apply",
        vol.Required("items"): [
            vol.Schema(
                {
                    vol.Required("id"): vol.In(list(rules.BLUEPRINT_FILES)),
                    vol.Required("enabled"): bool,
                    vol.Optional("options", default=dict): dict,
                },
                extra=vol.REMOVE_EXTRA,
            )
        ],
    }
)
@websocket_api.async_response
async def ws_recommendations_apply(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    from .automations import ProtectedFileError  # noqa: PLC0415

    try:
        if data.automations is not None:
            await data.automations.async_check_writable()
        items = await async_apply_recommendations(hass, data, msg["items"])
    except ProtectedFileError as err:
        connection.send_error(msg["id"], ERR_INVALID, err.message_fr)
        return
    except Exception:  # noqa: BLE001
        _LOGGER.exception("recommendations/apply failed")
        connection.send_error(
            msg["id"],
            ERR_FAILED,
            "Impossible de créer les automatismes. Vérifiez la page Dépannage puis réessayez.",
        )
        return
    connection.send_result(msg["id"], {"items": items})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/settings/set", vol.Required("settings"): dict}
)
@websocket_api.async_response
async def ws_settings_set(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    assert data.store is not None
    if "installer_pin" in msg["settings"]:
        connection.send_error(
            msg["id"], ERR_INVALID,
            audience.for_settings("Le code installateur se change dans « Réglages avancés ».", data.store.settings),
        )
        return
    changes, errors = rules.validate_settings(msg["settings"])
    if errors:
        connection.send_error(msg["id"], ERR_INVALID, rules.settings_error_message(errors))
        return
    old = dict(data.store.settings)
    commercial_change = "commercial_mode" in changes and changes["commercial_mode"] != old.get(
        "commercial_mode", True
    )
    expert_change = "expert_mode" in changes and changes["expert_mode"] != (old.get("expert_mode") is True)
    # Mode Expert ON = plus rien de caché : comme couper le mode commercial (mode installateur).
    if (
        expert_change
        and changes["expert_mode"] is True
        and (data.commercial is None or not data.commercial.can_manage(connection.user))
    ):
        connection.send_error(msg["id"], ERR_LOCKED, audience.for_settings(MSG_LOCKED, data.store.settings))
        return
    # Turning commercial mode ON is always safe; turning it OFF needs installer mode.
    if (
        commercial_change
        and changes["commercial_mode"] is False
        and (data.commercial is None or not data.commercial.can_manage(connection.user))
    ):
        connection.send_error(msg["id"], ERR_LOCKED, audience.for_settings(MSG_LOCKED, data.store.settings))
        return
    # « Où l'acheter ? » is an installer setting (Réglages avancés): installer mode needed.
    if (
        "shop_url" in changes
        and changes["shop_url"] != old.get("shop_url", "")
        and (data.commercial is None or not data.commercial.can_manage(connection.user))
    ):
        connection.send_error(msg["id"], ERR_LOCKED, audience.for_settings(MSG_LOCKED, data.store.settings))
        return
    settings = await data.store.async_update_settings(changes)
    if (commercial_change or expert_change) and data.commercial is not None:
        await data.commercial.async_apply()
    try:
        await async_settings_changed(hass, data, old, changes)
    except Exception:  # noqa: BLE001 - settings are saved anyway
        _LOGGER.exception("Could not refresh automations after settings change")
    from .ws_appearance import async_notify_changed  # noqa: PLC0415

    async_notify_changed(hass, changes)
    connection.send_result(msg["id"], {"settings": settings, "appearance": _appearance(settings)})


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/onboarding/complete"})
@websocket_api.async_response
async def ws_onboarding_complete(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    assert data.store is not None
    await data.store.async_set("onboarded", True)
    connection.send_result(msg["id"], {"onboarded": True})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/pairing/start", vol.Optional("device_type"): vol.Any(None, str)}
)
@websocket_api.async_response
async def ws_pairing_start(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    try:
        result = await data.pairing.async_start(msg.get("device_type"))
    except Exception:  # noqa: BLE001
        _LOGGER.exception("pairing/start failed")
        connection.send_error(
            msg["id"],
            ERR_FAILED,
            "L'antenne sans fil ne répond pas. Vérifiez qu'elle est bien branchée puis réessayez.",
        )
        return
    connection.send_result(msg["id"], result)


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/pairing/stop"})
@websocket_api.async_response
async def ws_pairing_stop(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    try:
        await data.pairing.async_stop()
    except Exception:  # noqa: BLE001
        _LOGGER.exception("pairing/stop failed")
        connection.send_error(msg["id"], ERR_FAILED, "Impossible d'arrêter la recherche. Réessayez.")
        return
    connection.send_result(msg["id"], {"ok": True})


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/pairing/subscribe"})
@websocket_api.async_response
async def ws_pairing_subscribe(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    msg_id = msg["id"]

    @callback
    def _forward(message: dict[str, Any]) -> None:
        connection.send_message(websocket_api.event_message(msg_id, message))

    connection.subscriptions[msg_id] = data.pairing.async_subscribe(_forward)
    connection.send_result(msg_id)


@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/energy/summary",
        vol.Optional("period", default="day"): vol.In(["day", "week", "month"]),
    }
)
@websocket_api.async_response
async def ws_energy_summary(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    assert data.store is not None
    try:
        summary = await async_energy_summary(hass, data.store, msg["period"])
    except Exception:  # noqa: BLE001
        _LOGGER.exception("energy/summary failed")
        connection.send_error(msg["id"], ERR_FAILED, "Impossible de lire la consommation pour le moment.")
        return
    connection.send_result(msg["id"], summary)


@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/heating/pause", vol.Required("window_entity_id"): str}
)
@websocket_api.async_response
async def ws_heating_pause(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    if data.heating is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    try:
        result = await data.heating.async_pause(msg["window_entity_id"])
    except Exception:  # noqa: BLE001
        _LOGGER.exception("heating/pause failed")
        connection.send_error(
            msg["id"], ERR_FAILED, "Impossible de mettre le chauffage en pause. Réessayez."
        )
        return
    connection.send_result(msg["id"], result)


COMMANDS = (
    ws_state_get,
    ws_rooms_set,
    ws_devices_assign,
    ws_recommendations_list,
    ws_recommendations_apply,
    ws_settings_set,
    ws_onboarding_complete,
    ws_pairing_start,
    ws_pairing_stop,
    ws_pairing_subscribe,
    ws_energy_summary,
    ws_heating_pause,
)


@callback
def async_register(hass: HomeAssistant) -> None:
    """Register the engine commands (once per HA run)."""
    flag = f"{DOMAIN}_ws_registered"
    if hass.data.get(flag):
        return
    hass.data[flag] = True
    for command in COMMANDS:
        websocket_api.async_register_command(hass, command)
    websocket_api.async_register_command(hass, ws_expert_status)

    _register_maintenance(hass)
    _register_provision(hass)
    _register_advanced(hass)
    _register_ideas(hass)
    _register_appearance(hass)
    _register_birthdays(hass)
    _register_guide(hass)


def _register_guide(hass: HomeAssistant) -> None:
    try:
        from . import ws_guide  # noqa: PLC0415

        ws_guide.async_register(hass)
    except Exception:  # noqa: BLE001 - the guide must never break the engine
        _LOGGER.exception("Could not register guide websocket commands")


def _register_birthdays(hass: HomeAssistant) -> None:
    try:
        from . import ws_birthdays  # noqa: PLC0415

        ws_birthdays.async_register(hass)
    except Exception:  # noqa: BLE001 - birthdays must never break the engine
        _LOGGER.exception("Could not register birthdays websocket commands")


def _register_appearance(hass: HomeAssistant) -> None:
    try:
        from . import ws_appearance  # noqa: PLC0415

        ws_appearance.async_register(hass)
    except Exception:  # noqa: BLE001 - themes must never break the engine
        _LOGGER.exception("Could not register appearance websocket commands")


def _register_ideas(hass: HomeAssistant) -> None:
    try:
        from . import ws_ideas  # noqa: PLC0415

        ws_ideas.async_register(hass)
    except Exception:  # noqa: BLE001 - ideas must never break the engine
        _LOGGER.exception("Could not register ideas websocket commands")


def _register_advanced(hass: HomeAssistant) -> None:
    try:
        from . import ws_advanced  # noqa: PLC0415

        ws_advanced.async_register(hass)
    except Exception:  # noqa: BLE001 - commercial mode must never break the engine
        _LOGGER.exception("Could not register advanced settings websocket commands")


def _register_provision(hass: HomeAssistant) -> None:
    try:
        from . import ws_provision  # noqa: PLC0415

        ws_provision.async_register(hass)
    except Exception:  # noqa: BLE001 - provisioning must never break the engine
        _LOGGER.exception("Could not register provisioning websocket commands")


def _register_maintenance(hass: HomeAssistant) -> None:
    try:
        from . import ws_maintenance  # noqa: PLC0415

        ws_maintenance.async_register(hass)
    except Exception:  # noqa: BLE001 - maintenance must never break the engine
        _LOGGER.exception("Could not register maintenance websocket commands")


__all__ = ["async_apply_recommendations", "async_register", "async_settings_changed"]


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/expert/status"})
@websocket_api.async_response
async def ws_expert_status(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    """Mode Expert : où vont les automatismes de Maison Facile (Réglages avancés)."""
    if (data := _require_runtime(hass, connection, msg)) is None:
        return
    assert data.store is not None
    info: dict[str, Any] = {"file": "automations.yaml", "separate": False, "blocked": False, "include_line": ""}
    if data.automations is not None:
        info = await data.automations.async_target_info()
    connection.send_result(msg["id"], {"expert_mode": data.store.settings.get("expert_mode") is True, **info})
