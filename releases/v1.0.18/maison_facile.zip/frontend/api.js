// Thin wrapper around the Home Assistant websocket connection (contract §5).

const PREFIX = "maison_facile/";

export class Api {
  constructor(getHass) {
    this._getHass = getHass;
    this._state = null;
    this._statePromise = null;
    this._listeners = new Set();
  }

  get hass() {
    return this._getHass();
  }

  /** Raw websocket call (`type` without the maison_facile/ prefix). */
  async ws(type, data = {}) {
    const hass = this.hass;
    if (!hass) throw new Error("hass not ready");
    return hass.callWS({ type: PREFIX + type, ...data });
  }

  /** Subscribe to a maison_facile subscription; returns an unsubscribe function (async). */
  async subscribe(type, callback, data = {}) {
    const hass = this.hass;
    if (!hass?.connection) throw new Error("no connection");
    return hass.connection.subscribeMessage(callback, { type: PREFIX + type, ...data });
  }

  // ----- cached state/get ----------------------------------------------------

  get state() {
    return this._state;
  }

  onState(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  _emit() {
    for (const fn of this._listeners) {
      try {
        fn(this._state);
      } catch (e) {
        console.error(e);
      }
    }
  }

  async loadState(force = false) {
    if (this._state && !force) return this._state;
    if (this._statePromise) return this._statePromise;
    this._statePromise = this.ws("state/get")
      .then((s) => {
        const prev = this._state?.advanced;
        this._state = normalizeState(s);
        // state/get only says unlocked or not: keep the details from advanced/status.
        if (prev) {
          const adv = this._state.advanced;
          if (adv.unlocked && !adv.until) adv.until = prev.until || null;
          if (!("pin_set" in adv) && "pin_set" in prev) adv.pin_set = prev.pin_set;
        }
        this._emit();
        return this._state;
      })
      .finally(() => {
        this._statePromise = null;
      });
    return this._statePromise;
  }

  /** Merge a partial result into the cached state (after a successful write). */
  patchState(patch) {
    if (!this._state) return;
    this._state = normalizeState({ ...this._state, ...patch });
    this._emit();
  }

  replaceDevice(device) {
    if (!this._state || !device) return;
    const devices = this._state.devices.slice();
    const i = devices.findIndex((d) => d.device_id === device.device_id);
    if (i >= 0) devices[i] = device;
    else devices.push(device);
    this.patchState({ devices });
  }

  // ----- moteur ---------------------------------------------------------------

  async setRooms(rooms) {
    const r = await this.ws("rooms/set", { rooms });
    this.patchState({ rooms: r.rooms || [] });
    return r.rooms || [];
  }

  async assignDevice(device_id, area_id) {
    const r = await this.ws("devices/assign", { device_id, area_id });
    if (r?.device) this.replaceDevice(r.device);
    return r?.device;
  }

  async listRecommendations() {
    const r = await this.ws("recommendations/list");
    return r?.items || [];
  }

  async applyRecommendations(items) {
    const r = await this.ws("recommendations/apply", { items });
    return r?.items || [];
  }

  async setSettings(settings) {
    const r = await this.ws("settings/set", { settings });
    if (r?.settings) this.patchState({ settings: { ...(this._state?.settings || {}), ...r.settings }, ...(r.appearance ? { appearance: r.appearance } : {}) });
    return r?.settings;
  }

  async completeOnboarding() {
    const r = await this.ws("onboarding/complete");
    this.patchState({ onboarded: r?.onboarded !== false });
    return r;
  }

  startPairing(device_type) {
    return this.ws("pairing/start", device_type ? { device_type } : {});
  }

  stopPairing() {
    return this.ws("pairing/stop");
  }

  /** Pause the heating of the window's room until it is closed again. */
  async pauseHeating(window_entity_id) {
    const r = await this.ws("heating/pause", { window_entity_id });
    if (r?.ok !== false) {
      const pauses = { ...(this._state?.heating_pauses || {}), [window_entity_id]: r?.paused || [] };
      this.patchState({ heating_pauses: pauses });
    }
    return r;
  }

  /** Local cleanup once the window is closed (the backend resumes heating itself). */
  forgetHeatingPause(window_entity_id) {
    const pauses = { ...(this._state?.heating_pauses || {}) };
    if (!(window_entity_id in pauses)) return;
    delete pauses[window_entity_id];
    this.patchState({ heating_pauses: pauses });
  }

  energySummary(period) {
    return this.ws("energy/summary", { period });
  }

  // ----- idées (CONTRACT §11) ------------------------------------------------------

  listIdeas() {
    return this.ws("ideas/list");
  }
  getIdea(idea_id) {
    return this.ws("ideas/get", { idea_id });
  }
  activateIdea(idea_id, options = {}) {
    return this.ws("ideas/activate", { idea_id, options });
  }
  /** Mode Expert : ce que l'activation va créer (rien n'est changé). */
  previewIdea(idea_id, options = {}) {
    return this.ws("ideas/preview", { idea_id, options });
  }
  expertStatus() {
    return this.ws("expert/status");
  }
  deactivateIdea(idea_id) {
    return this.ws("ideas/deactivate", { idea_id });
  }
  /** Save settings / device choices of an idea ({options?, devices?}). */
  configureIdea(idea_id, patch) {
    return this.ws("ideas/configure", { idea_id, ...patch });
  }
  /** The client goes to « Ajouter le capteur »: the next fitting device goes to this idea. */
  expectIdea(idea_id) {
    return this.ws("ideas/expect", { idea_id });
  }
  markIdeasSeen(idea_ids) {
    return this.ws("ideas/mark_seen", idea_ids ? { idea_ids } : {});
  }
  addDetected(target) {
    return this.ws("ideas/add_detected", target);
  }
  testAnnounce(entity_id) {
    return this.ws("ideas/test_announce", entity_id ? { entity_id } : {});
  }

  // ----- entretien ------------------------------------------------------------

  updatesStatus() {
    return this.ws("updates/status");
  }
  installUpdate(target) {
    return this.ws("updates/install", { target });
  }
  checkUpdates() {
    return this.ws("updates/check");
  }
  doctorList() {
    return this.ws("doctor/list");
  }
  doctorRescan() {
    return this.ws("doctor/rescan");
  }
  /** The contract says {id, choice?} but `id` is the websocket message id: the backend reads `problem_id`. */
  doctorFix(id, choice) {
    const data = { problem_id: id };
    if (choice !== undefined && choice !== null) data.choice = choice;
    return this.ws("doctor/fix", data);
  }
  doctorReport() {
    return this.ws("doctor/report");
  }

  // ----- provisionnement (CONTRACT_KIT §4) -------------------------------------

  provisionStatus() {
    return this.ws("provision/status");
  }
  retryProvision(step_id) {
    return this.ws("provision/retry", { step_id });
  }

  // ----- réglages avancés (mode commercial, NOTES_commercial.md) ---------------

  /** `fromGuard`: the change comes from mf-guard.js (its "Verrouiller" button). */
  _patchAdvanced(status, fromGuard = false) {
    if (!status || typeof status !== "object") return status;
    const keep = ["commercial_mode", "unlocked", "until", "pin_set"];
    const adv = { ...(this._state?.advanced || {}) };
    for (const k of keep) if (k in status) adv[k] = status[k];
    this.patchState({ advanced: adv });
    if (!fromGuard) {
      // Tell the guard of every HA page at once (unlock, lock, commercial mode on/off).
      try {
        window.dispatchEvent(new CustomEvent("maison-facile-advanced", { detail: { source: "panel", status: adv } }));
      } catch (e) {
        /* no guard: nothing to tell */
      }
    }
    return status;
  }
  /** « Bien choisir ses appareils » : {items, shop_url, cloud} (buying_guide.yaml). */
  getGuide() {
    return this.ws("guide/get");
  }
  async advancedStatus() {
    return this._patchAdvanced(await this.ws("advanced/status"));
  }
  async unlockAdvanced(pin) {
    const r = await this.ws("advanced/unlock", pin ? { pin } : {});
    this._patchAdvanced({ unlocked: true, until: r?.until || null });
    return r;
  }
  async lockAdvanced() {
    return this._patchAdvanced(await this.ws("advanced/lock"));
  }
  async setInstallerPin(pin) {
    return this._patchAdvanced(await this.ws("advanced/set_pin", { pin }));
  }
  async setCommercialMode(enabled) {
    await this.setSettings({ commercial_mode: !!enabled });
    this._patchAdvanced({ commercial_mode: !!enabled });
  }
}

const FRIENDLY_CODES = new Set(["not_ready", "not_found", "invalid_format", "failed", "install_failed", "fix_failed", "locked", "invalid_pin", "too_many_attempts"]);
const FIXED_MESSAGES = { unauthorized: "Seul le compte principal de la maison peut faire ce réglage." };

/** French message sent by the backend for Maison Facile errors, or null (never technical text). */
export function friendlyError(err) {
  if (err && typeof err === "object" && FIXED_MESSAGES[err.code]) return FIXED_MESSAGES[err.code];
  if (err && typeof err === "object" && FRIENDLY_CODES.has(err.code) && typeof err.message === "string" && err.message) {
    return err.message;
  }
  return null;
}

function normalizeState(s) {
  const st = s || {};
  return {
    version: st.version || "",
    onboarded: !!st.onboarded,
    settings: { theme: "clair", theme_auto: "fetes_saisons", animations: true, home_style: "maison_facile", liked_styles: [], update_mode: "auto", night_mode: "hour", night_time: "23:00", morning_time: "07:00", ...(st.settings || {}) },
    rooms: Array.isArray(st.rooms) ? st.rooms : [],
    devices: Array.isArray(st.devices) ? st.devices : [],
    heating_pauses: st.heating_pauses && typeof st.heating_pauses === "object" ? st.heating_pauses : {},
    provision: { active: false, done: false, ...(st.provision && typeof st.provision === "object" ? st.provision : {}) },
    status: { network_ok: false, radio_found: false, radio_kind: null, device_count: 0, ...(st.status || {}) },
    idea_tiles: Array.isArray(st.idea_tiles) ? st.idea_tiles : [],
    ideas_unseen: Number.isFinite(st.ideas_unseen) ? st.ideas_unseen : 0,
    // Effective theme of the day computed by the box (theme_rules.py); null on older backends.
    appearance: st.appearance && typeof st.appearance === "object" ? st.appearance : null,
    // Older backends without commercial mode: nothing is hidden.
    advanced: { commercial_mode: false, unlocked: false, until: null, ...(st.advanced && typeof st.advanced === "object" ? st.advanced : {}) },
    // Cloud integrations in use (Tuya / Smart Life…): warning of « Ajouter un appareil ».
    cloud: Array.isArray(st.cloud) ? st.cloud : [],
    // Who installed the box (texts, components/audience.js); null on older backends.
    audience: st.audience && typeof st.audience === "object" ? st.audience : null,
    // Box installed without hardware (installer v1.4): « Votre maison sans matériel ».
    discovery: st.discovery === true,
  };
}
