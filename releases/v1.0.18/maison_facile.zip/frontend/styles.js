// Themes (clair / sombre / contraste) as CSS custom properties + all component styles.

export const PALETTE = ["#E8590C", "#0E7A0D", "#6B47B8", "#0067C0", "#00838F", "#C2185B", "#5D6B7A", "#B8860B"];

const THEMES = `
:host, .app {
  --mf-blue: #0067C0; --mf-green: #0E7A0D; --mf-violet: #6B47B8; --mf-orange: #E8590C;
  --mf-gold: #FFB900; --mf-gold-text: #3A2A00; --mf-teal: #00838F; --mf-red: #C42B1C;
  --mf-warn-orange: #F7630C;
}
.app[data-tone="light"] {
  --bloom-ideas: radial-gradient(circle at 12% 18%, #FFE3B8 0%, rgba(255,227,184,0) 40%), radial-gradient(circle at 88% 12%, #D9C9F5 0%, rgba(217,201,245,0) 40%), radial-gradient(circle at 75% 95%, #C6ECE6 0%, rgba(198,236,230,0) 45%), radial-gradient(circle at 20% 90%, #B9D4F5 0%, rgba(185,212,245,0) 40%), #EEF0F5;
  --st-pret-bg: #E1ECF9; --st-pret-text: #00478A; --st-manque-bg: #FFF0E2; --st-manque-text: #8A3B00;
  --st-actif-bg: #DFF3DF; --st-actif-text: #0E5A0D; --st-attente-bg: #EFE9FA; --st-attente-text: #4B2A93;
  --st-later-bg: #E4E8EF; --st-later-text: #3A3F47; --need-miss-bg: #FFF6EC; --need-miss-border: #F7A36B;
  --bloom: radial-gradient(circle at 12% 18%, #B9D4F5 0%, rgba(185,212,245,0) 42%), radial-gradient(circle at 88% 12%, #D9C9F5 0%, rgba(217,201,245,0) 40%), radial-gradient(circle at 75% 95%, #F8D3E1 0%, rgba(248,211,225,0) 45%), radial-gradient(circle at 20% 90%, #C6ECE6 0%, rgba(198,236,230,0) 40%), #E8EEF7;
  --bloom-energy: radial-gradient(circle at 12% 18%, #FCE3B0 0%, rgba(252,227,176,0) 40%), radial-gradient(circle at 88% 12%, #D9C9F5 0%, rgba(217,201,245,0) 40%), radial-gradient(circle at 75% 95%, #F8D3E1 0%, rgba(248,211,225,0) 45%), radial-gradient(circle at 20% 90%, #C6ECE6 0%, rgba(198,236,230,0) 40%), #EEF0F5;
  --bloom-security: radial-gradient(circle at 12% 18%, #C3EBC9 0%, rgba(195,235,201,0) 40%), radial-gradient(circle at 88% 12%, #B9D4F5 0%, rgba(185,212,245,0) 40%), radial-gradient(circle at 75% 95%, #D9C9F5 0%, rgba(217,201,245,0) 45%), radial-gradient(circle at 20% 90%, #C6ECE6 0%, rgba(198,236,230,0) 40%), #EBF0F5;
  --glass: rgba(255,255,255,0.72); --glass-strong: rgba(255,255,255,0.85); --glass-border: rgba(255,255,255,0.9);
  --shadow: 0 8px 24px rgba(30,50,90,0.10); --shadow-big: 0 30px 80px rgba(30,50,90,0.22);
  --surface: #FFFFFF; --surface-2: #F7F9FC; --surface-soft: rgba(255,255,255,0.55);
  --text: #16181D; --sub: #4E535B; --muted: #5A5F67; --line: rgba(22,24,29,0.08);
  --field: #C9D1DC; --field-dim: #A9B1BC;
  --accent: #0067C0; --accent-text: #FFFFFF; --link: #0067C0;
  --lit: #FFF3D1; --lit-border: #FFB900; --lit-shadow: 0 10px 28px rgba(255,185,0,0.30);
  --off-btn: #E4E8EF; --off-btn-text: #3A3F47;
  --chip-on-bg: #FFB900; --chip-on-text: #3A2A00; --chip-off-bg: #E4E8EF; --chip-off-text: #3A3F47;
  --warn: #8A3B00; --warn-bg: rgba(255,240,226,0.92); --warn-border: #F7A36B; --warn-btn-text: #FFFFFF;
  --open-bg: #FFF0E2; --open-text: #A84300; --ok-text: #0E7A0D;
  --tag-bg: #E1ECF9; --tag-text: #00478A; --info-bg: #E1ECF9; --info-text: #00376B;
  --track: #E4E8EF; --demo-bg: linear-gradient(160deg, #F3F6FB 0%, #E3EAF4 100%);
  --code-bg: #1E222A; --code-text: #DDE3EC;
  --focus: #0067C0; --sel-bg: #0067C0; --sel-text: #FFFFFF;
  --q1: #0067C0; --q1-text: #FFFFFF; --q2: #0E7A0D; --q2-text: #FFFFFF; --q3: #6B47B8; --q3-text: #FFFFFF; --particle: transparent;
  color-scheme: light;
}
.app[data-tone="dark"] {
  --bloom-ideas: radial-gradient(circle at 12% 18%, #4A3510 0%, rgba(74,53,16,0) 42%), radial-gradient(circle at 88% 12%, #3B2368 0%, rgba(59,35,104,0) 42%), radial-gradient(circle at 75% 95%, #0F3F3B 0%, rgba(15,63,59,0) 45%), radial-gradient(circle at 20% 90%, #1D3A66 0%, rgba(29,58,102,0) 40%), #12141A;
  --st-pret-bg: #17324F; --st-pret-text: #9FD2FF; --st-manque-bg: rgba(247,99,12,0.20); --st-manque-text: #FFB27A;
  --st-actif-bg: rgba(108,203,95,0.18); --st-actif-text: #8EDB83; --st-attente-bg: rgba(135,100,184,0.25); --st-attente-text: #D1BFF5;
  --st-later-bg: #3A3D47; --st-later-text: #D9DCE1; --need-miss-bg: rgba(247,99,12,0.12); --need-miss-border: #B8622A;
  --bloom: radial-gradient(circle at 12% 18%, #1D3A66 0%, rgba(29,58,102,0) 45%), radial-gradient(circle at 88% 12%, #3B2368 0%, rgba(59,35,104,0) 42%), radial-gradient(circle at 75% 95%, #4A1E3A 0%, rgba(74,30,58,0) 45%), radial-gradient(circle at 20% 90%, #0F3F3B 0%, rgba(15,63,59,0) 40%), #12141A;
  --bloom-energy: radial-gradient(circle at 12% 18%, #4A3510 0%, rgba(74,53,16,0) 42%), radial-gradient(circle at 88% 12%, #3B2368 0%, rgba(59,35,104,0) 42%), radial-gradient(circle at 75% 95%, #4A1E3A 0%, rgba(74,30,58,0) 45%), radial-gradient(circle at 20% 90%, #0F3F3B 0%, rgba(15,63,59,0) 40%), #12141A;
  --bloom-security: radial-gradient(circle at 12% 18%, #12402A 0%, rgba(18,64,42,0) 42%), radial-gradient(circle at 88% 12%, #1D3A66 0%, rgba(29,58,102,0) 42%), radial-gradient(circle at 75% 95%, #3B2368 0%, rgba(59,35,104,0) 45%), radial-gradient(circle at 20% 90%, #0F3F3B 0%, rgba(15,63,59,0) 40%), #12141A;
  --glass: rgba(36,38,46,0.72); --glass-strong: rgba(36,38,46,0.88); --glass-border: rgba(255,255,255,0.08);
  --shadow: 0 8px 24px rgba(0,0,0,0.35); --shadow-big: 0 30px 80px rgba(0,0,0,0.5);
  --surface: #2A2D36; --surface-2: #23262E; --surface-soft: rgba(42,45,54,0.6);
  --text: #F4F5F7; --sub: #B9BDC5; --muted: #A6ABB4; --line: rgba(255,255,255,0.10);
  --field: #4A4E59; --field-dim: #6A6F7A;
  --accent: #4CC2FF; --accent-text: #06202E; --link: #4CC2FF;
  --lit: rgba(255,185,0,0.16); --lit-border: #FFB900; --lit-shadow: 0 10px 28px rgba(255,185,0,0.18);
  --off-btn: #3A3D47; --off-btn-text: #E6E8EC;
  --chip-on-bg: #FFB900; --chip-on-text: #2A1E00; --chip-off-bg: #3A3D47; --chip-off-text: #D9DCE1;
  --warn: #FFB27A; --warn-bg: rgba(70,40,18,0.85); --warn-border: #B8622A; --warn-btn-text: #2A1406;
  --open-bg: rgba(247,99,12,0.18); --open-text: #FFB27A; --ok-text: #6CCB5F;
  --tag-bg: #17324F; --tag-text: #9FD2FF; --info-bg: #17324F; --info-text: #CFE6FF;
  --track: #3A3D47; --demo-bg: linear-gradient(160deg, #2A2E38 0%, #1F232B 100%);
  --code-bg: #0D0F13; --code-text: #DDE3EC;
  --focus: #4CC2FF; --sel-bg: #4CC2FF; --sel-text: #06202E;
  --q1: #0067C0; --q1-text: #FFFFFF; --q2: #0E7A0D; --q2-text: #FFFFFF; --q3: #6B47B8; --q3-text: #FFFFFF; --particle: transparent;
  color-scheme: dark;
}
.app[data-theme="contraste"] {
  --bloom: #FFFFFF; --bloom-energy: #FFFFFF; --bloom-security: #FFFFFF; --bloom-ideas: #FFFFFF;
  --st-pret-bg: #FFFFFF; --st-pret-text: #000000; --st-manque-bg: #FFE6D6; --st-manque-text: #7A2600;
  --st-actif-bg: #FFFFFF; --st-actif-text: #0A5A09; --st-attente-bg: #FFFFFF; --st-attente-text: #4B2A93;
  --st-later-bg: #FFFFFF; --st-later-text: #000000; --need-miss-bg: #FFE6D6; --need-miss-border: #000000;
  --glass: #FFFFFF; --glass-strong: #FFFFFF; --glass-border: #000000;
  --shadow: none; --shadow-big: none;
  --surface: #FFFFFF; --surface-2: #FFFFFF; --surface-soft: #FFFFFF;
  --text: #000000; --sub: #1F1F1F; --muted: #1F1F1F; --line: #000000;
  --field: #000000; --field-dim: #000000;
  --accent: #003E92; --accent-text: #FFFFFF; --link: #003E92;
  --lit: #FFE9A8; --lit-border: #000000; --lit-shadow: none;
  --off-btn: #FFFFFF; --off-btn-text: #000000;
  --chip-on-bg: #000000; --chip-on-text: #FFFFFF; --chip-off-bg: #FFFFFF; --chip-off-text: #000000;
  --warn: #7A2600; --warn-bg: #FFE6D6; --warn-border: #000000; --warn-btn-text: #FFFFFF;
  --open-bg: #FFE6D6; --open-text: #7A2600; --ok-text: #0A5A09;
  --tag-bg: #FFFFFF; --tag-text: #000000; --info-bg: #FFFFFF; --info-text: #000000;
  --track: #FFFFFF; --demo-bg: #FFFFFF;
  --code-bg: #000000; --code-text: #FFFFFF;
  --focus: #000000; --sel-bg: #003E92; --sel-text: #FFFFFF;
  --mf-blue: #003E92; --mf-green: #0A5A09; --mf-violet: #4B2A93; --mf-orange: #A63A00;
  --q1: #003E92; --q1-text: #FFFFFF; --q2: #0A5A09; --q2-text: #FFFFFF; --q3: #4B2A93; --q3-text: #FFFFFF; --particle: transparent;
  color-scheme: light;
}
`;

// The 12 themes of the validated mockup (Themes.dc.html) + « Contraste élevé ».
// Colors are the mockup's; a few were darkened so that white text stays >= 4.5:1
// (scripts/check_contrast.py). `tone` picks the clair / sombre base tokens above.
// particle: color of the small falling things ("" = none); shape: round | leaf | confetti | heart.
export const THEME_DEFS = {
  clair: { name: "Clair", tone: "light", swatch: "linear-gradient(135deg,#B9D4F5,#F8D3E1)", accent: "#0067C0", particle: "" },
  sombre: { name: "Sombre", tone: "dark", swatch: "linear-gradient(135deg,#1D3A66,#4A1E3A)", accent: "#4CC2FF", particle: "" },
  contraste: { name: "Contraste élevé", tone: "light", swatch: "linear-gradient(90deg,#000000 50%,#FFFFFF 50%)", accent: "#003E92", particle: "" },
  printemps: {
    name: "Printemps", tone: "light", swatch: "linear-gradient(135deg,#FFD6E8,#CFF3C6)",
    bloom: "radial-gradient(circle at 15% 15%, #FFD6E8 0%, rgba(255,214,232,0) 45%), radial-gradient(circle at 85% 85%, #CFF3C6 0%, rgba(207,243,198,0) 45%), #F6FBF2",
    text: "#1D2618", sub: "#46503D", tile: "rgba(255,255,255,0.82)", tileOn: "#FFE6F0", accent: "#C2185B", accentText: "#FFFFFF",
    q2: "#2E7D32", q3: "#7B5EA7", particle: "#E2729B", shape: "round",
  },
  ete: {
    name: "Été", tone: "light", swatch: "linear-gradient(135deg,#FFE29A,#9EE7F0)",
    bloom: "radial-gradient(circle at 15% 15%, #FFE29A 0%, rgba(255,226,154,0) 45%), radial-gradient(circle at 85% 85%, #9EE7F0 0%, rgba(158,231,240,0) 45%), #FFF9EC",
    text: "#1F1A0C", sub: "#4F4630", tile: "rgba(255,255,255,0.82)", tileOn: "#FFF0C2", accent: "#0270AD", accentText: "#FFFFFF",
    q2: "#BF4400", q3: "#00796B", particle: "",
  },
  automne: {
    name: "Automne", tone: "light", swatch: "linear-gradient(135deg,#FFC98A,#E8B4A0)",
    bloom: "radial-gradient(circle at 15% 15%, #FFC98A 0%, rgba(255,201,138,0) 45%), radial-gradient(circle at 85% 85%, #E8B4A0 0%, rgba(232,180,160,0) 45%), #FBF3EA",
    text: "#2A1A0E", sub: "#584232", tile: "rgba(255,255,255,0.82)", tileOn: "#FFE7C7", accent: "#B4400B", accentText: "#FFFFFF",
    q2: "#5B6819", q3: "#7A3E9D", particle: "#D9772B", shape: "leaf",
  },
  hiver: {
    name: "Hiver", tone: "light", swatch: "linear-gradient(135deg,#CFE6FF,#E3E0FF)",
    bloom: "radial-gradient(circle at 15% 15%, #CFE6FF 0%, rgba(207,230,255,0) 45%), radial-gradient(circle at 85% 85%, #E3E0FF 0%, rgba(227,224,255,0) 45%), #F2F6FC",
    text: "#121A26", sub: "#435064", tile: "rgba(255,255,255,0.85)", tileOn: "#E3F0FF", accent: "#1565C0", accentText: "#FFFFFF",
    q2: "#00737E", q3: "#5E35B1", particle: "#8DB8E8", shape: "round",
  },
  halloween: {
    name: "Halloween", tone: "dark", swatch: "linear-gradient(135deg,#5A2A00,#3B1460)",
    bloom: "radial-gradient(circle at 15% 15%, #5A2A00 0%, rgba(90,42,0,0) 50%), radial-gradient(circle at 85% 85%, #3B1460 0%, rgba(59,20,96,0) 50%), #140F1A",
    text: "#FFF4E6", sub: "#DCC9B9", tile: "rgba(40,28,48,0.85)", tileOn: "rgba(255,140,26,0.20)", accent: "#FF8C1A", accentText: "#2A1300",
    surface: "#2C2133", surface2: "#231A29", q2: "#7E3FBF", q3: "#2F7A33", particle: "#FF8C1A", shape: "leaf",
  },
  noel: {
    name: "Noël", tone: "dark", swatch: "linear-gradient(135deg,#7A1020,#0E4D2C)",
    bloom: "radial-gradient(circle at 15% 15%, #7A1020 0%, rgba(122,16,32,0) 50%), radial-gradient(circle at 85% 85%, #0E4D2C 0%, rgba(14,77,44,0) 50%), #10161A",
    text: "#FFF8EE", sub: "#D8CEC2", tile: "rgba(30,38,40,0.85)", tileOn: "rgba(255,214,102,0.20)", accent: "#FF6B66", accentText: "#2A0605",
    surface: "#202A2C", surface2: "#1A2224", q1: "#C62828", q2: "#2E7D32", q3: "#C9A227", q3Text: "#1A1400", particle: "#FFFFFF", shape: "round",
  },
  nouvelan: {
    name: "Nouvel an", tone: "dark", swatch: "linear-gradient(135deg,#3A2D6B,#6B5A1E)",
    bloom: "radial-gradient(circle at 15% 15%, #3A2D6B 0%, rgba(58,45,107,0) 50%), radial-gradient(circle at 85% 85%, #6B5A1E 0%, rgba(107,90,30,0) 50%), #0E0E16",
    text: "#FFFBEF", sub: "#D6D0C0", tile: "rgba(34,32,48,0.85)", tileOn: "rgba(255,215,0,0.18)", accent: "#E6B800", accentText: "#1A1400",
    surface: "#25222F", surface2: "#1D1B27", q2: "#6A3DF0", q3: "#007A88", particle: "#FFD54F", shape: "confetti",
  },
  valentin: {
    name: "Saint-Valentin", tone: "light", swatch: "linear-gradient(135deg,#FFC1D6,#FFD9C9)",
    bloom: "radial-gradient(circle at 15% 15%, #FFC1D6 0%, rgba(255,193,214,0) 45%), radial-gradient(circle at 85% 85%, #FFD9C9 0%, rgba(255,217,201,0) 45%), #FFF4F7",
    text: "#2A0F18", sub: "#5A3843", tile: "rgba(255,255,255,0.85)", tileOn: "#FFE0EA", accent: "#C8175A", accentText: "#FFFFFF",
    q2: "#AD1457", q3: "#8E24AA", particle: "#E8608E", shape: "heart",
  },
  paques: {
    name: "Pâques", tone: "light", swatch: "linear-gradient(135deg,#FFF2A8,#D7C6FF)",
    bloom: "radial-gradient(circle at 15% 15%, #FFF2A8 0%, rgba(255,242,168,0) 45%), radial-gradient(circle at 85% 85%, #D7C6FF 0%, rgba(215,198,255,0) 45%), #FBFAF0",
    text: "#1E1B10", sub: "#4D4834", tile: "rgba(255,255,255,0.85)", tileOn: "#FFF6C9", accent: "#7149B8", accentText: "#FFFFFF",
    q2: "#2E7D32", q3: "#F9A825", q3Text: "#2A1E00", particle: "",
  },
  quatorze: {
    name: "14 Juillet", tone: "light", swatch: "linear-gradient(90deg,#1F3A93 33%,#FFFFFF 33% 66%,#C62828 66%)",
    bloom: "radial-gradient(circle at 10% 20%, #C9D8FF 0%, rgba(201,216,255,0) 45%), radial-gradient(circle at 90% 80%, #FFD0D0 0%, rgba(255,208,208,0) 45%), #FAFBFF",
    text: "#0F1426", sub: "#414A66", tile: "rgba(255,255,255,0.88)", tileOn: "#E6ECFF", accent: "#1F3A93", accentText: "#FFFFFF",
    q2: "#C62828", q3: "#5C6BC0", particle: "",
  },
};

export const THEME_ORDER = ["clair", "sombre", "printemps", "ete", "automne", "hiver", "halloween", "noel", "nouvelan", "valentin", "paques", "quatorze", "contraste"];

/** CSS variables of the seasonal / holiday themes (on top of the clair / sombre base). */
function themeCss(id, t) {
  const v = [
    `--bloom: ${t.bloom}`, `--bloom-energy: ${t.bloom}`, `--bloom-security: ${t.bloom}`, `--bloom-ideas: ${t.bloom}`,
    `--text: ${t.text}`, `--sub: ${t.sub}`, `--muted: ${t.sub}`,
    `--glass: ${t.tile}`, `--glass-strong: ${t.tile.replace(/0\.8\d\)$/, "0.94)")}`,
    `--lit: ${t.tileOn}`, `--lit-border: ${t.accent}`,
    `--accent: ${t.accent}`, `--accent-text: ${t.accentText}`, `--link: ${t.tone === "dark" ? t.accent : t.accent}`,
    `--focus: ${t.accent}`, `--sel-bg: ${t.accent}`, `--sel-text: ${t.accentText}`,
    `--q1: ${t.q1 || t.accent}`, `--q1-text: ${t.q1 ? "#FFFFFF" : t.accentText}`, `--q2: ${t.q2}`, `--q2-text: ${t.q2Text || "#FFFFFF"}`, `--q3: ${t.q3}`, `--q3-text: ${t.q3Text || "#FFFFFF"}`,
    `--particle: ${t.particle || "transparent"}`,
  ];
  if (t.tone === "light") v.push(`--mf-blue: ${t.accent}`, `--tag-text: ${t.text}`, `--tag-bg: ${t.tileOn}`);
  if (t.surface) v.push(`--surface: ${t.surface}`, `--surface-2: ${t.surface2}`, `--off-btn: ${t.surface2}`);
  return `.app[data-theme="${id}"] { ${v.join("; ")}; }`;
}

const SEASONAL = Object.entries(THEME_DEFS)
  .filter(([, t]) => t.bloom)
  .map(([id, t]) => themeCss(id, t))
  .join("\n");

const BASE = `
:host { display: block; height: 100%; min-height: 100vh; }
*, *::before, *::after { box-sizing: border-box; }
.app {
  position: relative; min-height: 100vh; height: 100%; display: flex; flex-direction: column;
  font-family: 'Segoe UI', 'Noto Sans', system-ui, -apple-system, sans-serif;
  background: var(--bloom); background-attachment: fixed; color: var(--text);
  -webkit-font-smoothing: antialiased; line-height: 1.3;
}
.app[data-page="energy"] { background: var(--bloom-energy); background-attachment: fixed; }
.app[data-page="security"] { background: var(--bloom-security); background-attachment: fixed; }
.app[data-page="ideas"] { background: var(--bloom-ideas); background-attachment: fixed; }
.app[data-theme="contraste"] .glass, .app[data-theme="contraste"] .card { border-width: 2px !important; }
h1, h2, h3, p { margin: 0; }
button, input, select, textarea { font-family: inherit; font-size: inherit; color: inherit; }
button { cursor: pointer; }
button:disabled { cursor: default; opacity: 0.6; }
a { color: var(--link); }
:focus-visible { outline: 3px solid var(--focus); outline-offset: 3px; border-radius: 12px; }
[hidden] { display: none !important; }
[tabindex="-1"]:focus { outline: none; }
.sr-only { position: absolute !important; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.content { flex: 1; min-height: 0; overflow: auto; display: flex; flex-direction: column; }
.content > [data-page] { flex: 1; display: flex; flex-direction: column; min-height: 0; }
.loading { flex: 1; display: flex; align-items: center; justify-content: center; font-size: 18px; color: var(--sub); gap: 14px; padding: 40px; }
.spinner { width: 28px; height: 28px; border-radius: 999px; border: 3px solid var(--track); border-top-color: var(--accent); animation: mfSpin 0.9s linear infinite; }
@keyframes mfSpin { to { transform: rotate(360deg); } }

/* Glass surfaces */
.glass { background: var(--glass); border: 1px solid var(--glass-border); box-shadow: var(--shadow); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); border-radius: 20px; }
.card { padding: 18px 20px; display: flex; flex-direction: column; gap: 10px; }
.solid { background: var(--surface); border-radius: 18px; }
.sub { color: var(--sub); }
.muted { color: var(--muted); font-size: 13px; }
.row { display: flex; align-items: center; gap: 12px; }
.wrap { flex-wrap: wrap; }
.grow { flex: 1; min-width: 0; }
.stack { display: flex; flex-direction: column; gap: 14px; }
.h2 { font-size: 19px; font-weight: 700; }
.h2-icon { display: flex; align-items: center; gap: 10px; font-size: 17px; font-weight: 700; }
.badge { width: 34px; height: 34px; border-radius: 10px; flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center; color: #FFFFFF; }
.badge.gold { background: var(--mf-gold); color: var(--mf-gold-text); }
.round { border-radius: 999px; }
.tag { display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 999px; background: var(--tag-bg); color: var(--tag-text); font-size: 13px; font-weight: 700; white-space: nowrap; }
.app[data-theme="contraste"] .tag { border: 2px solid #000; }
.chip { align-self: flex-start; padding: 3px 10px; border-radius: 999px; font-size: 13px; font-weight: 600; background: var(--chip-off-bg); color: var(--chip-off-text); }
.chip.on { background: var(--chip-on-bg); color: var(--chip-on-text); }
.app[data-theme="contraste"] .chip { border: 2px solid #000; }

/* Buttons */
.btn { display: inline-flex; align-items: center; justify-content: center; gap: 10px; min-height: 52px; padding: 0 24px; border-radius: 14px; border: 2px solid transparent; font-size: 17px; font-weight: 700; text-decoration: none; text-align: center; transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.15s ease; }
.btn:active:not(:disabled) { transform: scale(0.98); }
.btn.sm { min-height: 48px; padding: 0 18px; font-size: 16px; border-radius: 12px; }
.btn.primary { background: var(--mf-blue); color: #FFFFFF; box-shadow: 0 8px 20px rgba(0,103,192,0.35); }
.btn.success { background: var(--mf-green); color: #FFFFFF; box-shadow: 0 8px 20px rgba(14,122,13,0.28); }
.btn.violet { background: var(--mf-violet); color: #FFFFFF; }
.btn.secondary { background: var(--surface); color: var(--text); border-color: var(--field); font-weight: 600; }
.btn.ghost { background: transparent; color: var(--link); font-weight: 600; }
.btn.link { background: transparent; color: var(--link); font-weight: 600; text-decoration: underline; min-height: 48px; padding: 0 10px; font-size: 15px; }
.app[data-theme="contraste"] .btn.primary, .app[data-theme="contraste"] .btn.success, .app[data-theme="contraste"] .btn.violet { box-shadow: none; border-color: #000; }
.seg { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
.seg.three { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.opt { min-height: 52px; padding: 12px 16px; border-radius: 14px; border: 2px solid var(--field); background: var(--surface); color: var(--text); font-size: 16px; font-weight: 700; text-align: left; display: flex; flex-direction: column; justify-content: center; gap: 4px; }
.opt.center { text-align: center; align-items: center; }
.opt .opt-sub { font-size: 14px; font-weight: 400; opacity: 0.92; }
.opt[aria-pressed="true"] { background: var(--sel-bg); border-color: var(--sel-bg); color: var(--sel-text); }
.opt.green[aria-pressed="true"] { background: var(--mf-green); border-color: var(--mf-green); color: #FFFFFF; }
.opt.violet[aria-pressed="true"] { background: var(--mf-violet); border-color: var(--mf-violet); color: #FFFFFF; }

/* Taskbar (bottom navigation) */
.taskbar { display: flex; justify-content: center; padding: 6px 32px 16px; flex-shrink: 0; }
.taskbar .bar { display: flex; gap: 6px; padding: 6px; border-radius: 20px; }
.taskbar a { display: flex; align-items: center; gap: 8px; padding: 12px 20px; min-height: 48px; border-radius: 14px; color: var(--text); text-decoration: none; font-size: 16px; font-weight: 500; }
.taskbar a:hover { background: var(--surface-soft); }
.taskbar a[aria-current="page"] { background: var(--accent); color: var(--accent-text); font-weight: 700; padding: 12px 22px; }
.taskbar a[aria-current="page"] svg { stroke: currentColor; }
.taskbar .dot.info { background: var(--accent); color: var(--accent-text); }
.taskbar a[aria-current="page"] .dot.info { background: #FFFFFF; color: #0067C0; }
.taskbar .dot { min-width: 22px; height: 22px; padding: 0 6px; border-radius: 999px; background: var(--mf-warn-orange); color: #FFFFFF; font-size: 12px; font-weight: 800; display: inline-flex; align-items: center; justify-content: center; }
.app[data-theme="contraste"] .taskbar a[aria-current="page"] { outline: 2px solid #000; }

/* Toasts */
.toasts { position: fixed; left: 50%; bottom: 96px; transform: translateX(-50%); display: flex; flex-direction: column; gap: 10px; z-index: 50; width: min(560px, calc(100% - 32px)); }
.toast { display: flex; align-items: center; gap: 12px; padding: 12px 14px 12px 18px; border-radius: 16px; background: var(--glass-strong); border: 2px solid var(--warn-border); color: var(--text); box-shadow: var(--shadow); font-size: 16px; backdrop-filter: blur(20px); }
.toast.ok { border-color: var(--mf-green); }
.toast .btn { min-height: 44px; padding: 0 14px; font-size: 15px; }

/* Page header */
.page-head { display: flex; align-items: center; justify-content: space-between; gap: 24px; padding: 22px 32px 6px; flex-wrap: wrap; }
.page-head .title { display: flex; align-items: center; gap: 14px; }
.page-head h1 { font-size: 30px; font-weight: 800; }
.page-icon { width: 52px; height: 52px; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: #FFFFFF; flex-shrink: 0; }
.clock-pill { padding: 12px 20px; border-radius: 999px; font-size: 22px; font-weight: 800; }
.page-main { flex: 1; min-height: 0; display: flex; gap: 20px; padding: 14px 32px; }
.col { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px; }
.side { width: 390px; flex-shrink: 0; display: flex; flex-direction: column; gap: 14px; }

/* Home */
.home-head { display: flex; align-items: center; justify-content: space-between; gap: 24px; padding: 22px 32px 6px; flex-wrap: wrap; }
.clock { font-size: 56px; font-weight: 700; letter-spacing: -1.5px; line-height: 1; }
.pill { display: flex; align-items: center; gap: 12px; padding: 10px 18px 10px 12px; border-radius: 999px; font-size: 16px; }
.pill.mode { padding: 0 20px; min-height: 52px; border: 1px solid var(--glass-border); color: var(--text); font-size: 16px; }
.mode-dot { width: 12px; height: 12px; border-radius: 999px; flex-shrink: 0; }
.rooms-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
.room-tile { display: flex; align-items: center; gap: 16px; padding: 18px; border-radius: 20px; background: var(--glass); border: 2px solid var(--glass-border); box-shadow: var(--shadow); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); transition: background 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease; }
.room-tile.lit { background: var(--lit); border-color: var(--lit-border); box-shadow: var(--lit-shadow); }
.room-icon { width: 56px; height: 56px; flex-shrink: 0; border-radius: 16px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.room-name { font-size: 21px; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.room-meta { font-size: 16px; color: var(--sub); }
.room-meta strong { font-size: 20px; color: var(--text); }
.light-btn { width: 64px; height: 64px; flex-shrink: 0; border-radius: 999px; border: none; background: var(--off-btn); color: var(--off-btn-text); display: flex; align-items: center; justify-content: center; transition: background 0.2s ease, box-shadow 0.2s ease; }
.light-btn[aria-pressed="true"] { background: #FFB900; color: #3A2A00; box-shadow: 0 6px 18px rgba(255,185,0,0.55); }
.app[data-theme="contraste"] .light-btn { border: 2px solid #000; box-shadow: none; }
.quick-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.quick { display: flex; flex-direction: column; align-items: flex-start; gap: 12px; padding: 20px; border-radius: 20px; border: 2px solid transparent; color: #FFFFFF; text-align: left; min-height: 120px; }
.quick .q-title { font-size: 20px; font-weight: 700; }
.quick .q-sub { font-size: 14px; opacity: 0.95; }
.quick.blue { background: var(--q1); color: var(--q1-text); box-shadow: 0 10px 24px rgba(0,103,192,0.35); }
.quick.green { background: var(--q2); color: var(--q2-text); box-shadow: 0 10px 24px rgba(14,122,13,0.32); }
.quick.violet { background: var(--q3); color: var(--q3-text); box-shadow: 0 10px 24px rgba(107,71,184,0.35); }
.app[data-theme="contraste"] .quick { box-shadow: none; border-color: #000; }
/* « En écoute » (components/now-playing-rules.js) */
.np { display: flex; flex-direction: column; gap: 12px; }
.np-top { display: flex; gap: 14px; align-items: center; min-width: 0; }
.np-art { width: 72px; height: 72px; border-radius: 14px; object-fit: cover; flex-shrink: 0; box-shadow: var(--shadow); background: var(--surface-2); }
.np-noart { display: inline-flex; align-items: center; justify-content: center; color: #FFFFFF; background: linear-gradient(135deg, #6B47B8, #C2185B); }
.np-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.np-where { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 700; color: var(--sub); text-transform: uppercase; letter-spacing: 0.04em; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.np-title { font-size: 18px; font-weight: 800; line-height: 1.25; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
.np-sub { font-size: 15px; color: var(--sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.np-progress { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 0; }
.np-bar { grid-column: 1 / -1; height: 6px; border-radius: 3px; background: var(--track); overflow: hidden; }
.np-bar > div { height: 100%; border-radius: 3px; background: var(--accent); transition: width 1s linear; }
.np-time { font-size: 12px; color: var(--sub); font-variant-numeric: tabular-nums; }
.np-time:last-child { text-align: right; }
.np-controls { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.np-btn { width: 44px; height: 44px; border-radius: 50%; border: none; background: var(--off-btn); color: var(--off-btn-text); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; }
.np-btn.big { width: 54px; height: 54px; background: var(--accent); color: var(--accent-text); }
.np-btn:disabled { opacity: 0.6; cursor: default; }
.np-vol { display: inline-flex; align-items: center; gap: 8px; flex: 1; min-width: 120px; color: var(--sub); margin-left: 6px; }
.np-vol input { flex: 1; accent-color: var(--accent); min-width: 0; }
.np-others { display: flex; gap: 6px; flex-wrap: wrap; }
.np-others button { display: inline-flex; align-items: center; gap: 6px; max-width: 100%; padding: 6px 10px; border-radius: 999px; border: 1px solid var(--line); background: var(--surface-soft); color: var(--text); font-size: 13px; cursor: pointer; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
@media (prefers-reduced-motion: reduce) { .np-bar > div { transition: none; } }
.alert { display: flex; flex-direction: column; gap: 12px; padding: 18px 20px; border-radius: 20px; background: var(--warn-bg); color: var(--warn); border: 2px solid var(--warn-border); box-shadow: var(--shadow); }
.alert .btn { background: var(--warn); color: var(--warn-btn-text); width: 100%; min-height: 48px; font-size: 16px; }
.alert-icon { width: 40px; height: 40px; flex-shrink: 0; border-radius: 12px; background: var(--mf-warn-orange); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.ok-icon { width: 40px; height: 40px; flex-shrink: 0; border-radius: 12px; background: var(--mf-green); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.kwh { font-size: 30px; font-weight: 800; }
.kwh small { font-size: 16px; font-weight: 500; color: var(--sub); }
.mini-bars { display: flex; align-items: flex-end; gap: 6px; height: 64px; }
.mini-bars div { flex: 1; border-radius: 6px; min-height: 4px; }
.cam { position: relative; flex: 1; min-height: 120px; border-radius: 14px; overflow: hidden; background: linear-gradient(135deg, #2B3340 0%, #1A1F27 100%); color: #D6D9DE; display: flex; align-items: center; justify-content: center; font-size: 14px; text-align: center; }
.cam img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.cam .live { position: absolute; top: 10px; left: 10px; display: flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 999px; background: rgba(0,0,0,0.6); color: #FFFFFF; font-size: 12px; font-weight: 700; }
.cam .live i { width: 8px; height: 8px; border-radius: 999px; background: #FF4B4B; }
.cam .cam-name { position: absolute; bottom: 12px; left: 12px; padding: 4px 10px; border-radius: 999px; background: rgba(0,0,0,0.6); color: #FFFFFF; font-size: 13px; font-weight: 600; }
.empty { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; gap: 12px; padding: 30px 20px; color: var(--sub); font-size: 16px; }
.empty .big-icon { width: 72px; height: 72px; border-radius: 22px; display: flex; align-items: center; justify-content: center; color: #FFFFFF; }

/* Rooms page */
.room-list { width: 400px; flex-shrink: 0; display: flex; flex-direction: column; gap: 12px; }
.room-pick { display: flex; align-items: center; gap: 14px; padding: 14px 16px; border-radius: 20px; border: 2px solid var(--glass-border); background: var(--surface-soft); color: var(--text); text-align: left; box-shadow: 0 6px 18px rgba(30,50,90,0.06); backdrop-filter: blur(20px); width: 100%; }
.room-pick[aria-pressed="true"] { background: var(--surface); box-shadow: 0 12px 28px rgba(30,50,90,0.16); }
.room-pick .initial { width: 52px; height: 52px; flex-shrink: 0; border-radius: 16px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.room-pick .rp-name { font-size: 19px; font-weight: 800; }
.room-pick .rp-temp { font-size: 24px; font-weight: 800; }
.add-dashed { display: flex; align-items: center; justify-content: center; gap: 8px; min-height: 56px; border-radius: 20px; border: 2px dashed var(--field-dim); color: var(--text); background: var(--surface-soft); font-size: 16px; font-weight: 600; width: 100%; }
.detail { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px; padding: 22px; border-radius: 24px; }
.detail h2 { font-size: 30px; font-weight: 800; }
.color-bar { width: 12px; height: 40px; border-radius: 999px; flex-shrink: 0; }
.stats3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
.stat { display: flex; flex-direction: column; gap: 4px; padding: 16px; border-radius: 18px; background: var(--surface); }
.stat .label { font-size: 14px; color: var(--sub); }
.stat .value { font-size: 34px; font-weight: 800; }
.app[data-theme="contraste"] .stat { border: 2px solid #000; }
.thermo-ctl { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.round-btn { width: 52px; height: 52px; border-radius: 999px; border: none; color: #FFFFFF; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.round-btn.cold { background: var(--mf-blue); }
.round-btn.hot { background: var(--mf-orange); }
.setpoint { font-size: 28px; font-weight: 800; color: var(--mf-orange); }
.app[data-tone="dark"] .setpoint { color: #FF9A5C; }
.devices-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
.dev-toggle { display: flex; flex-direction: column; align-items: flex-start; gap: 12px; padding: 16px; min-height: 120px; border-radius: 18px; border: 2px solid var(--line); background: var(--surface); color: var(--text); text-align: left; transition: background 0.2s ease, border-color 0.2s ease; }
.dev-toggle[aria-pressed="true"] { background: var(--lit); border-color: var(--lit-border); box-shadow: var(--lit-shadow); }
.dev-toggle .di { width: 44px; height: 44px; border-radius: 999px; background: var(--off-btn); color: var(--off-btn-text); display: flex; align-items: center; justify-content: center; }
.dev-toggle[aria-pressed="true"] .di { background: #FFB900; color: #3A2A00; }
.dev-toggle .dn { font-size: 17px; font-weight: 700; }
.dev-toggle .ds { font-size: 14px; color: var(--sub); }
.sensor-line { display: flex; align-items: center; gap: 12px; min-height: 52px; padding: 8px 14px; border-radius: 14px; background: var(--surface); font-size: 16px; }
.sensor-line .sl-icon { width: 36px; height: 36px; border-radius: 10px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.back-link { display: none; }

/* Energy */
.kpis { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.kpi { display: flex; flex-direction: column; gap: 4px; padding: 18px 20px; border-radius: 20px; }
.kpi .k-label { font-size: 15px; color: var(--sub); }
.kpi .k-value { font-size: 34px; font-weight: 800; }
.kpi.gold { background: var(--mf-gold); color: var(--mf-gold-text); box-shadow: 0 10px 24px rgba(255,185,0,0.35); }
.kpi.gold .k-label { color: var(--mf-gold-text); font-weight: 600; }
.trend { display: flex; align-items: center; gap: 8px; font-size: 30px; font-weight: 800; }
.trend.down { color: var(--ok-text); }
.trend.up { color: var(--open-text); }
.chart { flex: 1; min-height: 220px; display: flex; align-items: flex-end; gap: 10px; padding-top: 10px; }
.chart .bar-col { flex: 1; height: 100%; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; gap: 8px; min-width: 0; }
.chart .bar { width: 100%; max-width: 64px; border-radius: 10px 10px 6px 6px; min-height: 4px; transition: height 0.4s ease; }
.chart .bar-label { font-size: 14px; color: var(--sub); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
.chart .bar-col.last .bar-label { font-weight: 800; color: var(--text); }
.legend { display: flex; gap: 14px; font-size: 13px; color: var(--sub); flex-wrap: wrap; }
.legend span { display: flex; align-items: center; gap: 6px; }
.legend i { width: 12px; height: 12px; border-radius: 4px; }
.share { display: flex; flex-direction: column; gap: 6px; }
.share .sh-top { display: flex; justify-content: space-between; gap: 10px; font-size: 16px; }
.track { height: 12px; border-radius: 999px; background: var(--track); overflow: hidden; }
.app[data-theme="contraste"] .track { border: 1px solid #000; }
.track > div { height: 100%; border-radius: 999px; }
.period { display: flex; gap: 6px; padding: 6px; border-radius: 16px; }
.period button { min-height: 48px; padding: 0 20px; border-radius: 12px; border: none; background: transparent; color: var(--text); font-size: 16px; font-weight: 700; }
.period button[aria-pressed="true"] { background: var(--accent); color: var(--accent-text); }
.tip { display: flex; flex-direction: column; gap: 12px; padding: 18px 20px; border-radius: 22px; background: var(--mf-green); color: #FFFFFF; box-shadow: 0 12px 28px rgba(14,122,13,0.30); }
.tip .btn.white { background: #FFFFFF; color: #0E5A0D; font-weight: 800; }
.tip .btn.outline { background: transparent; color: #FFFFFF; border-color: rgba(255,255,255,0.8); font-weight: 600; }

/* Security */
.banner { display: flex; flex-direction: column; gap: 14px; padding: 20px 22px; border-radius: 22px; color: #FFFFFF; }
.banner .b-icon { width: 52px; height: 52px; flex-shrink: 0; border-radius: 16px; background: rgba(255,255,255,0.22); display: flex; align-items: center; justify-content: center; }
.banner strong { font-size: 24px; }
.banner .modes button { min-height: 56px; border-radius: 14px; border: 2px solid rgba(255,255,255,0.6); background: rgba(255,255,255,0.16); color: #FFFFFF; font-size: 17px; font-weight: 800; }
.banner .modes button[aria-pressed="true"] { background: #FFFFFF; border-color: #FFFFFF; color: var(--banner-color); }
.banner .warnline { display: flex; align-items: center; gap: 10px; padding: 12px 14px; border-radius: 14px; background: #FFFFFF; color: #8A3B00; font-size: 16px; font-weight: 700; }
.app[data-theme="contraste"] .banner { border: 2px solid #000; }
.openings { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
.opening { display: flex; align-items: center; gap: 12px; min-height: 60px; padding: 0 14px; border-radius: 16px; border: 2px solid var(--line); background: var(--surface); }
.opening.open { background: var(--open-bg); border-color: var(--warn-border); }
.opening .o-dot { width: 14px; height: 14px; border-radius: 999px; flex-shrink: 0; background: #13A10E; }
.opening.open .o-dot { background: var(--mf-warn-orange); }
.opening.unk .o-dot { background: var(--field-dim); }
.opening .o-name { flex: 1; min-width: 0; font-size: 16px; font-weight: 600; }
.opening .o-state { font-size: 15px; font-weight: 700; color: var(--ok-text); }
.opening.open .o-state { color: var(--open-text); }
.opening.unk .o-state { color: var(--sub); }
.cams { flex: 1; min-height: 0; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
.cams .cam { border-radius: 22px; min-height: 180px; }
.history { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 4px; }
.history li { display: flex; gap: 12px; padding: 8px 0; }
.history .h-time { width: 52px; flex-shrink: 0; font-size: 15px; font-weight: 800; }
.history .h-dot { width: 10px; height: 10px; flex-shrink: 0; margin-top: 6px; border-radius: 999px; }
.history .h-text { font-size: 15px; line-height: 1.35; }

/* Settings */
.settings-head { display: flex; align-items: center; gap: 14px; padding: 24px 32px 10px 24px; }
.settings-head h1 { font-size: 32px; font-weight: 800; }
.icon-btn { width: 48px; height: 48px; border-radius: 14px; display: flex; align-items: center; justify-content: center; background: var(--glass); color: var(--text); box-shadow: var(--shadow); border: 1px solid var(--glass-border); flex-shrink: 0; }
.settings-body { flex: 1; min-height: 0; display: flex; gap: 20px; padding: 10px 32px 20px; }
.settings-nav { width: 250px; flex-shrink: 0; display: flex; flex-direction: column; gap: 6px; padding: 12px; border-radius: 22px; align-self: flex-start; }
.settings-nav a { display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 48px; padding: 0 14px; border-radius: 14px; color: var(--text); text-decoration: none; font-size: 16px; }
.settings-nav a:hover { background: var(--surface-soft); }
.settings-nav a[aria-current="page"] { background: var(--accent); color: var(--accent-text); font-weight: 700; }
.settings-nav .count { min-width: 24px; height: 24px; padding: 0 6px; border-radius: 999px; background: var(--mf-warn-orange); color: #FFFFFF; font-size: 13px; font-weight: 800; display: inline-flex; align-items: center; justify-content: center; }
.settings-nav a[aria-current="page"] .count { background: #FFFFFF; color: #0067C0; }
.settings-nav .count.info { background: var(--accent); color: var(--accent-text); }
.settings-nav a[aria-current="page"] .count.info { background: #FFFFFF; color: #0067C0; }
.settings-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px; }
.sec-title { font-size: 24px; font-weight: 800; }
.problem { display: flex; flex-direction: column; gap: 12px; padding: 18px 20px; border-radius: 20px; background: var(--glass-strong); border: 2px solid var(--p-color, var(--line)); box-shadow: var(--shadow); }
.problem .p-badge { width: 44px; height: 44px; flex-shrink: 0; border-radius: 14px; background: var(--p-color); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.problem .p-title { font-size: 18px; font-weight: 700; }
.problem .p-body { display: flex; flex-direction: column; gap: 12px; padding: 4px 0 0 58px; }
.problem ol { margin: 0; padding-left: 22px; display: flex; flex-direction: column; gap: 6px; font-size: 16px; line-height: 1.4; }
.problem .p-why { font-size: 16px; line-height: 1.45; }
pre.tech, textarea.tech { margin: 0; padding: 12px 14px; border-radius: 12px; background: var(--code-bg); color: var(--code-text); font-family: 'Cascadia Mono', Consolas, 'DejaVu Sans Mono', monospace; font-size: 13px; white-space: pre-wrap; word-break: break-word; border: none; width: 100%; }
textarea.tech { min-height: 220px; resize: vertical; }
.help-box { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 16px 20px; border-radius: 20px; background: var(--surface-soft); border: 1px dashed var(--field-dim); flex-wrap: wrap; }
.install-banner { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; padding: 12px 16px; border-radius: 18px; background: var(--warn-bg); border: 2px solid var(--warn-border); color: var(--warn); }
.install-banner .ib-text { flex: 1; min-width: 200px; font-size: 16px; font-weight: 700; display: flex; align-items: center; gap: 10px; }
.install-banner .btn { min-height: 44px; }
.app-banner { padding: 12px 24px 0; }
.app.narrow .app-banner { padding: 10px 12px 0; }
.app-banner[hidden] { display: none; }
.pin-input { max-width: 220px; letter-spacing: 0.3em; font-size: 20px; }
.pin-input::placeholder { letter-spacing: normal; font-size: 16px; }
.form-error { color: var(--mf-red); font-weight: 700; font-size: 15px; }
.app[data-tone="dark"] .form-error { color: #FF99A4; }
.app[data-theme="contraste"] .install-banner { border-color: #000; }
.dialog-backdrop { position: fixed; inset: 0; background: rgba(10,14,22,0.45); display: flex; align-items: center; justify-content: center; padding: 16px; z-index: 40; }
.dialog { width: min(720px, 100%); max-height: calc(100vh - 32px); overflow: auto; padding: 24px; border-radius: 24px; background: var(--glass-strong); border: 1px solid var(--glass-border); box-shadow: var(--shadow-big); backdrop-filter: blur(24px); display: flex; flex-direction: column; gap: 14px; }
.app[data-theme="contraste"] .dialog { border: 2px solid #000; background: #FFFFFF; }
.list-item { display: flex; align-items: center; gap: 14px; padding: 12px 16px; border-radius: 16px; background: var(--surface); box-shadow: 0 6px 18px rgba(30,50,90,0.08); flex-wrap: wrap; }
.app[data-theme="contraste"] .list-item { border: 2px solid #000; box-shadow: none; }
.li-icon { width: 42px; height: 42px; flex-shrink: 0; border-radius: 12px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.li-title { font-size: 17px; font-weight: 700; }
.li-sub { font-size: 14px; color: var(--sub); }
.field-label { display: flex; align-items: center; gap: 8px; font-size: 15px; color: var(--sub); }
.select, .input { height: 48px; min-width: 160px; padding: 0 12px; border-radius: 12px; border: 2px solid var(--field); background: var(--surface-2); color: var(--text); font-size: 16px; font-weight: 600; }
.input { font-weight: 500; min-width: 0; width: 100%; }
.check-row { display: flex; align-items: center; gap: 14px; padding: 14px 16px; border-radius: 16px; border: 2px solid var(--line); background: var(--surface-soft); color: var(--text); text-align: left; width: 100%; }
.check-row[aria-pressed="true"] { background: var(--surface); border-color: var(--mf-blue); }
.check-box { width: 30px; height: 30px; flex-shrink: 0; border-radius: 9px; border: 2px solid var(--field-dim); background: var(--surface); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.check-row[aria-pressed="true"] .check-box { background: var(--mf-blue); border-color: var(--mf-blue); }
.cr-title { font-size: 17px; font-weight: 700; }
.cr-why { font-size: 14px; color: var(--sub); }
.steps-check { display: flex; flex-direction: column; gap: 10px; }
.step-line { display: flex; align-items: center; gap: 12px; font-size: 17px; color: var(--muted); }
.step-line .sn { width: 32px; height: 32px; border-radius: 999px; border: 2px solid var(--field-dim); display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
.step-line.done { color: var(--text); }
.step-line.done .sn { background: var(--mf-green); border-color: var(--mf-green); color: #FFFFFF; }
.step-line.cur { color: var(--text); font-weight: 700; }
.step-line.cur .sn { border: 3px solid var(--mf-blue); color: var(--mf-blue); }
.app[data-tone="dark"] .step-line.cur .sn { border-color: #4CC2FF; color: #4CC2FF; }
.progress { height: 10px; border-radius: 999px; background: var(--track); overflow: hidden; }
.progress > div { height: 100%; border-radius: 999px; background: var(--mf-blue); transition: width 0.4s ease; }
.update-card { display: flex; gap: 22px; padding: 24px; border-radius: 22px; background: var(--glass-strong); border: 2px solid var(--mf-blue); box-shadow: 0 12px 30px rgba(0,103,192,0.16); }
.update-card.ok { border-color: var(--mf-green); box-shadow: 0 12px 30px rgba(14,122,13,0.16); align-items: center; }
.update-card.bad { border-color: var(--mf-red); }
.big-badge { width: 64px; height: 64px; flex-shrink: 0; border-radius: 18px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.status3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.status-dot { width: 10px; height: 10px; border-radius: 999px; flex-shrink: 0; }
.theme-cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.theme-card { display: flex; flex-direction: column; gap: 12px; padding: 14px; border-radius: 18px; border: 3px solid var(--line); background: var(--surface); color: var(--text); text-align: left; }
.theme-card[aria-pressed="true"] { border-color: var(--mf-blue); }
.theme-prev { height: 110px; border-radius: 12px; display: flex; gap: 8px; padding: 12px; align-items: flex-end; }
.theme-prev span { flex: 1; height: 50%; border-radius: 8px; }

/* Wizard + add device: centered big glass sheet */
.sheet-wrap { flex: 1; display: flex; align-items: center; justify-content: center; padding: 24px; }
.sheet { width: min(1100px, 100%); min-height: min(680px, calc(100vh - 48px)); max-height: calc(100vh - 48px); display: flex; border-radius: 28px; overflow: hidden; background: var(--glass-strong); border: 1px solid var(--glass-border); box-shadow: var(--shadow-big); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); }
.app[data-theme="contraste"] .sheet { border: 2px solid #000; }
.wiz-steps { width: 270px; flex-shrink: 0; display: flex; flex-direction: column; gap: 22px; padding: 30px 22px; background: var(--surface-soft); border-right: 1px solid var(--line); }
.wiz-steps ol { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
.wiz-steps li { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 12px; font-size: 15px; color: var(--muted); font-weight: 500; }
.wiz-steps li.cur { background: var(--surface); color: var(--text); font-weight: 700; }
.wiz-steps li.done { color: var(--text); }
.wiz-steps .dotn { width: 28px; height: 28px; flex-shrink: 0; border-radius: 999px; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; border: 2px solid var(--field-dim); }
.wiz-steps li.cur .dotn { background: var(--mf-blue); border-color: var(--mf-blue); color: #FFFFFF; }
.wiz-steps li.done .dotn { background: var(--mf-green); border-color: var(--mf-green); color: #FFFFFF; }
.brand { display: flex; align-items: center; gap: 12px; }
.brand .logo { width: 44px; height: 44px; border-radius: 14px; background: var(--mf-blue); color: #FFFFFF; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 16px rgba(0,103,192,0.35); }
.brand b { font-size: 18px; font-weight: 800; display: block; }
.brand span { font-size: 13px; color: var(--sub); }
.wiz-main { flex: 1; min-width: 0; min-height: 0; display: flex; flex-direction: column; }
.wiz-body { flex: 1; min-height: 0; overflow: auto; padding: 36px 44px 20px; }
.wiz-body h1 { font-size: 32px; font-weight: 800; letter-spacing: -0.3px; }
.wiz-body .lead { font-size: 17px; color: var(--sub); line-height: 1.5; }
.wiz-foot { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 18px 44px 24px; border-top: 1px solid var(--line); flex-wrap: wrap; }
.check-card { display: flex; align-items: center; gap: 14px; padding: 16px 18px; border-radius: 16px; background: var(--surface); box-shadow: 0 6px 18px rgba(30,50,90,0.08); }
.app[data-theme="contraste"] .check-card { border: 2px solid #000; }
.check-card .cc-icon { width: 40px; height: 40px; flex-shrink: 0; border-radius: 999px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.check-card strong { font-size: 17px; display: block; }
.check-card span.s { font-size: 14px; color: var(--sub); }
/* « Votre maison sans matériel » (wizard discover step, installer v1.4) */
.disc-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 10px; }
.disc-starter { display: flex; flex-direction: column; gap: 12px; }
.disc-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
.disc-list li { display: flex; align-items: center; gap: 12px; }
.disc-list li strong { display: block; font-size: 16px; }
.disc-list li .s { display: block; font-size: 14px; color: var(--sub); }
/* Empty home (no device yet) and soft notices of the Dépannage */
.home-empty { display: flex; align-items: center; gap: 18px; padding: 20px 22px; border-radius: 20px; margin: 10px 32px 0; }
.app.narrow .home-empty { margin: 8px 16px 0; }
.home-empty .he-icon { width: 60px; height: 60px; flex-shrink: 0; border-radius: 18px; background: #0E7A0D; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.home-empty .he-title { font-size: 20px; font-weight: 700; }
.home-empty .he-text { font-size: 16px; color: var(--sub); line-height: 1.45; }
.notice-card { display: flex; flex-direction: column; gap: 10px; padding: 18px 20px; border-radius: 18px; background: var(--surface); border: 2px solid rgba(0,103,192,0.30); }
.app[data-theme="contraste"] .notice-card { border-color: #000; }
.notice-card .nc-title { font-size: 18px; font-weight: 700; }
.notice-card .nc-icon { width: 44px; height: 44px; flex-shrink: 0; border-radius: 999px; background: #0067C0; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.notice-card ol { margin: 0; padding-left: 22px; display: flex; flex-direction: column; gap: 6px; font-size: 16px; }
@media (max-width: 560px) {
  .home-empty { flex-direction: column; align-items: flex-start; }
}
.room-choices { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; }
.room-choice { display: flex; flex-direction: column; align-items: flex-start; gap: 12px; padding: 16px; min-height: 104px; border-radius: 18px; border: 2px solid var(--line); background: var(--surface-soft); color: var(--text); text-align: left; }
.room-choice[aria-pressed="true"] { background: var(--surface); border-color: var(--rc); box-shadow: 0 8px 20px rgba(30,50,90,0.10); }
.room-choice .rc-icon { width: 36px; height: 36px; border-radius: 12px; background: var(--field-dim); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.room-choice[aria-pressed="true"] .rc-icon { background: var(--rc); }
.room-choice .rc-name { font-size: 17px; font-weight: 700; word-break: break-word; }
.add-room { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
.add-room .input { max-width: 320px; }
.done-hero { display: flex; flex-direction: column; align-items: center; text-align: center; gap: 18px; padding-top: 30px; }
.done-hero .hero-ok { width: 96px; height: 96px; border-radius: 999px; background: var(--mf-green); color: #FFFFFF; display: flex; align-items: center; justify-content: center; box-shadow: 0 14px 34px rgba(14,122,13,0.35); }
.done-hero h1 { font-size: 36px; }
.phone-box { width: 260px; flex-shrink: 0; border-radius: 24px; background: var(--surface); box-shadow: 0 10px 30px rgba(30,50,90,0.14); padding: 20px; display: flex; flex-direction: column; gap: 10px; align-items: center; text-align: center; }
.address { font-family: 'Cascadia Mono', Consolas, 'DejaVu Sans Mono', monospace; font-size: 17px; font-weight: 700; padding: 10px 12px; border-radius: 12px; background: var(--surface-2); border: 2px solid var(--field); word-break: break-all; user-select: all; }
.numbered { margin: 0; padding-left: 24px; display: flex; flex-direction: column; gap: 8px; font-size: 17px; line-height: 1.4; }
.prep-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
.prep-item { display: flex; align-items: flex-start; gap: 14px; padding: 14px 18px; border-radius: 16px; background: var(--surface); box-shadow: 0 6px 18px rgba(30,50,90,0.08); border: 2px solid transparent; }
.app[data-theme="contraste"] .prep-item { border-color: #000; }
.prep-item[data-state="running"] { border-color: var(--accent); }
.prep-item .pi-icon { width: 36px; height: 36px; flex-shrink: 0; border-radius: 999px; display: flex; align-items: center; justify-content: center; color: #FFFFFF; border: 2px solid transparent; }
.prep-item[data-state="pending"] .pi-icon { border-color: var(--field-dim); }
.prep-item[data-state="done"] .pi-icon { background: var(--mf-green); animation: mfPop 0.45s ease-out; }
.prep-item[data-state="skipped"] .pi-icon { background: var(--field-dim); }
.prep-item[data-state="error"] .pi-icon { background: var(--mf-warn-orange); animation: mfPop 0.45s ease-out; }
.prep-item .spinner { width: 24px; height: 24px; border-width: 3px; }
.prep-item .pi-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; flex: 1; }
.prep-item strong { font-size: 17px; }
.prep-item .pi-msg { font-size: 14px; color: var(--sub); line-height: 1.4; }
.prep-item[data-state="error"] .pi-msg { color: var(--warn); font-weight: 600; }
.prep-item .pi-state { font-size: 14px; color: var(--muted); white-space: nowrap; align-self: center; }
.prep-note { padding: 14px 18px; border-radius: 16px; background: var(--warn-bg); border: 1px solid var(--warn-border); color: var(--warn); font-size: 15px; line-height: 1.45; }
.prep-ok { color: var(--ok-text); font-weight: 700; font-size: 16px; }
@keyframes mfPop { 0% { transform: scale(0.6); } 60% { transform: scale(1.12); } 100% { transform: scale(1); } }

/* Add device */
.add-sheet { flex-direction: column; }
.add-head { display: flex; align-items: center; justify-content: space-between; padding: 22px 32px; border-bottom: 1px solid var(--line); gap: 12px; }
.add-head h1 { font-size: 24px; font-weight: 800; }
.add-body { flex: 1; min-height: 0; overflow: auto; padding: 28px 36px; }
.add-body h2 { font-size: 30px; font-weight: 800; }
.type-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 16px; }
.type-card { display: flex; flex-direction: column; align-items: flex-start; gap: 16px; padding: 22px; min-height: 180px; border-radius: 22px; border: 2px solid var(--glass-border); background: var(--surface); color: var(--text); text-align: left; box-shadow: 0 10px 26px rgba(30,50,90,0.10); }
.app[data-theme="contraste"] .type-card { border-color: #000; }
.type-card .tc-icon { width: 60px; height: 60px; border-radius: 18px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.type-card .tc-name { font-size: 19px; font-weight: 800; display: block; }
.type-card .tc-hint { font-size: 15px; color: var(--sub); }
.pair { display: flex; gap: 36px; }
.demo-col { width: 460px; flex-shrink: 0; display: flex; flex-direction: column; gap: 14px; }
.demo { position: relative; height: 380px; border-radius: 24px; background: var(--demo-bg); border: 1px solid var(--line); overflow: hidden; }
.demo .device { position: absolute; left: 70px; top: 120px; width: 130px; height: 170px; border-radius: 26px; background: #FFFFFF; box-shadow: 0 14px 30px rgba(30,50,90,0.18); display: flex; flex-direction: column; align-items: center; padding-top: 26px; gap: 14px; color: #4E535B; }
.demo .device.plug { border-radius: 30px 30px 40px 40px; }
.demo .device.thermo { height: 140px; top: 140px; }
.demo .device .screen { width: 84px; height: 34px; border-radius: 8px; background: #DDE6F2; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 800; color: #2B3038; }
.demo .led { width: 12px; height: 12px; border-radius: 999px; background: #C9D1DC; animation: mfLed 3s linear infinite; }
.demo .press { width: 34px; height: 34px; border-radius: 999px; background: #E4E8EF; border: 3px solid #A9B1BC; animation: mfPress 3s ease-in-out infinite; }
.demo .dev-label { margin-top: auto; margin-bottom: 18px; font-size: 13px; font-weight: 700; color: #4E535B; text-align: center; padding: 0 8px; }
.demo .tab { position: absolute; left: 196px; top: 236px; width: 60px; height: 14px; border-radius: 4px; background: #FFB900; animation: mfTab 3s ease-in-out infinite; }
.demo .finger { position: absolute; left: 116px; top: 108px; width: 38px; height: 90px; border-radius: 19px 19px 14px 14px; background: #E2A97E; box-shadow: inset 0 -10px 0 rgba(0,0,0,0.06); animation: mfFinger 3s ease-in-out infinite; }
.demo .wave { position: absolute; left: 175px; top: 145px; width: 120px; height: 120px; border-radius: 999px; border: 4px solid #2F8CFF; animation: mfWave 3s ease-out infinite; opacity: 0; }
.demo .wave.w2 { animation-delay: 0.25s; }
.demo .box { position: absolute; right: 44px; top: 170px; width: 120px; height: 80px; border-radius: 18px; background: #2B3038; box-shadow: 0 14px 30px rgba(30,50,90,0.25); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; }
.demo .box .bled { width: 12px; height: 12px; border-radius: 999px; background: #5A5F67; animation: mfBox 3s linear infinite; }
.demo .box span { font-size: 12px; font-weight: 700; color: #DDE3EC; }
.gestures { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
.gestures li { display: flex; align-items: center; gap: 14px; padding: 14px 16px; border-radius: 16px; border: 2px solid var(--line); background: var(--surface-soft); font-size: 17px; line-height: 1.35; animation: mfStep 3s linear infinite; }
.gestures .gn { width: 34px; height: 34px; flex-shrink: 0; border-radius: 999px; background: var(--mf-blue); color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 800; }
.listening { display: flex; align-items: center; gap: 14px; padding: 16px 18px; border-radius: 16px; background: var(--info-bg); color: var(--info-text); font-size: 16px; font-weight: 600; }
.app[data-theme="contraste"] .listening { border: 2px solid #000; }
.pulse { width: 14px; height: 14px; flex-shrink: 0; border-radius: 999px; background: var(--mf-blue); animation: mfPulse 1.4s ease-in-out infinite; }
.help-list { margin: 0; padding: 14px 18px 14px 36px; border-radius: 16px; background: var(--surface); display: flex; flex-direction: column; gap: 6px; font-size: 15px; line-height: 1.4; }
.found-hero { display: flex; align-items: center; gap: 18px; }
.found-hero .fh { width: 72px; height: 72px; border-radius: 999px; background: var(--mf-green); color: #FFFFFF; display: flex; align-items: center; justify-content: center; box-shadow: 0 12px 28px rgba(14,122,13,0.35); flex-shrink: 0; }
.pick-row { display: flex; flex-wrap: wrap; gap: 10px; }
.pick-row .opt { min-width: 120px; text-align: center; align-items: center; }

@keyframes mfFinger { 0% { transform: translateY(-70px); opacity: 0 } 12% { opacity: 1 } 25% { transform: translateY(0) } 70% { transform: translateY(0) } 85% { transform: translateY(-70px); opacity: 1 } 100% { transform: translateY(-70px); opacity: 0 } }
@keyframes mfPress { 0%, 24% { transform: scale(1) } 26%, 70% { transform: scale(0.82) } 72%, 100% { transform: scale(1) } }
@keyframes mfLed { 0%, 40% { background: #C9D1DC; box-shadow: none } 45%, 55%, 65%, 75% { background: #2F8CFF; box-shadow: 0 0 14px #2F8CFF } 50%, 60%, 70% { background: #C9D1DC; box-shadow: none } 80%, 100% { background: #2F8CFF; box-shadow: 0 0 14px #2F8CFF } }
@keyframes mfWave { 0%, 62% { transform: scale(0.3); opacity: 0 } 70% { opacity: 0.9 } 100% { transform: scale(1.6); opacity: 0 } }
@keyframes mfBox { 0%, 88% { background: #5A5F67; box-shadow: none } 92%, 100% { background: #13A10E; box-shadow: 0 0 16px #13A10E } }
@keyframes mfStep { 0% { background: var(--surface); border-color: #0067C0; box-shadow: 0 8px 20px rgba(0,103,192,0.18) } 30% { background: var(--surface); border-color: #0067C0; box-shadow: 0 8px 20px rgba(0,103,192,0.18) } 33.4%, 100% { background: var(--surface-soft); border-color: var(--line); box-shadow: none } }
@keyframes mfPulse { 0%, 100% { transform: scale(1); opacity: 1 } 50% { transform: scale(1.6); opacity: 0.4 } }
@keyframes mfTab { 0%, 10% { transform: translateX(0); opacity: 1 } 22% { transform: translateX(40px); opacity: 0 } 100% { transform: translateX(40px); opacity: 0 } }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: 0.001ms !important; animation-iteration-count: 1 !important; transition-duration: 0.001ms !important; }
  .demo .finger { transform: translateY(0); opacity: 1; }
  .demo .led, .demo .box .bled { background: #2F8CFF; }
  .demo .wave { opacity: 0.5; transform: scale(1); }
  .spinner { animation: none; border-top-color: var(--accent); }
}

/* Tablet portrait / small laptop */
@media (max-width: 1100px) {
  .side { width: 340px; }
  .room-list { width: 330px; }
  .demo-col { width: 380px; }
  .demo .box { right: 20px; }
  .type-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .room-choices { grid-template-columns: repeat(3, minmax(0, 1fr)); }
}

/* Phone / narrow */
.app.narrow .page-main, .app.narrow .settings-body { flex-direction: column; padding: 10px 16px; }
.app.narrow .side, .app.narrow .room-list, .app.narrow .settings-nav { width: 100%; }
.app.narrow .page-head, .app.narrow .home-head { padding: 16px 16px 4px; gap: 12px; }
.app.narrow .clock { font-size: 40px; }
.app.narrow .rooms-grid, .app.narrow .openings, .app.narrow .cams, .app.narrow .status3, .app.narrow .theme-cards { grid-template-columns: minmax(0, 1fr); }
.app.narrow .quick-grid, .app.narrow .kpis, .app.narrow .stats3 { grid-template-columns: minmax(0, 1fr); }
.app.narrow .devices-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.app.narrow .quick { min-height: 0; flex-direction: row; align-items: center; }
.app.narrow .seg, .app.narrow .seg.three { grid-template-columns: minmax(0, 1fr); }
.app.narrow .banner .seg.three { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.app.narrow .settings-head { padding: 16px 16px 6px; }
.app.narrow .settings-nav { flex-direction: row; overflow-x: auto; align-self: stretch; padding: 8px; }
.app.narrow .settings-nav a { white-space: nowrap; flex-shrink: 0; }
.app.narrow .room-list.has-sel { display: none; }
.app.narrow .detail.no-sel { display: none; }
.app.narrow .back-link { display: inline-flex; }
.app.narrow .detail { padding: 16px; }
.app.narrow .problem .p-body { padding-left: 0; }
.app.narrow .update-card { flex-direction: column; }
.app.narrow .taskbar { position: sticky; bottom: 0; padding: 0; z-index: 20; }
.app.narrow .taskbar .bar { width: 100%; border-radius: 0; display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 0; padding: 6px 4px 12px; background: var(--glass-strong); border-left: 0; border-right: 0; border-bottom: 0; }
.app.narrow .taskbar a { flex-direction: column; gap: 4px; padding: 6px 0; font-size: 12px; justify-content: center; position: relative; }
.app.narrow .taskbar a[aria-current="page"] { padding: 6px 0; }
.app.narrow .taskbar .dot { position: absolute; top: 2px; right: 18%; }
.app.narrow .toasts { bottom: 90px; }
.app.narrow .sheet-wrap { padding: 0; align-items: stretch; }
.app.narrow .sheet { border-radius: 0; min-height: 100vh; max-height: none; flex-direction: column; }
.app.narrow .wiz-steps { width: 100%; padding: 16px; gap: 10px; border-right: 0; border-bottom: 1px solid var(--line); }
.app.narrow .wiz-steps ol { flex-direction: row; overflow-x: auto; }
.app.narrow .wiz-steps li { padding: 6px; }
.app.narrow .wiz-steps li:not(.cur) .wl { display: none; }
.app.narrow .wiz-body { padding: 20px 16px; }
.app.narrow .wiz-foot { padding: 14px 16px 20px; }
.app.narrow .room-choices, .app.narrow .type-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.app.narrow .pair { flex-direction: column; gap: 20px; }
.app.narrow .demo-col { width: 100%; }
.app.narrow .demo { height: 300px; transform-origin: top left; }
.app.narrow .demo .device { left: 30px; top: 90px; }
.app.narrow .demo .finger { left: 76px; top: 78px; }
.app.narrow .demo .wave { left: 135px; top: 115px; }
.app.narrow .demo .tab { left: 156px; top: 206px; }
.app.narrow .demo .box { right: 16px; top: 140px; width: 100px; }
.app.narrow .add-body { padding: 20px 16px; }
.app.narrow .add-head { padding: 16px; }
.app.narrow .phone-row { flex-direction: column; }

/* Idées (pages/ideas.js, mockup Idees.dc.html) */
.ideas-main { flex: 1; min-height: 0; padding: 12px 32px 14px; }
.back-btn { width: 52px; height: 52px; border-radius: 16px; display: flex; align-items: center; justify-content: center; color: var(--text); flex-shrink: 0; }
.detect-banner { display: flex; align-items: center; gap: 16px; padding: 16px 20px; border-radius: 22px; background: #0067C0; color: #FFFFFF; box-shadow: 0 12px 28px rgba(0,103,192,0.30); }
.detect-banner .db-icon { width: 48px; height: 48px; flex-shrink: 0; border-radius: 14px; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; }
.detect-banner .db-btn { min-height: 48px; padding: 0 20px; border-radius: 12px; background: #FFFFFF; color: #00478A; font-size: 16px; font-weight: 800; white-space: nowrap; }
.app[data-theme="contraste"] .detect-banner { background: #003E92; box-shadow: none; border: 2px solid #000; }
.idea-filters { display: flex; flex-wrap: wrap; gap: 8px; }
.filter-chip { min-height: 44px; padding: 0 18px; border-radius: 999px; border: 2px solid var(--line); background: var(--glass-strong); color: var(--text); font-size: 15px; font-weight: 700; }
.filter-chip[aria-pressed="true"] { background: var(--text); border-color: var(--text); color: var(--surface); }
.ideas-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.idea-card { display: flex; flex-direction: column; align-items: flex-start; gap: 12px; padding: 18px; border-radius: 22px; border: 1px solid var(--glass-border); background: var(--glass-strong); color: var(--text); text-align: left; box-shadow: var(--shadow); min-height: 48px; }
.idea-card:hover { transform: translateY(-1px); }
.idea-card.later { opacity: 0.85; }
.ic-top { display: flex; align-items: center; justify-content: space-between; width: 100%; gap: 8px; }
.ic-initial { width: 48px; height: 48px; border-radius: 14px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 22px; font-weight: 800; flex-shrink: 0; }
.ic-title { font-size: 18px; font-weight: 800; }
.ic-pitch { font-size: 15px; color: var(--sub); line-height: 1.35; }
.ic-need { font-size: 14px; color: var(--sub); }
.new-dot { width: 10px; height: 10px; border-radius: 999px; background: var(--accent); display: inline-block; }
.st-badge { padding: 4px 10px; border-radius: 999px; font-size: 13px; font-weight: 700; white-space: nowrap; background: var(--st-pret-bg); color: var(--st-pret-text); }
.st-badge.manque { background: var(--st-manque-bg); color: var(--st-manque-text); }
.st-badge.actif { background: var(--st-actif-bg); color: var(--st-actif-text); }
.st-badge.attente { background: var(--st-attente-bg); color: var(--st-attente-text); }
.st-badge.non_pertinent { background: var(--st-later-bg); color: var(--st-later-text); }
.app[data-theme="contraste"] .st-badge, .app[data-theme="contraste"] .filter-chip, .app[data-theme="contraste"] .idea-card { border: 2px solid #000; }
.idea-detail { display: flex; gap: 20px; align-items: flex-start; }
.ideas-side { width: 400px; }
.idea-card-block { padding: 20px 22px; border-radius: 22px; background: var(--glass-strong); }
.idea-desc { font-size: 17px; line-height: 1.5; }
.need-row { display: flex; align-items: center; gap: 14px; padding: 12px 14px; border-radius: 16px; background: var(--surface); border: 2px solid var(--line); }
.need-row.missing { background: var(--need-miss-bg); border-color: var(--need-miss-border); }
.need-dot { width: 40px; height: 40px; flex-shrink: 0; border-radius: 12px; background: var(--mf-green); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.need-row.missing .need-dot { background: var(--mf-warn-orange); }
.need-row.optional .need-dot { background: var(--field-dim); }
.need-pick .select { margin-top: 6px; max-width: 100%; }
.qsa { display: grid; grid-template-columns: 90px 1fr; gap: 8px 12px; font-size: 16px; line-height: 1.4; }
.qsa-k { align-self: start; padding: 3px 0; border-radius: 8px; color: #FFFFFF; font-size: 13px; font-weight: 800; text-align: center; }
.opt-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 48px; font-size: 16px; }
.opt-row input[type="checkbox"] { width: 24px; height: 24px; accent-color: var(--accent); flex-shrink: 0; }
.next-card { display: flex; flex-direction: column; gap: 10px; padding: 18px 20px; border-radius: 22px; color: #FFFFFF; box-shadow: 0 12px 28px rgba(107,71,184,0.30); }
.next-card .next-btn { align-self: flex-start; min-height: 44px; padding: 0 16px; border-radius: 12px; border: 2px solid rgba(255,255,255,0.7); background: transparent; color: #FFFFFF; font-size: 15px; }
.app[data-theme="contraste"] .next-card { background: #4B2A93 !important; box-shadow: none; border: 2px solid #000; }
.btn.activate { min-height: 60px; border-radius: 18px; background: var(--mf-blue); color: #FFFFFF; font-size: 18px; font-weight: 800; box-shadow: 0 10px 24px rgba(30,50,90,0.20); width: 100%; }
.btn.activate.on { background: var(--mf-green); }
.btn.activate.waiting { background: var(--mf-violet); }
.app[data-theme="contraste"] .btn.activate { box-shadow: none; border-color: #000; }
.idea-tile { display: flex; flex-shrink: 0; align-items: center; gap: 14px; padding: 14px 16px; border-radius: 18px; background: var(--glass-strong); border: 2px solid var(--glass-border); box-shadow: var(--shadow); }
.idea-tile.lit { background: var(--lit); border-color: var(--lit-border); box-shadow: var(--lit-shadow); }
.idea-tile.danger { background: var(--warn-bg); border-color: var(--warn-border); color: var(--warn); }
.idea-tile .it-icon { width: 48px; height: 48px; flex-shrink: 0; border-radius: 14px; color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.idea-tile .it-title { font-size: 18px; }
.idea-tile .it-text { font-size: 14px; color: var(--sub); }
.idea-tile.danger .it-text { color: var(--warn); font-weight: 700; }
.app.narrow .ideas-main { padding: 10px 16px; }
.app.narrow .ideas-grid { grid-template-columns: minmax(0, 1fr); }
.app.narrow .idea-detail { flex-direction: column; align-items: stretch; }
.app.narrow .idea-detail > .col { width: 100%; }
.app.narrow .need-pick, .app.narrow .need-pick .select { width: 100%; min-width: 0; }
.app.narrow .ideas-side { width: 100%; }
.app.narrow .detect-banner { flex-wrap: wrap; }
.app.narrow .detect-banner .db-btn { width: 100%; }
.app.narrow .need-row { flex-wrap: wrap; }
.app.narrow .need-row > .btn { width: 100%; }
.app.narrow .qsa { grid-template-columns: 74px 1fr; }
@media (max-width: 1100px) { .ideas-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .ideas-side { width: 340px; } }

/* Apparence: falling flakes / leaves / confetti of the theme (decorative, home screen only) */
.fx, .ap-fx { position: absolute; inset: 0; overflow: hidden; pointer-events: none; z-index: 0; }
.fx { position: fixed; z-index: 30; }
.fx-p { position: absolute; top: -24px; border-radius: 999px; background: var(--particle); opacity: 0; animation: mfFall var(--dur) linear infinite; animation-delay: var(--delay); will-change: transform; }
.fx-p.leaf { border-radius: 2px 12px; }
.fx-p.confetti { border-radius: 2px; }
.fx-p.heart { border-radius: 50% 50% 0 50%; transform: rotate(45deg); }
.ap-fx .fx-p { animation-name: mfFallSmall; }
@keyframes mfFall { 0% { transform: translate3d(0, -20px, 0) rotate(0deg); opacity: 0; } 8% { opacity: 0.85; } 92% { opacity: 0.85; } 100% { transform: translate3d(var(--drift), 105vh, 0) rotate(220deg); opacity: 0; } }
@keyframes mfFallSmall { 0% { transform: translate3d(0, -20px, 0) rotate(0deg); opacity: 0; } 10% { opacity: 0.85; } 100% { transform: translate3d(var(--drift), 420px, 0) rotate(200deg); opacity: 0; } }
.app[data-anim="off"] .fx, .app[data-anim="off"] .ap-fx { display: none; }
.app.mf-hidden .fx-p, .app.mf-hidden .ap-mini * { animation-play-state: paused; }
/* Birthday tile confetti (components/idea-tile.js): paused when the panel is hidden, gone without animations. */
.app.mf-hidden .bd-confetti i { animation-play-state: paused; }
.app[data-anim="off"] .bd-confetti { display: none; }
@media (prefers-reduced-motion: reduce) { .fx, .ap-fx { display: none; } }
.wink { display: flex; align-items: center; gap: 8px; font-size: 15px; color: var(--text); margin-top: 2px; }
.wink-dot { width: 10px; height: 10px; border-radius: 999px; background: var(--accent); flex-shrink: 0; }

/* « Vous essayez le style Néon — Garder / Revenir » */
.style-trial { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin: 10px 32px 0; padding: 10px 14px 10px 18px; border-radius: 18px; background: var(--glass-strong); border: 2px solid var(--accent); color: var(--text); box-shadow: var(--shadow); position: relative; z-index: 2; }
.style-trial .st-text { flex: 1; min-width: 200px; display: flex; align-items: center; gap: 10px; font-size: 17px; font-weight: 700; }
.app.narrow .style-trial { margin: 10px 12px 0; }

/* Réglages › Apparence */
.ap-tabs { display: flex; gap: 6px; padding: 6px; border-radius: 18px; background: var(--glass); border: 1px solid var(--glass-border); align-self: flex-start; flex-wrap: wrap; }
.ap-tab { display: inline-flex; align-items: center; gap: 8px; min-height: 48px; padding: 0 18px; border-radius: 14px; border: 0; background: transparent; color: var(--text); font-size: 16px; font-weight: 600; }
.ap-tab[aria-selected="true"] { background: var(--accent); color: var(--accent-text); font-weight: 800; }
.ap-new { padding: 2px 8px; border-radius: 999px; background: var(--mf-gold); color: var(--mf-gold-text); font-size: 12px; font-weight: 800; }
.ap-grid { display: grid; grid-template-columns: minmax(0, 1.35fr) minmax(0, 1fr); gap: 20px; align-items: start; }
.ap-themes { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }
.ap-theme { display: flex; flex-direction: column; gap: 6px; padding: 6px; min-height: 48px; border-radius: 16px; border: 3px solid transparent; background: var(--surface); color: var(--text); text-align: left; }
.ap-theme[aria-pressed="true"] { border-color: var(--accent); }
.ap-swatch { height: 58px; border-radius: 11px; display: flex; align-items: flex-end; justify-content: flex-end; padding: 6px; box-shadow: inset 0 0 0 1px rgba(0,0,0,0.08); }
.ap-swatch i { width: 18px; height: 18px; border-radius: 999px; border: 2px solid rgba(255,255,255,0.9); }
.ap-theme-name { padding: 0 4px 2px; font-size: 14px; font-weight: 700; }
.app[data-theme="contraste"] .ap-theme { border-color: #000; }
.app[data-theme="contraste"] .ap-theme[aria-pressed="true"] { outline: 3px solid #003E92; }
.ap-anim input { width: 26px; height: 26px; accent-color: var(--accent); flex-shrink: 0; }
.ap-preview-col { display: flex; flex-direction: column; gap: 10px; min-width: 0; position: sticky; top: 0; }
.ap-preview-label { font-size: 14px; font-weight: 700; color: var(--sub); }
.ap-preview { position: relative; min-height: 420px; border-radius: 24px; overflow: hidden; background: var(--bloom); color: var(--text); box-shadow: var(--shadow-big); display: flex; flex-direction: column; gap: 14px; padding: 22px; }
.ap-preview > :not(.ap-fx) { position: relative; z-index: 1; }
.ap-pv-head { display: flex; align-items: baseline; gap: 14px; }
.ap-pv-clock { font-size: 36px; font-weight: 800; letter-spacing: -1px; }
.ap-pv-head strong { font-size: 20px; }
.ap-pv-rooms { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.ap-pv-room { display: flex; align-items: center; gap: 10px; padding: 12px; font-size: 14px; border-radius: 18px; background: var(--glass); border: 2px solid transparent; }
.ap-pv-room.on { background: var(--lit); border-color: var(--accent); }
.ap-pv-ic { width: 44px; height: 44px; flex-shrink: 0; border-radius: 13px; display: flex; align-items: center; justify-content: center; }
.ap-pv-quick { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }
.ap-pv-quick span { padding: 12px; border-radius: 16px; font-size: 14px; font-weight: 800; }
.ap-pv-quick .q1 { background: var(--q1); color: var(--q1-text); } .ap-pv-quick .q2 { background: var(--q2); color: var(--q2-text); } .ap-pv-quick .q3 { background: var(--q3); color: var(--q3-text); }
.ap-pv-wink { margin-top: auto; display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-radius: 16px; background: var(--glass); font-size: 15px; }
.ap-pv-wink i { width: 12px; height: 12px; flex-shrink: 0; border-radius: 999px; background: var(--accent); }
.ap-styles { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.ap-style { display: flex; flex-direction: column; gap: 12px; padding: 14px; border-radius: 22px; background: var(--glass-strong); border: 2px solid var(--glass-border); box-shadow: var(--shadow); }
.ap-style.current { border-color: var(--accent); }
.ap-style-name { font-size: 19px; font-weight: 800; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.ap-heart { width: 52px; height: 52px; flex-shrink: 0; border-radius: 999px; border: 2px solid var(--line); background: var(--surface); color: var(--sub); display: flex; align-items: center; justify-content: center; transition: transform 0.15s ease; }
.ap-heart[aria-pressed="true"] { color: #C2185B; border-color: #C2185B; background: #FFE6F0; }
.app[data-tone="dark"] .ap-heart[aria-pressed="true"] { color: #FF8AB8; border-color: #FF8AB8; background: rgba(255,138,184,0.15); }
.ap-heart:active { transform: scale(0.92); }
.ap-current { display: inline-flex; align-items: center; gap: 8px; min-height: 48px; padding: 0 16px; border-radius: 12px; background: var(--st-actif-bg); color: var(--st-actif-text); font-weight: 800; }
.ap-current.trial { background: var(--st-attente-bg); color: var(--st-attente-text); }
.app.narrow .ap-grid { grid-template-columns: minmax(0, 1fr); }
.app.narrow .ap-themes { grid-template-columns: repeat(3, minmax(0, 1fr)); }
.app.narrow .ap-styles { grid-template-columns: minmax(0, 1fr); }
.app.narrow .ap-preview-col { position: static; }
@media (max-width: 1100px) { .ap-styles { grid-template-columns: repeat(2, minmax(0, 1fr)); } .ap-grid { grid-template-columns: minmax(0, 1fr); } }

/* Animated mini previews of the home styles */
.ap-mini { position: relative; height: 120px; border-radius: 16px; overflow: hidden; }
.ap-mini * { position: absolute; display: block; }
.ap-mini-maison_facile { background: radial-gradient(circle at 15% 20%, #B9D4F5, transparent 50%), radial-gradient(circle at 85% 90%, #F8D3E1, transparent 50%), #E8EEF7; }
.mm-tile { width: 40%; height: 36%; border-radius: 10px; background: rgba(255,255,255,0.85); }
.mm-tile:nth-child(1) { left: 7%; top: 9%; } .mm-tile:nth-child(2) { left: 53%; top: 9%; } .mm-tile:nth-child(3) { left: 7%; top: 55%; } .mm-tile:nth-child(4) { left: 53%; top: 55%; }
.mm-tile.lit { background: #FFF3D1; border: 2px solid #FFB900; animation: mmGlow 3s ease-in-out infinite; }
.ap-mini-orbite { background: radial-gradient(60% 70% at 30% 40%, rgba(124,58,237,0.45), transparent 70%), #07051A; }
.mo-sun { left: 50%; top: 50%; width: 34px; height: 34px; margin: -17px 0 0 -17px; border-radius: 50%; background: radial-gradient(circle at 38% 32%, #FFF6DD, #FFD27A 35%, #FF8A4C 70%, #E0457B); box-shadow: 0 0 20px rgba(255,140,70,0.7); }
.mo-ring { left: 50%; top: 50%; width: 92px; height: 92px; margin: -46px 0 0 -46px; border-radius: 50%; border: 1px dashed rgba(183,156,255,0.6); animation: orbSpin 10s linear infinite; }
.mo-ring i { width: 14px; height: 14px; border-radius: 50%; }
.mo-ring i:nth-child(1) { left: 39px; top: -7px; background: #FF6FB5; box-shadow: 0 0 10px #FF6FB5; }
.mo-ring i:nth-child(2) { left: -7px; top: 50px; background: #2EE6A8; box-shadow: 0 0 10px #2EE6A8; }
.mo-ring i:nth-child(3) { left: 78px; top: 60px; background: #3D3866; }
.ap-mini-neon { background: #05050A; display: flex; }
.mn-tube { bottom: 14px; width: 18px; height: 88px; border-radius: 9px; border: 1px solid rgba(255,255,255,0.2); overflow: hidden; }
.mn-tube:nth-child(1) { left: 22%; } .mn-tube:nth-child(2) { left: 38%; } .mn-tube:nth-child(3) { left: 54%; } .mn-tube:nth-child(4) { left: 70%; }
.mn-tube i { left: 0; right: 0; bottom: 0; height: 100%; border-radius: 9px; transform-origin: bottom; animation: mnFill 4s ease-in-out infinite alternate; }
.mn-tube:nth-child(1) i { background: linear-gradient(to top, #FF3D7F, #FFB86B); box-shadow: 0 0 12px #FFB86B; }
.mn-tube:nth-child(2) i { background: linear-gradient(to top, #00B3A4, #7CFFCB); box-shadow: 0 0 12px #7CFFCB; animation-delay: -1s; }
.mn-tube:nth-child(3) i { background: linear-gradient(to top, #6A3DFF, #C79BFF); box-shadow: 0 0 12px #C79BFF; animation-delay: -2s; }
.mn-tube:nth-child(4) i { background: linear-gradient(to top, #0077FF, #7DF9FF); box-shadow: 0 0 12px #7DF9FF; animation-delay: -3s; }
.ap-mini-jumeau { background: radial-gradient(60% 60% at 50% 50%, rgba(92,225,255,0.2), transparent 70%), #030A14; perspective: 500px; }
.mj-plane { left: 50%; top: 50%; width: 96px; height: 96px; margin: -48px 0 0 -48px; transform: rotateX(56deg) rotateZ(-38deg); transform-style: preserve-3d; }
.mj-plane i { width: 44px; height: 44px; border-radius: 4px; background: #0E2F42; border: 1px solid rgba(92,225,255,0.6); }
.mj-plane i:nth-child(1) { left: 0; top: 0; } .mj-plane i:nth-child(2) { left: 52px; top: 0; } .mj-plane i:nth-child(3) { left: 0; top: 52px; } .mj-plane i:nth-child(4) { left: 52px; top: 52px; }
.mj-plane i.lit { animation: mjLit 3s ease-in-out infinite; }
.ap-mini-holo { background: radial-gradient(50% 60% at 0% 0%, #FFD6F0, transparent 70%), radial-gradient(50% 60% at 100% 100%, #C9F0FF, transparent 70%), #F6F4FB; perspective: 400px; }
.mh-card { top: 22px; width: 38%; height: 76px; border-radius: 14px; background: rgba(255,255,255,0.85); box-shadow: 0 6px 14px rgba(70,50,140,0.12); }
.mh-card:nth-child(1) { left: 8%; }
.mh-card.flip { right: 8%; transform-style: preserve-3d; animation: mhFlip 4s ease-in-out infinite; }
.mh-card.flip b { inset: 0; border-radius: 14px; background: linear-gradient(135deg, #FFB86B, #FF6FB5 50%, #B79CFF); transform: rotateY(180deg); backface-visibility: hidden; }
@keyframes mmGlow { 0%, 100% { box-shadow: 0 0 0 rgba(255,185,0,0); } 50% { box-shadow: 0 0 16px rgba(255,185,0,0.6); } }
@keyframes mnFill { from { transform: scaleY(0.15); } to { transform: scaleY(0.9); } }
@keyframes mjLit { 0%, 100% { background: #0E2F42; box-shadow: none; } 50% { background: #FFB547; box-shadow: 0 0 18px #FFB547; } }
@keyframes mhFlip { 0%, 30% { transform: rotateY(0deg); } 50%, 80% { transform: rotateY(180deg); } 100% { transform: rotateY(360deg); } }
@keyframes orbSpin { to { transform: rotate(360deg); } }
.app[data-anim="off"] .ap-mini *, .app[data-anim="off"] .ap-mini *::before { animation: none !important; }
@media (prefers-reduced-motion: reduce) { .ap-mini * { animation: none !important; } }

/* « Bien choisir ses appareils » (pages/guide.js) */
.gd-main { flex: 1; min-height: 0; padding: 12px 32px 24px; }
.gd-tabs { margin-bottom: 2px; }
.gd-panel { display: flex; flex-direction: column; gap: 16px; }
.gd-hero { display: flex; align-items: center; gap: 18px; padding: 20px 22px; border-radius: 22px; background: var(--mf-green); color: #FFFFFF; box-shadow: 0 12px 28px rgba(14,122,13,0.28); }
.gd-hero-ic { width: 56px; height: 56px; flex-shrink: 0; border-radius: 999px; background: rgba(255,255,255,0.22); display: flex; align-items: center; justify-content: center; }
.gd-hero-title { font-size: 24px; font-weight: 800; }
.gd-hero-text { font-size: 16px; line-height: 1.45; }
.gd-two { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; align-items: start; }
.gd-card { padding: 20px 22px; border-radius: 22px; background: var(--glass-strong); gap: 12px; }
.gd-card .h2 { display: flex; align-items: center; gap: 10px; }
.gd-zigbee { border: 2px solid var(--mf-green); }
.gd-wifi { border: 2px solid var(--warn-border); }
.gd-p { font-size: 16px; line-height: 1.5; }
.gd-brands { font-size: 15px; line-height: 1.45; color: var(--sub); }
.gd-brands strong { color: var(--text); }
.gd-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; font-size: 16px; line-height: 1.4; }
.gd-list li { display: flex; gap: 10px; align-items: flex-start; }
.gd-list li > svg { flex-shrink: 0; margin-top: 1px; color: var(--ok-text); }
.gd-list.warn li > svg { color: var(--open-text); }
.gd-list.small { font-size: 15px; gap: 6px; }
.gd-ok-ko { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
.gd-ok, .gd-ko { display: flex; flex-direction: column; gap: 4px; padding: 12px 14px; border-radius: 14px; font-size: 15px; line-height: 1.4; }
.gd-ok strong, .gd-ko strong { display: flex; align-items: center; gap: 6px; font-size: 15px; }
.gd-ok { background: var(--st-actif-bg); color: var(--st-actif-text); }
.gd-ko { background: var(--st-manque-bg); color: var(--st-manque-text); }
.gd-label { flex-direction: row; align-items: center; gap: 20px; }
.gd-svg { width: 100%; max-width: 420px; height: auto; align-self: center; display: block; }
.gd-svg-sm { width: 200px; flex-shrink: 0; }
.gd-svg .s-house { fill: var(--surface-soft); stroke: var(--field-dim); stroke-width: 2.5; stroke-linejoin: round; }
.gd-svg .s-link { fill: none; stroke: var(--mf-green); stroke-width: 3; stroke-dasharray: 6 5; stroke-linecap: round; }
.gd-svg .s-path { fill: none; stroke: var(--mf-warn-orange); stroke-width: 3; stroke-dasharray: 7 6; stroke-linecap: round; }
.gd-svg .s-boxdev { fill: #2B3038; }
.gd-svg .s-key { fill: var(--mf-blue); }
.gd-svg .s-led { fill: #6CCB5F; }
.gd-svg .s-dev { fill: var(--surface); stroke: var(--mf-green); stroke-width: 3; }
.gd-svg .s-dev.warn { stroke: var(--mf-warn-orange); }
.gd-svg .s-ic { color: var(--text); }
.gd-svg .s-ico { fill: none; stroke: var(--sub); stroke-width: 2; stroke-linecap: round; }
.gd-svg .s-cloud { fill: var(--surface); stroke: var(--field-dim); stroke-width: 2.5; stroke-linejoin: round; }
.gd-svg .s-cloud.warn { stroke: var(--mf-warn-orange); }
.gd-svg .s-cross { stroke: var(--open-text); stroke-width: 4; stroke-linecap: round; }
.gd-svg .s-warn { stroke: var(--open-text); stroke-width: 4; stroke-linecap: round; }
.gd-svg .s-phone { fill: var(--surface); stroke: var(--sub); stroke-width: 2.5; }
.gd-svg .s-txt { fill: var(--sub); font-size: 13px; font-family: inherit; }
.gd-svg .s-txt.b { fill: var(--text); font-weight: 700; }
.gd-svg .s-pack { fill: var(--surface); stroke: var(--field-dim); stroke-width: 2.5; }
.gd-svg .s-pack-top, .gd-svg .s-pack-side { fill: var(--surface-2); stroke: var(--field-dim); stroke-width: 2.5; stroke-linejoin: round; }
.gd-svg .s-tag { fill: var(--st-actif-bg); stroke: var(--mf-green); stroke-width: 2; }
.gd-svg .s-tag-txt { fill: var(--st-actif-text); font-size: 14px; font-weight: 800; font-family: inherit; }
.gd-svg .s-lens { fill: none; stroke: var(--text); stroke-width: 4; }
.gd-svg .s-lens-h { stroke: var(--text); stroke-width: 6; stroke-linecap: round; }
.gd-table-wrap { overflow-x: auto; border-radius: 14px; }
.gd-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 15px; background: var(--surface); border-radius: 14px; overflow: hidden; }
.gd-table th, .gd-table td { padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--line); vertical-align: middle; }
.gd-table thead th { font-size: 14px; color: var(--sub); font-weight: 700; background: var(--surface-2); }
.gd-table tbody tr:last-child th, .gd-table tbody tr:last-child td { border-bottom: 0; }
.gd-table tr.best th, .gd-table tr.best td { background: var(--st-actif-bg); color: var(--st-actif-text); }
.gd-tname { display: block; font-weight: 800; color: inherit; }
.gd-tnote { display: block; font-size: 13px; font-weight: 400; color: inherit; opacity: 0.92; }
.gd-c { display: inline-flex; align-items: center; gap: 6px; font-weight: 600; }
.gd-cell.yes svg { color: var(--ok-text); }
.gd-cell.no svg, .gd-cell.mid svg { color: var(--open-text); }
.gd-table tr.best .gd-cell svg { color: currentColor; }
.app[data-theme="contraste"] .gd-table { border: 2px solid #000; }
.gd-summary { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; padding: 18px 22px; border-radius: 22px; background: var(--glass-strong); border: 2px solid var(--accent); box-shadow: var(--shadow); }
.gd-summary > .stack { flex: 1; min-width: 220px; }
.gd-sum-title { font-size: 20px; font-weight: 800; }
.gd-sum-text { font-size: 15px; color: var(--sub); }
.gd-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; align-items: start; }
.gd-item { display: flex; flex-direction: column; gap: 10px; padding: 18px; border-radius: 22px; background: var(--glass-strong); border: 2px solid var(--glass-border); box-shadow: var(--shadow); }
.gd-item.focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent), var(--shadow); }
.gd-it-title { font-size: 18px; font-weight: 800; }
.gd-price { font-size: 15px; }
.gd-trap { display: flex; gap: 8px; align-items: flex-start; padding: 10px 12px; border-radius: 14px; background: var(--st-manque-bg); color: var(--st-manque-text); font-size: 15px; line-height: 1.4; }
.gd-trap svg { flex-shrink: 0; margin-top: 2px; }
.gd-for { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; font-size: 14px; color: var(--sub); }
.gd-idea { display: inline-flex; align-items: center; gap: 6px; min-height: 44px; padding: 0 12px; border-radius: 999px; border: 2px solid var(--line); background: var(--surface); color: var(--text); font-size: 14px; font-weight: 600; }
.gd-idea:hover { border-color: var(--accent); }
.app[data-theme="contraste"] .gd-idea { border-color: #000; }
.gd-shop { align-self: flex-start; }
.gd-ext { margin-left: 4px; padding: 2px 8px; border-radius: 999px; background: var(--tag-bg); color: var(--tag-text); font-size: 12px; font-weight: 700; }
.gd-ext-note { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-radius: 14px; background: var(--info-bg); color: var(--info-text); font-size: 15px; }
.gd-notice { display: flex; gap: 14px; align-items: flex-start; padding: 16px 18px; border-radius: 18px; background: var(--info-bg); color: var(--info-text); border: 2px solid var(--accent); }
.gd-notice .btn.link { color: var(--info-text); }
.gd-notice-ic { width: 44px; height: 44px; flex-shrink: 0; border-radius: 14px; background: var(--mf-blue); color: #FFFFFF; display: flex; align-items: center; justify-content: center; }
.gd-notice-title { font-size: 17px; }
.gd-notice-text { font-size: 15px; line-height: 1.45; }
.gd-before { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; padding: 12px 16px; border-radius: 16px; background: var(--surface-soft); border: 1px dashed var(--field-dim); font-size: 16px; }
.gd-before .grow { display: flex; align-items: center; gap: 8px; min-width: 220px; }
.gd-url { font-family: 'Cascadia Mono', Consolas, 'DejaVu Sans Mono', monospace; word-break: break-all; }
.app[data-theme="contraste"] .gd-hero { background: #0A5A09; box-shadow: none; border: 2px solid #000; }
.app[data-theme="contraste"] .gd-item, .app[data-theme="contraste"] .gd-card, .app[data-theme="contraste"] .gd-notice, .app[data-theme="contraste"] .gd-summary { border: 2px solid #000; }
@media (max-width: 1100px) { .gd-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
.app.narrow .gd-main { padding: 10px 16px 20px; }
.app.narrow .gd-two, .app.narrow .gd-grid, .app.narrow .gd-ok-ko { grid-template-columns: minmax(0, 1fr); }
.app.narrow .gd-label { flex-direction: column; align-items: stretch; }
.app.narrow .gd-svg-sm { align-self: center; }
.app.narrow .gd-hero { align-items: flex-start; padding: 16px; }
.app.narrow .gd-hero-title { font-size: 20px; }
/* Phone: each technology becomes a small card (label + value per line), no sideways scrolling. */
.app.narrow .gd-table, .app.narrow .gd-table tbody, .app.narrow .gd-table tr, .app.narrow .gd-table th, .app.narrow .gd-table td { display: block; width: 100%; }
.app.narrow .gd-table thead { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); }
.app.narrow .gd-table { background: transparent; }
.app.narrow .gd-table tr { background: var(--surface); border-radius: 14px; margin-bottom: 10px; border: 1px solid var(--line); overflow: hidden; }
.app.narrow .gd-table th[scope="row"] { padding: 10px 12px 6px; border-bottom: 0; }
.app.narrow .gd-table td { display: flex; justify-content: space-between; gap: 12px; padding: 6px 12px; border-bottom: 0; }
.app.narrow .gd-table td::before { content: attr(data-label); color: var(--sub); font-size: 14px; }
.app.narrow .gd-table tr.best td::before { color: inherit; }
.app.narrow .gd-table td:last-child { padding-bottom: 12px; }
.app.narrow .gd-tabs { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); align-self: stretch; }
.app.narrow .gd-tabs .ap-tab { justify-content: center; padding: 0 8px; font-size: 15px; }
.app.narrow .gd-summary .btn, .app.narrow .gd-before .btn { width: 100%; }
`;

export const STYLES = THEMES + SEASONAL + BASE;
