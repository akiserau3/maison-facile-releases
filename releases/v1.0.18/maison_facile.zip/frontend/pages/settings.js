import { Page, html, raw, dayAndTime, relTime, shortDate, copyText, timeHM, dateLong, fmtNum } from "../lib.js";
import { icon, deviceIcon } from "../icons.js";
import { typeInfo, roomColor, deviceStateText, buildHomeModel, findHeatingAlert } from "../components/model.js";
import { THEME_ORDER } from "../styles.js";
import { HOME_STYLE_DEFS, styleDef, themeDef, greeting, greetingHtml, wink, particlesHtml } from "../components/appearance.js";
import { effectiveTheme, toYMD } from "../components/theme-rules.js";
import { GuideSection } from "./guide.js";
import { validShopUrl, shopLink } from "../components/shop-url.js";
import { say, isPro } from "../components/audience.js";

const SECTIONS = [
  { id: "rooms", label: "Mes pièces" },
  { id: "devices", label: "Mes appareils" },
  { id: "automations", label: "Automatismes" },
  { id: "updates", label: "Mises à jour" },
  { id: "doctor", label: "Dépannage" },
  { id: "appearance", label: "Apparence" },
  { id: "guide", label: "Bien choisir ses appareils" },
  { id: "advanced", label: "Réglages avancés", admin: true },
];

/** Nombre de mises à jour à installer, pour le petit chiffre du menu : une version de
 * Maison Facile plus récente (sauf celle qui vient d'échouer) et/ou une version de Home
 * Assistant testée. Rien pendant une installation. */
export function updatesToInstall(s) {
  if (!s || RUNNING.has(s.phase)) return 0;
  const failed = s.last_failure?.version;
  const mf = s.mf?.available && s.mf.latest !== failed ? 1 : 0;
  const core = s.core?.available && s.core?.validated ? 1 : 0;
  return mf + core;
}

const SEVERITY_COLOR = { error: "#C42B1C", warning: "#F7630C", info: "#0067C0" };

const UPDATE_STEPS = [
  { phase: "backing_up", label: "Sauvegarde de votre maison" },
  { phase: "downloading", label: "Téléchargement de la nouvelle version" },
  { phase: "installing", label: "Installation de la nouvelle version" },
  { phase: "verifying", label: "Vérification que tout marche" },
  { phase: "restarting", label: "Redémarrage de la box" },
];
const RUNNING = new Set(UPDATE_STEPS.map((s) => s.phase));

function choiceLabel(c) {
  const l = c.label || String(c.value);
  return c.recommended && !/recommand/i.test(l) ? `${l} · Recommandé` : l;
}

// ===========================================================================
// Sub-pages
// ===========================================================================

class RoomsSection extends Page {
  init() {
    this.s = { rows: this.fromData(), dirty: false, newName: "" };
  }
  fromData() {
    return (this.data.rooms || []).map((r) => ({ area_id: r.area_id, name: r.name, color: r.color, icon: r.icon }));
  }
  dataChanged() {
    if (!this.s.dirty) this.s.rows = this.fromData();
    super.dataChanged();
  }
  template() {
    const rows = this.s.rows;
    return html`<div class="stack">
      <div><h2 class="sec-title">Mes pièces</h2><p class="sub" style="font-size:15px">Renommez, rangez dans l'ordre que vous voulez, ajoutez ou retirez une pièce.</p></div>
      <ul class="stack" style="list-style:none;margin:0;padding:0;gap:10px">
        ${rows.map((r, i) => html`<li class="list-item" data-key="${r.area_id || "new-" + i}">
          <span class="li-icon" style="background:${roomColor(r, i)}">${icon(r.icon, 22)}</span>
          <label class="grow" style="display:flex;flex-direction:column;gap:4px"><span class="sr-only">Nom de la pièce ${i + 1}</span>
            <input class="input" type="text" maxlength="50" value="${r.name}" data-field="name" data-index="${i}">
          </label>
          <button type="button" class="btn secondary sm" data-action="up" data-index="${i}" aria-label="Monter ${r.name}" ${i === 0 ? "disabled" : ""}>${icon("up", 20)}</button>
          <button type="button" class="btn secondary sm" data-action="down" data-index="${i}" aria-label="Descendre ${r.name}" ${i === rows.length - 1 ? "disabled" : ""}>${icon("down", 20)}</button>
          <button type="button" class="btn secondary sm" data-action="remove" data-index="${i}" aria-label="Retirer ${r.name}">${icon("trash", 20)}</button>
        </li>`)}
      </ul>
      <div class="add-room">
        <label class="grow" style="max-width:360px"><span class="sr-only">Nom de la nouvelle pièce</span><input class="input" type="text" maxlength="50" placeholder="Nouvelle pièce, par exemple : Buanderie" value="${this.s.newName}" data-field="new" data-enter="add"></label>
        <button type="button" class="btn secondary" data-action="add">${icon("plus", 20)}Ajouter</button>
      </div>
      <div class="row wrap">
        <button type="button" class="btn primary" data-action="save" ${!this.s.dirty || this.isBusy("save") ? "disabled" : ""}>${this.isBusy("save") ? "Enregistrement…" : "Enregistrer"}</button>
        ${this.s.dirty ? html`<button type="button" class="btn ghost" data-action="cancel">Annuler les changements</button>` : ""}
      </div>
      <p class="muted">Retirer une pièce ne supprime aucun appareil : ils restent dans « Mes appareils », sans pièce.</p>
    </div>`;
  }
  onInput(field, el) {
    if (field === "name") {
      this.s.rows[Number(el.dataset.index)].name = el.value;
      if (!this.s.dirty) this.setState({ dirty: true });
    } else if (field === "new") {
      this.s.newName = el.value;
    }
  }
  async onAction(action, el) {
    const rows = this.s.rows.slice();
    const i = Number(el.dataset.index);
    switch (action) {
      case "up":
        [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]];
        return this.setState({ rows, dirty: true });
      case "down":
        [rows[i + 1], rows[i]] = [rows[i], rows[i + 1]];
        return this.setState({ rows, dirty: true });
      case "remove":
        rows.splice(i, 1);
        return this.setState({ rows, dirty: true });
      case "add": {
        const name = (this.s.newName || "").trim();
        if (!name) return;
        rows.push({ name, icon: "room" });
        return this.setState({ rows, dirty: true, newName: "" });
      }
      case "cancel":
        return this.setState({ rows: this.fromData(), dirty: false });
      case "save": {
        const payload = this.s.rows.filter((r) => r.name.trim()).map((r) => (r.area_id ? { name: r.name.trim(), area_id: r.area_id } : { name: r.name.trim() }));
        return this.run("save", async () => {
          await this.api.setRooms(payload);
          this.s.dirty = false;
          this.s.rows = this.fromData();
          this.app.notify("C'est enregistré.");
        }, "Impossible d'enregistrer les pièces.");
      }
      default:
    }
  }
}

class DevicesSection extends Page {
  template() {
    const devices = this.data.devices || [];
    const rooms = this.data.rooms || [];
    for (const d of devices) Object.values(d.entities || {}).forEach((id) => this.st(id));
    return html`<div class="stack">
      <div class="row wrap" style="justify-content:space-between">
        <div><h2 class="sec-title">Mes appareils</h2><p class="sub" style="font-size:15px">${devices.length} appareil${devices.length > 1 ? "s" : ""}. Changez la pièce si elle est fausse.</p></div>
        <button type="button" class="btn primary sm" data-action="add">${icon("plus", 20)}Ajouter un appareil</button>
      </div>
      <ul class="stack" style="list-style:none;margin:0;padding:0;gap:10px">
        ${devices.map((d) => {
          const info = typeInfo(d.type);
          const low = typeof d.battery === "number" && d.battery < 15;
          const stateText = deviceStateText(this.hass, d);
          return html`<li class="list-item" data-key="${d.device_id}">
            <span class="li-icon" style="background:${info.color}">${icon(deviceIcon(d.type), 22)}</span>
            <span class="grow" style="display:flex;flex-direction:column"><strong class="li-title">${d.name}</strong><span class="li-sub">${d.type_label || info.label}${stateText ? ` · ${stateText}` : ""}${typeof d.battery === "number" ? ` · pile ${d.battery} %` : ""}</span></span>
            ${!d.available ? html`<span class="tag" style="background:#FFF0E2;color:#8A3B00">Ne répond plus</span>` : low ? html`<span class="tag" style="background:#FFF0E2;color:#8A3B00">Pile faible</span>` : ""}
            <label class="field-label">Pièce
              <select class="select" data-field="room" data-device="${d.device_id}" data-value="${d.area_id || ""}" ${this.isBusy(d.device_id) ? "disabled" : ""}>
                <option value="">Aucune</option>
                ${rooms.map((r) => html`<option value="${r.area_id}" ${r.area_id === d.area_id ? "selected" : ""}>${r.name}</option>`)}
              </select>
            </label>
          </li>`;
        })}
      </ul>
      ${devices.length === 0 ? html`<p class="glass card sub">Aucun appareil pour l'instant.</p>` : ""}
    </div>`;
  }
  onInput(field, el, ev) {
    if (field !== "room" || ev.type !== "change") return;
    const id = el.dataset.device;
    const area = el.value || null;
    this.run(id, () => this.api.assignDevice(id, area), "Impossible de changer la pièce de cet appareil.").then(() => this.render());
  }
  onAction(action) {
    if (action === "add") this.app.navigate("add", { back: "settings" });
  }
}

class AutomationsSection extends Page {
  init() {
    this.s = { items: null, error: false };
    this.load();
  }
  async load() {
    try {
      this.setState({ items: await this.api.listRecommendations(), error: false });
    } catch (e) {
      this.setState({ error: true });
    }
  }
  template() {
    const st = this.data.settings || {};
    let body;
    if (this.s.error) body = html`<div class="glass card"><p>Impossible de lire les automatismes.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div>`;
    else if (!this.s.items) body = html`<p class="sub">Chargement…</p>`;
    else if (!this.s.items.length) body = html`<p class="glass card sub">Aucun automatisme conseillé pour vos appareils pour l'instant.</p>`;
    else
      body = html`<div class="stack" style="gap:10px">${this.s.items.map((r) => html`<div class="stack" style="gap:8px" data-key="${r.id}">
        <button type="button" class="check-row" data-action="toggle" data-id="${r.id}" aria-pressed="${r.enabled ? "true" : "false"}" ${this.isBusy(r.id) ? "disabled" : ""}>
          <span class="check-box">${r.enabled ? icon("check", 18, { stroke: 3 }) : ""}</span>
          <span class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="cr-title">${r.title}</strong><span class="cr-why">${r.why}</span></span>
          ${r.recommended ? html`<span class="tag">Recommandé</span>` : ""}
        </button>
        ${r.enabled && (r.options || []).length
          ? (r.options || []).map((o) => html`<div class="row wrap" style="padding-left:60px;gap:10px"><span class="sub" style="font-size:15px">${o.label} :</span>
              ${(o.choices || []).map((c) => html`<button type="button" class="opt center" style="min-height:48px;padding:8px 14px;font-size:15px" data-action="option" data-id="${r.id}" data-key="${o.key}" data-value="${c.value}" aria-pressed="${String((r.values || {})[o.key]) === String(c.value) ? "true" : "false"}">${choiceLabel(c)}</button>`)}
            </div>`)
          : ""}
      </div>`)}</div>`;
    return html`<div class="stack">
      <div><h2 class="sec-title">Automatismes</h2><p class="sub" style="font-size:15px">Ce que la maison fait toute seule. Touchez pour activer ou couper.</p></div>
      ${body}
      <div class="glass card">
        <strong style="font-size:17px">Le mode nuit se déclenche…</strong>
        <div class="seg" role="group" aria-label="Déclenchement du mode nuit">
          <button type="button" class="opt center" data-action="night" data-value="hour" aria-pressed="${st.night_mode !== "voice" ? "true" : "false"}">Tous les soirs à ${(st.night_time || "23:00").replace(":00", " h").replace(":", " h ")} · Recommandé</button>
          <button type="button" class="opt center violet" data-action="night" data-value="voice" aria-pressed="${st.night_mode === "voice" ? "true" : "false"}">Seulement avec « Bonne nuit »</button>
        </div>
      </div>
    </div>`;
  }
  async apply(id, enabled, values) {
    return this.run(id, async () => {
      const items = await this.api.applyRecommendations([{ id, enabled, options: values || {} }]);
      if (items.length) this.s.items = items;
      else this.s.items = this.s.items.map((x) => (x.id === id ? { ...x, enabled, values } : x));
    }, "Impossible de changer cet automatisme.");
  }
  async onAction(action, el) {
    if (action === "retry") return this.load();
    if (action === "night") {
      return this.run("night", () => this.api.setSettings({ night_mode: el.dataset.value }).then(() => this.load()), "Impossible de changer le mode nuit.");
    }
    const r = (this.s.items || []).find((x) => x.id === el.dataset.id);
    if (!r) return;
    if (action === "toggle") return this.apply(r.id, !r.enabled, r.values);
    if (action === "option") return this.apply(r.id, true, { ...(r.values || {}), [el.dataset.key]: el.dataset.value });
  }
}

class UpdatesSection extends Page {
  init() {
    this.s = { status: null, error: false, live: null };
    this.load(true);
    this.subscribe();
  }
  async load(autoCheck = false) {
    try {
      const status = await this.api.updatesStatus();
      this.setState({ status, error: false });
      this.app.setUpdateCount?.(updatesToInstall(status));
      // À l'ouverture de la page : nouvelle vérification si la dernière date de plus d'une
      // heure (compte principal seulement ; la box limite à une vérification par 30 s).
      const last = Date.parse(status?.checked_at || "") || 0;
      if (autoCheck && this.app.isAdmin && Date.now() - last > 3600000 && !RUNNING.has(status?.phase)) {
        this.setState({ status: await this.api.checkUpdates() });
        this.app.setUpdateCount?.(updatesToInstall(this.s.status));
      }
    } catch (e) {
      if (!this.s.status) this.setState({ error: true });
    }
  }
  async subscribe() {
    try {
      const unsub = await this.api.subscribe("updates/subscribe", (msg) => {
        const prev = this.s.live?.phase;
        this.setState({ live: msg });
        if (msg && (msg.phase === "done" || msg.phase === "error" || msg.phase === "idle") && prev && prev !== msg.phase) this.load();
      });
      if (this.destroyed) unsub();
      else this.onCleanup(unsub);
    } catch (e) {
      /* status polling still works */
    }
  }
  template() {
    const s = this.s.status;
    if (this.s.error && !s) return html`<div class="stack"><h2 class="sec-title">Mises à jour</h2><div class="glass card"><p>Impossible de vérifier les mises à jour.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div></div>`;
    if (!s) return html`<div class="stack"><h2 class="sec-title">Mises à jour</h2><p class="sub">Chargement…</p></div>`;
    const phase = this.s.live?.phase || s.phase || "idle";
    const progress = this.s.live?.progress ?? s.progress ?? 0;
    const message = this.s.live?.message_fr || s.message_fr || "";
    const mode = this.data.settings?.update_mode || s.mode || "auto";
    return html`<div class="stack">
      <h2 class="sr-only">Mises à jour</h2>
      ${this.mainCard(s, phase, progress, message, mode)}
      ${s.core?.available && s.core?.validated && !RUNNING.has(phase)
        ? html`<div class="glass card row wrap" style="flex-direction:row"><span class="grow"><strong style="font-size:17px">Le système de la box peut être amélioré</strong><br><span class="sub" style="font-size:15px">${say(this.app, "Version testée par votre installateur.")}</span></span><button type="button" class="btn secondary sm" data-action="install" data-target="core">Installer</button></div>`
        : ""}
      <div class="status3">
        <div class="glass card" style="gap:6px"><span class="sub" style="font-size:15px">Système de la box</span>
          <strong style="font-size:18px" class="row"><span class="status-dot" style="background:${s.core?.available ? "#F7630C" : "#13A10E"}" aria-hidden="true"></span>${s.core?.available ? (s.core?.validated ? "Amélioration prête" : say(this.app, "En test chez l'installateur")) : "À jour"}</strong></div>
        <div class="glass card" style="gap:6px"><span class="sub" style="font-size:15px">Capteurs et prises</span>
          <strong style="font-size:18px" class="row"><span class="status-dot" style="background:${s.firmware?.pending ? "#F7630C" : "#13A10E"}" aria-hidden="true"></span>${s.firmware?.pending ? `${s.firmware.pending} en attente` : "À jour"}</strong></div>
        <div class="glass card" style="gap:6px"><span class="sub" style="font-size:15px">Dernière sauvegarde</span>
          <strong style="font-size:18px">${s.last_backup ? dayAndTime(s.last_backup) : "Pas encore"}</strong></div>
      </div>
      <div class="glass card">
        <strong style="font-size:18px">Comment installer les mises à jour ?</strong>
        <div class="seg" role="group" aria-label="Mode d'installation des mises à jour">
          <button type="button" class="opt green" data-action="mode" data-value="auto" aria-pressed="${mode === "auto" ? "true" : "false"}"><span>Toutes seules la nuit · Recommandé</span><span class="opt-sub">${say(this.app, "Seulement celles testées par votre installateur")}</span></button>
          <button type="button" class="opt" data-action="mode" data-value="ask" aria-pressed="${mode === "ask" ? "true" : "false"}"><span>Me demander avant</span><span class="opt-sub">Une notification arrive sur votre téléphone</span></button>
        </div>
      </div>
    </div>`;
  }
  mainCard(s, phase, progress, message, mode) {
    if (RUNNING.has(phase)) {
      const cur = UPDATE_STEPS.findIndex((x) => x.phase === phase);
      return html`<div class="update-card" style="flex-direction:column;gap:14px" aria-live="polite">
        <h2 style="font-size:24px;font-weight:800">Installation en cours…</h2>
        <p class="sub" style="font-size:16px">${message || "Vous pouvez continuer à utiliser vos interrupteurs normalement."}</p>
        <div class="steps-check">${UPDATE_STEPS.map((st, i) => html`<div class="step-line ${i < cur ? "done" : i === cur ? "cur" : ""}"><span class="sn">${i < cur ? icon("check", 18, { stroke: 3 }) : i + 1}</span>${st.label}</div>`)}</div>
        <div class="progress" role="progressbar" aria-label="Avancement" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(progress)}"><div style="width:${Math.max(3, Math.min(100, progress))}%"></div></div>
      </div>`;
    }
    if (phase === "error") {
      return html`<div class="update-card bad" style="align-items:center"><span class="big-badge" style="background:#C42B1C">${icon("warn", 34)}</span>
        <div class="grow stack" style="gap:6px"><h2 style="font-size:24px;font-weight:800">La mise à jour n'a pas pu se faire</h2><p class="sub" style="font-size:16px">${message || "Rien n'a été changé : votre maison fonctionne comme avant."}</p>
        <div class="row wrap"><button type="button" class="btn primary sm" data-action="install" data-target="${s.target || "mf"}">Réessayer</button><button type="button" class="btn ghost" data-action="go-doctor">Voir le dépannage</button>${this.app.isAdmin ? html`<button type="button" class="btn ghost" data-action="check-updates">Vérifier maintenant</button>` : ""}</div></div></div>`;
    }
    if (s.mf?.available) {
      return html`<div class="update-card">
        <span class="big-badge" style="background:#0067C0;box-shadow:0 8px 20px rgba(0,103,192,0.35)">${icon("download", 34)}</span>
        <div class="grow stack" style="gap:10px">
          <h2 style="font-size:24px;font-weight:800">Une amélioration est disponible</h2>
          <p class="sub" style="font-size:15px">Maison Facile ${s.mf.latest}${s.mf.validated_date ? say(this.app, ` · testée par votre installateur le ${shortDate(s.mf.validated_date)}`) : ""}</p>
          ${(s.mf.notes || []).length ? html`<ul style="margin:4px 0 0;padding-left:20px;display:flex;flex-direction:column;gap:6px;font-size:16px;line-height:1.4">${s.mf.notes.map((n) => html`<li>${n}</li>`)}</ul>` : ""}
          <div class="row wrap" style="margin-top:8px;gap:14px">
            <button type="button" class="btn primary" data-action="install" data-target="mf" ${this.isBusy("install") ? "disabled" : ""}>${this.isBusy("install") ? "Démarrage…" : "Installer maintenant"}</button>
            <span class="sub" style="font-size:15px">${mode === "auto" ? "Sinon, elle s'installera cette nuit vers 3 h. Durée : environ 5 minutes." : "Durée : environ 5 minutes. Une sauvegarde est faite avant."}</span>
          </div>
        </div>
      </div>`;
    }
    return html`<div class="update-card ok"><span class="big-badge round" style="background:#0E7A0D">${icon("check", 34, { stroke: 2.6 })}</span>
      <div class="stack" style="gap:4px"><h2 style="font-size:24px;font-weight:800">Tout est à jour</h2>
      <p class="sub" style="font-size:16px">${phase === "done" && message ? message : `Maison Facile ${s.mf?.installed || this.data.version || ""} est installée et tout fonctionne. Rien d'autre à faire.`}</p>
      ${s.error ? html`<p class="muted">Impossible de vérifier les nouveautés pour le moment. Nouvel essai plus tard.</p>` : s.checked_at ? html`<p class="muted">Dernière vérification : ${relTime(s.checked_at)}</p>` : ""}
      ${this.app.isAdmin ? html`<div class="row wrap" style="margin-top:6px"><button type="button" class="btn secondary sm" data-action="check-updates" ${this.isBusy("check") ? "disabled" : ""}>${icon("refresh", 20)}${this.isBusy("check") ? "Vérification…" : "Vérifier maintenant"}</button></div>` : ""}</div></div>`;
  }
  async onAction(action, el) {
    switch (action) {
      case "retry":
        return this.load();
      case "go-doctor":
        return this.app.page?.open?.("doctor");
      case "install":
        return this.run("install", async () => {
          await this.api.installUpdate(el.dataset.target);
          this.setState({ live: { phase: "backing_up", progress: 2, message_fr: "" } });
        }, "Impossible de lancer la mise à jour.");
      case "check-updates":
        return this.run("check", async () => {
          this.setState({ status: await this.api.checkUpdates() });
          this.app.setUpdateCount?.(updatesToInstall(this.s.status));
        }, "Impossible de vérifier les nouveautés pour le moment.");
      case "mode":
        return this.run("mode", () => this.api.setSettings({ update_mode: el.dataset.value }), "Impossible d'enregistrer ce choix.");
      default:
    }
  }
}

class DoctorSection extends Page {
  init() {
    this.s = { data: null, error: false, open: null, tech: {}, choice: {}, fixed: {}, report: null, reportError: false, copied: false };
    this.load(false);
  }
  async load(rescan) {
    try {
      const d = rescan ? await this.api.doctorRescan() : await this.api.doctorList();
      const firstOpen = (d.problems || []).find((p) => !p.notice && (p.fix?.kind !== "none" || p.steps?.length));
      this.setState({ data: d, error: false, fixed: {}, open: this.s.open && (d.problems || []).some((p) => p.id === this.s.open) ? this.s.open : firstOpen?.id || null });
      this.app.setProblemCount((d.problems || []).filter((p) => p.severity !== "info").length);
    } catch (e) {
      this.setState({ error: true });
    }
  }
  remaining() {
    return (this.s.data?.problems || []).filter((p) => !this.s.fixed[p.id] && !p.notice);
  }
  /** Soft notices (« Pas encore d'antenne Zigbee : c'est normal »): information, not problems. */
  notices() {
    return (this.s.data?.problems || []).filter((p) => p.notice);
  }
  template() {
    const d = this.s.data;
    if (this.s.error && !d) return html`<div class="stack"><h2 class="sec-title">Dépannage</h2><div class="glass card"><p>Impossible de lancer la vérification.</p><button type="button" class="btn secondary sm" data-action="rescan">Réessayer</button></div></div>`;
    if (!d) return html`<div class="stack"><h2 class="sec-title">Dépannage</h2><p class="sub"><span class="spinner" style="display:inline-block;vertical-align:middle;margin-right:10px"></span>Vérification de la maison…</p></div>`;
    const left = this.remaining().length;
    const real = (d.problems || []).filter((p) => !p.notice);
    const headline = left === 0 ? "Tout fonctionne, aucun problème" : d.headline && left === real.length ? d.headline : left === 1 ? "1 problème à régler" : `${left} problèmes à régler`;
    return html`<div class="stack" style="gap:12px">
      <div class="row wrap" style="justify-content:space-between">
        <div><h2 class="sec-title">${headline}</h2><p class="sub" style="font-size:15px">Dernière vérification : ${relTime(d.checked_at) || "à l'instant"}</p></div>
        <button type="button" class="btn secondary sm" data-action="rescan" ${this.isBusy("rescan") ? "disabled" : ""}>${icon("refresh", 20)}${this.isBusy("rescan") ? "Vérification…" : "Vérifier à nouveau"}</button>
      </div>
      ${this.notices().map((p) => this.notice(p))}
      ${left === 0 && !real.length ? html`<div class="update-card ok"><span class="big-badge round" style="background:#0E7A0D">${icon("check", 34, { stroke: 2.6 })}</span><p style="font-size:17px">${(this.data.devices || []).length ? "Tous vos appareils répondent et la box va bien." : "La box va bien."}</p></div>` : ""}
      ${real.map((p) => this.problem(p))}
      <div class="help-box">
        <span style="font-size:16px">Vous découvrez la box ? La visite guidée montre chaque partie de l'écran en une minute.</span>
        <button type="button" class="btn secondary sm" data-action="tour" style="white-space:nowrap">${icon("play", 20)}Revoir la visite guidée</button>
      </div>
      <div class="help-box">
        <span style="font-size:16px">${say(this.app, "Toujours bloqué ? Votre installateur reçoit le rapport complet, sans vos mots de passe.")}</span>
        <button type="button" class="btn violet sm" data-action="report" style="white-space:nowrap" ${this.isBusy("report") ? "disabled" : ""}>${icon("help", 20)}${this.isBusy("report") ? "Préparation…" : "Demander de l'aide"}</button>
      </div>
      ${this.s.report !== null ? this.reportDialog() : ""}
    </div>`;
  }
  notice(p) {
    const link = p.link || null;
    return html`<article class="notice-card" data-key="${p.id}" role="note" aria-labelledby="nc-${p.id}">
      <div class="row" style="gap:14px">
        <span class="nc-icon" aria-hidden="true">${icon("help", 24)}</span>
        <div class="grow" style="display:flex;flex-direction:column;gap:2px"><strong id="nc-${p.id}" class="nc-title">${p.title}</strong><span class="sub" style="font-size:15px">${p.status}</span></div>
      </div>
      ${p.why ? html`<p style="font-size:16px;line-height:1.45">${p.why}</p>` : ""}
      ${(p.steps || []).length ? html`<ol>${p.steps.map((x) => html`<li>${x}</li>`)}</ol>` : ""}
      ${link ? html`<div class="row wrap"><button type="button" class="btn primary" data-action="notice-link" data-id="${p.id}">${icon("plug", 20)}${link.label || "Voir"}</button></div>` : ""}
    </article>`;
  }
  problem(p) {
    const fixedMsg = this.s.fixed[p.id];
    const fixed = fixedMsg !== undefined;
    const open = this.s.open === p.id && !fixed;
    const color = fixed ? "#0E7A0D" : SEVERITY_COLOR[p.severity] || "#0067C0";
    const fix = p.fix || { kind: "none" };
    const choices = fix.choices || [];
    const choice = this.s.choice[p.id] ?? (choices.find((c) => c.recommended) || choices[0])?.value;
    const techOpen = !!this.s.tech[p.id];
    const actionBg = fix.kind === "manual" ? "#0067C0" : fix.kind === "auto" ? "#0E7A0D" : "#6B47B8";
    return html`<article class="problem" data-key="${p.id}" style="--p-color:${color};${fixed ? "border-color:rgba(14,122,13,0.35)" : ""}">
      <div class="row">
        <span class="p-badge">${icon(fixed ? "check" : "warn", 24, { stroke: fixed ? 2.6 : 2 })}</span>
        <div class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="p-title">${p.title}</strong><span class="sub" style="font-size:15px">${fixed ? fixedMsg || "Réparé, tout fonctionne" : p.status}</span></div>
        ${!fixed ? html`<button type="button" class="btn secondary sm" data-action="toggle" data-id="${p.id}" aria-expanded="${open ? "true" : "false"}">${open ? "Masquer" : "Voir comment réparer"}</button>` : ""}
      </div>
      ${open
        ? html`<div class="p-body">
          ${p.why ? html`<p class="p-why"><strong>Pourquoi ?</strong> ${p.why}</p>` : ""}
          ${(p.steps || []).length ? html`<ol>${p.steps.map((s) => html`<li>${s}</li>`)}</ol>` : ""}
          ${choices.length
            ? html`<div class="seg" role="group" aria-label="Choix de réparation" style="max-width:560px">${choices.map((c) => html`<button type="button" class="opt center" style="min-height:48px;font-size:15px" data-action="choice" data-id="${p.id}" data-value="${c.value}" aria-pressed="${String(choice) === String(c.value) ? "true" : "false"}">${choiceLabel(c)}</button>`)}</div>`
            : ""}
          <div class="row wrap">
            ${fix.kind === "none"
              ? html`<button type="button" class="btn violet" data-action="report">${icon("help", 20)}${fix.label || "Demander de l'aide"}</button>`
              : html`<button type="button" class="btn" style="background:${actionBg};color:#FFFFFF;box-shadow:0 8px 20px rgba(30,50,90,0.18)" data-action="fix" data-id="${p.id}" ${this.isBusy("fix-" + p.id) ? "disabled" : ""}>${icon("wrench", 20)}${this.isBusy("fix-" + p.id) ? "Un instant…" : fix.label || (fix.kind === "manual" ? "C'est fait, vérifier" : "Réparer pour moi")}</button>`}
            ${p.tech ? html`<button type="button" class="btn link" data-action="tech" data-id="${p.id}" aria-expanded="${techOpen ? "true" : "false"}">${say(this.app, "Détails pour l'installateur")}</button>` : ""}
          </div>
          ${techOpen ? html`<pre class="tech">${p.tech}</pre>` : ""}
        </div>`
        : ""}
    </article>`;
  }
  reportDialog() {
    return html`<div class="dialog-backdrop" data-action="close-report-bg">
      <div class="dialog" role="dialog" aria-modal="true" aria-labelledby="mf-report-title">
        <h2 id="mf-report-title" class="sec-title">${say(this.app, "Rapport pour votre installateur")}</h2>
        ${this.s.reportError
          ? html`<p style="font-size:16px">Le rapport n'a pas pu être préparé. Seul le compte principal de la maison peut le demander. ${say(this.app, "Appelez votre installateur, il saura vous aider.")}</p>`
          : html`<p class="sub" style="font-size:15px">${say(this.app, "Copiez ce texte et envoyez-le à votre installateur (par message ou par e-mail).")} Il ne contient ni mot de passe, ni code secret.</p>
            <label><span class="sr-only">Texte du rapport</span><textarea class="tech" readonly id="mf-report-text">${this.s.report}</textarea></label>`}
        <div class="row wrap">
          ${!this.s.reportError ? html`<button type="button" class="btn primary" data-action="copy">${icon(this.s.copied ? "check" : "copy", 20)}${this.s.copied ? "Copié !" : "Copier"}</button>` : ""}
          ${isPro(this.app) && this.app.data?.settings?.installer_contact ? html`<span class="sub">Votre installateur : ${this.app.data.settings.installer_name || ""} ${this.app.data.settings.installer_contact}</span>` : ""}
          <button type="button" class="btn secondary" data-action="close-report">Fermer</button>
        </div>
      </div>
    </div>`;
  }
  afterRender() {
    if (this.s.report !== null && !this._dialogFocused) {
      this._dialogFocused = true;
      const b = this.el.querySelector('.dialog [data-action="copy"], .dialog [data-action="close-report"]');
      b?.focus();
      this._esc = (ev) => {
        if (ev.key === "Escape") this.closeReport();
      };
      this.el.addEventListener("keydown", this._esc);
    }
  }
  closeReport() {
    this._dialogFocused = false;
    if (this._esc) this.el.removeEventListener("keydown", this._esc);
    this.setState({ report: null, reportError: false, copied: false });
    this.el.querySelector('[data-action="report"]')?.focus();
  }
  async onAction(action, el, ev) {
    const id = el.dataset.id;
    switch (action) {
      case "tour":
        return this.app.startTour();
      case "rescan":
        return this.run("rescan", () => this.load(true), "Impossible de vérifier à nouveau.");
      case "notice-link": {
        const link = (this.s.data?.problems || []).find((p) => p.id === el.dataset.id)?.link;
        if (!link?.page) return undefined;
        return this.app.navigate(link.page, { ...(link.params || {}), back: "settings", backParams: { section: "doctor" } });
      }
      case "toggle":
        return this.setState({ open: this.s.open === id ? null : id });
      case "tech":
        return this.setState({ tech: { ...this.s.tech, [id]: !this.s.tech[id] } });
      case "choice":
        return this.setState({ choice: { ...this.s.choice, [id]: el.dataset.value } });
      case "fix": {
        const p = (this.s.data.problems || []).find((x) => x.id === id);
        const choices = p?.fix?.choices || [];
        const choice = choices.length ? this.s.choice[id] ?? (choices.find((c) => c.recommended) || choices[0]).value : undefined;
        return this.run("fix-" + id, async () => {
          const r = await this.api.doctorFix(id, choice);
          if (r?.ok) {
            const fixed = { ...this.s.fixed, [id]: r.message_fr || "Réparé, tout fonctionne" };
            const next = (this.s.data.problems || []).find((x) => !fixed[x.id]);
            this.setState({ fixed, open: next ? next.id : null });
            this.app.setProblemCount(this.remaining().filter((x) => x.severity !== "info").length);
          } else {
            this.app.toast(r?.message_fr || "Ce n'est pas encore réparé.", null);
          }
        }, "Impossible de réparer ce problème.");
      }
      case "report":
        return this.run("report", async () => {
          try {
            const r = await this.api.doctorReport();
            this.setState({ report: r?.text || "", reportError: false, copied: false });
          } catch (e) {
            this.setState({ report: "", reportError: true });
          }
        }, "");
      case "copy": {
        const ta = this.el.querySelector("#mf-report-text");
        const ok = await copyText(this.s.report, ta);
        if (ok) this.setState({ copied: true });
        else this.app.toast("Impossible de copier. Sélectionnez le texte et copiez-le à la main.", null);
        return;
      }
      case "close-report":
        return this.closeReport();
      case "close-report-bg":
        if (ev.target === el) this.closeReport();
        return;
      default:
    }
  }
}

// Réglages › Apparence (mockup Themes.dc.html): theme of the day, 12 themes + contrast,
// small animations, and the playful « Style de l'accueil » tab (Maison Facile by default
// + Orbite, Néon, Jumeau 3D, Holo), with « Essayer » and a « J'aime » saved on the box.
const AUTO_CHOICES = [
  { id: "fetes_saisons", label: "Fêtes et saisons", hint: "Halloween, Noël… et le reste de l'année, la saison", recommended: true },
  { id: "fetes", label: "Seulement les fêtes", hint: "Votre thème habituel, sauf pendant les fêtes" },
  { id: "saisons", label: "Seulement les saisons", hint: "Printemps, été, automne, hiver" },
  { id: "non", label: "Non, merci", hint: "Le thème reste celui que vous choisissez" },
];

class AppearanceSection extends Page {
  init() {
    this.s = { tab: this.params.tab === "style" || this.params.section === "style" ? "style" : "theme" };
    // Tabs: arrow keys move between « Thème » and « Style de l'accueil » (WAI-ARIA tabs).
    this._onTabKey = (ev) => {
      const tab = ev.target.closest?.('[role="tab"]');
      if (!tab || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(ev.key)) return;
      ev.preventDefault();
      const next = this.s.tab === "theme" ? "style" : "theme";
      this.setState({ tab: next });
      this.el.querySelector(`[role="tab"][data-tab="${next}"]`)?.focus();
    };
    this.el.addEventListener("keydown", this._onTabKey);
    this.onCleanup(() => this.el?.removeEventListener("keydown", this._onTabKey));
  }

  get settings() {
    return this.data.settings || {};
  }

  template() {
    const tab = this.s.tab;
    const tabBtn = (id, label, extra = "") => html`<button type="button" role="tab" class="ap-tab" id="ap-tab-${id}" data-tab="${id}" data-action="tab" aria-controls="ap-panel-${id}" aria-selected="${tab === id ? "true" : "false"}" tabindex="${tab === id ? "0" : "-1"}">${label}${extra}</button>`;
    return html`<div class="stack">
      <div><h2 class="sec-title">Apparence</h2><p class="sub" style="font-size:15px">Le changement s'applique tout de suite, sur tous les écrans de la maison.</p></div>
      <div class="ap-tabs" role="tablist" aria-label="Apparence">
        ${tabBtn("theme", html`${icon("palette", 20)}Thème et couleurs`)}
        ${tabBtn("style", html`${icon("magic", 20)}Style de l'accueil`, html`<span class="ap-new">Nouveau</span>`)}
      </div>
      <div role="tabpanel" id="ap-panel-${tab}" aria-labelledby="ap-tab-${tab}" data-key="panel-${tab}">
        ${tab === "theme" ? this.themeTab() : this.styleTab()}
      </div>
    </div>`;
  }

  // ----- Thème ------------------------------------------------------------------

  themeTab() {
    const st = this.settings;
    const app = this.app.appearance || {};
    const auto = this.app.themePreview?.theme_auto || st.theme_auto || "fetes_saisons";
    const cur = this.app.theme;
    const def = themeDef(cur);
    const autoNote = app.reason_fr && app.reason_fr.startsWith("Choisi automatiquement") ? " (choisi automatiquement aujourd'hui)" : "";
    return html`<div class="ap-grid">
      <div class="stack" style="gap:14px">
        <section class="glass card">
          <h3 class="h2">Changer de thème tout seul ?</h3>
          <p class="sub" style="font-size:15px">Votre écran se met aux couleurs du moment. Vous pouvez toujours choisir à la main.</p>
          <div class="seg" role="group" aria-label="Changement automatique du thème">
            ${AUTO_CHOICES.map((a) => html`<button type="button" class="opt" data-action="auto" data-value="${a.id}" aria-pressed="${auto === a.id ? "true" : "false"}" ${this.isBusy("auto") ? "disabled" : ""}>
              <span>${a.label}</span><span class="opt-sub">${a.hint}${a.recommended ? " · Recommandé" : ""}</span></button>`)}
          </div>
        </section>
        <section class="glass card">
          <h3 class="h2">Choisir un thème</h3>
          <div class="ap-themes" role="group" aria-label="Thème de l'écran">
            ${THEME_ORDER.map((id) => {
              const t = themeDef(id);
              return html`<button type="button" class="ap-theme" data-action="theme" data-theme="${id}" aria-pressed="${cur === id ? "true" : "false"}" data-key="th-${id}">
                <span class="ap-swatch" style="background:${t.swatch}" aria-hidden="true"><i style="background:${t.accent}"></i></span>
                <span class="ap-theme-name">${t.name}</span>
              </button>`;
            })}
          </div>
          <p class="muted" role="status">${app.reason_fr || ""}</p>
        </section>
        <label class="check-row ap-anim">
          <span class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="cr-title">Petites animations (flocons, feuilles…)</strong>
          <span class="cr-why">Coupées automatiquement si l'appareil demande moins de mouvement</span></span>
          <input type="checkbox" data-field="animations" ${st.animations !== false ? "checked" : ""}>
        </label>
      </div>
      <section class="ap-preview-col" aria-label="Aperçu">
        <span class="ap-preview-label">Aperçu de l'accueil · ${def.name}${autoNote}</span>
        ${this.preview(cur)}
      </section>
    </div>`;
  }

  preview(themeId) {
    const get = (id) => this.st(id);
    const model = buildHomeModel(this.data, this.hass, get, { heatingAlert: findHeatingAlert(this.data, get) });
    const g = greeting(themeId, this.app.appearance, model.userName);
    const rooms = model.rooms.slice(0, 2);
    const anim = this.settings.animations !== false;
    return html`<div class="ap-preview" aria-hidden="true">
      ${anim ? raw(`<div class="ap-fx">${particlesHtml(themeId)}</div>`) : ""}
      <div class="ap-pv-head"><span class="ap-pv-clock">${timeHM(new Date())}</span><span><strong>${greetingHtml(g)}</strong><br><span class="sub">${dateLong(new Date())}</span></span></div>
      <div class="ap-pv-rooms">${rooms.map((r) => html`<div class="ap-pv-room ${r.on ? "on" : ""}"><span class="ap-pv-ic" style="background:${r.on ? "var(--accent)" : r.color};color:${r.on ? "var(--accent-text)" : "#FFFFFF"}">${icon(r.icon, 22)}</span><span><strong>${r.name}</strong><br><span class="sub">${r.temp !== null ? `${fmtNum(r.temp, 1)}° · ` : ""}${r.on ? "lumière allumée" : "éteinte"}</span></span></div>`)}</div>
      <div class="ap-pv-quick"><span class="q1">Tout éteindre</span><span class="q2">Je pars</span><span class="q3">Bonne nuit</span></div>
      <div class="ap-pv-wink"><i></i>${wink(themeId, this.app.appearance, model, get)}</div>
    </div>`;
  }

  // ----- Style de l'accueil ---------------------------------------------------------

  styleTab() {
    const saved = styleDef(this.settings.home_style).id;
    const trial = this.app.styleTrial;
    const liked = new Set(this.settings.liked_styles || []);
    const contrast = this.app.theme === "contraste";
    return html`<div class="stack" style="gap:14px">
      <p class="sub" style="font-size:16px;line-height:1.45">Changez le look de l'écran d'accueil, juste pour le plaisir. Les autres écrans ne changent pas.
        Essayez sans risque : un bandeau vous propose ensuite de garder le style ou de revenir.</p>
      ${contrast ? html`<p class="prep-note">Avec le thème « Contraste élevé », l'accueil reste en style Maison Facile, le plus lisible.</p>` : ""}
      <div class="ap-styles">
        ${HOME_STYLE_DEFS.map((d) => {
          const isSaved = saved === d.id;
          const isTrial = trial === d.id;
          const like = liked.has(d.id);
          return html`<article class="ap-style ${isSaved ? "current" : ""}" data-key="st-${d.id}" aria-labelledby="ap-st-${d.id}">
            <div class="ap-mini ap-mini-${d.id}" aria-hidden="true">${MINIS[d.id]}</div>
            <div class="row" style="align-items:flex-start;gap:10px">
              <div class="grow"><h3 id="ap-st-${d.id}" class="ap-style-name">${d.name}${d.id === "maison_facile" ? html` <span class="tag">Par défaut</span>` : ""}</h3><p class="sub" style="font-size:14px;line-height:1.35">${d.tagline}</p></div>
              <button type="button" class="ap-heart" data-action="like" data-style="${d.id}" aria-pressed="${like ? "true" : "false"}" aria-label="J'aime le style ${d.name}" ${this.isBusy("like") ? "disabled" : ""}>${raw(heartSvg(like))}</button>
            </div>
            <div class="row wrap" style="gap:8px">
              ${isSaved && !trial
                ? html`<span class="ap-current">${icon("check", 18, { stroke: 3 })}Style actuel</span>`
                : isTrial
                  ? html`<span class="ap-current trial">${icon("magic", 18)}En essai</span>`
                  : html`<button type="button" class="btn primary sm" data-action="try" data-style="${d.id}" ${contrast ? "disabled" : ""}>${icon("play", 20)}Essayer</button>`}
            </div>
          </article>`;
        })}
      </div>
      ${saved !== "maison_facile" || trial
        ? html`<div class="row wrap"><button type="button" class="btn secondary" data-action="back-mf" ${this.isBusy("back") ? "disabled" : ""}>${icon("back", 20)}Revenir à Maison Facile</button></div>`
        : ""}
      <p class="muted" style="font-size:14px;line-height:1.4">Vos « J'aime » sont gardés sur la box : ${say(this.app, "votre installateur les voit dans le rapport d'aide.")} Rien n'est envoyé sur Internet.</p>
    </div>`;
  }

  // ----- actions -------------------------------------------------------------------

  async save(key, patch, preview, errorText) {
    if (preview) this.app.previewTheme(preview);
    this.render();
    return this.run(key, async () => {
      try {
        await this.api.setSettings(patch);
        return true;
      } finally {
        if (preview) this.app.previewTheme(null);
      }
    }, errorText);
  }

  onInput(field, el, ev) {
    if (field !== "animations" || ev.type !== "change") return;
    const before = this.settings.animations !== false;
    const animations = !!el.checked;
    // Shown at once (the checkbox must not jump back while the box answers).
    this.api.patchState({ settings: { ...this.settings, animations } });
    this.save("anim", { animations }, null, "Impossible d'enregistrer ce choix.").then((ok) => {
      if (!ok) this.api.patchState({ settings: { ...this.settings, animations: before } });
    });
  }

  async onAction(action, el) {
    const st = this.settings;
    switch (action) {
      case "tab":
        return this.setState({ tab: el.dataset.tab });
      case "auto": {
        const theme_auto = el.dataset.value;
        return this.save("auto", { theme_auto }, { theme: st.theme, theme_auto }, "Impossible d'enregistrer ce choix.");
      }
      case "theme": {
        const theme = el.dataset.theme;
        // A theme picked by hand that the automatic change would replace today: stop it.
        const ymd = toYMD(this.data.appearance?.date || new Date());
        const wouldShow = effectiveTheme({ ...st, theme }, ymd).theme_effective;
        const patch = wouldShow === theme ? { theme } : { theme, theme_auto: "non" };
        await this.save("theme", patch, { theme_auto: patch.theme_auto || st.theme_auto, theme }, "Impossible d'enregistrer le thème.");
        if (patch.theme_auto === "non" && st.theme_auto !== "non") this.app.notify("Thème choisi à la main : le changement automatique est coupé.");
        return undefined;
      }
      case "like": {
        const id = el.dataset.style;
        const liked = new Set(st.liked_styles || []);
        if (liked.has(id)) liked.delete(id);
        else liked.add(id);
        return this.save("like", { liked_styles: HOME_STYLE_DEFS.map((d) => d.id).filter((x) => liked.has(x)) }, null, "Impossible d'enregistrer ce « J'aime ».");
      }
      case "try":
        return this.app.tryStyle(el.dataset.style);
      case "back-mf":
        this.app.endTrial();
        return this.save("back", { home_style: "maison_facile" }, null, "Impossible de revenir au style Maison Facile.");
      default:
    }
  }
}

function heartSvg(on) {
  return `<svg width="26" height="26" viewBox="0 0 24 24" fill="${on ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>`;
}

// Small animated previews of the styles (pure CSS, see styles.js « Apparence »).
const MINIS = {
  maison_facile: raw('<span class="mm-tile"></span><span class="mm-tile lit"></span><span class="mm-tile"></span><span class="mm-tile"></span>'),
  orbite: raw('<span class="mo-sun"></span><span class="mo-ring"><i></i><i></i><i></i></span>'),
  neon: raw('<span class="mn-tube"><i></i></span><span class="mn-tube"><i></i></span><span class="mn-tube"><i></i></span><span class="mn-tube"><i></i></span>'),
  jumeau: raw('<span class="mj-plane"><i></i><i class="lit"></i><i></i><i></i></span>'),
  holo: raw('<span class="mh-card"></span><span class="mh-card flip"><b></b></span>'),
};

// Installer area: Home Assistant itself, commercial mode, installer code (NOTES_commercial.md).
class AdvancedSection extends Page {
  init() {
    this.s = { status: null, error: false, pin: "", newPin: "", formError: "", shopUrl: this.data.settings?.shop_url || "", shopError: "" };
    this.load();
    // Keep "encore N min" fresh.
    this.every(30000, () => this.render());
  }
  async load() {
    try {
      this.setState({ status: await this.api.advancedStatus(), error: false });
    } catch (e) {
      this.setState({ error: true });
    }
    if (this.app.isAdmin) {
      try {
        this.setState({ expert: await this.api.expertStatus() });
      } catch (e) {
        /* ancienne box ou pas admin : la carte s'affiche sans le détail du fichier */
      }
    }
  }
  dataChanged() {
    // Unlock / lock / expiry seen by the panel: same view here.
    const adv = this.data.advanced || {};
    if (this.s.status) this.s.status = { ...this.s.status, ...adv };
    super.dataChanged();
  }
  template() {
    const intro = html`<div><h2 class="sec-title">Réglages avancés</h2>
      <p class="sub" style="font-size:16px;line-height:1.45;max-width:640px">${say(this.app, "Ces réglages sont pour votre installateur.")} Une mauvaise manipulation peut empêcher la maison de fonctionner.</p></div>`;
    const st = this.s.status;
    if (this.s.error && !st) return html`<div class="stack">${intro}<div class="glass card"><p>Impossible de lire ces réglages.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div></div>`;
    if (!st) return html`<div class="stack">${intro}<p class="sub">Chargement…</p></div>`;
    const open = st.unlocked || !st.commercial_mode;
    return html`<div class="stack">${intro}${open ? this.openView(st) : this.lockedView(st)}</div>`;
  }
  /** Mode Expert : Home Assistant déjà configuré, rien de caché ni changé sans accord. */
  expertCard() {
    const on = this.app.api.state?.settings?.expert_mode === true;
    const x = this.s.expert;
    return html`<button type="button" class="check-row" data-action="expert" aria-pressed="${on ? "true" : "false"}" ${this.isBusy("expert") ? "disabled" : ""} data-key="expert">
        <span class="check-box">${on ? icon("check", 18, { stroke: 3 }) : ""}</span>
        <span class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="cr-title">Mode Expert</strong>
        <span class="cr-why">Pour un Home Assistant déjà configuré : rien n'est caché, chaque idée montre ce qu'elle va créer avant de le faire, aucun appareil n'est renommé, Home Assistant n'est jamais mis à jour tout seul, et vos automatismes ne sont jamais touchés.</span></span>
      </button>
      ${on && x
        ? html`<div class="glass card stack" style="gap:10px" data-key="expert-file">
            <strong style="font-size:17px">Où vont les automatismes de Maison Facile</strong>
            <span class="sub" style="font-size:15px">${x.separate
              ? html`Dans un fichier à part, <code>${x.file}</code> : votre <code>automations.yaml</code> n'est jamais modifié.`
              : html`Dans <code>automations.yaml</code>, à côté des vôtres (seuls ceux dont l'identifiant commence par <code>mf_</code> sont gérés). ${x.blocked ? "Votre fichier contient des commentaires : il ne sera pas réécrit tant que le fichier à part n'est pas déclaré." : ""}`}</span>
            ${x.separate ? "" : html`<span class="sub" style="font-size:15px">Pour un fichier à part, ajoutez cette ligne dans <code>configuration.yaml</code>, puis redémarrez :</span>
              <pre class="tech">${x.include_line}</pre>
              <div class="row wrap"><button type="button" class="btn secondary sm" data-action="copy-include">${icon("copy", 18)}Copier la ligne</button></div>`}
          </div>`
        : ""}`;
  }

  lockedView(st) {
    const err = this.s.formError;
    return html`<div class="glass card stack" style="gap:14px;max-width:640px" data-key="locked">
      <div class="row" style="gap:14px"><span class="li-icon" style="background:#5D6B7A">${icon("lock", 22)}</span>
        <span class="grow"><strong style="font-size:18px">Home Assistant est caché</strong><br><span class="sub" style="font-size:15px">Votre maison s'utilise entièrement depuis Maison Facile.</span></span></div>
      ${st.pin_set
        ? html`<label class="field-label" style="display:flex;flex-direction:column;gap:6px;align-items:flex-start">${say(this.app, "Code de l'installateur")}
            <input class="input pin-input" type="password" inputmode="numeric" autocomplete="off" maxlength="8" data-field="pin" data-enter="unlock" value="${this.s.pin}" aria-describedby="mf-adv-err" aria-invalid="${err ? "true" : "false"}">
          </label>`
        : ""}
      ${err ? html`<p class="form-error" id="mf-adv-err" role="alert">${err}</p>` : ""}
      <div class="row wrap"><button type="button" class="btn violet" data-action="unlock" ${this.isBusy("unlock") ? "disabled" : ""}>${icon("wrench", 20)}${this.isBusy("unlock") ? "Vérification…" : "Ouvrir les réglages avancés"}</button></div>
    </div>`;
  }
  openView(st) {
    const n = this.app.unlockMinutesLeft;
    const err = this.s.formError;
    return html`
      ${st.unlocked
        ? html`<div class="install-banner" role="status" data-key="banner"><span class="ib-text">${icon("wrench", 22)}${say(this.app, "Mode installateur actif")}${n ? ` (encore ${n} min)` : ""}</span>
            <button type="button" class="btn secondary sm" data-action="home">Revenir à Ma maison</button>
            <button type="button" class="btn primary sm" data-action="lock" ${this.isBusy("lock") ? "disabled" : ""}>${icon("lock", 20)}Verrouiller</button></div>`
        : html`<div class="install-banner" role="status" data-key="banner"><span class="ib-text">${icon("warn", 22)}Mode commercial désactivé : toute l'interface de Home Assistant est visible.</span></div>`}
      <div class="glass card row wrap" style="flex-direction:row;gap:14px" data-key="ha">
        <span class="grow"><strong style="font-size:18px">Home Assistant</strong><br><span class="sub" style="font-size:15px">Intégrations, appareils, journaux, sauvegardes… Revenez ensuite avec « Ma maison » dans le menu.</span></span>
        <button type="button" class="btn primary" data-action="open-ha">Ouvrir Home Assistant</button>
      </div>
      <button type="button" class="check-row" data-action="commercial" aria-pressed="${st.commercial_mode ? "true" : "false"}" ${this.isBusy("commercial") ? "disabled" : ""} data-key="commercial">
        <span class="check-box">${st.commercial_mode ? icon("check", 18, { stroke: 3 }) : ""}</span>
        <span class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="cr-title">Mode commercial</strong>
        <span class="cr-why">Le client ne voit que Maison Facile : la box s'ouvre sur « Ma maison » et Home Assistant reste derrière ces réglages.</span></span>
        <span class="tag">Recommandé</span>
      </button>
      ${this.expertCard(st)}
      <div class="glass card stack" style="gap:12px" data-key="pin">
        <strong style="font-size:18px">${say(this.app, "Code de l'installateur")}</strong>
        <span class="sub" style="font-size:15px">${st.pin_set ? "Un code protège l'ouverture de ces réglages." : "Aucun code : le compte principal de la maison peut ouvrir ces réglages."} 4 à 8 chiffres, enregistré chiffré.</span>
        <div class="row wrap" style="gap:12px">
          <label><span class="sr-only">${st.pin_set ? "Nouveau code" : "Code à définir"}</span><input class="input pin-input" type="password" inputmode="numeric" autocomplete="new-password" maxlength="8" placeholder="${st.pin_set ? "Nouveau code" : "Code"}" data-field="newpin" data-enter="save-pin" value="${this.s.newPin}"></label>
          <button type="button" class="btn secondary" data-action="save-pin" ${this.isBusy("pin") ? "disabled" : ""}>${st.pin_set ? "Changer le code" : "Définir le code"}</button>
          ${st.pin_set ? html`<button type="button" class="btn ghost" data-action="clear-pin" ${this.isBusy("pin") ? "disabled" : ""}>Supprimer le code</button>` : ""}
        </div>
        ${err ? html`<p class="form-error" role="alert">${err}</p>` : ""}
      </div>
      ${this.shopCard()}`;
  }
  /** « Où l'acheter ? » of the buying guide: empty = button hidden (NOTES_guide.md). */
  shopCard() {
    const saved = this.data.settings?.shop_url || "";
    const draft = this.s.shopUrl;
    const example = shopLink(validShopUrl(draft) ? draft : saved, "ouverture");
    const err = this.s.shopError;
    return html`<div class="glass card stack" style="gap:12px" data-key="shop">
      <strong style="font-size:18px">Lien « Où l'acheter ? »</strong>
      <span class="sub" style="font-size:15px;line-height:1.45">Pour le guide « Bien choisir ses appareils ». Adresse https d'un site de conseils d'achat (le vôtre ou celui de la communauté). Vide : le bouton est masqué. Écrivez <code>{need}</code> pour y mettre le type d'appareil (ouverture, prise…).</span>
      <span class="sub" style="font-size:14px">Pas de lien affilié dans la box : gardez-les sur votre site.</span>
      <label class="stack" style="gap:6px"><span class="field-label">Adresse du site</span>
        <input class="input" type="url" inputmode="url" autocomplete="off" spellcheck="false" maxlength="500" placeholder="https://exemple.org/guide?appareil={need}" data-field="shop" data-enter="save-shop" value="${draft}" aria-describedby="mf-shop-help${err ? " mf-shop-err" : ""}" aria-invalid="${err ? "true" : "false"}">
      </label>
      <span class="muted" id="mf-shop-help">${example ? html`Exemple pour un détecteur d'ouverture : <span class="gd-url">${example}</span>` : saved ? "" : "Aucun lien : le bouton « Où l'acheter ? » n'apparaît pas."}</span>
      ${err ? html`<p class="form-error" id="mf-shop-err" role="alert">${err}</p>` : ""}
      <div class="row wrap" style="gap:12px">
        <button type="button" class="btn secondary" data-action="save-shop" ${this.isBusy("shop") || draft.trim() === saved ? "disabled" : ""}>Enregistrer le lien</button>
        ${saved ? html`<button type="button" class="btn ghost" data-action="clear-shop" ${this.isBusy("shop") ? "disabled" : ""}>Retirer le lien</button>` : ""}
      </div>
    </div>`;
  }
  async saveShop(value) {
    const url = validShopUrl(value);
    if (url === null) return this.setState({ shopError: "L'adresse doit commencer par https:// et ne contenir ni espace ni guillemet. Seul {need} est permis entre accolades." });
    return this.run("shop", async () => {
      await this.api.setSettings({ shop_url: url });
      this.setState({ shopUrl: url, shopError: "" });
      this.app.notify(url ? "Le lien « Où l'acheter ? » est enregistré." : "Le lien « Où l'acheter ? » est retiré.");
    }, "Impossible d'enregistrer ce lien.");
  }
  onInput(field, el) {
    if (field === "shop") {
      this.s.shopUrl = el.value;
      if (this.s.shopError) this.setState({ shopError: "" });
      else this.requestRender();
      return;
    }
    if (field === "pin") this.s.pin = el.value;
    else if (field === "newpin") this.s.newPin = el.value;
    if (this.s.formError) this.setState({ formError: "" });
  }
  async onAction(action) {
    switch (action) {
      case "retry":
        return this.load();
      case "unlock":
        return this.run("unlock", async () => {
          try {
            await this.api.unlockAdvanced(this.s.status?.pin_set ? this.s.pin : undefined);
          } catch (err) {
            this.setState({ formError: this.app.errorText(err, "Impossible d'ouvrir les réglages avancés."), pin: "" });
            return;
          }
          this.s.pin = "";
          this.s.formError = "";
          await this.load();
        }, "Impossible d'ouvrir les réglages avancés.");
      case "lock":
        return this.run("lock", () => this.app.lockAdvanced().then(() => this.load()), "Impossible de verrouiller.");
      case "save-shop":
        return this.saveShop(this.s.shopUrl);
      case "clear-shop":
        return this.saveShop("");
      case "home":
        return this.app.navigate("home");
      case "open-ha":
        return this.app.openHomeAssistant();
      case "expert": {
        const next = this.app.api.state?.settings?.expert_mode !== true;
        return this.run("expert", async () => {
          await this.api.setSettings({ expert_mode: next });
          await this.load();
          this.app.notify(next ? "Mode Expert activé : rien n'est caché ni changé sans votre accord." : "Mode Expert désactivé.");
        }, "Impossible de changer le mode Expert.");
      }
      case "copy-include": {
        const line = this.s.expert?.include_line || "";
        try {
          await navigator.clipboard.writeText(line);
          this.app.notify("Ligne copiée.");
        } catch (e) {
          this.app.notify("Copie impossible : sélectionnez la ligne à la main.");
        }
        return undefined;
      }
      case "commercial": {
        const next = !this.s.status?.commercial_mode;
        return this.run("commercial", async () => {
          await this.api.setCommercialMode(next);
          await this.load();
          this.app.notify(next ? "Mode commercial activé." : "Mode commercial désactivé.");
        }, "Impossible de changer le mode commercial.");
      }
      case "save-pin":
      case "clear-pin": {
        const pin = action === "clear-pin" ? "" : (this.s.newPin || "").trim();
        if (action === "save-pin" && !/^[0-9]{4,8}$/.test(pin)) return this.setState({ formError: "Le code doit contenir 4 à 8 chiffres." });
        return this.run("pin", async () => {
          await this.api.setInstallerPin(pin);
          this.s.newPin = "";
          await this.load();
          this.app.notify(say(this.app, pin ? "Le code de l'installateur est enregistré." : "Le code de l'installateur est supprimé."));
        }, "Impossible d'enregistrer le code.");
      }
      default:
    }
  }
}

const SECTION_PAGES = {
  rooms: RoomsSection,
  devices: DevicesSection,
  automations: AutomationsSection,
  updates: UpdatesSection,
  doctor: DoctorSection,
  appearance: AppearanceSection,
  guide: GuideSection,
  advanced: AdvancedSection,
};

// ===========================================================================
// Settings shell
// ===========================================================================

export class SettingsPage extends Page {
  init() {
    this.s = { section: this.allowed(this.params.section) ? this.params.section : "updates" };
    this.sub = null;
  }

  /** Sections shown to this account ("Réglages avancés": admins only). */
  sections() {
    return SECTIONS.filter((s) => !s.admin || this.app.isAdmin);
  }

  allowed(id) {
    return !!SECTION_PAGES[id] && this.sections().some((s) => s.id === id);
  }

  template() {
    const count = this.app.problemCount;
    return html`
      <header class="settings-head">
        <button type="button" class="icon-btn" data-action="home" aria-label="Retour à l'accueil">${icon("back", 24)}</button>
        <h1>Réglages</h1>
      </header>
      <div class="settings-body">
        <nav class="settings-nav glass" aria-label="Rubriques des réglages">
          ${this.sections().map((s) => html`<a href="#" data-key="${s.id}" data-action="section" data-section="${s.id}" ${this.s.section === s.id ? html`aria-current="page"` : ""}>${s.label}${s.id === "doctor" && count > 0 ? html`<span class="count" aria-label="${count} à régler">${count}</span>` : ""}${s.id === "updates" && this.app.updateCount > 0 ? html`<span class="count info" aria-label="${this.app.updateCount} à installer">${this.app.updateCount}</span>` : ""}</a>`)}
        </nav>
        <main class="settings-main" data-key="main-${this.s.section}"><div data-sub="${this.s.section}" data-morph-skip></div></main>
      </div>`;
  }

  afterRender() {
    const host = this.el.querySelector("[data-sub]");
    if (!host) return;
    if (this.sub && this.sub.el === host) return;
    if (this.sub) this.sub.destroy();
    this.children = [];
    const Sub = SECTION_PAGES[this.s.section];
    this.sub = new Sub(this.app, this.params);
    this.children.push(this.sub);
    this.sub.mount(host);
  }

  problemCountChanged() {
    this.requestRender();
  }

  open(section) {
    if (!this.allowed(section)) return;
    if (this.sub) this.sub.destroy();
    this.sub = null;
    this.children = [];
    this.params = {};
    this.setState({ section });
    this.el.querySelector(".settings-main")?.focus?.();
  }

  onAction(action, el) {
    if (action === "home") return this.app.navigate("home");
    if (action === "section") return this.open(el.dataset.section);
  }
}

