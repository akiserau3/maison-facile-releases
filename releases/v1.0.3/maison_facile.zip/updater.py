"""Safe updates for Maison Facile and Home Assistant core (CONTRACT §8).

Maison Facile install pipeline (each step reported as a phase):
backing_up -> downloading (+ sha256) -> verifying (extract, isolated compile check
in a subprocess, manifest.json, HA config check) -> installing (atomic swap) ->
restarting. ``update.pending`` in the store lets the next start tell whether the new
version is the one running.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from collections.abc import Callable
from datetime import timedelta
from pathlib import Path
from typing import Any

import aiohttp

from homeassistant.components import persistent_notification
from homeassistant.config import async_check_ha_config_file
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import __version__ as HA_VERSION
from homeassistant.core import CALLBACK_TYPE, HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.event import async_track_time_change, async_track_time_interval
from homeassistant.util import dt as dt_util

from . import versioning
from .backup_helper import async_create_backup
from .const import DEFAULT_VERSIONS_URL, DOMAIN, EVENT_UPDATE_PROGRESS, VERSION

_LOGGER = logging.getLogger(__name__)

CORE_UPDATE_ENTITY = "update.home_assistant_core_update"
CHECK_INTERVAL = timedelta(hours=6)
FETCH_TIMEOUT = aiohttp.ClientTimeout(total=30)
DOWNLOAD_TIMEOUT = aiohttp.ClientTimeout(total=600, sock_read=60)
MAX_ARCHIVE_BYTES = 50 * 1024 * 1024
MAX_EXTRACTED_BYTES = 200 * 1024 * 1024
NIGHTLY_HOUR = 3
NOTIFICATION_ID = "maison_facile_update"

PHASE_IDLE = "idle"
PHASE_BACKING_UP = "backing_up"
PHASE_DOWNLOADING = "downloading"
PHASE_INSTALLING = "installing"
PHASE_VERIFYING = "verifying"
PHASE_RESTARTING = "restarting"
PHASE_DONE = "done"
PHASE_ERROR = "error"
BUSY_PHASES = {PHASE_BACKING_UP, PHASE_DOWNLOADING, PHASE_INSTALLING, PHASE_VERIFYING, PHASE_RESTARTING}

TARGETS = ("mf", "core")

ProgressListener = Callable[[dict[str, Any]], None]


class UpdateError(HomeAssistantError):
    """Install failure; ``str(err)`` is a French sentence for the user."""


class SwapError(UpdateError):
    """Folder swap failure; ``files_changed`` tells if the installed files differ now."""

    def __init__(self, message: str, files_changed: bool) -> None:
        super().__init__(message)
        self.files_changed = files_changed


MSG_UNCHANGED = "Rien n'a été modifié, l'ancienne version continue de fonctionner."
MSG_MANUAL_RESTORE = (
    "La box est dans un état incomplet : votre installateur doit remettre l'ancienne version "
    "(dossier maison_facile.bak)."
)
VERIFY_TIMEOUT = 180  # seconds for the isolated compile check


# --------------------------------------------------------------------------- file helpers (executor)

_DISABLED_MANIFEST = "manifest.json.disabled"


def _safe_extract(archive: Path, dest: Path) -> Path:
    """Extract ``archive`` into ``dest`` (zip-slip/symlink/size safe). Returns the package root."""
    total = 0
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            name = info.filename
            parts = Path(name).parts
            if name.startswith(("/", "\\")) or ".." in parts or (parts and ":" in parts[0]):
                raise UpdateError("L'archive de mise à jour contient un chemin dangereux.")
            if stat.S_ISLNK(info.external_attr >> 16):
                raise UpdateError("L'archive de mise à jour contient un lien interdit.")
            total += info.file_size
            if total > MAX_EXTRACTED_BYTES:
                raise UpdateError("L'archive de mise à jour est anormalement grosse.")
        zf.extractall(dest)
    if (dest / "manifest.json").is_file():
        return dest
    # Tolerate an archive whose content sits in a single top-level folder.
    subdirs = [p for p in dest.iterdir() if p.is_dir() and not p.name.startswith("__")]
    if len(subdirs) == 1 and (subdirs[0] / "manifest.json").is_file():
        return subdirs[0]
    raise UpdateError("L'archive ne contient pas de fichier manifest.json.")


# Runs in a separate Python process (same interpreter as HA) so a broken release can
# never affect the running Home Assistant. argv: package root, expected domain, version.
_VERIFY_SCRIPT = r"""
import json, pathlib, py_compile, sys, tempfile
root = pathlib.Path(sys.argv[1])
sys.path.insert(0, str(root.parent))
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
if manifest.get("domain") != sys.argv[2]:
    sys.exit("domain mismatch: %r" % manifest.get("domain"))
if manifest.get("version") != sys.argv[3]:
    sys.exit("version mismatch: %r" % manifest.get("version"))
if not (root / "__init__.py").is_file():
    sys.exit("missing __init__.py")
with tempfile.TemporaryDirectory() as out:
    for i, path in enumerate(sorted(root.rglob("*.py"))):
        py_compile.compile(str(path), cfile=str(pathlib.Path(out) / ("%d.pyc" % i)), doraise=True)
print("ok")
"""


def _verify_isolated(root: Path, expected_version: str) -> None:
    """Compile every .py and read manifest.json in a subprocess (executor only)."""
    try:
        proc = subprocess.run(  # noqa: S603 - fixed interpreter and script, paths as argv
            [sys.executable, "-I", "-c", _VERIFY_SCRIPT, str(root), DOMAIN, expected_version],
            capture_output=True,
            text=True,
            timeout=VERIFY_TIMEOUT,
            check=False,
            cwd=str(root.parent),
        )
    except (OSError, subprocess.TimeoutExpired) as err:
        _LOGGER.error("Isolated check could not run: %s", err)
        raise UpdateError("La vérification de la nouvelle version n'a pas pu se faire. " + MSG_UNCHANGED) from err
    if proc.returncode != 0 or proc.stdout.strip() != "ok":
        _LOGGER.error("New release failed the isolated check: %s", (proc.stderr or proc.stdout)[-2000:])
        raise UpdateError("La nouvelle version contient une erreur : elle n'est pas installée. " + MSG_UNCHANGED)


def _swap_dirs(new_root: Path, target: Path, backup: Path) -> None:
    """Replace ``target`` by ``new_root``; the old one becomes ``backup``.

    The old manifest is renamed first so Home Assistant never sees two integrations
    with the same domain. Every step is undone if a later one fails.
    Raises :class:`SwapError` with ``files_changed`` reflecting the real state.
    """
    try:
        if backup.exists():
            shutil.rmtree(backup)
        manifest = target / "manifest.json"
        os.replace(manifest, target / _DISABLED_MANIFEST)
    except OSError as err:
        _LOGGER.error("Swap preparation failed: %s", err)
        raise SwapError("Impossible de préparer le remplacement des fichiers. " + MSG_UNCHANGED, False) from err

    def _undo_manifest() -> bool:
        try:
            os.replace(target / _DISABLED_MANIFEST, target / "manifest.json")
        except OSError:
            _LOGGER.exception("Could not restore manifest.json")
            return False
        return True

    try:
        os.replace(target, backup)
    except OSError as err:
        _LOGGER.error("Could not move current version aside: %s", err)
        if _undo_manifest():
            raise SwapError("Impossible de mettre l'ancienne version de côté. " + MSG_UNCHANGED, False) from err
        raise SwapError(MSG_MANUAL_RESTORE, True) from err

    try:
        os.replace(new_root, target)
    except OSError as err:
        _LOGGER.error("Could not move new version in place: %s", err)
        try:
            os.replace(backup, target)
        except OSError:
            _LOGGER.exception("Could not put the old version back")
            raise SwapError(MSG_MANUAL_RESTORE, True) from err
        if _undo_manifest():
            raise SwapError("Impossible de mettre la nouvelle version en place. " + MSG_UNCHANGED, False) from err
        raise SwapError(MSG_MANUAL_RESTORE, True) from err


def _write_file(path: Path, chunks: list[bytes]) -> None:
    with path.open("wb") as handle:
        for chunk in chunks:
            handle.write(chunk)


# --------------------------------------------------------------------------- Updater


class Updater:
    """Checks the release manifest, exposes status and runs installs."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        self.hass = hass
        self.entry = entry
        self.manifest: dict[str, Any] | None = None
        self.manifest_error: str | None = None
        self.checked_at: str | None = None
        self.phase: str = PHASE_IDLE
        self.progress: int = 0
        self.message_fr: str = ""
        self.target: str | None = None
        self._listeners: list[ProgressListener] = []
        self._lock = asyncio.Lock()
        self._files_changed = False
        self._notified: set[str] = set()
        self.package_dir = Path(__file__).resolve().parent
        self.backup_dir = self.package_dir.with_name(f"{self.package_dir.name}.bak")

    # ------------------------------------------------------------------ store access

    @property
    def _store(self) -> Any | None:
        return getattr(getattr(self.entry, "runtime_data", None), "store", None)

    @property
    def _settings(self) -> dict[str, Any]:
        store = self._store
        return store.data.get("settings", {}) if store else {}

    @property
    def _update_data(self) -> dict[str, Any]:
        store = self._store
        return store.data.setdefault("update", {}) if store else {}

    async def _save(self) -> None:
        if self._store is not None:
            await self._store.async_save()

    @property
    def mode(self) -> str:
        return self._settings.get("update_mode", "auto")

    @property
    def channel(self) -> str:
        return self._settings.get("update_channel", "stable")

    @property
    def last_failure(self) -> dict[str, Any] | None:
        return self._update_data.get("last_failure")

    @property
    def busy(self) -> bool:
        return self.phase in BUSY_PHASES

    # ------------------------------------------------------------------ lifecycle

    async def async_start(self) -> None:
        unsubs = [
            async_track_time_interval(self.hass, self._async_periodic_check, CHECK_INTERVAL),
            async_track_time_change(self.hass, self._async_nightly, hour=NIGHTLY_HOUR, minute=0, second=0),
        ]
        for unsub in unsubs:
            self.entry.async_on_unload(unsub)
        await self._async_check_pending()
        await self._async_cleanup_after_restart()
        self.entry.async_create_background_task(
            self.hass, self.async_refresh(), f"{DOMAIN}_initial_update_check"
        )

    async def _async_check_pending(self) -> None:
        """After our restart: is the new version the one running? (end of setup)."""
        pending = self._update_data.pop("pending", None)
        if not pending:
            return
        if pending.get("version") == VERSION:
            self._update_data["last_install"] = {
                "target": "mf",
                "from": pending.get("previous_version"),
                "version": VERSION,
                "at": pending.get("at"),
            }
            self._update_data.pop("last_failure", None)
            self.phase, self.progress = PHASE_DONE, 100
            self.message_fr = f"Maison Facile {VERSION} est installée et tout fonctionne."
        else:
            # Another version is running: the old one was put back (by hand or restore).
            _LOGGER.warning("Pending update to %s not running (running %s)", pending.get("version"), VERSION)
            self._update_data["last_failure"] = {
                "target": "mf",
                "version": pending.get("version"),
                "phase": PHASE_RESTARTING,
                "error": f"version {pending.get('version')} attendue, {VERSION} en cours d'exécution (retour arrière)",
                "at": dt_util.utcnow().isoformat(),
            }
            self.phase, self.progress = PHASE_ERROR, 0
            self.message_fr = "La nouvelle version n'a pas démarré : l'ancienne fonctionne toujours."
        await self._save()

    async def _async_cleanup_after_restart(self) -> None:
        """Show "done" right after a core update, forget failures fixed since."""
        last = self._update_data.get("last_install") or {}
        at = dt_util.parse_datetime(last.get("at") or "")
        if at and dt_util.utcnow() - at < timedelta(hours=1) and self.phase == PHASE_IDLE:
            if last.get("target") == "core":
                self.phase, self.progress = PHASE_DONE, 100
                self.message_fr = "Le système de la box est à jour et tout fonctionne."
        failure = self.last_failure
        if failure and failure.get("target") == "mf" and not versioning.is_newer(failure.get("version"), VERSION):
            self._update_data.pop("last_failure", None)
            await self._save()

    async def _async_periodic_check(self, _now: Any = None) -> None:
        await self.async_refresh()

    async def async_check_now(self) -> None:
        """Bouton « Vérifier maintenant » : relit versions.json tout de suite.

        Rien pendant une installation ; au plus une vérification toutes les 30 s.
        """
        if self.busy:
            return
        last = dt_util.parse_datetime(self.checked_at or "")
        if last and dt_util.utcnow() - last < timedelta(seconds=30):
            return
        await self.async_refresh()

    async def _async_nightly(self, _now: Any = None) -> None:
        if self.mode != "auto" or self.busy:
            return
        await self.async_refresh()
        target: str | None = None
        if self._mf_info()["available"]:
            target = "mf"
        else:
            core = self._core_info()
            if core["available"] and core["validated"]:
                target = "core"
        if target is None:
            return
        _LOGGER.info("Nightly automatic install of %s", target)
        try:
            await self.async_install(target)
        except UpdateError as err:
            _LOGGER.warning("Nightly install of %s failed: %s", target, err)

    # ------------------------------------------------------------------ manifest

    async def async_refresh(self) -> None:
        """Download and validate the release manifest. Never raises."""
        url = self._settings.get("versions_url") or DEFAULT_VERSIONS_URL
        self.checked_at = dt_util.utcnow().isoformat()
        if not versioning.is_https_url(url):
            self.manifest_error = "L'adresse du fichier des versions doit commencer par https://"
            self._notify_listeners()
            return
        try:
            session = async_get_clientsession(self.hass)
            async with session.get(url, timeout=FETCH_TIMEOUT) as resp:
                resp.raise_for_status()
                data = await resp.json(content_type=None)
            self.manifest = versioning.validate_manifest(data)
            self.manifest_error = None
        except versioning.ManifestError as err:
            self.manifest_error = f"Fichier des versions invalide : {err}"
            _LOGGER.warning("Invalid versions manifest: %s", err)
        except (aiohttp.ClientError, TimeoutError, ValueError) as err:
            self.manifest_error = "Impossible de vérifier les mises à jour (pas de connexion internet ?)"
            _LOGGER.info("Cannot fetch versions manifest: %s", err)
        await self._async_remember_validated_core()
        self._async_notify_if_needed()
        self._notify_listeners()

    async def _async_remember_validated_core(self) -> None:
        release = versioning.channel_release(self.manifest, self.channel)
        value = release.get("max_ha_validated") if release else None
        if value and self._update_data.get("validated_core_max") != value:
            self._update_data["validated_core_max"] = value
            await self._save()

    # ------------------------------------------------------------------ status

    def _release(self) -> dict[str, Any] | None:
        return versioning.pick_release(self.manifest, self.channel, HA_VERSION)

    def _mf_info(self) -> dict[str, Any]:
        release = self._release()
        latest = release["version"] if release else None
        return {
            "installed": VERSION,
            "latest": latest or VERSION,
            "available": versioning.is_newer(latest, VERSION),
            "notes": list(release["notes_fr"]) if release else [],
            "validated_date": release.get("validated_date") if release else None,
            "channel": self.channel,
        }

    def _core_info(self) -> dict[str, Any]:
        state = self.hass.states.get(CORE_UPDATE_ENTITY)
        installed = HA_VERSION
        latest = installed
        if state is not None:
            installed = state.attributes.get("installed_version") or installed
            latest = state.attributes.get("latest_version") or installed
        max_validated = self._update_data.get("validated_core_max")
        release = versioning.channel_release(self.manifest, self.channel)
        if release:
            max_validated = release.get("max_ha_validated")
        return {
            "installed": installed,
            "latest": latest,
            "available": state is not None and versioning.is_newer(latest, installed),
            "validated": versioning.core_update_allowed(latest, max_validated),
        }

    def _firmware_pending(self) -> int:
        return sum(
            1
            for st in self.hass.states.async_all("update")
            if st.state == "on" and st.attributes.get("device_class") == "firmware"
        )

    def status(self) -> dict[str, Any]:
        """Payload of ``updates/status`` (CONTRACT §5, plus a few extra keys)."""
        return {
            "mf": self._mf_info(),
            "core": self._core_info(),
            "firmware": {"pending": self._firmware_pending()},
            "last_backup": self._update_data.get("last_backup"),
            "mode": self.mode,
            "phase": self.phase,
            "progress": self.progress,
            # extras
            "message_fr": self.message_fr,
            "target": self.target,
            "checked_at": self.checked_at,
            "error": self.manifest_error,
            "last_install": self._update_data.get("last_install"),
            "last_failure": self.last_failure,
        }

    # ------------------------------------------------------------------ progress

    @callback
    def async_add_listener(self, listener: ProgressListener) -> CALLBACK_TYPE:
        self._listeners.append(listener)

        @callback
        def _remove() -> None:
            if listener in self._listeners:
                self._listeners.remove(listener)

        return _remove

    def _progress_payload(self) -> dict[str, Any]:
        return {"phase": self.phase, "progress": self.progress, "message_fr": self.message_fr}

    @callback
    def _notify_listeners(self) -> None:
        payload = self._progress_payload()
        for listener in list(self._listeners):
            try:
                listener(payload)
            except Exception:  # noqa: BLE001 - a broken subscriber must not stop installs
                _LOGGER.exception("Update progress listener failed")

    @callback
    def _set_phase(self, phase: str, progress: int, message_fr: str) -> None:
        self.phase, self.progress, self.message_fr = phase, max(0, min(100, progress)), message_fr
        self.hass.bus.async_fire(EVENT_UPDATE_PROGRESS, {**self._progress_payload(), "target": self.target})
        self._notify_listeners()

    @callback
    def _async_notify_if_needed(self) -> None:
        if self.mode != "ask":
            return
        lines: list[str] = []
        mf = self._mf_info()
        if mf["available"] and f"mf:{mf['latest']}" not in self._notified:
            self._notified.add(f"mf:{mf['latest']}")
            notes = "".join(f"\n- {n}" for n in mf["notes"])
            lines.append(f"Une amélioration de Maison Facile est prête (version {mf['latest']}).{notes}")
        core = self._core_info()
        if core["available"] and core["validated"] and f"core:{core['latest']}" not in self._notified:
            self._notified.add(f"core:{core['latest']}")
            lines.append(f"Une mise à jour du système de la box, testée par votre installateur, est prête ({core['latest']}).")
        if not lines:
            return
        lines.append("\nOuvrez « Ma maison » › Réglages › Mises à jour, puis appuyez sur « Installer maintenant ». "
                     "Une sauvegarde est faite avant, comme toujours.")
        persistent_notification.async_create(
            self.hass, "\n\n".join(lines), title="Mise à jour disponible", notification_id=NOTIFICATION_ID
        )

    # ------------------------------------------------------------------ install

    async def async_start_install(self, target: str) -> None:
        """Validate then run the install in the background (used by websocket)."""
        self._precheck(target)
        self.target = target
        # Mark busy synchronously so a second request is refused right away.
        self._set_phase(PHASE_BACKING_UP, 0, "Préparation de la mise à jour…")
        self.entry.async_create_background_task(
            self.hass, self._async_install_quiet(target), f"{DOMAIN}_install_{target}"
        )

    async def _async_install_quiet(self, target: str) -> None:
        try:
            await self._async_run(target)
        except UpdateError:
            pass  # already reported through phase "error"

    def _precheck(self, target: str) -> None:
        if target not in TARGETS:
            raise UpdateError("Mise à jour inconnue.")
        if self.busy or self._lock.locked():
            raise UpdateError("Une mise à jour est déjà en cours.")
        if target == "mf" and not self._mf_info()["available"]:
            raise UpdateError("Maison Facile est déjà à jour.")
        if target == "core":
            core = self._core_info()
            if not core["available"]:
                raise UpdateError("Le système de la box est déjà à jour.")
            if not core["validated"]:
                raise UpdateError("Cette version du système n'a pas encore été testée par votre installateur.")

    async def async_install(self, target: str) -> None:
        """Run an install and wait for it. Raises :class:`UpdateError` (French)."""
        self._precheck(target)
        await self._async_run(target)

    async def _async_run(self, target: str) -> None:
        async with self._lock:
            self.target = target
            self._files_changed = False
            self._update_data.pop("last_failure", None)
            try:
                if target == "mf":
                    await self._async_install_mf()
                else:
                    await self._async_install_core()
            except UpdateError as err:
                await self._async_fail(target, str(err))
                raise
            except Exception as err:  # noqa: BLE001 - never leave a half-done state silent
                _LOGGER.exception("Unexpected error while installing %s", target)
                await self._async_fail(target, "Erreur inattendue pendant la mise à jour.", repr(err))
                if self._files_changed:
                    raise UpdateError(
                        "Erreur inattendue après la mise en place des fichiers : redémarrez la box. "
                        "Si elle ne revient pas, votre installateur remettra l'ancienne version."
                    ) from err
                raise UpdateError("Erreur inattendue pendant la mise à jour. " + MSG_UNCHANGED) from err

    async def _async_fail(self, target: str, message: str, detail: str | None = None) -> None:
        version = self._mf_info()["latest"] if target == "mf" else self._core_info()["latest"]
        self._update_data["last_failure"] = {
            "target": target,
            "version": version,
            "phase": self.phase,
            "error": detail or message,
            "at": dt_util.utcnow().isoformat(),
        }
        await self._save()
        self._set_phase(PHASE_ERROR, self.progress, message)

    async def _async_backup(self) -> None:
        self._set_phase(PHASE_BACKING_UP, 5, "Sauvegarde de votre maison…")
        result = await async_create_backup(self.hass, self.entry)
        if not result.ok:
            raise UpdateError(result.message_fr)

    async def _async_install_mf(self) -> None:
        release = self._release()
        if release is None:
            raise UpdateError("Aucune version compatible avec votre box.")
        version: str = release["version"]

        await self._async_backup()
        archive_bytes = await self._async_download(release["url"], release["sha256"])

        self._set_phase(PHASE_VERIFYING, 60, "Vérification de la nouvelle version…")
        custom_components = self.package_dir.parent
        staging = Path(
            await self.hass.async_add_executor_job(
                lambda: tempfile.mkdtemp(prefix=f".{DOMAIN}_new_", dir=custom_components)
            )
        )
        try:
            try:
                archive_path = staging / "release.zip"
                await self.hass.async_add_executor_job(_write_file, archive_path, archive_bytes)
                new_root = await self.hass.async_add_executor_job(
                    _safe_extract, archive_path, staging / "content"
                )
            except zipfile.BadZipFile as err:
                raise UpdateError("Le fichier téléchargé est abîmé. " + MSG_UNCHANGED) from err
            except OSError as err:
                _LOGGER.error("Cannot write/extract the release: %s", err)
                raise UpdateError("Impossible d'écrire la nouvelle version sur la box. " + MSG_UNCHANGED) from err

            await self.hass.async_add_executor_job(_verify_isolated, new_root, version)

            config_error = await async_check_ha_config_file(self.hass)
            if config_error:
                _LOGGER.error("HA configuration invalid, update cancelled: %s", config_error)
                raise UpdateError("La configuration de la box contient une erreur, la mise à jour est annulée.")

            self._set_phase(PHASE_INSTALLING, 80, "Installation de la nouvelle version…")
            try:
                await self.hass.async_add_executor_job(_swap_dirs, new_root, self.package_dir, self.backup_dir)
            except SwapError as err:
                self._files_changed = err.files_changed
                raise
            self._files_changed = True
        finally:
            await self.hass.async_add_executor_job(shutil.rmtree, staging, True)

        self._update_data["pending"] = {
            "version": version,
            "previous_version": VERSION,
            "at": dt_util.utcnow().isoformat(),
        }
        await self._save()
        await self._async_restart()

    async def _async_download(self, url: str, expected_sha256: str) -> list[bytes]:
        self._set_phase(PHASE_DOWNLOADING, 30, "Téléchargement de la nouvelle version…")
        hasher = hashlib.sha256()
        chunks: list[bytes] = []
        size = 0
        try:
            session = async_get_clientsession(self.hass)
            async with session.get(url, timeout=DOWNLOAD_TIMEOUT) as resp:
                resp.raise_for_status()
                total = resp.content_length or 0
                if total > MAX_ARCHIVE_BYTES:
                    raise UpdateError("Le fichier de mise à jour est anormalement gros.")
                last_reported = 30
                async for chunk in resp.content.iter_chunked(64 * 1024):
                    size += len(chunk)
                    if size > MAX_ARCHIVE_BYTES:
                        raise UpdateError("Le fichier de mise à jour est anormalement gros.")
                    hasher.update(chunk)
                    chunks.append(chunk)
                    if total:
                        pct = 30 + int(25 * size / total)
                        if pct > last_reported:
                            last_reported = pct
                            self._set_phase(PHASE_DOWNLOADING, pct, "Téléchargement de la nouvelle version…")
        except (aiohttp.ClientError, TimeoutError) as err:
            _LOGGER.warning("Download failed: %s", err)
            raise UpdateError("Le téléchargement a échoué. Vérifiez la connexion internet.") from err
        if hasher.hexdigest() != expected_sha256.lower():
            raise UpdateError("Le fichier téléchargé n'est pas celui attendu (empreinte différente) : installation refusée.")
        return chunks

    async def _async_install_core(self) -> None:
        core = self._core_info()
        self._set_phase(PHASE_BACKING_UP, 5, "Sauvegarde de votre maison…")
        # update.install with backup=True lets the Supervisor make the backup itself.
        self._set_phase(PHASE_INSTALLING, 30, "Installation de la mise à jour du système…")
        try:
            await self.hass.services.async_call(
                "update",
                "install",
                {"entity_id": CORE_UPDATE_ENTITY, "backup": True},
                blocking=True,
            )
        except HomeAssistantError as err:
            _LOGGER.error("Core update failed: %s", err)
            raise UpdateError("La mise à jour du système de la box a échoué. Rien n'a été modifié.") from err
        self._update_data["last_install"] = {
            "target": "core", "from": core["installed"], "version": core["latest"], "at": dt_util.utcnow().isoformat()
        }
        await self._save()
        # The Supervisor restarts Home Assistant itself.
        self._set_phase(PHASE_RESTARTING, 95, "Redémarrage de la box…")

    async def _async_restart(self) -> None:
        self._set_phase(PHASE_RESTARTING, 95, "Redémarrage de la box… Elle revient dans une minute.")
        try:
            await self.hass.services.async_call("homeassistant", "restart", {}, blocking=True)
        except HomeAssistantError as err:
            # Files are in place; the new version starts at the next restart ("pending" kept).
            _LOGGER.error("Restart refused: %s", err)
            raise UpdateError(
                "La nouvelle version est prête mais la box a refusé de redémarrer. "
                "Redémarrez-la (débranchez-la 10 secondes) pour terminer."
            ) from err


async def async_setup_updater(hass: HomeAssistant, entry: ConfigEntry) -> Updater:
    """Create the updater, schedule checks (startup, every 6 h) and the 03:00 run."""
    updater = Updater(hass, entry)
    await updater.async_start()
    return updater
