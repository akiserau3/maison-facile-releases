"""Page « Applications » : installer, démarrer et ouvrir les applications HAOS choisies.

La logique (catalogue, bouton à afficher) est dans apps_rules.py. Ici : lecture de l'état sur
le Supervisor, installation en tâche de fond (sauvegarde d'abord, puis dépôt, installation,
démarrage), et commandes websocket (compte principal seulement).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.hassio import is_hassio

from . import apps_rules as ar
from .backup_helper import async_create_backup
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)
DATA_APPS = f"{DOMAIN}_apps"  # hass.data : {"busy": {id: {"step", "error"}}, "lock": Lock}


def _runtime(hass: HomeAssistant) -> dict[str, Any]:
    return hass.data.setdefault(DATA_APPS, {"busy": {}, "lock": asyncio.Lock(), "tasks": set()})


def _client(hass: HomeAssistant) -> Any:
    from homeassistant.components.hassio import get_supervisor_client  # noqa: PLC0415

    return get_supervisor_client(hass)


async def async_app_info(hass: HomeAssistant, slug: str) -> dict[str, Any]:
    """État d'une application : not_installed / not_running / running (+ version, page)."""
    from aiohasupervisor import SupervisorError  # noqa: PLC0415

    client = _client(hass)
    try:
        store = await client.store.addon_info(slug)
    except SupervisorError:
        return {"state": "not_installed"}  # dépôt pas encore ajouté : rien d'installé
    if not store.installed:
        return {"state": "not_installed"}
    try:
        info = await client.addons.addon_info(slug)
    except SupervisorError:
        return {"state": "unknown"}
    started = str(getattr(info.state, "value", info.state)) == "started"
    return {
        "state": "running" if started else "not_running",
        "version": info.version,
        "update_available": bool(getattr(info, "update_available", False)),
        "ingress_url": getattr(info, "ingress_url", None) if getattr(info, "ingress", False) else None,
    }


async def async_list(hass: HomeAssistant) -> dict[str, Any]:
    if not is_hassio(hass):
        return {"available": False, "message": ar.MSG["not_haos"], "apps": []}
    busy = _runtime(hass)["busy"]
    infos = await asyncio.gather(*(async_app_info(hass, a["slug"]) for a in ar.CATALOG), return_exceptions=True)
    apps = []
    for app, info in zip(ar.CATALOG, infos, strict=True):
        if isinstance(info, BaseException):
            _LOGGER.debug("App %s: %s", app["slug"], info)
            info = {"state": "unknown"}
        apps.append(ar.app_payload(app, info, busy.get(app["id"])))
    return {"available": True, "message": "", "apps": apps}


async def _async_ensure_repository(hass: HomeAssistant, url: str) -> None:
    from aiohasupervisor.models import StoreAddRepository  # noqa: PLC0415

    client = _client(hass)
    repositories = await client.store.repositories_list()
    known = {str(r.source).rstrip("/").lower() for r in repositories}
    if url.lower() not in known:
        await client.store.add_repository(StoreAddRepository(repository=url))


async def _async_install(hass: HomeAssistant, entry: Any, app: dict[str, Any]) -> None:
    """Sauvegarde → dépôt → installation → démarrage. Les erreurs restent sur la tuile."""
    from aiohasupervisor import SupervisorError  # noqa: PLC0415

    rt = _runtime(hass)
    busy = rt["busy"]
    name = app["name"]
    try:
        async with rt["lock"]:
            busy[app["id"]] = {"step": "backup"}
            result = await async_create_backup(hass, entry)
            if not result.ok:
                busy[app["id"]] = {"error": ar.MSG["backup_failed"]}
                return
            if app["repository"]:
                busy[app["id"]] = {"step": "repository"}
                try:
                    await _async_ensure_repository(hass, app["repository"])
                except SupervisorError as err:
                    _LOGGER.warning("App %s: repository %s: %s", app["slug"], app["repository"], err)
                    busy[app["id"]] = {"error": ar.MSG["repository_failed"].format(name=name)}
                    return
            busy[app["id"]] = {"step": "install"}
            client = _client(hass)
            try:
                await client.store.install_addon(app["slug"])
            except SupervisorError as err:
                _LOGGER.warning("App %s: install failed: %s", app["slug"], err)
                busy[app["id"]] = {"error": ar.MSG["install_failed"].format(name=name)}
                return
            busy[app["id"]] = {"step": "start"}
            try:
                await client.addons.start_addon(app["slug"])
            except SupervisorError as err:
                # Certaines applications demandent un réglage avant de démarrer (Samba…).
                _LOGGER.info("App %s installed, not started: %s", app["slug"], err)
            busy.pop(app["id"], None)
            _LOGGER.info("App %s installed", app["slug"])
    except Exception:  # noqa: BLE001 - jamais de tâche qui meurt en silence
        _LOGGER.exception("App %s: install failed", app["slug"])
        busy[app["id"]] = {"error": ar.MSG["install_failed"].format(name=name)}


def _entry(hass: HomeAssistant) -> Any | None:
    entries = hass.config_entries.async_entries(DOMAIN)
    return entries[0] if entries else None


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/apps/list"})
@websocket_api.async_response
async def ws_apps_list(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    connection.send_result(msg["id"], await async_list(hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/apps/install", vol.Required("app_id"): vol.In(list(ar.BY_ID))}
)
@callback
def ws_apps_install(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    """Lance l'installation en tâche de fond ; la page relit apps/list pour suivre."""
    if not is_hassio(hass):
        connection.send_error(msg["id"], "not_supported", ar.MSG["not_haos"])
        return
    rt = _runtime(hass)
    if rt["lock"].locked():
        connection.send_error(msg["id"], "busy", ar.MSG["busy"])
        return
    app = ar.BY_ID[msg["app_id"]]
    entry = _entry(hass)
    rt["busy"][app["id"]] = {"step": "backup"}
    task = hass.async_create_background_task(_async_install(hass, entry, app), f"{DOMAIN}_app_install_{app['id']}")
    rt["tasks"].add(task)
    task.add_done_callback(rt["tasks"].discard)
    connection.send_result(msg["id"], {"started": True})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/apps/start", vol.Required("app_id"): vol.In(list(ar.BY_ID))}
)
@websocket_api.async_response
async def ws_apps_start(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    from aiohasupervisor import SupervisorError  # noqa: PLC0415

    app = ar.BY_ID[msg["app_id"]]
    if not is_hassio(hass):
        connection.send_error(msg["id"], "not_supported", ar.MSG["not_haos"])
        return
    try:
        await _client(hass).addons.start_addon(app["slug"])
    except SupervisorError as err:
        _LOGGER.warning("App %s: start failed: %s", app["slug"], err)
        connection.send_error(msg["id"], "start_failed", ar.MSG["start_failed"].format(name=app["name"]))
        return
    _runtime(hass)["busy"].pop(app["id"], None)
    connection.send_result(msg["id"], await async_list(hass))


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in (ws_apps_list, ws_apps_install, ws_apps_start):
        websocket_api.async_register_command(hass, command)
