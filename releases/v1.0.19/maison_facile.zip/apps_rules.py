"""Page « Applications » : la sélection Maison Facile d'applications HAOS (logique pure, sans HA).

Une application (ex-« module complémentaire » de Home Assistant OS) s'installe depuis la
boutique du Supervisor. Maison Facile en propose une courte liste choisie, expliquée en
français, avec un seul bouton qui change selon l'état : Installer → Démarrer → Ouvrir.
Avant chaque installation, une sauvegarde complète est faite (backup_helper.py).

Identifiants (slug) : préfixe = 8 premiers caractères du SHA-1 de l'adresse du dépôt
(règle du Supervisor), « core_ » pour les applications officielles.
Tests : tests/test_apps_rules.py.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from typing import Any

COMMUNITY_REPO = "https://github.com/hassio-addons/repository"

# Champs : id (court, stable), slug, repository (None = boutique officielle), name, icon,
# color, category, what (une phrase), why (à quoi ça sert chez soi), level (facile /
# intermédiaire / avancé), needs (ce qu'il faut avant, facultatif), opens (a une page).
CATALOG: tuple[dict[str, Any], ...] = (
    {
        "id": "music_assistant",
        "slug": "d5369777_music_assistant",
        "repository": "https://github.com/music-assistant/home-assistant-addon",
        "name": "Music Assistant",
        "icon": "music",
        "color": "#C2185B",
        "category": "Musique",
        "what": "Toute votre musique sur toutes vos enceintes.",
        "why": "Spotify, Deezer, Tidal, YouTube Music, radios et vos fichiers, sur les enceintes et télés de la maison. Avec les paroles et un mode karaoké.",
        "level": "facile",
        "needs": "",
        "opens": True,
    },
    {
        "id": "zigbee2mqtt",
        "slug": "45df7312_zigbee2mqtt",
        "repository": "https://github.com/zigbee2mqtt/hassio-zigbee2mqtt",
        "name": "Zigbee2MQTT",
        "icon": "signal",
        "color": "#E8590C",
        "category": "Appareils",
        "what": "Une autre façon de gérer vos capteurs Zigbee.",
        "why": "Accepte encore plus de modèles de capteurs. Maison Facile utilise déjà le Zigbee intégré : ne l'installez que si un capteur n'est pas reconnu.",
        "level": "avancé",
        "needs": "L'application Mosquitto, et l'antenne Zigbee libérée du Zigbee intégré.",
        "opens": True,
    },
    {
        "id": "mosquitto",
        "slug": "core_mosquitto",
        "repository": None,
        "name": "Mosquitto",
        "icon": "chat",
        "color": "#5D6B7A",
        "category": "Appareils",
        "what": "Le facteur qui transporte les messages de certains appareils.",
        "why": "Nécessaire pour Zigbee2MQTT et pour les appareils « MQTT » (certains Shelly, Tasmota…).",
        "level": "intermédiaire",
        "needs": "",
        "opens": False,
    },
    {
        "id": "frigate",
        "slug": "ccab4aaf_frigate",
        "repository": "https://github.com/blakeblackshear/frigate-hass-addons",
        "name": "Frigate",
        "icon": "camera",
        "color": "#00838F",
        "category": "Sécurité",
        "what": "Vos caméras reconnaissent les personnes, les voitures, les animaux.",
        "why": "Enregistre seulement ce qui compte et envoie une alerte « personne devant la porte », sans cloud.",
        "level": "avancé",
        "needs": "Des caméras IP (RTSP) et un PC assez puissant.",
        "opens": True,
    },
    {
        "id": "esphome",
        "slug": "5c53de3b_esphome",
        "repository": "https://github.com/esphome/home-assistant-addon",
        "name": "ESPHome",
        "icon": "devices",
        "color": "#6B47B8",
        "category": "Bricolage",
        "what": "Créez vos propres capteurs avec de petites cartes électroniques.",
        "why": "Pour les bricoleurs : une carte ESP32 à quelques euros devient un capteur de votre choix.",
        "level": "avancé",
        "needs": "Une carte ESP32 ou ESP8266.",
        "opens": True,
    },
    {
        "id": "node_red",
        "slug": "a0d7b954_nodered",
        "repository": COMMUNITY_REPO,
        "name": "Node-RED",
        "icon": "magic",
        "color": "#C42B1C",
        "category": "Automatismes",
        "what": "Des automatismes avancés en reliant des blocs.",
        "why": "Pour aller plus loin que les idées de Maison Facile, en dessinant des schémas.",
        "level": "avancé",
        "needs": "",
        "opens": True,
    },
    {
        "id": "file_editor",
        "slug": "core_configurator",
        "repository": None,
        "name": "Éditeur de fichiers",
        "icon": "wrench",
        "color": "#0067C0",
        "category": "Outils",
        "what": "Modifier les fichiers de configuration depuis le navigateur.",
        "why": "Utile pour suivre un tutoriel qui demande d'ajouter une ligne dans configuration.yaml.",
        "level": "intermédiaire",
        "needs": "",
        "opens": True,
    },
    {
        "id": "samba",
        "slug": "core_samba",
        "repository": None,
        "name": "Partage réseau (Samba)",
        "icon": "download",
        "color": "#0E7A0D",
        "category": "Outils",
        "what": "Voir les dossiers de la box depuis votre PC.",
        "why": "Récupérer une sauvegarde ou déposer un fichier, comme une clé USB sur le réseau.",
        "level": "intermédiaire",
        "needs": "Choisir un nom d'utilisateur et un mot de passe dans ses réglages.",
        "opens": False,
    },
)
BY_ID: dict[str, dict[str, Any]] = {a["id"]: a for a in CATALOG}
LEVELS = ("facile", "intermédiaire", "avancé")
STATES = ("not_installed", "installing", "updating", "not_running", "running", "unknown")

MSG = {
    "not_haos": "Les applications s'installent seulement sur Home Assistant OS (la box Maison Facile).",
    "backup_failed": "La sauvegarde n'a pas pu se faire : rien n'a été installé, par sécurité.",
    "install_failed": "« {name} » n'a pas pu s'installer. Vérifiez Internet, puis réessayez.",
    "start_failed": "« {name} » n'a pas pu démarrer. Ouvrez Dépannage, ou réessayez.",
    "repository_failed": "La boutique de « {name} » n'a pas pu être ajoutée. Vérifiez Internet, puis réessayez.",
    "busy": "Une installation est déjà en cours. Patientez un instant.",
    "unknown_app": "Cette application n'existe pas dans la sélection.",
}


def repository_hash(url: str) -> str:
    """Préfixe des identifiants d'un dépôt (même calcul que le Supervisor)."""
    return hashlib.sha1(url.lower().encode()).hexdigest()[:8]  # noqa: S324 - identifiant, pas sécurité


def check_catalog() -> list[str]:
    """Incohérences du catalogue (vide = OK). Utilisé par les tests."""
    problems: list[str] = []
    for app in CATALOG:
        repo = app["repository"]
        if repo is None:
            if not app["slug"].startswith("core_"):
                problems.append(f"{app['id']}: slug officiel attendu (core_…)")
        elif not app["slug"].startswith(repository_hash(repo) + "_"):
            problems.append(f"{app['id']}: le slug ne correspond pas au dépôt {repo}")
        if app["level"] not in LEVELS:
            problems.append(f"{app['id']}: niveau inconnu {app['level']}")
    return problems


def next_action(state: str, busy_step: str | None = None) -> dict[str, str]:
    """Le bouton à afficher pour une application, selon son état."""
    if busy_step:
        labels = {"backup": "Sauvegarde…", "repository": "Préparation…", "install": "Installation…", "start": "Démarrage…"}
        return {"action": "wait", "label": labels.get(busy_step, "Un instant…")}
    if state == "not_installed":
        return {"action": "install", "label": "Installer"}
    if state in ("installing", "updating"):
        return {"action": "wait", "label": "Installation…"}
    if state == "not_running":
        return {"action": "start", "label": "Démarrer"}
    if state == "running":
        return {"action": "open", "label": "Ouvrir"}
    return {"action": "retry", "label": "Réessayer"}


def app_payload(app: Mapping[str, Any], info: Mapping[str, Any] | None, busy: Mapping[str, Any] | None) -> dict[str, Any]:
    """Une tuile de la page (``apps/list``). ``info`` = état lu sur le Supervisor."""
    info = info or {}
    state = str(info.get("state") or "unknown")
    if state not in STATES:
        state = "unknown"
    step = (busy or {}).get("step")
    action = next_action(state, step)
    if action["action"] == "open" and not (app["opens"] and info.get("ingress_url")):
        action = {"action": "none", "label": "En marche"}
    return {
        "id": app["id"],
        "name": app["name"],
        "icon": app["icon"],
        "color": app["color"],
        "category": app["category"],
        "what": app["what"],
        "why": app["why"],
        "level": app["level"],
        "needs": app["needs"],
        "state": state,
        "version": info.get("version"),
        "update_available": bool(info.get("update_available")),
        "ingress_url": info.get("ingress_url") if state == "running" else None,
        "action": action["action"],
        "label": action["label"],
        "error": (busy or {}).get("error"),
    }
