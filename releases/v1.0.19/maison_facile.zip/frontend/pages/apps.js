// Réglages > Applications : la sélection Maison Facile d'applications Home Assistant OS
// (apps_rules.py). Un seul bouton par application : Installer → Démarrer → Ouvrir.
// « Ouvrir » affiche l'application dans Maison Facile (page « ingress » du Supervisor) :
// on ne quitte jamais Maison Facile.
import { Page, html } from "../lib.js";
import { icon } from "../icons.js";

const LEVEL_CHIP = { facile: "actif", "intermédiaire": "", "avancé": "manque" };

export class AppsSection extends Page {
  init() {
    this.s = { data: null, error: false, open: null, confirm: null, frameError: false };
    this.load();
    // Pendant une installation : on relit l'état toutes les 3 s.
    this.every(3000, () => {
      if ((this.s.data?.apps || []).some((a) => a.action === "wait")) this.load();
    });
  }

  async load() {
    try {
      this.setState({ data: await this.api.appsList(), error: false });
    } catch (e) {
      if (!this.s.data) this.setState({ error: true });
    }
  }

  template() {
    const intro = html`<div><h2 class="sec-title">Applications</h2>
      <p class="sub" style="font-size:16px;line-height:1.45;max-width:680px">Des applications choisies par Maison Facile pour aller plus loin : musique, caméras intelligentes, bricolage… Une sauvegarde complète est faite avant chaque installation.</p></div>`;
    if (this.s.open) return this.openView(this.s.open);
    const d = this.s.data;
    if (this.s.error && !d) return html`<div class="stack">${intro}<div class="glass card"><p>Impossible de lire les applications.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div></div>`;
    if (!d) return html`<div class="stack">${intro}<p class="sub">Chargement…</p></div>`;
    if (!d.available) return html`<div class="stack">${intro}<div class="glass card"><p>${d.message}</p></div></div>`;
    return html`<div class="stack">${intro}<div class="apps-grid">${d.apps.map((a) => this.tile(a))}</div></div>`;
  }

  tile(a) {
    const installed = a.state !== "not_installed" && a.state !== "unknown";
    const busy = a.action === "wait";
    const confirming = this.s.confirm === a.id;
    return html`<article class="glass card app-tile" data-key="app-${a.id}">
      <div class="row" style="gap:14px;align-items:center">
        <span class="li-icon" style="background:${a.color};width:52px;height:52px;border-radius:15px">${icon(a.icon, 26)}</span>
        <div class="grow" style="min-width:0">
          <strong style="font-size:18px">${a.name}</strong>
          <div class="row wrap" style="gap:6px;margin-top:4px"><span class="st-badge ${LEVEL_CHIP[a.level] ?? ""}">${a.level[0].toUpperCase() + a.level.slice(1)}</span><span class="tag">${a.category}</span></div>
        </div>
      </div>
      <p style="font-size:16px;font-weight:600">${a.what}</p>
      <p class="sub" style="font-size:15px">${a.why}</p>
      ${a.needs ? html`<p class="sub" style="font-size:14px">${icon("warn", 16)} Il faut : ${a.needs}</p>` : ""}
      <p class="sub" style="font-size:14px">${installed ? html`${icon("check", 16)} Installée${a.version ? ` · version ${a.version}` : ""}${a.state === "not_running" ? " · arrêtée" : ""}${a.update_available ? " · mise à jour disponible" : ""}` : "Pas installée"}</p>
      ${a.error ? html`<p class="form-error" role="alert">${a.error}</p>` : ""}
      ${confirming
        ? html`<div class="stack" style="gap:8px" role="group" aria-label="Confirmer l'installation">
            <p style="font-size:15px">Une sauvegarde complète de la box est faite d'abord, puis « ${a.name} » s'installe. Comptez quelques minutes, vous pouvez continuer à utiliser la maison.</p>
            <div class="row wrap"><button type="button" class="btn primary sm" data-action="install" data-id="${a.id}">Installer maintenant</button><button type="button" class="btn secondary sm" data-action="cancel">Annuler</button></div>
          </div>`
        : html`<div class="row wrap" style="margin-top:auto">
            ${a.action === "none"
              ? html`<span class="tag">${a.label}</span>`
              : html`<button type="button" class="btn ${a.action === "open" ? "primary" : "secondary"} sm" data-action="${a.action === "install" ? "ask-install" : a.action}" data-id="${a.id}" ${busy || this.isBusy(a.id) ? "disabled" : ""}>${busy ? html`<span class="spinner" style="display:inline-block;width:16px;height:16px;margin-right:6px"></span>` : ""}${a.label}</button>`}
          </div>`}
    </article>`;
  }

  openView(a) {
    return html`<div class="stack" style="gap:12px">
      <div class="row wrap" style="gap:12px;align-items:center">
        <button type="button" class="btn secondary sm" data-action="close">${icon("back", 18)}Retour aux applications</button>
        <strong style="font-size:18px">${a.name}</strong>
      </div>
      ${this.s.frameError
        ? html`<div class="glass card"><p>Impossible d'ouvrir « ${a.name} » ici.</p><button type="button" class="btn secondary sm" data-action="open" data-id="${a.id}">Réessayer</button></div>`
        : html`<iframe class="app-frame" src="${a.ingress_url}" title="${a.name}" data-key="frame-${a.id}" allow="autoplay; clipboard-write; fullscreen"></iframe>`}
    </div>`;
  }

  /** Session « ingress » du Supervisor (cookie lu par /api/hassio_ingress/), comme le fait Home Assistant. */
  async openSession() {
    const r = await this.hass.callWS({ type: "supervisor/api", endpoint: "/ingress/session", method: "post" });
    const session = r?.session;
    if (!session) throw new Error("no ingress session");
    const secure = window.location.protocol === "https:" ? ";Secure" : "";
    document.cookie = `ingress_session=${session};path=/api/hassio_ingress/;SameSite=Strict${secure}`;
    clearInterval(this._keep);
    this._keep = setInterval(() => {
      this.hass.callWS({ type: "supervisor/api", endpoint: "/ingress/validate_session", method: "post", data: { session } }).catch(() => {});
    }, 60000);
    this.onCleanup(() => clearInterval(this._keep));
  }

  async onAction(action, el) {
    const id = el.dataset.id;
    const app = (this.s.data?.apps || []).find((a) => a.id === id);
    switch (action) {
      case "retry":
        this.setState({ error: false });
        return this.load();
      case "ask-install":
        return this.setState({ confirm: id });
      case "cancel":
        return this.setState({ confirm: null });
      case "install":
        this.s.confirm = null;
        return this.run(id, async () => {
          await this.api.appsInstall(id);
          await this.load();
        }, "Impossible de lancer l'installation.");
      case "start":
        return this.run(id, async () => {
          this.setState({ data: await this.api.appsStart(id) });
          this.app.notify(`« ${app?.name || "L'application"} » a démarré.`);
        }, "Impossible de démarrer cette application.");
      case "open":
        if (!app?.ingress_url) return undefined;
        return this.run(id, async () => {
          try {
            await this.openSession();
            this.setState({ open: app, frameError: false });
          } catch (e) {
            this.setState({ open: app, frameError: true });
          }
        }, "Impossible d'ouvrir cette application.");
      case "close":
        clearInterval(this._keep);
        this.setState({ open: null });
        return this.load();
      default:
        return undefined;
    }
  }
}
