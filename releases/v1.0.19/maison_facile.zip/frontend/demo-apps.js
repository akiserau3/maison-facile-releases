// Démo de Réglages > Applications (copie du catalogue de apps_rules.py, régénérée à la main
// si le catalogue change). Music Assistant installée et démarrée, le reste à installer.
export const DEMO_APPS = [
  {
    "id": "music_assistant",
    "name": "Music Assistant",
    "icon": "music",
    "color": "#C2185B",
    "category": "Musique",
    "what": "Toute votre musique sur toutes vos enceintes.",
    "why": "Spotify, Deezer, Tidal, YouTube Music, radios et vos fichiers, sur les enceintes et télés de la maison. Avec les paroles et un mode karaoké.",
    "level": "facile",
    "needs": "",
    "opens": true
  },
  {
    "id": "zigbee2mqtt",
    "name": "Zigbee2MQTT",
    "icon": "signal",
    "color": "#E8590C",
    "category": "Appareils",
    "what": "Une autre façon de gérer vos capteurs Zigbee.",
    "why": "Accepte encore plus de modèles de capteurs. Maison Facile utilise déjà le Zigbee intégré : ne l'installez que si un capteur n'est pas reconnu.",
    "level": "avancé",
    "needs": "L'application Mosquitto, et l'antenne Zigbee libérée du Zigbee intégré.",
    "opens": true
  },
  {
    "id": "mosquitto",
    "name": "Mosquitto",
    "icon": "chat",
    "color": "#5D6B7A",
    "category": "Appareils",
    "what": "Le facteur qui transporte les messages de certains appareils.",
    "why": "Nécessaire pour Zigbee2MQTT et pour les appareils « MQTT » (certains Shelly, Tasmota…).",
    "level": "intermédiaire",
    "needs": "",
    "opens": false
  },
  {
    "id": "frigate",
    "name": "Frigate",
    "icon": "camera",
    "color": "#00838F",
    "category": "Sécurité",
    "what": "Vos caméras reconnaissent les personnes, les voitures, les animaux.",
    "why": "Enregistre seulement ce qui compte et envoie une alerte « personne devant la porte », sans cloud.",
    "level": "avancé",
    "needs": "Des caméras IP (RTSP) et un PC assez puissant.",
    "opens": true
  },
  {
    "id": "esphome",
    "name": "ESPHome",
    "icon": "devices",
    "color": "#6B47B8",
    "category": "Bricolage",
    "what": "Créez vos propres capteurs avec de petites cartes électroniques.",
    "why": "Pour les bricoleurs : une carte ESP32 à quelques euros devient un capteur de votre choix.",
    "level": "avancé",
    "needs": "Une carte ESP32 ou ESP8266.",
    "opens": true
  },
  {
    "id": "node_red",
    "name": "Node-RED",
    "icon": "magic",
    "color": "#C42B1C",
    "category": "Automatismes",
    "what": "Des automatismes avancés en reliant des blocs.",
    "why": "Pour aller plus loin que les idées de Maison Facile, en dessinant des schémas.",
    "level": "avancé",
    "needs": "",
    "opens": true
  },
  {
    "id": "file_editor",
    "name": "Éditeur de fichiers",
    "icon": "wrench",
    "color": "#0067C0",
    "category": "Outils",
    "what": "Modifier les fichiers de configuration depuis le navigateur.",
    "why": "Utile pour suivre un tutoriel qui demande d'ajouter une ligne dans configuration.yaml.",
    "level": "intermédiaire",
    "needs": "",
    "opens": true
  },
  {
    "id": "samba",
    "name": "Partage réseau (Samba)",
    "icon": "download",
    "color": "#0E7A0D",
    "category": "Outils",
    "what": "Voir les dossiers de la box depuis votre PC.",
    "why": "Récupérer une sauvegarde ou déposer un fichier, comme une clé USB sur le réseau.",
    "level": "intermédiaire",
    "needs": "Choisir un nom d'utilisateur et un mot de passe dans ses réglages.",
    "opens": false
  }
];

export function createDemoApps({ wait }) {
  const state = { music_assistant: { state: "running", version: "2.8.4" }, mosquitto: { state: "not_running", version: "6.5.1" } };
  const busy = {};
  const page = (name) => "data:text/html;charset=utf-8," + encodeURIComponent(`<body style="margin:0;font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;background:linear-gradient(135deg,#2a1b6b,#c2185b);color:#fff"><div style="text-align:center"><h1>${name}</h1><p>La vraie application s'affiche ici, dans Maison Facile.</p></div></body>`);
  const list = () => ({
    available: true,
    message: "",
    apps: DEMO_APPS.map((a) => {
      const st = state[a.id] || { state: "not_installed" };
      const b = busy[a.id];
      const action = b ? "wait" : st.state === "not_installed" ? "install" : st.state === "not_running" ? "start" : a.opens ? "open" : "none";
      const label = b ? b : { install: "Installer", start: "Démarrer", open: "Ouvrir", none: "En marche" }[action];
      return { ...a, state: st.state, version: st.version || null, update_available: false, ingress_url: st.state === "running" && a.opens ? page(a.name) : null, action, label, error: null };
    }),
  });
  return {
    "apps/list": list,
    "apps/install": async ({ app_id }) => {
      busy[app_id] = "Sauvegarde…";
      (async () => {
        await wait(2500); busy[app_id] = "Installation…";
        await wait(3000); busy[app_id] = "Démarrage…";
        await wait(1500); delete busy[app_id]; state[app_id] = { state: "running", version: "1.0.0" };
      })();
      return { started: true };
    },
    "apps/start": ({ app_id }) => { state[app_id] = { ...state[app_id], state: "running" }; return list(); },
  };
}
