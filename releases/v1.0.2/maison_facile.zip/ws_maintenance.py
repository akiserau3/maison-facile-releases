"""Websocket commands "maison_facile/updates/*" and "maison_facile/doctor/*" (CONTRACT §5)."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback

from . import audience
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

ERR_NOT_READY = "not_ready"
ERR_INSTALL = "install_failed"
ERR_NOT_FOUND = "not_found"
ERR_FIX = "fix_failed"

MSG_NOT_READY = "Maison Facile démarre encore. Réessayez dans quelques secondes."


def _runtime(hass: HomeAssistant) -> Any | None:
    entries = hass.config_entries.async_entries(DOMAIN)
    return getattr(entries[0], "runtime_data", None) if entries else None


def _updater(hass: HomeAssistant) -> Any | None:
    return getattr(_runtime(hass), "updater", None)


def _doctor(hass: HomeAssistant) -> Any | None:
    return getattr(_runtime(hass), "doctor", None)


# --------------------------------------------------------------------------- updates


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/updates/status"})
@websocket_api.async_response
async def ws_updates_status(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    updater = _updater(hass)
    if updater is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    connection.send_result(msg["id"], audience.for_hass(updater.status(), hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/updates/install", vol.Required("target"): vol.In(["mf", "core"])}
)
@websocket_api.async_response
async def ws_updates_install(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    updater = _updater(hass)
    if updater is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    from .updater import UpdateError  # noqa: PLC0415

    try:
        await updater.async_start_install(msg["target"])
    except UpdateError as err:
        connection.send_error(msg["id"], ERR_INSTALL, audience.for_hass(str(err), hass))
        return
    connection.send_result(msg["id"], {"started": True})


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/updates/subscribe"})
@callback
def ws_updates_subscribe(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    updater = _updater(hass)
    if updater is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    msg_id = msg["id"]

    @callback
    def _forward(payload: dict[str, Any]) -> None:
        connection.send_message(websocket_api.event_message(msg_id, audience.for_hass(payload, hass)))

    connection.subscriptions[msg_id] = updater.async_add_listener(_forward)
    connection.send_result(msg_id)
    # Send the current state right away so the page can draw itself.
    _forward({"phase": updater.phase, "progress": updater.progress, "message_fr": updater.message_fr})


# --------------------------------------------------------------------------- doctor


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/doctor/list"})
@websocket_api.async_response
async def ws_doctor_list(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    doctor = _doctor(hass)
    if doctor is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    if doctor.checked_at is None:
        await doctor.async_analyze()
    connection.send_result(msg["id"], audience.for_hass(doctor.as_dict(), hass))


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/doctor/rescan"})
@websocket_api.async_response
async def ws_doctor_rescan(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    doctor = _doctor(hass)
    if doctor is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    connection.send_result(msg["id"], audience.for_hass(await doctor.async_analyze(), hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/doctor/fix",
        # The contract says {id, choice?} but "id" is the websocket message id
        # (overwritten by hass.callWS): the problem id travels as "problem_id".
        vol.Optional("problem_id"): str,
        vol.Optional("choice"): vol.Any(str, int, None),
    }
)
@websocket_api.async_response
async def ws_doctor_fix(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    doctor = _doctor(hass)
    if doctor is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
        return
    problem_id = msg.get("problem_id")
    if not problem_id:
        connection.send_error(msg["id"], ERR_NOT_FOUND, "Quel problème faut-il réparer ? (champ « problem_id » manquant)")
        return
    choice = msg.get("choice")
    try:
        result = await doctor.async_fix(problem_id, None if choice is None else str(choice))
    except Exception:  # noqa: BLE001
        _LOGGER.exception("doctor/fix failed")
        connection.send_error(
            msg["id"], ERR_FIX,
            audience.for_hass("La réparation n'a pas pu être lancée. Votre installateur peut vous aider.", hass),
        )
        return
    connection.send_result(msg["id"], audience.for_hass(result, hass))


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/doctor/report"})
@websocket_api.async_response
async def ws_doctor_report(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    from .diagnostics import async_build_report  # noqa: PLC0415

    try:
        text = await async_build_report(hass)
    except Exception:  # noqa: BLE001
        _LOGGER.exception("doctor/report failed")
        connection.send_error(msg["id"], ERR_FIX, "Impossible de préparer le rapport pour le moment.")
        return
    connection.send_result(msg["id"], {"text": text})


@callback
def async_register(hass: HomeAssistant) -> None:
    """Register the maintenance websocket commands (called once by __init__.py)."""
    for command in (
        ws_updates_status,
        ws_updates_install,
        ws_updates_subscribe,
        ws_doctor_list,
        ws_doctor_rescan,
        ws_doctor_fix,
        ws_doctor_report,
    ):
        websocket_api.async_register_command(hass, command)
