"""Maison Facile: a simple, family-friendly layer on top of Home Assistant."""

from __future__ import annotations

import logging
from pathlib import Path

from homeassistant.components import frontend, panel_custom
from homeassistant.components.http import StaticPathConfig
from homeassistant.config_entries import SOURCE_IMPORT, ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.start import async_at_started
from homeassistant.helpers.typing import ConfigType

from . import websocket_api as mf_websocket
from .automations import AutomationManager, async_install_blueprints
from .commercial import CommercialManager
from .const import (
    DOMAIN,
    GUARD_MODULE_URL,
    PANEL_ICON,
    PANEL_TITLE,
    PANEL_URL_PATH,
    PANEL_WEBCOMPONENT,
    STATIC_URL,
    VERSION,
    MaisonFacileData,
)
from .heating import HeatingPauseManager
from .pairing import PairingManager
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)

PLATFORMS = [Platform.SELECT, Platform.SWITCH, Platform.UPDATE]
FRONTEND_DIR = Path(__file__).parent / "frontend"
_STATIC_FLAG = f"{DOMAIN}_static_registered"

# `maison_facile:` (no option) in configuration.yaml creates the entry by import
# (box prepared by the installer, CONTRACT_KIT.md). Options are ignored with a log.
CONFIG_SCHEMA = cv.empty_config_schema(DOMAIN)

type MaisonFacileConfigEntry = ConfigEntry[MaisonFacileData]


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    """Register the websocket commands once per HA run; YAML key -> import flow."""
    mf_websocket.async_register(hass)
    if DOMAIN in config and not hass.config_entries.async_entries(DOMAIN):
        hass.async_create_task(
            hass.config_entries.flow.async_init(
                DOMAIN, context={"source": SOURCE_IMPORT}, data={}
            ),
            f"{DOMAIN}_import",
        )
    return True


async def _async_register_panel(hass: HomeAssistant) -> None:
    if not hass.data.get(_STATIC_FLAG):
        await hass.http.async_register_static_paths(
            [StaticPathConfig(STATIC_URL, str(FRONTEND_DIR), cache_headers=False)]
        )
        hass.data[_STATIC_FLAG] = True
    if PANEL_URL_PATH in hass.data.get(frontend.DATA_PANELS, {}):
        return
    await panel_custom.async_register_panel(
        hass,
        frontend_url_path=PANEL_URL_PATH,
        webcomponent_name=PANEL_WEBCOMPONENT,
        module_url=f"{STATIC_URL}/maison-facile-panel.js?v={VERSION}",
        sidebar_title=PANEL_TITLE,
        sidebar_icon=PANEL_ICON,
        require_admin=False,
        config={},
    )


async def async_setup_entry(hass: HomeAssistant, entry: MaisonFacileConfigEntry) -> bool:
    """Set up Maison Facile from its config entry."""
    store = MaisonFacileStore(hass)
    await store.async_load()

    data = MaisonFacileData(store=store)
    data.automations = AutomationManager(hass)
    data.pairing = PairingManager(hass, store)
    data.pairing.async_setup()
    data.heating = HeatingPauseManager(hass, store)
    entry.runtime_data = data

    try:
        await async_install_blueprints(hass)
    except Exception:  # noqa: BLE001 - the panel must still load
        _LOGGER.exception("Could not install Maison Facile blueprints")

    await _async_register_panel(hass)
    mf_websocket.async_register(hass)

    _async_add_guard(hass)

    try:
        data.commercial = CommercialManager(hass, store)
        # Default panel + family sidebars, re-applied at every start (idempotent).
        await data.commercial.async_setup()
    except Exception:  # noqa: BLE001 - the panel must still load
        _LOGGER.exception("Maison Facile commercial mode could not start")

    try:
        from .updater import async_setup_updater  # noqa: PLC0415

        data.updater = await async_setup_updater(hass, entry)
    except Exception:  # noqa: BLE001 - isolated maintenance module
        _LOGGER.exception("Maison Facile updater could not start")

    try:
        from .doctor import async_setup_doctor  # noqa: PLC0415

        data.doctor = await async_setup_doctor(hass, entry)
    except Exception:  # noqa: BLE001 - isolated maintenance module
        _LOGGER.exception("Maison Facile doctor could not start")

    try:
        from .provision import async_setup_provision  # noqa: PLC0415

        data.provision = await async_setup_provision(hass, entry, store)
    except Exception:  # noqa: BLE001 - provisioning must never block the panel
        _LOGGER.exception("Maison Facile provisioning could not start")

    try:
        await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    except Exception:
        # The entry will not be set up: do not leave listeners of the modules above behind.
        await _async_stop_modules(data)
        _async_remove_guard(hass)
        raise

    try:
        from .ideas import async_setup_ideas  # noqa: PLC0415

        data.ideas = await async_setup_ideas(hass, entry, data)
    except Exception:  # noqa: BLE001 - the ideas catalogue must never block the panel
        _LOGGER.exception("Maison Facile ideas could not start")

    try:
        from .birthdays import async_setup_birthdays  # noqa: PLC0415

        data.birthdays = await async_setup_birthdays(hass, entry, data)
    except Exception:  # noqa: BLE001 - birthday reminders must never block the panel
        _LOGGER.exception("Maison Facile birthdays could not start")

    try:
        from .energy_report import async_setup_energy_report  # noqa: PLC0415

        data.energy_report = await async_setup_energy_report(hass, entry, data)
    except Exception:  # noqa: BLE001 - the monthly report must never block the panel
        _LOGGER.exception("Maison Facile monthly report could not start")

    async def _rearm_heating(_event: object = None) -> None:
        try:
            await data.heating.async_setup()
        except Exception:  # noqa: BLE001
            _LOGGER.exception("Could not re-arm heating pauses")

    if hass.is_running:
        await _rearm_heating()
    else:
        # Climate/scene entities are only reliable once HA has fully started
        # (async_at_started: its cancel stays safe on unload after it has run).
        entry.async_on_unload(async_at_started(hass, _rearm_heating))
    return True


async def async_unload_entry(hass: HomeAssistant, entry: MaisonFacileConfigEntry) -> bool:
    """Unload a config entry."""
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if not unloaded:
        return False
    await _async_stop_modules(entry.runtime_data)
    frontend.async_remove_panel(hass, PANEL_URL_PATH)
    _async_remove_guard(hass)
    return True


def _async_add_guard(hass: HomeAssistant) -> None:
    """Load mf-guard.js on every page of HA's frontend (official API, NOTES_commercial.md).

    The guard sends the family back to Maison Facile and hides HA's sidebar while
    commercial mode is on and the advanced settings are locked. It does nothing
    when our websocket commands do not answer (integration not loaded).
    """
    try:
        frontend.add_extra_js_url(hass, GUARD_MODULE_URL)
    except Exception:  # noqa: BLE001 - the panel must still load
        _LOGGER.exception("Could not register the Maison Facile frontend guard")


def _async_remove_guard(hass: HomeAssistant) -> None:
    try:
        frontend.remove_extra_js_url(hass, GUARD_MODULE_URL)
    except Exception:  # noqa: BLE001
        _LOGGER.debug("Maison Facile frontend guard was not registered")


async def _async_stop_modules(data: MaisonFacileData) -> None:
    """Remove the listeners / timers of every module started by async_setup_entry."""
    if data.pairing is not None:
        data.pairing.async_unload()
    if data.heating is not None:
        data.heating.async_unload()
    if data.provision is not None:
        data.provision.async_unload()
    if data.commercial is not None:
        data.commercial.async_unload()
    if data.ideas is not None:
        data.ideas.async_unload()
    if getattr(data, "birthdays", None) is not None:
        data.birthdays.async_unload()
    if getattr(data, "energy_report", None) is not None:
        data.energy_report.async_unload()
    for obj in (data.updater, data.doctor):
        unload = getattr(obj, "async_unload", None)
        if unload is None:
            continue
        try:
            result = unload()
            if hasattr(result, "__await__"):
                await result
        except Exception:  # noqa: BLE001
            _LOGGER.exception("Error while unloading a maintenance module")


async def async_remove_entry(hass: HomeAssistant, entry: MaisonFacileConfigEntry) -> None:
    """Integration removed: Home Assistant opens on its own dashboard again and the
    family sidebars we changed are restored (NOTES_commercial.md)."""
    store = MaisonFacileStore(hass)
    await store.async_load()
    try:
        await CommercialManager(hass, store).async_revert()
    except Exception:  # noqa: BLE001
        _LOGGER.exception("Could not revert Maison Facile commercial mode")
