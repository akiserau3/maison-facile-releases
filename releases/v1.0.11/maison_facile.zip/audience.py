"""Who installed the box, and the texts that depend on it (pure logic, no HA import).

A box can be installed by a professional for a client (``profile = "pro"``) or by a private
person who downloaded the free ISO (``profile = "particulier"``). The installer writes the
profile in ``maison_facile_kit.json`` (v1.3+); the ``settings`` step copies it to
``settings.profile``. When it is absent (older installers, manual install), a box with an
installer name is a pro box, otherwise a private one.

Many texts say « votre installateur ». For a private person there is nobody to call: the
texts point to « Réglages avancés » or to the community instead. For a pro with a name,
« votre installateur » becomes that name. ``adapt`` does this on any French text;
``adapt_payload`` on a whole websocket answer (ids, technical details and contact details
are never touched). The frontend has the same table for its own texts
(``frontend/components/audience.js``). Tested in ``tests/test_audience.py``.

Discovery mode (installer v1.4, ``equipment = "none"``): the box was installed without any
hardware (old PC or VM, to discover). ``discovery_mode`` says when the panel shows the
« Votre maison sans matériel » path and the doctor a soft notice instead of an alert.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from typing import Any

PROFILES = ("particulier", "pro")
EQUIPMENTS = ("some", "none")
DOMAIN = "maison_facile"

# Keys whose values are never rewritten (ids, technical details, contact details, links).
SKIP_KEYS = frozenset({
    "id", "idea_id", "key", "tech", "detail", "installer_name", "installer_contact", "entity_id",
    "entity_ids", "device_id", "area_id", "domain", "handler", "flow_id", "url", "shop_url", "icon",
    "color", "service", "page",
})

# Private person: (pattern, replacement), most specific first. Every text of the box that
# names « l'installateur » must be covered (tests/test_audience.py scans the sources).
_PARTICULIER: list[tuple[str, str]] = [
    # Doctor
    (r"Votre installateur peut s'en occuper", "À régler dans Réglages avancés"),
    (r"Appuyez sur « Demander de l'aide » : votre installateur recevra les détails, sans vos mots de passe\.",
     "Appuyez sur « Demander de l'aide » : vous obtenez un rapport à partager sur le forum de la communauté, sans vos mots de passe."),
    (r"Si cela échoue encore, votre installateur s'en occupera\.",
     "Si cela échoue encore, demandez de l'aide à la communauté (rapport dans « Demander de l'aide »)."),
    (r"Si leurs identifiants ont été effacés, votre installateur les ajoutera\.",
     "Si leurs identifiants ont été effacés, ajoutez les caméras dans Réglages avancés."),
    (r"Les outils de l'installateur ne sont pas encore activés", "Les outils en plus (HACS) ne sont pas encore activés"),
    (r"Ils servent à votre installateur pour ajouter des modules en plus\.", "Ils servent à ajouter des modules en plus."),
    (r"Rien à faire de votre côté : votre installateur les activera avec son propre compte lors de son passage\.",
     "Pour les activer : Réglages avancés, puis connexion avec un compte GitHub. Rien ne presse."),
    (r"Ce problème doit être réglé par votre installateur\. Appuyez sur « Demander de l'aide »\.",
     "Ce problème se règle dans Réglages avancés. « Demander de l'aide » prépare un rapport à partager avec la communauté."),
    (r"Votre installateur peut vous aider\.", "La communauté Home Assistant peut vous aider (forum)."),
    # Provisioning
    (r"Réglages de votre installateur", "Vos réglages"),
    (r"Les coordonnées de votre installateur sont enregistrées\.", "Vos réglages sont enregistrés."),
    (r"Rien à recopier : votre installateur n'a pas laissé de coordonnées\.", "Vos réglages sont enregistrés."),
    (r"Le fichier préparé par votre installateur est illisible\. Il pourra le refaire\.",
     "Le fichier préparé à l'installation est illisible. Vous pouvez tout régler ensuite dans Maison Facile."),
    (r"Réessayez ou contactez votre installateur\.", "Réessayez, ou demandez de l'aide à la communauté."),
    (r"votre installateur doit le faire à la main\.", "ajoutez-le à la main dans Réglages avancés."),
    (r"Aucune adresse de caméra n'a été donnée : votre installateur ajoutera les caméras\.",
     "Aucune adresse de caméra n'a été donnée : ajoutez les caméras dans Maison Facile."),
    (r"Les identifiants des caméras ont été effacés par sécurité : votre installateur doit ajouter les caméras\.",
     "Les identifiants des caméras ont été effacés par sécurité : ajoutez les caméras dans Réglages avancés."),
    (r"L'intégration Frigate s'ajoute avec HACS par votre installateur\.",
     "L'intégration Frigate s'ajoute avec HACS, dans Réglages avancés."),
    (r"Pas d'outils de l'installateur dans ce kit\.", "Pas d'outils en plus (HACS)."),
    (r"Les outils de l'installateur sont prêts\. Votre installateur les activera lors de son passage\.",
     "Les outils en plus (HACS) sont prêts. Activez-les quand vous voulez dans Réglages avancés."),
    (r"Outils de l'installateur", "Outils en plus (HACS)"),
    (r"Réessayez, ou votre installateur s'en occupera\.", "Réessayez, ou demandez de l'aide à la communauté."),
    (r"votre installateur doit la mettre à jour\.", "son logiciel doit être mis à jour (voir la notice de l'antenne)."),
    # Ideas
    (r"demandez à votre installateur de le saisir \(Paramètres > Appareils et services\)",
     "saisissez-le dans Réglages avancés, puis Paramètres > Appareils et services"),
    (r"Votre installateur peut le terminer dans Paramètres > Appareils et services\.",
     "Vous pouvez le terminer dans Réglages avancés, puis Paramètres > Appareils et services."),
    (r"Aucune voix de synthèse n'est installée sur la box : demandez à votre installateur\.",
     "Aucune voix de synthèse n'est installée sur la box : ajoutez-en une dans Réglages avancés (Paramètres > Appareils et services)."),
    (r"relié par son application : votre installateur s'en occupe", "relié par son application, puis dans Réglages avancés"),
    (r"\(votre installateur s'en occupe\)", "(Réglages avancés, Paramètres > Système > Général)"),
    (r"reliée à la box par votre installateur", "reliée à la box dans Réglages avancés"),
    (r"votre installateur ajoute une\s+intégration de la communauté",
     "vous ajoutez, dans Réglages avancés, une intégration de la communauté"),
    (r"à relier par votre installateur :", "à relier dans Réglages avancés :"),
    (r"Votre installateur relie l'intégration officielle Météo-France \(gratuite\) avec la ville\s+de la maison\.",
     "Reliez l'intégration officielle Météo-France (gratuite) avec la ville de la maison, dans Réglages avancés."),
    (r"\(installateur\)", "(Réglages avancés)"),
    # Buying guide
    (r"Compatible Home Assistant : demandez à votre installateur avant d'acheter\.",
     "Compatible Home Assistant : vérifiez-le avant d'acheter (liste des intégrations, ou forum de la communauté)."),
    # Updates
    (r"\*Testée par votre installateur le ", "*Testée le "),
    (r", testée par votre installateur,", ", déjà testée,"),
    (r"n'a pas encore été testée par votre installateur\.", "n'a pas encore été testée."),
    (r"La box est dans un état incomplet : votre installateur doit remettre l'ancienne version",
     "La box est dans un état incomplet : remettez l'ancienne version depuis Réglages avancés"),
    (r"Si elle ne revient pas, votre installateur remettra l'ancienne version\.",
     "Si elle ne revient pas, remettez l'ancienne version depuis la sauvegarde (Réglages avancés)."),
    # Commercial mode
    (r" \(mode installateur\)", ""),
    (r"Le code installateur se change dans « Réglages avancés »\.", "Le code se change dans « Réglages avancés »."),
]
_PARTICULIER_RE = [(re.compile(p), r) for p, r in _PARTICULIER]
_VOTRE_RE = re.compile(r"\b([Vv])otre installateur\b")


def profile_of(settings: Mapping[str, Any] | None) -> str:
    """``particulier`` or ``pro`` (absent: pro when an installer name is set)."""
    settings = settings or {}
    profile = settings.get("profile")
    if profile in PROFILES:
        return str(profile)
    return "pro" if str(settings.get("installer_name") or "").strip() else "particulier"


def summary(settings: Mapping[str, Any] | None) -> dict[str, str]:
    """``state/get.audience``: who the texts talk to."""
    settings = settings or {}
    return {"profile": profile_of(settings), "installer_name": str(settings.get("installer_name") or "").strip()}


def adapt(text: str, profile: str, installer_name: str = "") -> str:
    """French text for this profile (pro without name: unchanged)."""
    if not isinstance(text, str) or "nstallateur" not in text:
        return text
    if profile == "pro":
        name = (installer_name or "").strip()
        return _VOTRE_RE.sub(name, text) if name else text
    for regex, replacement in _PARTICULIER_RE:
        text = regex.sub(replacement, text)
    return text


def adapt_payload(value: Any, profile: str, installer_name: str = "", _key: str | None = None) -> Any:
    """Copy of a websocket answer with every French text adapted (see ``SKIP_KEYS``)."""
    if _key in SKIP_KEYS:
        return value
    if isinstance(value, str):
        return adapt(value, profile, installer_name)
    if isinstance(value, Mapping):
        return {k: adapt_payload(v, profile, installer_name, str(k)) for k, v in value.items()}
    if isinstance(value, list):
        return [adapt_payload(v, profile, installer_name) for v in value]
    if isinstance(value, tuple):
        return tuple(adapt_payload(v, profile, installer_name) for v in value)
    return value


def for_settings(value: Any, settings: Mapping[str, Any] | None) -> Any:
    """``adapt_payload`` with the profile and installer name of these settings."""
    who = summary(settings)
    if who["profile"] == "pro" and not who["installer_name"]:
        return value
    return adapt_payload(value, who["profile"], who["installer_name"])


def settings_of_hass(hass: Any) -> dict[str, Any]:
    """Settings of the Maison Facile entry (``{}`` if not loaded). Duck-typed: no HA import."""
    try:
        for entry in hass.config_entries.async_entries(DOMAIN):
            store = getattr(getattr(entry, "runtime_data", None), "store", None)
            if store is not None:
                return dict(store.settings)
    except Exception:  # noqa: BLE001 - texts must never break an answer
        return {}
    return {}


def for_hass(value: Any, hass: Any) -> Any:
    """``adapt_payload`` for the box of this ``hass``."""
    return for_settings(value, settings_of_hass(hass))


# --------------------------------------------------------------------------- discovery mode


def discovery_mode(
    equipment: Any, radio_found: bool, radio_expected: Any, device_count: int
) -> bool:
    """True when the box has no hardware yet (installer v1.4 « Non, je découvre »).

    - an antenna is found → never (normal behaviour as soon as it is plugged in);
    - ``equipment == "some"`` → never; ``"none"`` → yes;
    - unknown (older installers, manual install) → only if no antenna is expected and the
      box has no device at all.
    """
    if radio_found:
        return False
    if equipment == "some":
        return False
    if equipment == "none":
        return True
    return radio_expected is not True and int(device_count or 0) == 0


def no_hardware_needs(needs: Iterable[Mapping[str, Any]], no_purchase_roles: Iterable[str]) -> bool:
    """An idea that works without buying anything: every required need is an app / a service."""
    free = set(no_purchase_roles)
    for need in needs:
        if need.get("optional"):
            continue
        if any(role not in free for role in need.get("roles", ())):
            return False
    return True
