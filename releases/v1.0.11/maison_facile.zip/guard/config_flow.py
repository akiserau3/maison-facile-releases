"""Entrée unique du gardien, créée automatiquement par Maison Facile (source « system »)."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigFlow, ConfigFlowResult

DOMAIN = "maison_facile_guard"
TITLE = "Gardien des mises à jour"


class GuardConfigFlow(ConfigFlow, domain=DOMAIN):
    VERSION = 1

    async def async_step_system(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        await self.async_set_unique_id(DOMAIN)
        self._abort_if_unique_id_configured()
        return self.async_create_entry(title=TITLE, data={})

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        return await self.async_step_system(user_input)
