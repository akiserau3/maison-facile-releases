"""PURE logic: which theme the screen shows today (holidays and seasons).

No Home Assistant import: tested by ``tests/test_theme_rules.py``. The same rules are
mirrored in ``frontend/components/theme-rules.js`` (instant preview in Réglages ›
Apparence); the box's answer (``state/get.appearance``) always wins.

Calendar (France):
- Halloween : 24 → 31 October
- Noël : 1 → 26 December
- Nouvel an : 27 December → 2 January
- Saint-Valentin : 12 → 14 February
- Pâques : Good Friday → Easter Monday (Gregorian computus)
- 14 Juillet : 13 → 14 July
Seasons (astronomical, approximated): spring 20 March, summer 21 June,
autumn 22 September, winter 21 December.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

# Every theme the client can pick by hand (Réglages › Apparence).
BASE_THEMES: tuple[str, ...] = ("clair", "sombre", "contraste")
SEASON_THEMES: tuple[str, ...] = ("printemps", "ete", "automne", "hiver")
HOLIDAY_THEMES: tuple[str, ...] = ("halloween", "noel", "nouvelan", "valentin", "paques", "quatorze")
THEMES: tuple[str, ...] = BASE_THEMES + SEASON_THEMES + HOLIDAY_THEMES

THEME_AUTO_MODES: tuple[str, ...] = ("fetes_saisons", "fetes", "saisons", "non")
DEFAULT_THEME_AUTO = "fetes_saisons"

HOME_STYLES: tuple[str, ...] = ("maison_facile", "orbite", "neon", "jumeau", "holo")
DEFAULT_HOME_STYLE = "maison_facile"

THEME_NAMES_FR: dict[str, str] = {
    "clair": "Clair",
    "sombre": "Sombre",
    "contraste": "Contraste élevé",
    "printemps": "Printemps",
    "ete": "Été",
    "automne": "Automne",
    "hiver": "Hiver",
    "halloween": "Halloween",
    "noel": "Noël",
    "nouvelan": "Nouvel an",
    "valentin": "Saint-Valentin",
    "paques": "Pâques",
    "quatorze": "14 Juillet",
}

STYLE_NAMES_FR: dict[str, str] = {
    "maison_facile": "Maison Facile",
    "orbite": "Orbite",
    "neon": "Néon",
    "jumeau": "Jumeau 3D",
    "holo": "Holo",
}

_HOLIDAY_REASON_FR: dict[str, str] = {
    "halloween": "Halloween (du 24 au 31 octobre)",
    "noel": "Noël (du 1er au 26 décembre)",
    "nouvelan": "le Nouvel an (du 27 décembre au 2 janvier)",
    "valentin": "la Saint-Valentin (du 12 au 14 février)",
    "paques": "Pâques (du vendredi saint au lundi de Pâques)",
    "quatorze": "le 14 Juillet",
}

_SEASON_REASON_FR: dict[str, str] = {
    "printemps": "c'est le printemps",
    "ete": "c'est l'été",
    "automne": "c'est l'automne",
    "hiver": "c'est l'hiver",
}


def easter_sunday(year: int) -> date:
    """Gregorian Easter Sunday (anonymous Gregorian algorithm, Meeus/Jones/Butcher)."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month, day = divmod(h + l - 7 * m + 114, 31)
    return date(year, month, day + 1)


def holiday_for(day: date) -> str | None:
    """Holiday theme for this local date, or None."""
    m, d = day.month, day.day
    if m == 10 and 24 <= d <= 31:
        return "halloween"
    if m == 12 and d <= 26:
        return "noel"
    if (m == 12 and d >= 27) or (m == 1 and d <= 2):
        return "nouvelan"
    if m == 2 and 12 <= d <= 14:
        return "valentin"
    if m == 7 and d in (13, 14):
        return "quatorze"
    easter = easter_sunday(day.year)
    if easter - timedelta(days=2) <= day <= easter + timedelta(days=1):
        return "paques"
    return None


def season_for(day: date) -> str:
    """Astronomical season (approximated with fixed dates)."""
    md = (day.month, day.day)
    if md >= (12, 21) or md < (3, 20):
        return "hiver"
    if md < (6, 21):
        return "printemps"
    if md < (9, 22):
        return "ete"
    return "automne"


def effective_theme(settings: dict[str, Any], day: date) -> dict[str, Any]:
    """What the screen shows today.

    Returns ``{theme_effective, reason_fr, occasion, season, auto}``:
    - ``theme`` (the client's own choice) is used when ``theme_auto`` is ``non``, outside
      holidays with ``fetes``, and ALWAYS when it is ``contraste`` (accessibility first:
      the automatic change never replaces the high-contrast theme);
    - priority: holiday > season.
    """
    chosen = settings.get("theme")
    if chosen not in THEMES:
        chosen = "clair"
    auto = settings.get("theme_auto")
    if auto not in THEME_AUTO_MODES:
        auto = DEFAULT_THEME_AUTO
    holiday = holiday_for(day)
    season = season_for(day)
    result: dict[str, Any] = {"occasion": holiday, "season": season, "auto": auto}

    def manual(reason: str) -> dict[str, Any]:
        return {**result, "theme_effective": chosen, "reason_fr": reason}

    if chosen == "contraste":
        return manual("Contraste élevé : le thème ne change jamais tout seul.")
    if auto == "non":
        return manual("Thème choisi à la main.")
    if auto in ("fetes_saisons", "fetes") and holiday:
        return {
            **result,
            "theme_effective": holiday,
            "reason_fr": f"Choisi automatiquement : {_HOLIDAY_REASON_FR[holiday]}.",
        }
    if auto in ("fetes_saisons", "saisons"):
        return {
            **result,
            "theme_effective": season,
            "reason_fr": f"Choisi automatiquement : {_SEASON_REASON_FR[season]}.",
        }
    # "fetes" outside holidays: the client's usual theme.
    return manual("Votre thème habituel (pas de fête aujourd'hui).")


def appearance_summary(settings: dict[str, Any], day: date) -> dict[str, Any]:
    """``state/get.appearance``: the effective theme + the date it was computed for."""
    return {**effective_theme(settings, day), "date": day.isoformat()}


def report_line(settings: dict[str, Any]) -> str:
    """One line of the help report (doctor/report): current style and liked styles."""
    style = settings.get("home_style")
    if style not in HOME_STYLES:
        style = DEFAULT_HOME_STYLE
    liked = [s for s in settings.get("liked_styles") or [] if s in HOME_STYLES]
    liked_fr = ", ".join(STYLE_NAMES_FR[s] for s in liked) if liked else "aucun"
    theme = THEME_NAMES_FR.get(settings.get("theme"), "Clair")
    return (
        f"Apparence : style d'accueil {STYLE_NAMES_FR[style]} · styles aimés : {liked_fr} · "
        f"thème {theme} (automatique : {settings.get('theme_auto', DEFAULT_THEME_AUTO)})"
    )
