"""Pure device classification logic for Maison Facile.

This module must NOT import homeassistant: it is unit-tested on its own.

Input: a device description::

    {
        "manufacturer": str | None,
        "model": str | None,
        "name": str | None,
        "entities": [
            {"entity_id": str, "domain": str, "device_class": str | None,
             "unit": str | None, "original_name": str | None,
             "entity_category": "diagnostic" | "config" | None,   # optional
             "disabled": bool}                                     # optional
        ],
    }

Output: ``{"type": str, "type_label": str, "entities": {role: entity_id}}``.
"""

from __future__ import annotations

from typing import Any

TYPE_LABELS: dict[str, str] = {
    "ouverture": "Détecteur d'ouverture",
    "mouvement": "Détecteur de mouvement",
    "thermo": "Thermomètre",
    "prise": "Prise connectée",
    "lumiere": "Lumière",
    "fumee": "Détecteur de fumée",
    "camera": "Caméra",
    "chauffage": "Chauffage",
    "sirene": "Sirène",
    "fuite": "Détecteur de fuite d'eau",
    "vanne": "Vanne d'eau",
    "tv": "Télévision",
    "enceinte": "Enceinte connectée",
    "sonnette": "Sonnette",
    "bouton": "Bouton",
    "autre": "Appareil",
}

ROLES: tuple[str, ...] = (
    "contact",
    "motion",
    "temperature",
    "humidity",
    "power",
    "energy",
    "switch",
    "light",
    "smoke",
    "camera",
    "climate",
    "siren",
    "battery",
    # Added for the "Idées" catalogue (ideas_rules.py).
    "leak",
    "valve",
    "media",
    "doorbell",
    "button",
    "weather",
)

CONTACT_CLASSES = {"door", "window", "opening", "garage_door"}
MOTION_CLASSES = {"motion", "occupancy", "presence"}
SMOKE_CLASSES = {"smoke"}
LEAK_CLASSES = {"moisture"}

ENERGY_UNITS = {"kwh", "wh", "mwh"}
POWER_UNITS = {"w", "kw"}
TEMPERATURE_UNITS = {"°c", "°f", "c", "f"}

# Keywords used only when the integration did not give a device_class.
_CONTACT_WORDS = ("contact", "door", "window", "porte", "fenetre", "fenêtre", "opening", "ouverture")
_MOTION_WORDS = ("motion", "occupancy", "presence", "mouvement", "présence", "pir")
_SMOKE_WORDS = ("smoke", "fumee", "fumée")
_PLUG_WORDS = ("plug", "prise", "outlet", "socket")
_LEAK_WORDS = ("leak", "fuite", "moisture", "water_leak")
_DOORBELL_WORDS = ("doorbell", "sonnette", "visitor", "visiteur")
_TV_WORDS = ("tv", "tele", "télé", "television", "télévision", "bravia", "shield")

_IGNORED_CATEGORIES = {"diagnostic", "config"}


def _lower(value: Any) -> str:
    return str(value).lower() if value else ""


def _entity_text(entity: dict[str, Any]) -> str:
    return f"{_lower(entity.get('entity_id'))} {_lower(entity.get('original_name'))}"


def _has_word(text: str, words: tuple[str, ...]) -> bool:
    return any(word in text for word in words)


def entity_role(entity: dict[str, Any]) -> str | None:
    """Return the Maison Facile role of a single entity, or None."""
    entity_id = _lower(entity.get("entity_id"))
    domain = _lower(entity.get("domain")) or entity_id.split(".", 1)[0]
    device_class = _lower(entity.get("device_class"))
    unit = _lower(entity.get("unit"))
    text = _entity_text(entity)

    if domain == "binary_sensor":
        if device_class in CONTACT_CLASSES:
            return "contact"
        if device_class in MOTION_CLASSES:
            return "motion"
        if device_class in SMOKE_CLASSES:
            return "smoke"
        if device_class in LEAK_CLASSES:
            return "leak"
        if not device_class:
            if _has_word(text, _SMOKE_WORDS):
                return "smoke"
            if _has_word(text, _LEAK_WORDS):
                return "leak"
            if _has_word(text, _DOORBELL_WORDS):
                return "doorbell"
            if _has_word(text, _MOTION_WORDS):
                return "motion"
            if _has_word(text, _CONTACT_WORDS):
                return "contact"
        return None

    if domain == "sensor":
        if device_class == "battery":
            return "battery"
        if device_class == "temperature":
            return "temperature"
        if device_class == "humidity":
            return "humidity"
        if device_class == "power":
            return "power"
        if device_class == "energy":
            return "energy"
        if not device_class:
            if unit in ENERGY_UNITS:
                return "energy"
            if unit in POWER_UNITS:
                return "power"
            if unit in TEMPERATURE_UNITS:
                return "temperature"
            if unit == "%":
                if "batter" in text:
                    return "battery"
                if "humid" in text:
                    return "humidity"
        return None

    if domain == "event":
        if device_class == "doorbell" or _has_word(text, _DOORBELL_WORDS):
            return "doorbell"
        if device_class == "button":
            return "button"
        return None

    simple = {
        "valve": "valve",
        "media_player": "media",
        "weather": "weather",
        "switch": "switch",
        "light": "light",
        "camera": "camera",
        "climate": "climate",
        "siren": "siren",
    }
    return simple.get(domain)


def _is_ignored(entity: dict[str, Any]) -> bool:
    return bool(entity.get("disabled")) or _lower(entity.get("entity_category")) in _IGNORED_CATEGORIES


def collect_roles(entities: list[dict[str, Any]]) -> dict[str, str]:
    """Map each role to the first matching entity.

    Diagnostic/config entities are ignored, except for the battery role
    (most Zigbee integrations flag the battery sensor as diagnostic).
    Entities are sorted by entity_id first so the result is deterministic.
    """
    roles: dict[str, str] = {}
    for entity in sorted(entities, key=lambda e: _lower(e.get("entity_id"))):
        role = entity_role(entity)
        if role is None or role in roles:
            continue
        if _is_ignored(entity) and role != "battery":
            continue
        entity_id = entity.get("entity_id")
        if entity_id:
            roles[role] = str(entity_id)
    return roles


def _is_tv(device: dict[str, Any], entities: list[dict[str, Any]]) -> bool:
    for entity in entities:
        if _lower(entity.get("domain")) == "media_player" and _lower(entity.get("device_class")) == "tv":
            return True
    text = " ".join(_lower(device.get(k)) for k in ("model", "name", "manufacturer"))
    words = set(text.replace("-", " ").replace("_", " ").split())
    return any(word in words for word in _TV_WORDS)


def _device_type(device: dict[str, Any], roles: dict[str, str], entities: list[dict[str, Any]] | None = None) -> str:
    if "smoke" in roles:
        return "fumee"
    if "leak" in roles:
        return "fuite"
    if "contact" in roles:
        return "ouverture"
    if "motion" in roles:
        return "mouvement"
    if "camera" in roles:
        return "camera"
    if "climate" in roles:
        return "chauffage"
    if "siren" in roles:
        return "sirene"
    if "valve" in roles:
        return "vanne"
    if "media" in roles:
        return "tv" if _is_tv(device, entities or []) else "enceinte"
    if "doorbell" in roles:
        return "sonnette"
    if "button" in roles and len(roles.keys() - {"battery"}) == 1:
        return "bouton"
    if "light" in roles:
        return "lumiere"
    if "switch" in roles:
        if "power" in roles or "energy" in roles:
            return "prise"
        text = " ".join(_lower(device.get(k)) for k in ("model", "name", "manufacturer"))
        if _has_word(text, _PLUG_WORDS):
            return "prise"
        return "autre"
    if "temperature" in roles:
        return "thermo"
    return "autre"


def classify_device(device: dict[str, Any]) -> dict[str, Any]:
    """Classify a device description (see module docstring)."""
    entities = [e for e in device.get("entities") or [] if isinstance(e, dict)]
    roles = collect_roles(entities)
    device_type = _device_type(device, roles, entities)
    return {
        "type": device_type,
        "type_label": TYPE_LABELS[device_type],
        "entities": roles,
    }


def has_primary_entity(device: dict[str, Any]) -> bool:
    """True when the device has at least one usable, non-diagnostic entity."""
    return any(
        isinstance(e, dict) and not _is_ignored(e) for e in device.get("entities") or []
    )
