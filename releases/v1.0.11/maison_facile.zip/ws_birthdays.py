"""Websocket commands of « Anniversaires » (CONTRACT.md §12).

``id`` being the websocket message id, the commands take ``birthday_id``.
"""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback

from .birthdays import BirthdayError, BirthdaysManager
from .birthdays_rules import MAX_ITEMS, MAX_VCF_BYTES
from .const import DOMAIN, MaisonFacileData

_LOGGER = logging.getLogger(__name__)

MSG_NOT_READY = "Maison Facile n'est pas encore prête. Réessayez dans quelques secondes."
MSG_FAILED = "Une erreur est survenue. Réessayez, ou utilisez la page Dépannage."

ITEM_SCHEMA = vol.Schema(
    {
        vol.Optional("birthday_id"): vol.Any(None, str),
        vol.Required("name"): str,
        vol.Required("day"): vol.Any(int, str),
        vol.Required("month"): vol.Any(int, str),
        vol.Optional("year"): vol.Any(None, int, str),
        vol.Optional("relation"): vol.Any(None, str),
        vol.Optional("phone"): vol.Any(None, str),
        vol.Optional("channel"): vol.Any(None, str),
        vol.Optional("message"): vol.Any(None, str),
        vol.Optional("source"): vol.Any(None, str),
    },
    extra=vol.REMOVE_EXTRA,
)


def _manager(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> BirthdaysManager | None:
    for entry in hass.config_entries.async_entries(DOMAIN):
        data = getattr(entry, "runtime_data", None)
        if isinstance(data, MaisonFacileData) and getattr(data, "birthdays", None) is not None:
            return data.birthdays
    connection.send_error(msg["id"], "not_ready", MSG_NOT_READY)
    return None


async def _run(connection: websocket_api.ActiveConnection, msg: dict[str, Any], coro: Any, what: str) -> None:
    try:
        result = await coro
    except BirthdayError as err:
        connection.send_error(msg["id"], err.code, err.message_fr)
        return
    except Exception:
        _LOGGER.exception("birthdays/%s failed", what)
        connection.send_error(msg["id"], "failed", MSG_FAILED)
        return
    connection.send_result(msg["id"], result)


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/birthdays/list"})
@websocket_api.async_response
async def ws_list(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    payload = manager.list_payload()
    if not connection.user.is_admin:
        # Family accounts see names and dates, never the phone numbers nor the SMS/WhatsApp links.
        from . import birthdays_rules  # noqa: PLC0415

        payload = {**payload, "items": [birthdays_rules.family_view(i) for i in payload["items"]]}
    connection.send_result(msg["id"], payload)


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/birthdays/save", vol.Required("item"): ITEM_SCHEMA})
@websocket_api.async_response
async def ws_save(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return

    async def _save() -> dict[str, Any]:
        item = await manager.async_save_item(msg["item"])
        return {"item": item, **manager.list_payload()}

    await _run(connection, msg, _save(), "save")


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/birthdays/delete", vol.Required("birthday_id"): str})
@websocket_api.async_response
async def ws_delete(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return

    async def _delete() -> dict[str, Any]:
        await manager.async_delete(msg["birthday_id"])
        return manager.list_payload()

    await _run(connection, msg, _delete(), "delete")


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/birthdays/clear"})
@websocket_api.async_response
async def ws_clear(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return

    async def _clear() -> dict[str, Any]:
        await manager.async_clear()
        return manager.list_payload()

    await _run(connection, msg, _clear(), "clear")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/birthdays/import_vcf",
        # Characters; the byte size (2 Mo) is checked by the manager.
        vol.Required("content"): vol.All(str, vol.Length(max=MAX_VCF_BYTES)),
    }
)
@websocket_api.async_response
async def ws_import_vcf(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return

    async def _read() -> dict[str, Any]:
        return await hass.async_add_executor_job(manager.import_vcf, msg["content"])

    await _run(connection, msg, _read(), "import_vcf")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/birthdays/import_confirm",
        vol.Required("items"): vol.All([ITEM_SCHEMA], vol.Length(max=MAX_ITEMS)),
    }
)
@websocket_api.async_response
async def ws_import_confirm(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return

    async def _import() -> dict[str, Any]:
        result = await manager.async_import(msg["items"])
        return {**result, **manager.list_payload()}

    await _run(connection, msg, _import(), "import_confirm")


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/birthdays/calendars"})
@websocket_api.async_response
async def ws_calendars(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    connection.send_result(msg["id"], {"calendars": manager.calendars()})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/birthdays/import_calendar", vol.Required("entity_id"): str}
)
@websocket_api.async_response
async def ws_import_calendar(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_import_calendar(msg["entity_id"]), "import_calendar")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/birthdays/settings",
        vol.Optional("enabled"): bool,
        vol.Optional("days_before"): int,
        vol.Optional("hour"): int,
        vol.Optional("sync_calendar"): bool,
        vol.Optional("calendar_entity"): str,
    }
)
@websocket_api.async_response
async def ws_settings(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    changes = {k: v for k, v in msg.items() if k in ("enabled", "days_before", "hour", "sync_calendar", "calendar_entity")}

    async def _set() -> dict[str, Any]:
        await manager.async_set_settings(changes)
        return manager.list_payload()

    await _run(connection, msg, _set(), "settings")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/birthdays/test_notify", vol.Required("birthday_id"): str}
)
@websocket_api.async_response
async def ws_test_notify(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_test_notify(msg["birthday_id"]), "test_notify")


COMMANDS = (
    ws_list,
    ws_save,
    ws_delete,
    ws_clear,
    ws_import_vcf,
    ws_import_confirm,
    ws_calendars,
    ws_import_calendar,
    ws_settings,
    ws_test_notify,
)


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in COMMANDS:
        websocket_api.async_register_command(hass, command)
