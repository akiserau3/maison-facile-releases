"""Energy summary computed from recorder long-term statistics."""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er
from homeassistant.util import dt as dt_util

from . import compat, rules
from .onboarding import list_devices
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)

ENERGY_UNITS = {"kwh": 1.0, "wh": 0.001, "mwh": 1000.0}
STATE_CLASSES = {"total", "total_increasing"}
WEEKDAYS_FR = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"]
TOP_LIMIT = 5


def _empty(buckets: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "total_kwh": 0.0,
        "cost_eur": 0.0,
        "previous_kwh": 0.0,
        "change_pct": None,
        "buckets": [{"label": b["label"], "kwh": 0.0} for b in buckets],
        "top": [],
        "has_data": False,
    }


# --------------------------------------------------------------------------- sensors


def _energy_sensors(hass: HomeAssistant) -> dict[str, str | None]:
    """{entity_id: device_id|None} for every energy sensor with long-term statistics."""
    ent_reg = er.async_get(hass)
    found: dict[str, str | None] = {}
    for state in hass.states.async_all("sensor"):
        attrs = state.attributes
        if attrs.get("device_class") != "energy":
            continue
        if attrs.get("state_class") not in STATE_CLASSES:
            continue
        if str(attrs.get("unit_of_measurement", "")).lower() not in ENERGY_UNITS:
            continue
        entry = ent_reg.async_get(state.entity_id)
        found[state.entity_id] = entry.device_id if entry else None
    return found


def _plug_device_ids(hass: HomeAssistant, store: MaisonFacileStore) -> set[str]:
    return {d["device_id"] for d in list_devices(hass, store) if d["type"] == "prise"}


async def _grid_sensors(hass: HomeAssistant) -> set[str]:
    """Grid consumption statistics configured in the HA energy dashboard, if any."""
    if "energy" not in hass.config.components:
        return set()
    try:
        from homeassistant.components.energy.data import async_get_manager  # noqa: PLC0415

        manager = await async_get_manager(hass)
    except Exception:  # noqa: BLE001 - energy component optional
        return set()
    data = manager.data or {}
    return compat.grid_import_statistics(data.get("energy_sources"))


# --------------------------------------------------------------------------- periods


def _period_bounds(period: str, now: datetime) -> tuple[datetime, datetime, datetime, list[dict[str, Any]]]:
    """Return (start, prev_start, prev_end, bucket definitions) in local time."""
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if period == "day":
        start = midnight
        prev_start = start - timedelta(days=1)
        buckets = [
            {"label": f"{h} h", "start": start + timedelta(hours=h), "end": start + timedelta(hours=h + 3)}
            for h in range(0, 24, 3)
        ]
    elif period == "week":
        start = midnight - timedelta(days=midnight.weekday())
        prev_start = start - timedelta(days=7)
        buckets = [
            {"label": WEEKDAYS_FR[i], "start": start + timedelta(days=i), "end": start + timedelta(days=i + 1)}
            for i in range(7)
        ]
    else:  # month
        start = midnight.replace(day=1)
        prev_start = (start - timedelta(days=1)).replace(day=1)
        next_month = (start + timedelta(days=32)).replace(day=1)
        buckets = []
        day = start
        index = 1
        while day < next_month:
            end = min(day + timedelta(days=7), next_month)
            buckets.append({"label": f"Sem. {index}", "start": day, "end": end})
            day = end
            index += 1
    # Previous period: same elapsed duration, so the comparison is fair.
    prev_end = prev_start + (now - start)
    return start, prev_start, prev_end, buckets


def _row_start(row: dict[str, Any]) -> datetime | None:
    value = row.get("start")
    if isinstance(value, (int, float)):
        return dt_util.utc_from_timestamp(value)
    if isinstance(value, datetime):
        return value
    return None


# --------------------------------------------------------------------------- summary


async def async_energy_summary(
    hass: HomeAssistant, store: MaisonFacileStore, period: str
) -> dict[str, Any]:
    kwh_price = float(store.settings.get("kwh_price") or 0)
    now = dt_util.now()
    start, prev_start, prev_end, buckets = _period_bounds(period, now)

    if "recorder" not in hass.config.components:
        return _empty(buckets)

    sensors = _energy_sensors(hass)
    grid = await _grid_sensors(hass)
    plug_devices = _plug_device_ids(hass, store)
    # Plugs only: sensors that look like a main meter (no plug device, or a
    # name such as "Linky", "compteur", "total"...) are never summed.
    device_ids: dict[str, str | None] = {}
    for eid, dev in sensors.items():
        if eid in grid:
            continue
        state = hass.states.get(eid)
        name = state.name if state is not None else None
        if rules.looks_like_main_meter(name, eid, dev is not None and dev in plug_devices):
            continue
        device_ids[eid] = dev
    # The house total is the grid consumption of the HA energy dashboard when
    # configured, otherwise the sum of the plugs.
    total_ids = grid or set(device_ids)
    all_ids = total_ids | set(device_ids)
    if not all_ids:
        return _empty(buckets)

    from homeassistant.components.recorder import get_instance  # noqa: PLC0415
    from homeassistant.components.recorder.statistics import (  # noqa: PLC0415
        statistic_during_period,
        statistics_during_period,
    )

    instance = get_instance(hass)
    units = {"energy": "kWh"}

    try:
        stats: dict[str, list[dict[str, Any]]] = await instance.async_add_executor_job(
            statistics_during_period,
            hass,
            dt_util.as_utc(start),
            dt_util.as_utc(now),
            all_ids,
            "hour",
            units,
            {"change"},
        )

        def _previous() -> float:
            total = 0.0
            for stat_id in total_ids:
                result = statistic_during_period(
                    hass, dt_util.as_utc(prev_start), dt_util.as_utc(prev_end), stat_id, {"change"}, units
                )
                total += float(result.get("change") or 0)
            return total

        previous = await instance.async_add_executor_job(_previous)
    except Exception:  # noqa: BLE001 - never break the panel because of statistics
        _LOGGER.exception("Could not read energy statistics")
        return _empty(buckets)

    has_rows = False
    bucket_totals = [0.0] * len(buckets)
    per_stat: dict[str, float] = {}
    for stat_id, rows in stats.items():
        subtotal = 0.0
        for row in rows:
            change = row.get("change")
            if change is None:
                continue
            has_rows = True
            change = max(0.0, float(change))
            subtotal += change
            if stat_id in total_ids:
                row_start = _row_start(row)
                if row_start is None:
                    continue
                local = dt_util.as_local(row_start)
                for index, bucket in enumerate(buckets):
                    if bucket["start"] <= local < bucket["end"]:
                        bucket_totals[index] += change
                        break
        per_stat[stat_id] = subtotal

    total = sum(per_stat.get(s, 0.0) for s in total_ids)

    # Top consumers grouped by device name.
    dev_reg = dr.async_get(hass)
    by_name: dict[str, float] = {}
    for stat_id, device_id in device_ids.items():
        kwh = per_stat.get(stat_id, 0.0)
        if kwh <= 0:
            continue
        name: str | None = None
        if device_id and (device := dev_reg.async_get(device_id)) is not None:
            name = device.name_by_user or device.name
        if not name:
            state = hass.states.get(stat_id)
            name = state.name if state else stat_id
        by_name[name] = by_name.get(name, 0.0) + kwh
    reference = total or sum(by_name.values())
    top = [
        {
            "name": name,
            "kwh": round(kwh, 2),
            "share_pct": round(100 * kwh / reference) if reference else 0,
        }
        for name, kwh in sorted(by_name.items(), key=lambda kv: kv[1], reverse=True)[:TOP_LIMIT]
    ]

    change_pct = round(100 * (total - previous) / previous) if previous > 0 else None
    return {
        "total_kwh": round(total, 2),
        "cost_eur": round(total * kwh_price, 2),
        "previous_kwh": round(previous, 2),
        "change_pct": change_pct,
        "buckets": [
            {"label": b["label"], "kwh": round(bucket_totals[i], 2)} for i, b in enumerate(buckets)
        ],
        "top": top,
        "has_data": has_rows,
    }
