"""Memories of the ideas, shown as home tiles (kept across restarts).

* « Courrier en attente » (switch.maison_facile_courrier), idea « Courrier arrivé »: the
  blueprint ``mailbox_alert.yaml`` turns it on when the postman passes and off when the
  front door opens; the home tile « Relevé » turns it off. Attribute ``arrived_at`` (ISO,
  UTC) = time of the last delivery.
* « Poubelles à sortir » (switch.maison_facile_poubelles), idea « Poubelles » : the blueprint
  ``bins_reminder.yaml`` turns it on the evening before a collection and off the next day;
  the home tile « Sorti » turns it off. Attributes ``reminded_at`` = time of the reminder,
  ``bins`` = « le bac jaune et le bac vert » (entity service ``maison_facile.remind_bins``).
"""

from __future__ import annotations

from typing import Any

import voluptuous as vol
from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers import entity_platform
from homeassistant.helpers.device_registry import DeviceEntryType, DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity
from homeassistant.util import dt as dt_util

from .const import BIN_FLAG_ENTITY_ID, DOMAIN, MAIL_FLAG_ENTITY_ID, VERSION

SERVICE_REMIND_BINS = "remind_bins"


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    async_add_entities([MailWaitingSwitch(entry), BinsOutSwitch(entry)])
    # maison_facile.remind_bins {bins}: « Ce soir : sortez le bac jaune » (bins_reminder.yaml).
    entity_platform.async_get_current_platform().async_register_entity_service(
        SERVICE_REMIND_BINS, {vol.Required("bins"): cv.string}, "async_remind_bins"
    )


class MailWaitingSwitch(SwitchEntity, RestoreEntity):
    """On = du courrier attend dans la boîte aux lettres."""

    _attr_has_entity_name = True
    _attr_translation_key = "mail"
    _attr_icon = "mdi:mailbox"
    _attr_should_poll = False

    def __init__(self, entry: ConfigEntry) -> None:
        self._attr_unique_id = f"{DOMAIN}_courrier"
        self.entity_id = MAIL_FLAG_ENTITY_ID
        self._attr_is_on = False
        self._arrived_at: str | None = None
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="Maison Facile",
            manufacturer="Maison Facile",
            model="Ma maison",
            sw_version=VERSION,
            entry_type=DeviceEntryType.SERVICE,
        )

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {"arrived_at": self._arrived_at}

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        last = await self.async_get_last_state()
        if last is not None:
            self._attr_is_on = last.state == "on"
            self._arrived_at = last.attributes.get("arrived_at")

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._attr_is_on = True
        self._arrived_at = dt_util.utcnow().isoformat()
        self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._attr_is_on = False
        self.async_write_ha_state()


class BinsOutSwitch(SwitchEntity, RestoreEntity):
    """On = une poubelle est à sortir ce soir (collecte demain)."""

    _attr_has_entity_name = True
    _attr_translation_key = "bins"
    _attr_icon = "mdi:trash-can"
    _attr_should_poll = False

    def __init__(self, entry: ConfigEntry) -> None:
        self._attr_unique_id = f"{DOMAIN}_poubelles"
        self.entity_id = BIN_FLAG_ENTITY_ID
        self._attr_is_on = False
        self._reminded_at: str | None = None
        self._bins: str | None = None
        self._attr_device_info = DeviceInfo(identifiers={(DOMAIN, entry.entry_id)})

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        return {"reminded_at": self._reminded_at, "bins": self._bins}

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        last = await self.async_get_last_state()
        if last is not None:
            self._attr_is_on = last.state == "on"
            self._reminded_at = last.attributes.get("reminded_at")
            self._bins = last.attributes.get("bins")

    async def async_turn_on(self, **kwargs: Any) -> None:
        self._attr_is_on = True
        self._reminded_at = dt_util.utcnow().isoformat()
        self.async_write_ha_state()

    async def async_remind_bins(self, bins: str) -> None:
        """On, with the bins to take out tonight (shown on the home tile)."""
        self._bins = str(bins).strip()[:200] or None
        await self.async_turn_on()

    async def async_turn_off(self, **kwargs: Any) -> None:
        self._attr_is_on = False
        self.async_write_ha_state()
