"""Apparence: effective theme of the day (theme_rules.py) for the panels.

- ``state/get.appearance`` and ``settings/set.appearance`` (websocket_api.py);
- ``maison_facile/appearance/subscribe``: one message ``{appearance}`` now, then again
  just after local midnight (``async_track_time_change``) and whenever a setting that
  changes the theme is saved (dispatcher ``SIGNAL_APPEARANCE``), so every tablet of the
  house switches to Halloween at the same time.
"""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.dispatcher import (
    async_dispatcher_connect,
    async_dispatcher_send,
)
from homeassistant.helpers.event import async_track_time_change
from homeassistant.util import dt as dt_util

from . import theme_rules
from .const import DOMAIN, SIGNAL_APPEARANCE, MaisonFacileData

_LOGGER = logging.getLogger(__name__)

# Settings whose change can change what the screens show.
APPEARANCE_KEYS = {"theme", "theme_auto", "animations", "home_style", "liked_styles"}


def appearance_for(settings: dict[str, Any]) -> dict[str, Any]:
    """Effective theme for today's LOCAL date of Home Assistant."""
    return theme_rules.appearance_summary(settings, dt_util.now().date())


@callback
def async_notify_changed(hass: HomeAssistant, changes: dict[str, Any]) -> None:
    """Tell the subscribed panels when an appearance setting was saved."""
    if APPEARANCE_KEYS & set(changes):
        async_dispatcher_send(hass, SIGNAL_APPEARANCE)


def _settings(hass: HomeAssistant) -> dict[str, Any] | None:
    for entry in hass.config_entries.async_entries(DOMAIN):
        data = getattr(entry, "runtime_data", None)
        if isinstance(data, MaisonFacileData) and data.store is not None:
            return data.store.settings
    return None


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/appearance/subscribe"})
@callback
def ws_appearance_subscribe(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if _settings(hass) is None:
        connection.send_error(
            msg["id"], "not_ready", "Maison Facile n'est pas encore prête. Réessayez dans quelques secondes."
        )
        return

    @callback
    def push(*_args: Any) -> None:
        settings = _settings(hass)
        if settings is None:
            return
        connection.send_message(
            websocket_api.event_message(msg["id"], {"appearance": appearance_for(settings)})
        )

    unsubs = [
        async_dispatcher_connect(hass, SIGNAL_APPEARANCE, push),
        # A few seconds after midnight, local time of the box.
        async_track_time_change(hass, push, hour=0, minute=0, second=5),
    ]

    @callback
    def unsubscribe() -> None:
        for unsub in unsubs:
            unsub()

    connection.subscriptions[msg["id"]] = unsubscribe
    connection.send_result(msg["id"])
    push()


@callback
def async_register(hass: HomeAssistant) -> None:
    websocket_api.async_register_command(hass, ws_appearance_subscribe)
