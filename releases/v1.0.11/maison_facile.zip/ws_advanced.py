"""Websocket commands of the "Réglages avancés" (commercial mode, NOTES_commercial.md).

| type | entrée | sortie |
|---|---|---|
| `advanced/status` | – | `{commercial_mode, unlocked, until, pin_set, is_admin}` |
| `advanced/unlock` (admin) | `{pin?}` | `{ok:true, until}` — 30 min for THIS user |
| `advanced/lock` (admin) | – | status |
| `advanced/set_pin` (admin, installer mode) | `{pin}` ("" = no code) | status |
"""

from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback

from . import audience
from .const import DOMAIN, MaisonFacileData
from .rules import validate_settings

ERR_NOT_READY = "not_ready"
ERR_INVALID = "invalid_format"
ERR_LOCKED = "locked"
ERR_PIN = "invalid_pin"
ERR_TOO_MANY = "too_many_attempts"

MSG_NOT_READY = "Maison Facile n'est pas encore prête. Réessayez dans quelques secondes."
MSG_LOCKED = "Ouvrez d'abord les réglages avancés (mode installateur)."


def _manager(hass: HomeAssistant) -> Any:
    for entry in hass.config_entries.async_entries(DOMAIN):
        data = getattr(entry, "runtime_data", None)
        if isinstance(data, MaisonFacileData) and data.commercial is not None:
            return data.commercial
    return None


def _require(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> Any:
    manager = _manager(hass)
    if manager is None:
        connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
    return manager


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/advanced/status"})
@callback
def ws_advanced_status(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (manager := _require(hass, connection, msg)) is None:
        return
    connection.send_result(msg["id"], manager.status(connection.user))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/advanced/unlock",
        vol.Optional("pin"): vol.Any(None, vol.All(str, vol.Length(max=64))),
    }
)
@websocket_api.async_response
async def ws_advanced_unlock(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (manager := _require(hass, connection, msg)) is None:
        return
    result = await manager.async_unlock(connection.user, msg.get("pin"))
    if not result["ok"]:
        connection.send_error(msg["id"], result["code"], result["message_fr"])
        return
    connection.send_result(msg["id"], {"ok": True, "until": result["until"]})


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/advanced/lock"})
@callback
def ws_advanced_lock(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (manager := _require(hass, connection, msg)) is None:
        return
    manager.lock(connection.user.id)
    connection.send_result(msg["id"], manager.status(connection.user))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/advanced/set_pin", vol.Required("pin"): vol.All(str, vol.Length(max=64))}
)
@websocket_api.async_response
async def ws_advanced_set_pin(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> None:
    if (manager := _require(hass, connection, msg)) is None:
        return
    if not manager.can_manage(connection.user):
        connection.send_error(msg["id"], ERR_LOCKED, audience.for_hass(MSG_LOCKED, hass))
        return
    clean, errors = validate_settings({"installer_pin": msg["pin"]})
    if errors:
        connection.send_error(
            msg["id"], ERR_INVALID, "Le code doit contenir 4 à 8 chiffres (ou rester vide pour ne pas en avoir)."
        )
        return
    await manager.async_set_pin(clean["installer_pin"])
    connection.send_result(msg["id"], manager.status(connection.user))


COMMANDS = (ws_advanced_status, ws_advanced_unlock, ws_advanced_lock, ws_advanced_set_pin)


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in COMMANDS:
        websocket_api.async_register_command(hass, command)
