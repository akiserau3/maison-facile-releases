"""Installe et active le gardien des mises à jour (intégration ``maison_facile_guard``).

Le gardien est livré DANS Maison Facile (dossier ``guard/``) et recopié à chaque démarrage
dans ``custom_components/maison_facile_guard`` s'il manque ou a changé. Il a sa propre
entrée (créée ici, source « system ») : il se charge donc même si une future version de
Maison Facile est cassée. Voir guard/__init__.py.
"""

from __future__ import annotations

import filecmp
import logging
import os
import shutil
import tempfile
from pathlib import Path

from homeassistant import data_entry_flow, loader
from homeassistant.core import HomeAssistant

_LOGGER = logging.getLogger(__name__)
GUARD_DOMAIN = "maison_facile_guard"
GUARD_SOURCE = Path(__file__).parent / "guard"
GUARD_FILES = ("__init__.py", "config_flow.py", "rules.py", "manifest.json")


def _guard_up_to_date(dest: Path) -> bool:
    return all(
        (dest / name).is_file() and filecmp.cmp(GUARD_SOURCE / name, dest / name, shallow=False)
        for name in GUARD_FILES
    )


def _copy_guard(custom_components: Path) -> bool:
    """Copie le gardien (remplacement atomique). True si des fichiers ont changé."""
    dest = custom_components / GUARD_DOMAIN
    if _guard_up_to_date(dest):
        return False
    custom_components.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=f".{GUARD_DOMAIN}_", dir=custom_components))
    try:
        for name in GUARD_FILES:
            shutil.copy2(GUARD_SOURCE / name, tmp / name)
        old = custom_components / f".{GUARD_DOMAIN}_old"
        if old.exists():
            shutil.rmtree(old)
        if dest.exists():
            os.replace(dest, old)
        os.replace(tmp, dest)
        shutil.rmtree(old, ignore_errors=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return True


def _forget_loader_cache(hass: HomeAssistant) -> None:
    """Home Assistant a déjà listé les intégrations perso au démarrage : on lui fait
    relire la liste pour qu'il trouve le gardien qui vient d'être copié."""
    comps = hass.data.get(loader.DATA_CUSTOM_COMPONENTS)
    if isinstance(comps, dict) and GUARD_DOMAIN not in comps:
        hass.data.pop(loader.DATA_CUSTOM_COMPONENTS, None)
    cache = hass.data.get(loader.DATA_INTEGRATIONS)
    if isinstance(cache, dict) and GUARD_DOMAIN in cache:
        cached = cache[GUARD_DOMAIN]
        if not isinstance(cached, loader.Integration):
            cache.pop(GUARD_DOMAIN, None)


async def async_ensure_guard(hass: HomeAssistant) -> None:
    """Gardien présent, à jour et activé. Ne lève jamais (best effort, réessayé au démarrage)."""
    try:
        custom_components = Path(hass.config.path("custom_components"))
        changed = await hass.async_add_executor_job(_copy_guard, custom_components)
        if changed:
            _LOGGER.info("Maison Facile update guard installed/updated")
        if hass.config_entries.async_entries(GUARD_DOMAIN):
            return
        _forget_loader_cache(hass)
        try:
            await hass.config_entries.flow.async_init(GUARD_DOMAIN, context={"source": "system"})
        except (loader.IntegrationNotFound, data_entry_flow.UnknownHandler):
            # Dossier custom_components inhabituel (tests, installation manuelle) : on réessaiera
            # au prochain démarrage, quand Home Assistant aura relu ses intégrations.
            _LOGGER.warning("Update guard copied but not found yet by Home Assistant")
    except Exception:  # noqa: BLE001 - jamais bloquant pour Maison Facile
        _LOGGER.exception("Could not install the Maison Facile update guard")
