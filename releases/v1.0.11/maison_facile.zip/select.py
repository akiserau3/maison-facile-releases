"""House mode select entity: select.maison_facile_mode."""

from __future__ import annotations

from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceEntryType, DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity

from .const import DOMAIN, MODES, VERSION


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    async_add_entities([HouseModeSelect(entry)])


class HouseModeSelect(SelectEntity, RestoreEntity):
    """« Mode de la maison » : maison / absent / nuit."""

    _attr_has_entity_name = True
    _attr_translation_key = "mode"
    _attr_icon = "mdi:home-switch"
    _attr_options = list(MODES)
    _attr_should_poll = False

    def __init__(self, entry: ConfigEntry) -> None:
        self._attr_unique_id = f"{DOMAIN}_mode"
        # Forces entity_id select.maison_facile_mode whatever the language.
        self.entity_id = f"select.{DOMAIN}_mode"
        self._attr_current_option = MODES[0]
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="Maison Facile",
            manufacturer="Maison Facile",
            model="Ma maison",
            sw_version=VERSION,
            entry_type=DeviceEntryType.SERVICE,
        )

    async def async_added_to_hass(self) -> None:
        await super().async_added_to_hass()
        last = await self.async_get_last_state()
        if last is not None and last.state in MODES:
            self._attr_current_option = last.state

    async def async_select_option(self, option: str) -> None:
        if option not in MODES:
            raise ValueError(f"Mode inconnu : {option}")
        self._attr_current_option = option
        self.async_write_ha_state()
