"""« Bilan du mois » : monthly energy report (idea ``bilan_mensuel``, CONTRACT.md §11).

On the 1st of each month (9:05, caught up during the first week if the box was off), the
consumption of the past month is read from the recorder long-term statistics — the same
sensors as the « Énergie » page (energy.py): the grid consumption of the HA energy
dashboard when it is configured, otherwise the sum of the plugs that measure — and sent as
« En octobre, la maison a consommé 312 kWh, soit environ 78 € … » with the comparison to the
month before (persistent notification + ``settings.notify_service``). Price = ``kwh_price``.

Store key ``energy_report`` = ``{enabled: bool, last_sent: "YYYY-MM" | None}``.
"""

from __future__ import annotations

import datetime as dt
import logging
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import CALLBACK_TYPE, HomeAssistant, callback
from homeassistant.helpers.event import async_track_time_change
from homeassistant.helpers.start import async_at_started
from homeassistant.util import dt as dt_util

from . import rules
from .const import DOMAIN, MaisonFacileData
from .energy import _energy_sensors, _grid_sensors, _plug_device_ids

_LOGGER = logging.getLogger(__name__)

STORE_KEY = "energy_report"
RUN_HOUR, RUN_MINUTE = 9, 5
CATCH_UP_DAYS = 7  # the box was off on the 1st: still send it during the first week
NOTIFICATION_ID = "mf_idea_bilan_mensuel"

MONTHS_FR = [
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre",
]


# --------------------------------------------------------------------------- pure helpers


def month_bounds(today: dt.date) -> tuple[dt.date, dt.date, dt.date]:
    """(start of the month before last, start of last month, start of this month)."""
    this_start = today.replace(day=1)
    last_start = (this_start - dt.timedelta(days=1)).replace(day=1)
    before_start = (last_start - dt.timedelta(days=1)).replace(day=1)
    return before_start, last_start, this_start


def month_key(day: dt.date) -> str:
    return f"{day.year:04d}-{day.month:02d}"


def _de(month: str) -> str:
    """« de mars » / « d'avril »."""
    return f"d'{month}" if month[0] in "aeiouyéèâ" else f"de {month}"


def _num(value: float) -> str:
    return f"{value:,.0f}".replace(",", " ")


def report_text(
    last_month: int, before_month: int, kwh: float, previous_kwh: float, price: float, whole_house: bool
) -> tuple[str, str]:
    """(title, message) of the monthly report, in simple French."""
    month = MONTHS_FR[last_month - 1]
    before = MONTHS_FR[before_month - 1]
    who = "la maison a consommé" if whole_house else "les appareils branchés sur une prise qui mesure ont consommé"
    message = f"En {month}, {who} {_num(kwh)} kWh"
    if price > 0:
        message += f", soit environ {_num(kwh * price)} €"
    message += "."
    if previous_kwh > 0:
        change = round(100 * (kwh - previous_kwh) / previous_kwh)
        if abs(change) <= 2:
            message += f" C'est à peu près comme en {before}."
        elif change < 0:
            message += f" C'est {-change} % de moins qu'en {before} : bravo !"
        else:
            message += f" C'est {change} % de plus qu'en {before}."
    return f"Bilan {_de(month)}", message


# --------------------------------------------------------------------------- module


class EnergyReportManager:
    """Monthly report: on / off (the idea), schedule, statistics, message."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, data: MaisonFacileData) -> None:
        self.hass = hass
        self.entry = entry
        self.data = data
        self.store = data.store
        self._unsubs: list[CALLBACK_TYPE] = []

    async def async_setup(self) -> None:
        self._unsubs.append(
            async_track_time_change(self.hass, self._on_time, hour=RUN_HOUR, minute=RUN_MINUTE, second=0)
        )
        # Runs now if HA has started, else once it has (cancel is safe after it ran).
        self._unsubs.append(async_at_started(self.hass, self._on_started))

    @callback
    def async_unload(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs.clear()

    @callback
    def _on_started(self, _hass: HomeAssistant) -> None:
        self._start()

    @callback
    def _on_time(self, _now: dt.datetime) -> None:
        self._start()

    @callback
    def _start(self) -> None:
        self.entry.async_create_background_task(self.hass, self._async_safe_run(), f"{DOMAIN}_energy_report")

    async def _async_safe_run(self) -> None:
        try:
            await self.async_run()
        except Exception:
            _LOGGER.exception("Monthly energy report failed")

    # ------------------------------------------------------------------ state

    @property
    def raw(self) -> dict[str, Any]:
        value = self.store.data.get(STORE_KEY)
        value = value if isinstance(value, dict) else {}
        return {"enabled": bool(value.get("enabled", False)), "last_sent": value.get("last_sent")}

    @callback
    def module_state(self) -> dict[str, Any]:
        """For the idea « Bilan du mois » (ideas_rules context ``modules.energy_report``)."""
        return {"active": self.raw["enabled"], "preview_tile": None}

    async def async_set_enabled(self, enabled: bool) -> None:
        raw = self.raw
        raw["enabled"] = bool(enabled)
        if enabled and not raw.get("last_sent"):
            # No report for a month that ended before the idea was switched on.
            raw["last_sent"] = month_key(month_bounds(dt_util.now().date())[1])
        await self.store.async_set(STORE_KEY, raw)

    # ------------------------------------------------------------------ report

    async def async_month_totals(self, today: dt.date) -> dict[str, Any] | None:
        """kWh of last month and of the month before (None without recorder / sensors)."""
        if "recorder" not in self.hass.config.components:
            return None
        sensors = _energy_sensors(self.hass)
        grid = await _grid_sensors(self.hass)
        plugs = _plug_device_ids(self.hass, self.store)
        # Same choice as the « Énergie » page: grid consumption if configured, else the plugs.
        plug_ids = set()
        for entity_id, device_id in sensors.items():
            if entity_id in grid:
                continue
            state = self.hass.states.get(entity_id)
            name = state.name if state is not None else None
            if rules.looks_like_main_meter(name, entity_id, device_id is not None and device_id in plugs):
                continue
            plug_ids.add(entity_id)
        total_ids = grid or plug_ids
        if not total_ids:
            return None

        from homeassistant.components.recorder import get_instance  # noqa: PLC0415
        from homeassistant.components.recorder.statistics import (
            statistic_during_period,  # noqa: PLC0415
        )

        before_start, last_start, this_start = month_bounds(today)

        def _utc(day: dt.date) -> dt.datetime:
            return dt_util.as_utc(dt.datetime.combine(day, dt.time(0, 0), tzinfo=dt_util.get_default_time_zone()))

        def _sum(start: dt.date, end: dt.date) -> float:
            total = 0.0
            for stat_id in total_ids:
                result = statistic_during_period(
                    self.hass, _utc(start), _utc(end), stat_id, {"change"}, {"energy": "kWh"}
                )
                total += max(0.0, float(result.get("change") or 0))
            return total

        instance = get_instance(self.hass)
        last = await instance.async_add_executor_job(_sum, last_start, this_start)
        previous = await instance.async_add_executor_job(_sum, before_start, last_start)
        return {"kwh": last, "previous_kwh": previous, "whole_house": bool(grid),
                "month": last_start.month, "before_month": before_start.month}

    async def async_run(self, force: bool = False) -> bool:
        """Send last month's report once (True when sent)."""
        raw = self.raw
        if not raw["enabled"] and not force:
            return False
        now = dt_util.now()
        today = now.date()
        last_key = month_key(month_bounds(today)[1])
        if not force:
            if raw.get("last_sent") == last_key or today.day > CATCH_UP_DAYS:
                return False
            if today.day == 1 and (now.hour, now.minute) < (RUN_HOUR, RUN_MINUTE):
                return False
        # Marked as sent BEFORE any await: two runs close together (start-up + 9:05) send it once.
        raw["last_sent"] = last_key
        await self.store.async_set(STORE_KEY, raw)  # sets store.data before its first await
        totals = await self.async_month_totals(today)
        if not totals or totals["kwh"] <= 0:
            _LOGGER.info("Monthly report %s: no consumption measured, nothing sent", last_key)
            return False
        price = float(self.store.settings.get("kwh_price") or 0)
        title, message = report_text(
            totals["month"], totals["before_month"], totals["kwh"], totals["previous_kwh"], price, totals["whole_house"]
        )
        await self.hass.services.async_call(
            "persistent_notification", "create",
            {"notification_id": NOTIFICATION_ID, "title": title, "message": message}, blocking=True,
        )
        service = str(self.store.settings.get("notify_service") or "")
        domain, _, name = service.partition(".")
        if name and self.hass.services.has_service(domain, name):
            try:
                await self.hass.services.async_call(domain, name, {"title": title, "message": message}, blocking=True)
            except Exception as err:  # noqa: BLE001 - the persistent notification is there anyway
                _LOGGER.warning("Monthly report: notification failed (%s)", type(err).__name__)
        _LOGGER.info("Monthly report %s sent", last_key)
        return True


async def async_setup_energy_report(
    hass: HomeAssistant, entry: ConfigEntry, data: MaisonFacileData
) -> EnergyReportManager:
    manager = EnergyReportManager(hass, entry, data)
    await manager.async_setup()
    return manager
