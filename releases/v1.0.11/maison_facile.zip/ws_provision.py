"""Websocket commands "maison_facile/provision/*" (CONTRACT_KIT.md §4)."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback

from . import provision_rules as rules
from . import audience
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

ERR_NOT_READY = "not_ready"
ERR_NOT_FOUND = "not_found"
MSG_NOT_READY = "Maison Facile démarre encore. Réessayez dans quelques secondes."
INACTIVE = {"active": False, "done": False, "kit": None, "steps": []}


def _provisioner(hass: HomeAssistant) -> Any | None:
    for entry in hass.config_entries.async_entries(DOMAIN):
        provision = getattr(getattr(entry, "runtime_data", None), "provision", None)
        if provision is not None:
            return provision
    return None


def _loaded(hass: HomeAssistant) -> bool:
    return any(
        getattr(getattr(e, "runtime_data", None), "store", None) is not None
        for e in hass.config_entries.async_entries(DOMAIN)
    )


def provision_summary(hass: HomeAssistant) -> dict[str, bool]:
    """``{active, done}`` for state/get."""
    provision = _provisioner(hass)
    return provision.summary() if provision is not None else {"active": False, "done": False}


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/provision/status"})
@callback
def ws_provision_status(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    provision = _provisioner(hass)
    if provision is None:
        if not _loaded(hass):
            connection.send_error(msg["id"], ERR_NOT_READY, MSG_NOT_READY)
            return
        connection.send_result(msg["id"], audience.for_hass(dict(INACTIVE), hass))
        return
    connection.send_result(msg["id"], audience.for_hass(provision.status(), hass))


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/provision/subscribe"})
@callback
def ws_provision_subscribe(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    provision = _provisioner(hass)
    msg_id = msg["id"]
    if provision is None:
        if not _loaded(hass):
            connection.send_error(msg_id, ERR_NOT_READY, MSG_NOT_READY)
            return
        # Not a box prepared by the installer: nothing will ever change.
        connection.subscriptions[msg_id] = lambda: None
        connection.send_result(msg_id)
        connection.send_message(websocket_api.event_message(msg_id, dict(INACTIVE)))
        return

    @callback
    def _forward(payload: dict[str, Any]) -> None:
        connection.send_message(websocket_api.event_message(msg_id, audience.for_hass(payload, hass)))

    connection.subscriptions[msg_id] = provision.async_subscribe(_forward)
    connection.send_result(msg_id)
    _forward(provision.status())  # first message = current state


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/provision/retry", vol.Required("step_id"): vol.In(rules.STEP_IDS)}
)
@websocket_api.async_response
async def ws_provision_retry(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict) -> None:
    provision = _provisioner(hass)
    if provision is None or provision.state is None:
        connection.send_error(msg["id"], ERR_NOT_FOUND, "Aucune préparation automatique n'est prévue sur cette box.")
        return
    try:
        await provision.async_retry(msg["step_id"])
    except KeyError:
        connection.send_error(msg["id"], ERR_NOT_FOUND, "Cette étape n'existe pas.")
        return
    connection.send_result(msg["id"], audience.for_hass(provision.status(), hass))


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in (ws_provision_status, ws_provision_subscribe, ws_provision_retry):
        websocket_api.async_register_command(hass, command)
