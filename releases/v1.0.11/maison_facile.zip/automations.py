"""Blueprint installation and management of Maison Facile automations.

Only automations whose ``id`` starts with ``mf_`` are ever touched.
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

import yaml

from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .const import AUTOMATION_ID_PREFIX, BLUEPRINT_SUBDIR
from .rules import yaml_has_comments

_LOGGER = logging.getLogger(__name__)

AUTOMATIONS_FILE = "automations.yaml"
BACKUP_SUFFIX = ".mf-"
BACKUPS_KEPT = 5
EMBEDDED_BLUEPRINTS = Path(__file__).parent / "blueprints" / "automation"


class _Dumper(yaml.SafeDumper):
    """SafeDumper that never emits tags/anchors and keeps multiline text readable."""

    def ignore_aliases(self, data: Any) -> bool:  # noqa: ARG002
        return True


class _Tagged:
    """A user scalar with a custom tag (``!secret x``, ``!include y``), kept verbatim."""

    __slots__ = ("tag", "value")

    def __init__(self, tag: str, value: str) -> None:
        self.tag = tag
        self.value = value

    def __eq__(self, other: object) -> bool:
        return isinstance(other, _Tagged) and (self.tag, self.value) == (other.tag, other.value)

    def __hash__(self) -> int:
        return hash((self.tag, self.value))


class _Loader(yaml.SafeLoader):
    """SafeLoader that keeps unknown tags instead of resolving them.

    Secrets are never resolved, so they can never be written back in clear.
    """


def _construct_tagged(loader: yaml.SafeLoader, tag_suffix: str, node: yaml.Node) -> _Tagged:
    if not isinstance(node, yaml.ScalarNode):
        raise ValueError("Unsupported tagged YAML collection in automations.yaml")
    return _Tagged("!" + tag_suffix, loader.construct_scalar(node))


_Loader.add_multi_constructor("!", _construct_tagged)


def _str_presenter(dumper: yaml.SafeDumper, data: str) -> yaml.ScalarNode:
    style = "|" if "\n" in data else None
    return dumper.represent_scalar("tag:yaml.org,2002:str", data, style=style)


def _tagged_presenter(dumper: yaml.SafeDumper, data: _Tagged) -> yaml.ScalarNode:
    return dumper.represent_scalar(data.tag, data.value)


_Dumper.add_representer(str, _str_presenter)
_Dumper.add_representer(_Tagged, _tagged_presenter)


def _is_mf(item: Any) -> bool:
    return isinstance(item, dict) and str(item.get("id", "")).startswith(AUTOMATION_ID_PREFIX)


# --------------------------------------------------------------------------- blueprints


def _copy_blueprints(config_dir: str) -> int:
    """Copy embedded blueprints when missing or older. Runs in the executor."""
    if not EMBEDDED_BLUEPRINTS.is_dir():
        _LOGGER.warning("Embedded blueprints folder is missing: %s", EMBEDDED_BLUEPRINTS)
        return 0
    target = Path(config_dir) / "blueprints" / "automation" / BLUEPRINT_SUBDIR
    target.mkdir(parents=True, exist_ok=True)
    copied = 0
    for source in sorted(EMBEDDED_BLUEPRINTS.glob("*.yaml")):
        dest = target / source.name
        if dest.exists():
            # copy2 keeps the mtime, so a destination newer than the embedded
            # file was edited locally: keep it. Same content: nothing to do.
            if source.read_bytes() == dest.read_bytes():
                continue
            if source.stat().st_mtime < dest.stat().st_mtime:
                continue
        tmp = dest.with_suffix(".yaml.tmp")
        shutil.copy2(source, tmp)
        os.replace(tmp, dest)
        copied += 1
    return copied


async def async_install_blueprints(hass: HomeAssistant) -> int:
    copied = await hass.async_add_executor_job(_copy_blueprints, hass.config.config_dir)
    if copied:
        _LOGGER.info("Installed %s Maison Facile blueprint(s)", copied)
    return copied


# --------------------------------------------------------------------------- automations.yaml


def _read_text(path: Path) -> str:
    if not path.exists():
        return ""
    with path.open(encoding="utf-8") as handle:
        return handle.read()


def _parse(content: str) -> list[Any]:
    if not content.strip():
        return []
    data = yaml.load(content, Loader=_Loader)  # noqa: S506 - SafeLoader subclass
    if data is None:
        return []
    if not isinstance(data, list):
        raise ValueError("automations.yaml is not a list")
    return data


def _read_automations(path: Path) -> list[Any]:
    return _parse(_read_text(path))


def _backup(path: Path) -> None:
    """Copy ``path`` to ``<name>.mf-<timestamp>`` and keep the last BACKUPS_KEPT copies."""
    if not path.exists():
        return
    stamp = dt_util.utcnow().strftime("%Y%m%d-%H%M%S-%f")
    shutil.copy2(path, path.with_name(f"{path.name}{BACKUP_SUFFIX}{stamp}"))
    backups = sorted(path.parent.glob(f"{path.name}{BACKUP_SUFFIX}*"))
    for old in backups[:-BACKUPS_KEPT]:
        try:
            old.unlink()
        except OSError:
            _LOGGER.debug("Could not remove old backup %s", old.name)


def _write_atomic(path: Path, data: list[Any]) -> None:
    text = yaml.dump(
        data, Dumper=_Dumper, allow_unicode=True, sort_keys=False, default_flow_style=False
    ) if data else "[]\n"
    fd, tmp = tempfile.mkstemp(prefix=".automations.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        if path.exists():
            shutil.copymode(path, tmp)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def instance_to_automation(instance: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": instance["automation_id"],
        "alias": instance["alias"],
        "description": instance["description"],
        "use_blueprint": {"path": instance["blueprint"], "input": instance["inputs"]},
    }


def _apply(
    link: Path, remove_ids: set[str], remove_prefixes: tuple[str, ...], add: list[dict[str, Any]]
) -> dict[str, Any]:
    """Synchronous merge (executor).

    Returns ``{"changed": bool, "had_comments": bool, "mf_ids": [ids in the file]}``.
    A symlinked automations.yaml is written through to its resolved target.
    """
    path = link.resolve() if link.is_symlink() else link
    content = _read_text(path)
    current = _parse(content)
    new_ids = {a["id"] for a in add}
    kept: list[Any] = []
    for item in current:
        if _is_mf(item):
            item_id = str(item["id"])
            if item_id in remove_ids or item_id in new_ids or item_id.startswith(remove_prefixes):
                continue
        kept.append(item)
    result = kept + add
    mf_ids = sorted(str(i["id"]) for i in result if _is_mf(i))
    if result == current:
        return {"changed": False, "had_comments": False, "mf_ids": mf_ids}
    _backup(path)
    _write_atomic(path, result)
    return {"changed": True, "had_comments": yaml_has_comments(content), "mf_ids": mf_ids}


def _list_mf_ids(path: Path) -> list[str]:
    return sorted(str(item["id"]) for item in _read_automations(path) if _is_mf(item))


class AutomationManager:
    """Serializes all writes of automations.yaml.

    After each write, ``last_apply_ok`` / ``last_apply_message`` / ``missing_ids``
    tell whether every expected ``mf_*`` automation was loaded by HA (read by the
    maintenance agent).
    """

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._lock = asyncio.Lock()
        self._warned_comments = False
        self.last_apply_ok: bool = True
        self.last_apply_message: str | None = None
        self.last_apply_at: str | None = None
        self.missing_ids: list[str] = []

    @property
    def path(self) -> Path:
        return Path(self.hass.config.path(AUTOMATIONS_FILE))

    async def async_list_ids(self) -> list[str]:
        return await self.hass.async_add_executor_job(_list_mf_ids, self.path)

    async def async_sync(
        self,
        plan: dict[str, list[dict[str, Any]]],
        previous: dict[str, list[str]] | None = None,
    ) -> dict[str, list[str]]:
        """Replace the automations of each recommendation in ``plan``.

        For every recommendation id in ``plan``, all ``mf_<id>_*`` automations
        (and ids listed in ``previous``) are removed, then the planned ones are
        added. Returns ``{recommendation_id: [automation ids]}``.
        """
        previous = previous or {}
        remove_ids: set[str] = set()
        prefixes: list[str] = []
        add: list[dict[str, Any]] = []
        for rec_id, instances in plan.items():
            prefixes.append(f"{AUTOMATION_ID_PREFIX}{rec_id}_")
            remove_ids.update(i for i in previous.get(rec_id, []) if i.startswith(AUTOMATION_ID_PREFIX))
            add.extend(instance_to_automation(inst) for inst in instances)
        async with self._lock:
            outcome = await self.hass.async_add_executor_job(
                _apply, self.path, remove_ids, tuple(prefixes), add
            )
            if outcome["had_comments"] and not self._warned_comments:
                self._warned_comments = True
                _LOGGER.warning(
                    "automations.yaml contained comments; they are not kept when Maison Facile "
                    "rewrites the file (a backup automations.yaml.mf-* was made)"
                )
            if outcome["changed"]:
                if await self._async_reload():
                    self._verify(outcome["mf_ids"])
        return {rec_id: [i["automation_id"] for i in instances] for rec_id, instances in plan.items()}

    async def _async_reload(self) -> bool:
        self.last_apply_at = dt_util.utcnow().isoformat()
        if not self.hass.services.has_service("automation", "reload"):
            _LOGGER.debug("automation.reload not available yet")
            return False
        try:
            await self.hass.services.async_call("automation", "reload", blocking=True)
        except Exception:  # noqa: BLE001 - a broken user automation must not break us
            _LOGGER.exception("automation.reload failed")
            self._set_result(False, "Le rechargement des automatismes a échoué.", [])
            return False
        return True

    def _verify(self, expected: list[str]) -> None:
        loaded: set[str] = set()
        for state in self.hass.states.async_all("automation"):
            automation_id = state.attributes.get("id")
            if automation_id and state.state != "unavailable":
                loaded.add(str(automation_id))
        missing = sorted(set(expected) - loaded)
        if missing:
            _LOGGER.error("Maison Facile automations not loaded after reload: %s", ", ".join(missing))
            self._set_result(
                False,
                f"{len(missing)} automatisme(s) Maison Facile n'ont pas pu être chargés.",
                missing,
            )
        else:
            self._set_result(True, None, [])

    def _set_result(self, ok: bool, message: str | None, missing: list[str]) -> None:
        self.last_apply_ok = ok
        self.last_apply_message = message
        self.missing_ids = missing
