"""Pure version logic for Maison Facile (no Home Assistant import).

- Parses Home Assistant style versions (``2026.10.3``, ``2026.10.0b1``,
  ``2026.11.0.dev20261020``) and semver (``1.4.0``, ``1.4.0-beta.1``).
- Strictly validates the release manifest (``versions.json``, CONTRACT §8).
- Picks the release to offer for a channel and decides whether a Home
  Assistant core update has been validated by the installer.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

CHANNELS: tuple[str, ...] = ("stable", "test")
MANIFEST_SCHEMA = 1

# Pre-release ranking: dev < alpha < beta < rc < final.
_PRE_RANK = {"dev": 0, "a": 1, "alpha": 1, "b": 2, "beta": 2, "rc": 3}
_FINAL_RANK = 4

_VERSION_RE = re.compile(
    r"""^\s*v?
    (?P<release>\d+(?:\.\d+){0,3})          # 1 to 4 numeric parts
    (?:
        [-.]?(?P<pre>dev|alpha|beta|a|b|rc)  # pre-release tag
        [.-]?(?P<pre_num>\d*)
    )?
    (?:\+[0-9A-Za-z.-]+)?                   # semver build metadata (ignored)
    \s*$""",
    re.VERBOSE | re.IGNORECASE,
)
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class VersionError(ValueError):
    """Raised when a version string cannot be parsed."""


class ManifestError(ValueError):
    """Raised when the release manifest is invalid. ``str(err)`` is French."""


@dataclass(frozen=True, order=True)
class Version:
    """Comparable version. Order: release parts, then pre-release rank/number."""

    release: tuple[int, ...]
    pre_rank: int = _FINAL_RANK
    pre_num: int = 0

    @property
    def is_prerelease(self) -> bool:
        return self.pre_rank != _FINAL_RANK


def parse_version(value: str) -> Version:
    """Parse ``value`` into a :class:`Version`. Raises :class:`VersionError`."""
    if not isinstance(value, str):
        raise VersionError(f"version must be a string, got {type(value).__name__}")
    match = _VERSION_RE.match(value)
    if match is None:
        raise VersionError(f"invalid version: {value!r}")
    parts = [int(p) for p in match.group("release").split(".")]
    # Normalise to 3 parts minimum so "2026.10" == "2026.10.0"; drop trailing zeros
    # beyond the third part so "1.0.0.0" == "1.0.0".
    while len(parts) < 3:
        parts.append(0)
    while len(parts) > 3 and parts[-1] == 0:
        parts.pop()
    pre = match.group("pre")
    if pre is None:
        return Version(tuple(parts))
    pre_num = int(match.group("pre_num") or 0)
    return Version(tuple(parts), _PRE_RANK[pre.lower()], pre_num)


def is_valid_version(value: Any) -> bool:
    try:
        parse_version(value)
    except VersionError:
        return False
    return True


def compare_versions(left: str, right: str) -> int:
    """Return -1, 0 or 1 like the old ``cmp``."""
    a, b = parse_version(left), parse_version(right)
    return (a > b) - (a < b)


def is_newer(candidate: str | None, installed: str | None) -> bool:
    """True if ``candidate`` is strictly newer than ``installed`` (False on garbage)."""
    if not candidate or not installed:
        return False
    try:
        return parse_version(candidate) > parse_version(installed)
    except VersionError:
        return False


# --------------------------------------------------------------------------- manifest

_REQUIRED_RELEASE_FIELDS: dict[str, type | tuple[type, ...]] = {
    "version": str,
    "released": str,
    "validated_date": str,
    "min_ha": str,
    "max_ha_validated": str,
    "url": str,
    "sha256": str,
    "notes_fr": list,
}


def _validate_release(channel: str, release: Any) -> dict[str, Any]:
    where = f"canal « {channel} »"
    if not isinstance(release, dict):
        raise ManifestError(f"{where} : ce n'est pas un objet")
    for field, expected in _REQUIRED_RELEASE_FIELDS.items():
        if field not in release:
            raise ManifestError(f"{where} : champ « {field} » manquant")
        if not isinstance(release[field], expected):
            raise ManifestError(f"{where} : champ « {field} » de type incorrect")
    for field in ("version", "min_ha", "max_ha_validated"):
        if not is_valid_version(release[field]):
            raise ManifestError(f"{where} : « {field} » n'est pas une version valide")
    for field in ("released", "validated_date"):
        if not _DATE_RE.match(release[field]):
            raise ManifestError(f"{where} : « {field} » doit être une date AAAA-MM-JJ")
    if parse_version(release["min_ha"]) > parse_version(release["max_ha_validated"]):
        raise ManifestError(f"{where} : « min_ha » est plus récent que « max_ha_validated »")
    if not is_https_url(release["url"]):
        raise ManifestError(f"{where} : l'adresse de téléchargement doit commencer par https://")
    if not _SHA256_RE.match(release["sha256"]):
        raise ManifestError(f"{where} : empreinte sha256 invalide (64 caractères hexadécimaux minuscules)")
    notes = release["notes_fr"]
    if not all(isinstance(n, str) and n.strip() for n in notes):
        raise ManifestError(f"{where} : « notes_fr » doit être une liste de phrases")
    return release


def is_https_url(url: Any) -> bool:
    """Strict https URL with a host and without embedded credentials."""
    if not isinstance(url, str) or any(c.isspace() for c in url):
        return False
    parsed = urlparse(url)
    return (
        parsed.scheme == "https"
        and bool(parsed.hostname)
        and parsed.username is None
        and parsed.password is None
    )


def validate_manifest(manifest: Any) -> dict[str, Any]:
    """Validate the whole manifest and return it. Raises :class:`ManifestError`."""
    if not isinstance(manifest, dict):
        raise ManifestError("le fichier des versions n'est pas un objet JSON")
    if manifest.get("schema") != MANIFEST_SCHEMA or isinstance(manifest.get("schema"), bool):
        raise ManifestError(f"format du fichier des versions non pris en charge (schema attendu : {MANIFEST_SCHEMA})")
    channels = manifest.get("channels")
    if not isinstance(channels, dict) or not channels:
        raise ManifestError("aucun canal dans le fichier des versions")
    unknown = set(channels) - set(CHANNELS)
    if unknown:
        raise ManifestError(f"canal inconnu : {', '.join(sorted(unknown))}")
    if "stable" not in channels:
        raise ManifestError("le canal « stable » est obligatoire")
    for name, release in channels.items():
        _validate_release(name, release)
    return manifest


def channel_release(manifest: dict[str, Any] | None, channel: str) -> dict[str, Any] | None:
    """Raw release of ``channel`` (falls back to ``stable``), no HA filtering."""
    if not manifest:
        return None
    channels = manifest.get("channels") or {}
    return channels.get(channel) or channels.get("stable")


def pick_release(manifest: dict[str, Any] | None, channel: str, ha_version: str) -> dict[str, Any] | None:
    """Release to offer on ``channel`` for the installed HA ``ha_version``.

    Returns ``None`` if there is no manifest, or if the release needs a newer Home
    Assistant (``min_ha > ha_version``). An unknown channel falls back to ``stable``.
    """
    release = channel_release(manifest, channel)
    if release is None:
        return None
    try:
        if parse_version(release["min_ha"]) > parse_version(ha_version):
            return None
    except (VersionError, KeyError):
        return None
    return release


def core_update_allowed(core_latest: str | None, max_ha_validated: str | None) -> bool:
    """True only if the core version has been validated (``core_latest <= max``)."""
    if not core_latest or not max_ha_validated:
        return False
    try:
        return parse_version(core_latest) <= parse_version(max_ha_validated)
    except VersionError:
        return False
