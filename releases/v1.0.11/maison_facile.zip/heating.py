"""Pause the heating of a room while a window is open, then restore it."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Any

from homeassistant.core import CALLBACK_TYPE, Event, EventStateChangedData, HomeAssistant, callback
from homeassistant.helpers.event import async_track_point_in_utc_time, async_track_state_change_event
from homeassistant.util import dt as dt_util

from . import rules
from .onboarding import list_devices
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)


class HeatingPauseManager:
    """Keeps track of running heating pauses (persisted in the store)."""

    def __init__(self, hass: HomeAssistant, store: MaisonFacileStore) -> None:
        self.hass = hass
        self.store = store
        self._unsubs: dict[str, list[CALLBACK_TYPE]] = {}
        self._lock = asyncio.Lock()
        self._tasks: set[asyncio.Task[None]] = set()

    # ------------------------------------------------------------------ public

    def summary(self) -> dict[str, list[str]]:
        """{window_entity_id: [climate entity_ids]} for state/get."""
        return {w: list(p.get("climates", [])) for w, p in self.store.heating_pauses.items()}

    async def async_setup(self) -> None:
        """Re-arm the pauses stored before a restart."""
        now = dt_util.utcnow()
        for window, pause in list(self.store.heating_pauses.items()):
            until = dt_util.parse_datetime(str(pause.get("until") or ""))
            window_state = self.hass.states.get(window)
            if until is None or until <= now or (window_state is not None and window_state.state == "off"):
                self._spawn(self.async_restore(window, "restart"))
                continue
            self._arm(window, until)

    @callback
    def async_unload(self) -> None:
        for unsubs in self._unsubs.values():
            for unsub in unsubs:
                unsub()
        self._unsubs.clear()
        for task in self._tasks:
            task.cancel()
        self._tasks.clear()

    async def async_pause(self, window_entity_id: str) -> dict[str, Any]:
        async with self._lock:
            if window_entity_id in self.store.heating_pauses:
                return {
                    "ok": True,
                    "paused": list(self.store.heating_pauses[window_entity_id].get("climates", [])),
                    "message_fr": rules.HEATING_PAUSE_MESSAGES_FR["already_paused"],
                }
            states = {s.entity_id: s.state for s in self.hass.states.async_all(("binary_sensor", "climate"))}
            plan = rules.plan_heating_pause(
                list_devices(self.hass, self.store), window_entity_id, states
            )
            message = rules.HEATING_PAUSE_MESSAGES_FR[plan["reason"]]
            if plan["reason"] != "paused":
                return {"ok": plan["ok"], "paused": [], "message_fr": message}

            climates: list[str] = plan["climates"]
            scene_id: str = plan["scene_id"]
            await self.hass.services.async_call(
                "scene", "create", {"scene_id": scene_id, "snapshot_entities": climates}, blocking=True
            )
            await self.hass.services.async_call(
                "climate", "turn_off", {"entity_id": climates}, blocking=True
            )
            until = dt_util.utcnow() + timedelta(seconds=rules.HEATING_PAUSE_MAX_SECONDS)
            pauses = dict(self.store.heating_pauses)
            pauses[window_entity_id] = {"scene_id": scene_id, "climates": climates, "until": until.isoformat()}
            await self.store.async_set("heating_pauses", pauses)
            self._arm(window_entity_id, until)
            _LOGGER.info("Heating paused for %s (%d climate(s))", window_entity_id, len(climates))
            return {"ok": True, "paused": climates, "message_fr": message}

    async def async_restore(self, window_entity_id: str, why: str) -> None:
        async with self._lock:
            self._disarm(window_entity_id)
            pause = self.store.heating_pauses.get(window_entity_id)
            if pause is None:
                return
            scene_entity = f"scene.{pause['scene_id']}"
            try:
                if self.hass.states.get(scene_entity) is not None:
                    await self.hass.services.async_call(
                        "scene", "turn_on", {"entity_id": scene_entity}, blocking=True
                    )
                    await self.hass.services.async_call(
                        "scene", "delete", {"entity_id": scene_entity}, blocking=True
                    )
                else:
                    # Scene lost (e.g. restart): dynamic scenes are not persisted.
                    # Turning back on is the safest default for heating.
                    await self.hass.services.async_call(
                        "climate", "turn_on", {"entity_id": pause.get("climates", [])}, blocking=True
                    )
            except Exception:  # noqa: BLE001 - always drop the pause record
                _LOGGER.exception("Could not restore heating for %s", window_entity_id)
            pauses = dict(self.store.heating_pauses)
            pauses.pop(window_entity_id, None)
            await self.store.async_set("heating_pauses", pauses)
            _LOGGER.info("Heating restored for %s (%s)", window_entity_id, why)

    # ------------------------------------------------------------------ internals

    def _spawn(self, coro: Any) -> None:
        task = self.hass.async_create_background_task(coro, "maison_facile_heating_restore")
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    @callback
    def _arm(self, window: str, until: datetime) -> None:
        self._disarm(window)

        @callback
        def _on_change(event: Event[EventStateChangedData]) -> None:
            new = event.data.get("new_state")
            if new is not None and new.state == "off":
                self._spawn(self.async_restore(window, "closed"))

        @callback
        def _on_timeout(_now: datetime) -> None:
            self._spawn(self.async_restore(window, "timeout"))

        self._unsubs[window] = [
            async_track_state_change_event(self.hass, [window], _on_change),
            async_track_point_in_utc_time(self.hass, _on_timeout, until),
        ]

    @callback
    def _disarm(self, window: str) -> None:
        for unsub in self._unsubs.pop(window, []):
            unsub()
