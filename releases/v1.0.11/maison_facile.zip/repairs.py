"""Repair flows: the "Réparer" button of Settings > Repairs calls Doctor.async_fix."""

from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant import data_entry_flow
from homeassistant.components.repairs import RepairsFlow
from homeassistant.core import HomeAssistant

from .const import DOMAIN


def _doctor(hass: HomeAssistant) -> Any | None:
    entries = hass.config_entries.async_entries(DOMAIN)
    if not entries:
        return None
    return getattr(getattr(entries[0], "runtime_data", None), "doctor", None)


class MaisonFacileRepairFlow(RepairsFlow):
    """Confirm (and pick a choice when the problem offers some), then fix."""

    def __init__(self, problem_id: str) -> None:
        self._problem_id = problem_id

    def _placeholders(self, problem: dict[str, Any] | None) -> dict[str, str]:
        if problem is None:
            return {"title": "", "why": "", "steps": ""}
        return {
            "title": problem["title"],
            "why": problem["why"],
            "steps": "\n".join(f"{i}. {s}" for i, s in enumerate(problem["steps"], 1)),
        }

    async def async_step_init(self, user_input: dict[str, str] | None = None) -> data_entry_flow.FlowResult:
        return await self.async_step_confirm(user_input)

    async def async_step_confirm(self, user_input: dict[str, str] | None = None) -> data_entry_flow.FlowResult:
        doctor = _doctor(self.hass)
        if doctor is None:
            return self.async_abort(reason="not_ready")
        problem = doctor.get_problem(self._problem_id)
        if problem is None:
            return self.async_create_entry(data={})

        choices = problem["fix"]["choices"]
        if user_input is not None:
            result = await doctor.async_fix(self._problem_id, user_input.get("choice"))
            if result["ok"]:
                return self.async_create_entry(data={})
            return self.async_abort(reason="fix_failed", description_placeholders={"message": result["message_fr"]})

        schema = vol.Schema({})
        if choices:
            default = next((c["value"] for c in choices if c["recommended"]), choices[0]["value"])
            schema = vol.Schema({
                vol.Required("choice", default=default): vol.In(
                    {c["value"]: c["label"] + (" · Recommandé" if c["recommended"] else "") for c in choices}
                )
            })
        return self.async_show_form(
            step_id="confirm",
            data_schema=schema,
            description_placeholders=self._placeholders(problem),
        )


async def async_create_fix_flow(
    hass: HomeAssistant, issue_id: str, data: dict[str, Any] | None
) -> RepairsFlow:
    problem_id = (data or {}).get("problem_id") or issue_id
    return MaisonFacileRepairFlow(str(problem_id))
