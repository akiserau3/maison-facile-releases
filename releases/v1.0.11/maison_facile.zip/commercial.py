"""Commercial mode: the family only sees Maison Facile (NOTES_commercial.md).

- frontend system data "core".default_panel = our panel (HA opens on it after login);
- family accounts (non-admin) get a sidebar showing only "Ma maison"
  (frontend user data "sidebar"); the previous value is kept in our store and
  restored when commercial mode is turned off or the integration is removed;
- "Réglages avancés": per-user unlock for 30 min (memory only), optional
  installer code stored as a salted PBKDF2 hash, 5 wrong codes / 5 min.

Admins' own sidebar preferences are never touched: on the panel the kiosk mode
(frontend side) hides Home Assistant's chrome for them.
"""

from __future__ import annotations

import asyncio
import copy
from datetime import datetime, timedelta
import logging
import time
from typing import Any

from homeassistant.auth import EVENT_USER_ADDED, EVENT_USER_REMOVED, EVENT_USER_UPDATED
from homeassistant.auth.models import User
from homeassistant.const import EVENT_PANELS_UPDATED
from homeassistant.core import Event, HomeAssistant, callback
from homeassistant.helpers.debounce import Debouncer
from homeassistant.util import dt as dt_util

from . import commercial_rules as cr
from .const import PANEL_URL_PATH
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)

try:  # Frontend storage API (HA 2025.x+). Older cores: commercial mode is UI-only.
    from homeassistant.components.frontend import DATA_PANELS
    from homeassistant.components.frontend.storage import async_system_store, async_user_store
except ImportError:  # pragma: no cover - depends on the HA version
    DATA_PANELS = "frontend_panels"  # type: ignore[assignment]
    async_system_store = None  # type: ignore[assignment]
    async_user_store = None  # type: ignore[assignment]

SYSTEM_KEY = "core"
SIDEBAR_KEY = "sidebar"


def is_family_user(user: User) -> bool:
    """Accounts whose sidebar we manage: real, active, non-admin people."""
    return not user.system_generated and user.is_active and not user.is_admin


class CommercialManager:
    """Applies commercial mode and holds the in-memory unlock state."""

    def __init__(self, hass: HomeAssistant, store: MaisonFacileStore) -> None:
        self.hass = hass
        self.store = store
        self.limiter = cr.AttemptLimiter()
        self._unlocked: dict[str, datetime] = {}
        self._lock = asyncio.Lock()
        self._unsubs: list[Any] = []
        self._debouncer: Debouncer | None = None

    # ------------------------------------------------------------------ state

    @property
    def advanced(self) -> dict[str, Any]:
        data = self.store.data.setdefault("advanced", {})
        data.setdefault("pin", None)
        data.setdefault("sidebars", {})
        return data

    @property
    def enabled(self) -> bool:
        return self.store.settings.get("commercial_mode", True) is not False

    @property
    def pin_set(self) -> bool:
        return bool(self.advanced.get("pin"))

    def unlocked_until(self, user_id: str | None) -> datetime | None:
        if not user_id or (until := self._unlocked.get(user_id)) is None:
            return None
        if until <= dt_util.utcnow():
            self._unlocked.pop(user_id, None)
            return None
        return until

    def can_manage(self, user: User | None) -> bool:
        """Installer mode: admin AND (commercial mode off OR unlocked for this user)."""
        if user is None or not user.is_admin:
            return False
        return not self.enabled or self.unlocked_until(user.id) is not None

    def status(self, user: User | None) -> dict[str, Any]:
        is_admin = bool(user and user.is_admin)
        until = self.unlocked_until(user.id) if is_admin and user else None
        return {
            "commercial_mode": self.enabled,
            "unlocked": until is not None,
            "until": until.isoformat() if until else None,
            "pin_set": self.pin_set,
            "is_admin": is_admin,
        }

    def summary(self, user: User | None) -> dict[str, Any]:
        """Short form for state/get."""
        status = self.status(user)
        return {"commercial_mode": status["commercial_mode"], "unlocked": status["unlocked"]}

    # ------------------------------------------------------------------ unlock

    async def async_unlock(self, user: User, pin: str | None) -> dict[str, Any]:
        """Return ``{ok, until}`` or ``{ok: False, code, message_fr}``."""
        now = time.monotonic()
        wait = self.limiter.retry_after(user.id, now)
        if wait > 0:
            return {"ok": False, "code": "too_many_attempts", "message_fr": cr.wait_message_fr(wait)}
        record = self.advanced.get("pin")
        if record:
            good = await self.hass.async_add_executor_job(cr.verify_pin, pin or "", record)
            if not good:
                self.limiter.failure(user.id, now)
                left = self.limiter.remaining(user.id, now)
                if left == 0:
                    message = cr.wait_message_fr(self.limiter.retry_after(user.id, now))
                else:
                    message = (
                        "Ce code n'est pas le bon. "
                        f"Encore {left} essai{'s' if left > 1 else ''} avant une pause de 5 minutes."
                    )
                _LOGGER.warning("Wrong installer code for user %s", user.id)
                return {"ok": False, "code": "invalid_pin", "message_fr": message}
        self.limiter.reset(user.id)
        until = dt_util.utcnow() + timedelta(seconds=cr.UNLOCK_SECONDS)
        self._unlocked[user.id] = until
        _LOGGER.info("Advanced settings unlocked for user %s until %s", user.id, until.isoformat())
        return {"ok": True, "until": until.isoformat()}

    @callback
    def lock(self, user_id: str) -> None:
        self._unlocked.pop(user_id, None)

    async def async_set_pin(self, pin: str) -> None:
        """Set (4-8 digits) or remove ("") the installer code. Stored hashed only."""
        if pin:
            record = await self.hass.async_add_executor_job(cr.hash_pin, pin)
        else:
            record = None
        self.advanced["pin"] = record
        await self.store.async_save()

    # ------------------------------------------------------------------ apply

    async def async_setup(self) -> None:
        hass = self.hass
        self._debouncer = Debouncer(
            hass, _LOGGER, cooldown=2.0, immediate=False, function=self.async_apply
        )

        @callback
        def _changed(_event: Event) -> None:
            if self._debouncer is not None:
                self._debouncer.async_schedule_call()

        for event_type in (EVENT_USER_ADDED, EVENT_USER_UPDATED, EVENT_USER_REMOVED, EVENT_PANELS_UPDATED):
            self._unsubs.append(hass.bus.async_listen(event_type, _changed))
        await self._watch_system_core()
        await self.async_apply()

    async def _watch_system_core(self) -> None:
        """Put our default panel back when someone rewrites the system data "core".

        HA's onboarding ends with ``frontend/set_system_data core = {onboarded_version,
        onboarded_date}`` (it replaces the whole value): without this, the first page
        after onboarding is HA's own dashboard (bug seen on HA 2026.10.4).
        """
        if async_system_store is None:
            return
        try:
            system_store = await async_system_store(self.hass)
            subscribe = system_store.async_subscribe
        except Exception:  # noqa: BLE001 - older/changed API: the frontend guard still helps
            _LOGGER.warning("Commercial mode: cannot watch the frontend system data")
            return

        @callback
        def _core_changed() -> None:
            if self.enabled:
                self.hass.async_create_task(self._restore_default_panel(), f"{PANEL_URL_PATH}_default_panel")

        self._unsubs.append(subscribe(SYSTEM_KEY, _core_changed))

    async def _restore_default_panel(self) -> None:
        try:
            async with self._lock:
                if not self.enabled:
                    return
                system_store = await async_system_store(self.hass)
                new = cr.plan_system_core_restore(system_store.data.get(SYSTEM_KEY), PANEL_URL_PATH)
                if new is not None:
                    await system_store.async_set_item(SYSTEM_KEY, new)
                    _LOGGER.info("Default panel put back after the system data was rewritten")
        except Exception:  # noqa: BLE001 - never break the integration
            _LOGGER.exception("Commercial mode: could not put the default panel back")

    @callback
    def async_unload(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs.clear()
        if self._debouncer is not None:
            self._debouncer.async_shutdown()
            self._debouncer = None

    async def async_apply(self) -> None:
        """Idempotent: bring default panel and family sidebars in line with the setting."""
        async with self._lock:
            for step in (self._apply_default_panel, self._apply_sidebars):
                try:
                    await step(self.enabled)
                except Exception:  # noqa: BLE001 - never break the integration
                    _LOGGER.exception("Commercial mode: %s failed", step.__name__)

    async def async_revert(self) -> None:
        """Integration removed: give Home Assistant back its defaults."""
        async with self._lock:
            for step in (self._apply_default_panel, self._apply_sidebars):
                try:
                    await step(False)
                except Exception:  # noqa: BLE001
                    _LOGGER.exception("Commercial mode revert: %s failed", step.__name__)

    async def _apply_default_panel(self, enabled: bool) -> None:
        if async_system_store is None:
            return
        system_store = await async_system_store(self.hass)
        new = cr.plan_system_core(system_store.data.get(SYSTEM_KEY), enabled, PANEL_URL_PATH)
        if new is not None:
            await system_store.async_set_item(SYSTEM_KEY, new)
            _LOGGER.info("Default panel for all users: %s", new.get("default_panel", "Home Assistant default"))

    async def _apply_sidebars(self, enabled: bool) -> None:
        if async_user_store is None:
            return
        hass = self.hass
        managed: dict[str, Any] = self.advanced["sidebars"]
        panels = list(hass.data.get(DATA_PANELS, {}))
        users = {u.id: u for u in await hass.auth.async_get_users()}
        targets = {uid for uid, u in users.items() if enabled and is_family_user(u)}
        dirty = False

        for uid in sorted(targets):
            ustore = await async_user_store(hass, uid)
            current = ustore.data.get(SIDEBAR_KEY)
            new = cr.plan_sidebar(current, panels, PANEL_URL_PATH)
            if uid not in managed:
                managed[uid] = {"saved": copy.deepcopy(current) if isinstance(current, dict) else None}
                dirty = True
            if managed[uid].get("applied") != new:
                managed[uid]["applied"] = new
                dirty = True
            if current != new:
                await ustore.async_set_item(SIDEBAR_KEY, new)

        for uid in [u for u in managed if u not in targets]:
            entry = managed.pop(uid)
            dirty = True
            if uid not in users:
                continue
            ustore = await async_user_store(hass, uid)
            value = cr.restore_sidebar(ustore.data.get(SIDEBAR_KEY), entry.get("saved"), entry.get("applied"))
            if value is not None:
                await ustore.async_set_item(SIDEBAR_KEY, value)

        if dirty:
            await self.store.async_save()
