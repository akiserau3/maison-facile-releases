// Tiny rendering toolkit: auto-escaping templates, DOM morphing (keeps focus and
// scroll because existing nodes are reused) and a base Page class.

const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ESC[c]);
}

export class Raw {
  constructor(s) {
    this.s = s;
  }
  toString() {
    return this.s;
  }
}

export const raw = (s) => new Raw(String(s));

function val(v) {
  if (v === null || v === undefined || v === false) return "";
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(val).join("");
  return esc(v);
}

/** Tagged template: every interpolated value is HTML-escaped unless it is a Raw. */
export function html(strings, ...values) {
  let out = strings[0];
  for (let i = 0; i < values.length; i++) out += val(values[i]) + strings[i + 1];
  return new Raw(out);
}

// ---------------------------------------------------------------------------
// DOM morphing
// ---------------------------------------------------------------------------

function keyOf(node) {
  return node.nodeType === 1 ? node.getAttribute("data-key") : null;
}

function same(a, b) {
  return a.nodeType === b.nodeType && a.nodeName === b.nodeName && keyOf(a) === keyOf(b);
}

function syncAttributes(from, to) {
  for (const { name } of Array.from(from.attributes)) {
    if (!to.hasAttribute(name)) from.removeAttribute(name);
  }
  for (const { name, value } of Array.from(to.attributes)) {
    if (from.getAttribute(name) !== value) from.setAttribute(name, value);
  }
}

function isFocused(el) {
  const root = el.getRootNode();
  return root && root.activeElement === el;
}

function morphNode(from, to) {
  if (from.nodeType === 3 || from.nodeType === 8) {
    if (from.nodeValue !== to.nodeValue) from.nodeValue = to.nodeValue;
    return;
  }
  if (from.hasAttribute("data-morph-skip")) return;
  syncAttributes(from, to);
  const tag = from.nodeName;
  if (tag === "INPUT") {
    if (from.type === "checkbox" || from.type === "radio") from.checked = to.hasAttribute("checked");
    else if (!isFocused(from)) {
      const v = to.getAttribute("value") ?? "";
      if (from.value !== v) from.value = v;
    }
    return;
  }
  if (tag === "TEXTAREA") {
    if (!isFocused(from) && from.value !== to.textContent) from.value = to.textContent;
    return;
  }
  morphChildren(from, to);
  if (tag === "SELECT" && to.hasAttribute("data-value")) {
    const v = to.getAttribute("data-value");
    if (from.value !== v) from.value = v;
  }
}

function morphChildren(from, to) {
  const keyed = new Map();
  for (const c of Array.from(from.childNodes)) {
    const k = keyOf(c);
    if (k) keyed.set(k, c);
  }
  const targets = Array.from(to.childNodes);
  let i = 0;
  for (const t of targets) {
    let cur = from.childNodes[i] || null;
    const k = keyOf(t);
    if (k && (!cur || keyOf(cur) !== k)) {
      const match = keyed.get(k);
      if (match && match.nodeName === t.nodeName) {
        from.insertBefore(match, cur);
        cur = match;
      }
    }
    if (cur && same(cur, t)) {
      morphNode(cur, t);
    } else {
      from.insertBefore(document.importNode(t, true), cur);
    }
    i++;
  }
  while (from.childNodes.length > i) from.removeChild(from.lastChild);
}

/** Update `parent` children so that they match the `markup` HTML string. */
export function morph(parent, markup) {
  const tpl = document.createElement("template");
  tpl.innerHTML = String(markup);
  morphChildren(parent, tpl.content);
}

// ---------------------------------------------------------------------------
// Base page
// ---------------------------------------------------------------------------

export class Page {
  constructor(app, params = {}) {
    this.app = app;
    this.params = params;
    this.s = {};
    this.el = null;
    this.children = [];
    this._watch = new Map();
    this._timers = [];
    this._cleanups = [];
    this._raf = 0;
    this.destroyed = false;
  }

  get hass() {
    return this.app.hass;
  }
  get data() {
    return this.app.data;
  }
  get api() {
    return this.app.api;
  }

  mount(el) {
    this.el = el;
    el.setAttribute("data-page", "");
    const own = (target, selector) => {
      const found = target.closest(selector);
      if (!found || !el.contains(found)) return null;
      return found.closest("[data-page]") === el ? found : null;
    };
    this._onClick = (ev) => {
      const t = own(ev.target, "[data-action]");
      if (!t || t.disabled || t.getAttribute("aria-disabled") === "true") return;
      if (t.tagName === "A") ev.preventDefault();
      this.onAction(t.dataset.action, t, ev);
    };
    this._onInput = (ev) => {
      const t = own(ev.target, "[data-field]");
      if (t) this.onInput(t.dataset.field, t, ev);
    };
    this._onKey = (ev) => {
      if (ev.key !== "Enter") return;
      const t = own(ev.target, "[data-enter]");
      if (t) {
        ev.preventDefault();
        this.onAction(t.dataset.enter, t, ev);
      }
    };
    el.addEventListener("click", this._onClick);
    el.addEventListener("input", this._onInput);
    el.addEventListener("change", this._onInput);
    el.addEventListener("keydown", this._onKey);
    // Camera images that fail to load fall back to a still message (retried every 10 s).
    this.camFail = {};
    this.camTick = Date.now();
    this._onImgError = (ev) => {
      const id = ev.target?.getAttribute?.("data-cam");
      if (id && !this.camFail[id]) {
        this.camFail[id] = true;
        this.requestRender();
      }
    };
    el.addEventListener("error", this._onImgError, true);
    this._timers.push(setInterval(() => {
      if (Object.keys(this.camFail).length) {
        this.camFail = {};
        this.requestRender();
      }
    }, 10000));
    this.init();
    this.render();
  }

  /** Read an entity state and remember it so that we re-render only when it changes. */
  st(entityId) {
    if (!entityId) return undefined;
    const s = this.hass?.states?.[entityId];
    this._watch.set(entityId, s);
    return s;
  }

  render() {
    if (!this.el || this.destroyed) return;
    this._watch = new Map();
    morph(this.el, this.template());
    this.afterRender();
  }

  requestRender() {
    if (this._raf || this.destroyed) return;
    // Hidden tab: nothing to paint, catch up once in onVisible().
    if (typeof document !== "undefined" && document.hidden) {
      this._staleWhileHidden = true;
      return;
    }
    const raf = typeof requestAnimationFrame === "function" ? requestAnimationFrame : (f) => setTimeout(f, 16);
    this._raf = raf(() => {
      this._raf = 0;
      this.render();
    });
  }

  hassChanged(hass) {
    for (const [id, s] of this._watch) {
      if (hass.states?.[id] !== s) {
        this.requestRender();
        break;
      }
    }
    for (const c of this.children) c.hassChanged(hass);
  }

  dataChanged() {
    this.requestRender();
    for (const c of this.children) c.dataChanged();
  }

  setState(patch) {
    Object.assign(this.s, patch);
    this.render();
  }

  /** Repeating timer; ticks are skipped while the tab is hidden (onVisible() catches up). */
  every(ms, fn) {
    const id = setInterval(() => {
      if (typeof document !== "undefined" && document.hidden) return;
      fn();
    }, ms);
    this._timers.push(id);
    return id;
  }

  later(ms, fn) {
    const id = setTimeout(fn, ms);
    this._timers.push(id);
    return id;
  }

  /** Called by the panel when the tab becomes visible again. */
  onVisible() {
    this._staleWhileHidden = false;
    this.requestRender();
    if (this._camToUrl) this.tickCameras();
    for (const c of this.children) c.onVisible();
  }

  // ----- cameras: only the <img src> changes every 2 s, never the whole page ------

  /** Image URL for a camera entity, or null if unavailable / failed to load. */
  cameraSrc(entityId, toUrl) {
    if (this.camFail[entityId]) return null;
    const url = toUrl(this.hass?.states?.[entityId]);
    if (!url || url.startsWith("data:")) return url;
    return `${url}${url.includes("?") ? "&" : "?"}_=${this.camTick}`;
  }

  /** Start refreshing every <img data-cam> of this page in place. */
  startCameras(toUrl, ms = 2000) {
    this._camToUrl = toUrl;
    this.every(ms, () => this.tickCameras());
  }

  tickCameras() {
    if (!this.el || !this._camToUrl) return;
    this.camTick = Date.now();
    let flip = false;
    for (const img of this.el.querySelectorAll("img[data-cam]")) {
      const src = this.cameraSrc(img.getAttribute("data-cam"), this._camToUrl);
      if (!src) flip = true;
      else if (img.getAttribute("src") !== src) img.setAttribute("src", src);
    }
    for (const off of this.el.querySelectorAll("[data-cam-off]")) {
      if (!this.camFail[off.getAttribute("data-cam-off")] && this.cameraSrc(off.getAttribute("data-cam-off"), this._camToUrl)) flip = true;
    }
    if (flip) this.requestRender();
  }

  onCleanup(fn) {
    this._cleanups.push(fn);
  }

  /** Run an async action with a busy flag and a friendly French error toast. */
  async run(key, fn, errorText) {
    const busy = { ...(this.s.busy || {}) };
    if (busy[key]) return undefined;
    busy[key] = true;
    this.setState({ busy });
    try {
      return await fn();
    } catch (err) {
      console.warn("[maison-facile]", key, err);
      this.app.toast(this.app.errorText(err, errorText), () => this.run(key, fn, errorText));
      return undefined;
    } finally {
      if (!this.destroyed) {
        const b = { ...(this.s.busy || {}) };
        delete b[key];
        this.setState({ busy: b });
      }
    }
  }

  isBusy(key) {
    return !!(this.s.busy && this.s.busy[key]);
  }

  destroy() {
    this.destroyed = true;
    for (const c of this.children) c.destroy();
    this.children = [];
    for (const id of this._timers) {
      clearInterval(id);
      clearTimeout(id);
    }
    for (const fn of this._cleanups) {
      try {
        fn();
      } catch (e) {
        /* ignore */
      }
    }
    if (this.el) {
      this.el.removeEventListener("click", this._onClick);
      this.el.removeEventListener("input", this._onInput);
      this.el.removeEventListener("change", this._onInput);
      this.el.removeEventListener("keydown", this._onKey);
      this.el.removeEventListener("error", this._onImgError, true);
    }
    this.el = null;
  }

  // Hooks to override
  init() {}
  template() {
    return "";
  }
  afterRender() {}
  onAction() {}
  onInput() {}
}

// ---------------------------------------------------------------------------
// Formatting helpers (French)
// ---------------------------------------------------------------------------

export function num(v) {
  const n = typeof v === "number" ? v : parseFloat(v);
  return Number.isFinite(n) ? n : null;
}

export function fmtNum(n, digits = 1) {
  if (n === null || n === undefined || !Number.isFinite(n)) return "–";
  return n.toLocaleString("fr-FR", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function fmtSmart(n) {
  if (n === null || n === undefined || !Number.isFinite(n)) return "–";
  const digits = Math.abs(n) >= 100 ? 0 : 1;
  return fmtNum(n, digits);
}

export function fmtEur(n) {
  if (n === null || n === undefined || !Number.isFinite(n)) return "–";
  return n.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
}

export function timeHM(d = new Date()) {
  return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

export function dateLong(d = new Date()) {
  const s = d.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export function toDate(v) {
  if (v === null || v === undefined || v === "") return null;
  const d = typeof v === "number" ? new Date(v < 1e12 ? v * 1000 : v) : new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export function relTime(v) {
  const d = toDate(v);
  if (!d) return "";
  const diff = Math.round((Date.now() - d.getTime()) / 60000);
  if (diff < 1) return "à l'instant";
  if (diff < 60) return `il y a ${diff} minute${diff > 1 ? "s" : ""}`;
  const h = Math.round(diff / 60);
  if (h < 24) return `il y a ${h} heure${h > 1 ? "s" : ""}`;
  const j = Math.round(h / 24);
  return `il y a ${j} jour${j > 1 ? "s" : ""}`;
}

export function dayAndTime(v) {
  const d = toDate(v);
  if (!d) return "–";
  const today = new Date();
  const yest = new Date(Date.now() - 86400000);
  const t = timeHM(d);
  if (d.toDateString() === today.toDateString()) return `Aujourd'hui, ${t}`;
  if (d.toDateString() === yest.toDateString()) return `Hier, ${t}`;
  return `${d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })}, ${t}`;
}

export function shortDate(v) {
  const d = toDate(v);
  return d ? d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "";
}

export function plural(n, one, many) {
  return `${n} ${n > 1 ? many : one}`;
}

export function lsGet(key, fallback = null) {
  try {
    const v = window.localStorage.getItem(key);
    return v === null ? fallback : v;
  } catch (e) {
    return fallback;
  }
}

export function lsSet(key, value) {
  try {
    window.localStorage.setItem(key, value);
  } catch (e) {
    /* ignore */
  }
}

export async function copyText(text, fallbackEl) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) {
    if (fallbackEl && fallbackEl.select) {
      fallbackEl.focus();
      fallbackEl.select();
      try {
        return document.execCommand("copy");
      } catch (e2) {
        return false;
      }
    }
    return false;
  }
}
