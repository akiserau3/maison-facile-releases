// « Anniversaires » for the demo without Home Assistant (copy of birthdays_rules.py, simplified).
// A few birthdays, one of them today (« Mamie, 80 ans »); DEMO_VCF = an example contacts file.
// URL: ?birthdays=0 starts with no birthday.

const MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
const WEEKDAYS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
const TEMPLATES = ["Joyeux anniversaire {nom} !", "Bon anniversaire {nom} ! Je t'embrasse fort.", "Joyeux anniversaire {nom} ! Plein de bonheur pour cette nouvelle année."];
const NO_AUTO_SEND = "Maison Facile prépare le message mais ne l'envoie jamais tout seul : vous le relisez et vous appuyez vous-même sur « Envoyer ».";

export const DEMO_VCF = [
  "BEGIN:VCARD", "VERSION:2.1",
  "N;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:Lef=C3=A8vre;=C3=89lodie;;;",
  "FN;CHARSET=UTF-8;ENCODING=QUOTED-PRINTABLE:=C3=89lodie Lef=C3=A8vre",
  "TEL;CELL:06 11 22 33 44", "TEL;HOME:03 27 00 00 00", "BDAY:19850314", "END:VCARD",
  "BEGIN:VCARD", "VERSION:3.0", "FN:Tonton Jo", "TEL;TYPE=CELL:07 55 44 33 22", "BDAY:--0704", "END:VCARD",
  "BEGIN:VCARD", "VERSION:3.0", "FN:Lucas Bernard", "TEL;TYPE=CELL:+33 6 98 76 54 32", "BDAY:2012-01-22", "END:VCARD",
  "BEGIN:VCARD", "VERSION:4.0", "FN:Plombier", "TEL;TYPE=work:03 27 11 11 11", "END:VCARD",
  "BEGIN:VCARD", "VERSION:4.0", "FN:Paul Martin", "BDAY:--1031", "END:VCARD",
  "",
].join("\r\n");

const pad = (n) => String(n).padStart(2, "0");
const isLeap = (y) => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
const dayStart = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());

function occurrence(year, day, month) {
  return month === 2 && day === 29 && !isLeap(year) ? new Date(year, 1, 28) : new Date(year, month - 1, day);
}
function nextOcc(day, month, today) {
  let o = occurrence(today.getFullYear(), day, month);
  if (o < today) o = occurrence(today.getFullYear() + 1, day, month);
  return o;
}
function normPhone(raw) {
  let t = String(raw || "").replace(/^tel:/i, "").replace(/\(0\)/g, "");
  if (!t.trim()) return null;
  const plus = t.trim().startsWith("+");
  let d = t.replace(/\D/g, "");
  if (plus) { /* keep */ } else if (d.startsWith("00")) d = d.slice(2);
  else if (d.startsWith("0") && d.length === 10) d = `33${d.slice(1)}`;
  else return null;
  return d.length >= 8 && d.length <= 15 ? `+${d}` : null;
}
const display = (p) => (p && p.startsWith("+33") && p.length === 12 ? `0${p.slice(3)}`.replace(/(\d\d)(?=\d)/g, "$1 ") : p || "");
const callName = (i) => (i.relation || "").trim() || String(i.name || "").split(" ")[0] || "?";
const deName = (n) => (/^[aeiouyhàâéèêëîïôöùûü]/i.test(n) ? `d'${n}` : `de ${n}`);
const key = (name, day, month) => `${String(name).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "")}|${day}|${month}`;

function message(i, occ) {
  const age = i.year ? occ.getFullYear() - i.year : null;
  const tpl = (i.message || "").trim() || TEMPLATES[(i.id.charCodeAt(0) + occ.getFullYear()) % TEMPLATES.length];
  return tpl.replace("{nom}", callName(i)).replace("{prenom}", i.name.split(" ")[0]).replace("{age}", age ?? "").replace(/\s+/g, " ").trim();
}
function links(i, text) {
  if (!i.phone) return {};
  const body = encodeURIComponent(text);
  return { sms: { android: `sms:${i.phone}?body=${body}`, ios: `sms:${i.phone}&body=${body}` }, whatsapp: `https://wa.me/${i.phone.slice(1)}?text=${body}` };
}
function view(i, today) {
  const occ = nextOcc(i.day, i.month, today);
  const days = Math.round((occ - today) / 86400000);
  const age = i.year ? occ.getFullYear() - i.year : null;
  const text = message(i, occ);
  return {
    birthday_id: i.id, name: i.name, relation: i.relation || "", call_name: callName(i), day: i.day, month: i.month, year: i.year || null,
    phone: i.phone || "", phone_display: display(i.phone), channel: i.channel || "sms", message: i.message || "", source: i.source || "manual",
    next_date: `${occ.getFullYear()}-${pad(occ.getMonth() + 1)}-${pad(occ.getDate())}`, days, today: days === 0,
    when_fr: days === 0 ? "Aujourd'hui" : days === 1 ? "Demain" : days === 2 ? "Après-demain" : `Dans ${days} jours`,
    date_fr: `${WEEKDAYS[occ.getDay()]} ${occ.getDate() === 1 ? "1er" : occ.getDate()} ${MONTHS[occ.getMonth()]}`,
    age_next: age, age_fr: age === null ? "" : `${age} an${age > 1 ? "s" : ""}`, text, links: links(i, text),
  };
}

/** Minimal .vcf reader (FN/N, BDAY, first mobile) — the box uses birthdays_rules.parse_vcf. */
function parseVcf(text) {
  const lines = [];
  for (const l of text.replace(/\r\n/g, "\n").split("\n")) {
    if (/^[ \t]/.test(l) && lines.length) lines[lines.length - 1] += l.slice(1);
    else lines.push(l);
  }
  const qp = (v) => {
    const bytes = [];
    for (let i = 0; i < v.length; i++) {
      const hex = v.substr(i + 1, 2);
      if (v[i] === "=" && /^[0-9A-F]{2}$/i.test(hex)) {
        bytes.push(parseInt(hex, 16));
        i += 2;
      } else bytes.push(v.charCodeAt(i) & 0xff);
    }
    return new TextDecoder().decode(new Uint8Array(bytes));
  };
  const out = [];
  let cur = null;
  let without = 0;
  for (const line of lines) {
    const up = line.trim().toUpperCase();
    if (up === "BEGIN:VCARD") { cur = { name: "", bday: null, phone: null }; continue; }
    if (up === "END:VCARD") {
      if (cur && cur.name && cur.bday) out.push({ ...cur });
      else if (cur) without++;
      cur = null;
      continue;
    }
    if (!cur) continue;
    const idx = line.indexOf(":");
    if (idx < 0) continue;
    const head = line.slice(0, idx).toUpperCase();
    let value = line.slice(idx + 1);
    if (head.includes("QUOTED-PRINTABLE")) value = qp(value);
    const name = head.split(";")[0].split(".").pop();
    if (name === "FN") cur.name = value.trim();
    else if (name === "BDAY") {
      const m = value.trim().match(/^(?:--|(\d{4})-?)(\d{2})-?(\d{2})/);
      if (m) cur.bday = { year: m[1] && Number(m[1]) >= 1900 ? Number(m[1]) : null, month: Number(m[2]), day: Number(m[3]) };
    } else if (name === "TEL" && !cur.phone && /CELL|MOBILE|IPHONE/.test(head)) cur.phone = normPhone(value);
  }
  return {
    candidates: out.map((c) => ({ key: key(c.name, c.bday.day, c.bday.month), name: c.name, day: c.bday.day, month: c.bday.month, year: c.bday.year, phone: c.phone, source: "vcf" })),
    without_date: without,
  };
}

let current = null;

/** Names for the idea need « Des dates d'anniversaire » (demo-hass.js). */
export function birthdayPeople() {
  return current ? current.items.map((i) => ({ id: i.id, name: callName(i) })) : [];
}
export function birthdaysActive() {
  return !!current && current.settings.enabled && current.items.length > 0;
}

export function createDemoBirthdays({ wsError, params, notifyOk = true }) {
  const today = () => dayStart(new Date());
  const t = today();
  const plus = (n) => new Date(t.getTime() + n * 86400000);
  const seed = [
    { id: "b_mamie", name: "Josette", relation: "Mamie", day: t.getDate(), month: t.getMonth() + 1, year: t.getFullYear() - 80, phone: "+33612345678", channel: "sms" },
    { id: "b_paul", name: "Paul Martin", relation: "", day: plus(3).getDate(), month: plus(3).getMonth() + 1, year: null, phone: "+33711223344", channel: "whatsapp" },
    { id: "b_lea", name: "Léa", relation: "Ma filleule", day: plus(19).getDate(), month: plus(19).getMonth() + 1, year: t.getFullYear() - 11, phone: null, channel: "sms" },
    { id: "b_jean", name: "Jean Dupont", relation: "", day: plus(64).getDate(), month: plus(64).getMonth() + 1, year: null, phone: "+33698765432", channel: "sms" },
  ];
  const st = {
    items: params.get("birthdays") === "0" ? [] : seed,
    settings: { enabled: true, days_before: 3, hour: 9, sync_calendar: false, calendar_entity: "" },
  };
  current = st;
  let seq = 0;
  const payload = () => ({
    items: st.items.map((i) => view(i, today())).sort((a, b) => a.days - b.days || a.name.localeCompare(b.name)),
    settings: { ...st.settings }, notify: { service_ok: notifyOk, mobile: true }, announce: false,
    no_auto_send_fr: NO_AUTO_SEND, max_vcf_bytes: 2 * 1024 * 1024,
  });
  const clean = (raw) => {
    const name = String(raw.name || "").trim().slice(0, 60);
    if (!name) throw wsError("invalid_format", "Indiquez le prénom de la personne.");
    const day = Number(raw.day);
    const month = Number(raw.month);
    const d = new Date(2000, month - 1, day);
    if (!(month >= 1 && month <= 12) || d.getDate() !== day) throw wsError("invalid_format", "Cette date n'existe pas : vérifiez le jour et le mois.");
    const year = raw.year ? Number(raw.year) : null;
    if (raw.year && !(year >= 1900 && year <= t.getFullYear())) throw wsError("invalid_format", `L'année doit être entre 1900 et ${t.getFullYear()} (ou rester vide).`);
    let phone = null;
    if (raw.phone) {
      phone = normPhone(raw.phone);
      if (!phone) throw wsError("invalid_format", "Ce numéro de téléphone n'est pas reconnu (exemple : 06 12 34 56 78).");
    }
    return { name, day, month, year, relation: String(raw.relation || "").trim().slice(0, 40), phone, channel: raw.channel === "whatsapp" ? "whatsapp" : "sms", message: String(raw.message || "").slice(0, 300), source: raw.source || "manual" };
  };
  const mark = (cands) => {
    const keys = new Set(st.items.map((i) => key(i.name, i.day, i.month)));
    return cands.map((c) => ({ ...c, already: keys.has(c.key) }));
  };

  const handlers = {
    "birthdays/list": () => payload(),
    "birthdays/save": ({ item }) => {
      const c = clean(item);
      let id = item.birthday_id;
      if (id) {
        const idx = st.items.findIndex((i) => i.id === id);
        if (idx < 0) throw wsError("not_found", "Cet anniversaire n'existe plus.");
        st.items[idx] = { ...st.items[idx], ...c, id };
      } else {
        id = `b_new${++seq}`;
        st.items.push({ ...c, id });
      }
      return { item: view(st.items.find((i) => i.id === id), today()), ...payload() };
    },
    "birthdays/delete": ({ birthday_id }) => {
      if (!st.items.some((i) => i.id === birthday_id)) throw wsError("not_found", "Cet anniversaire n'existe plus.");
      st.items = st.items.filter((i) => i.id !== birthday_id);
      return payload();
    },
    "birthdays/clear": () => {
      st.items = [];
      st.settings = { ...st.settings, sync_calendar: false, calendar_entity: "" };
      return payload();
    },
    "birthdays/import_vcf": ({ content }) => {
      if (!/BEGIN:VCARD/i.test(content || "")) throw wsError("invalid_format", "Ce fichier n'est pas un fichier de contacts (.vcf). Exportez vos contacts depuis votre téléphone, puis réessayez.");
      const r = parseVcf(content);
      return { candidates: mark(r.candidates), without_date: r.without_date };
    },
    "birthdays/import_confirm": ({ items }) => {
      let added = 0;
      let skipped = 0;
      const keys = new Set(st.items.map((i) => key(i.name, i.day, i.month)));
      for (const raw of items || []) {
        try {
          const c = clean(raw);
          const k = key(c.name, c.day, c.month);
          if (keys.has(k)) { skipped++; continue; }
          keys.add(k);
          st.items.push({ ...c, id: `b_imp${++seq}` });
          added++;
        } catch (e) {
          skipped++;
        }
      }
      return { added, skipped, ...payload() };
    },
    "birthdays/calendars": () => ({ calendars: params.get("calendar") === "1" ? [{ entity_id: "calendar.anniversaires", name: "Anniversaires", birthdays: true }] : [] }),
    "birthdays/import_calendar": () => ({
      candidates: mark([
        { key: key("Mamie", st.items[0]?.day || 1, st.items[0]?.month || 1), name: "Mamie", day: st.items[0]?.day || 1, month: st.items[0]?.month || 1, year: null, phone: null, source: "calendar" },
        { key: key("Camille", 9, 6), name: "Camille", day: 9, month: 6, year: null, phone: null, source: "calendar" },
      ]),
      entity_id: "calendar.anniversaires",
    }),
    "birthdays/settings": (msg) => {
      for (const k of ["enabled", "days_before", "hour", "sync_calendar", "calendar_entity"]) if (k in msg) st.settings[k] = msg[k];
      return payload();
    },
    "birthdays/test_notify": () => ({ ok: true, message_fr: "C'est envoyé : regardez votre téléphone." }),
  };

  const tiles = () => {
    if (!st.settings.enabled) return [];
    return st.items.map((i) => view(i, today())).filter((v) => v.today).map((v) => ({
      idea_id: "anniversaire", key: `birthday-${v.birthday_id}`, kind: "birthday",
      title: `C'est l'anniversaire ${deName(v.call_name)} aujourd'hui`, icon: "cake", color: "#C2185B", entity_ids: [],
      attribute: null, unit: null, threshold: null, show: "always", on_text: v.age_fr ? `${v.age_fr} !` : "Pensez à lui souhaiter !",
      off_text: null, action: null, page: { page: "ideas", params: { id: "anniversaire", view: "birthdays" } }, preview: null,
      birthday_id: v.birthday_id, message: v.text, channel: v.channel, links: v.links,
    }));
  };
  const previewTile = {
    idea_id: "anniversaire", key: "birthday-preview", kind: "birthday", title: "C'est l'anniversaire de Mamie aujourd'hui", icon: "cake",
    color: "#C2185B", entity_ids: [], attribute: null, unit: null, threshold: null, show: "always", on_text: "80 ans !", off_text: null,
    action: null, preview: "80 ans !", links: {},
  };
  const setEnabled = (on) => {
    st.settings.enabled = !!on;
  };
  return { handlers, tiles, previewTile, setEnabled };
}
