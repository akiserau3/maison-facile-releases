import { Page, html, timeHM, toDate } from "../lib.js";
import { icon } from "../icons.js";
import { MODES, MODE_ENTITY, currentMode, openings, roleEntities, cameraUrl, isOn, isUnavailable } from "../components/model.js";

const MODE_ORDER = ["maison", "absent", "nuit"];

export class SecurityPage extends Page {
  init() {
    this.s = { now: new Date(), history: null, historyHidden: false, pendingMode: null };
    this.every(15000, () => this.setState({ now: new Date() }));
    this.startCameras(cameraUrl);
    this.loadHistory();
    this.every(60000, () => this.loadHistory());
  }

  watchedIds() {
    const ids = [MODE_ENTITY];
    for (const role of ["contact", "motion", "smoke"]) ids.push(...roleEntities(this.data.devices, role).map((x) => x.entity_id));
    return ids;
  }

  async loadHistory() {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const ids = this.watchedIds().filter((id) => this.hass.states[id]);
    if (!ids.length) return this.setState({ historyHidden: true });
    try {
      const events = await this.hass.callWS({ type: "logbook/get_events", start_time: start.toISOString(), entity_ids: ids });
      this.setState({ history: Array.isArray(events) ? events : [], historyHidden: false });
    } catch (e) {
      // Logbook not available: the block is simply hidden.
      this.setState({ historyHidden: true });
    }
  }

  historyItems() {
    const byId = new Map();
    for (const d of this.data.devices || []) for (const [role, id] of Object.entries(d.entities || {})) byId.set(id, { d, role });
    const items = [];
    for (const ev of this.s.history || []) {
      const when = toDate(ev.when);
      if (!when || !ev.entity_id) continue;
      const st = ev.state;
      let text = null;
      let color = "#0067C0";
      if (ev.entity_id === MODE_ENTITY) {
        const m = MODES[st];
        if (!m) continue;
        text = st === "maison" ? "Retour à la maison, alarme désactivée" : st === "absent" ? "Alarme activée (absent)" : "Début du mode nuit";
        color = m.dot;
      } else {
        const info = byId.get(ev.entity_id);
        if (!info) continue;
        const name = info.d.name;
        if (info.role === "contact") {
          if (st === "on") { text = `Ouverture : ${name}`; color = "#F7630C"; }
          else if (st === "off") { text = `Fermeture : ${name}`; color = "#0067C0"; }
        } else if (info.role === "motion" && st === "on") {
          text = `Mouvement vu par ${name}`; color = "#F7630C";
        } else if (info.role === "smoke" && st === "on") {
          text = `Fumée détectée : ${name}`; color = "#C42B1C";
        }
      }
      if (text) items.push({ when, text, color, key: `${ev.entity_id}-${ev.when}` });
    }
    items.sort((a, b) => b.when - a.when);
    return items.slice(0, 25);
  }

  template() {
    this.st(MODE_ENTITY);
    const mode = this.s.pendingMode || currentMode(this.hass);
    const m = MODES[mode];
    const get = (id) => this.st(id);
    const ops = openings(this.data, get);
    const open = ops.filter((o) => o.open);
    const warn = mode !== "maison" && open.length > 0;
    const cams = roleEntities(this.data.devices, "camera");
    const smokes = roleEntities(this.data.devices, "smoke");
    return html`
      <header class="page-head">
        <div class="title">
          <span class="page-icon" style="background:#0E7A0D;box-shadow:0 8px 18px rgba(14,122,13,0.35)">${icon("shield", 28)}</span>
          <div><h1>Sécurité</h1><span class="sub" style="font-size:15px">Alarme, ouvertures, caméras et fumée</span></div>
        </div>
        <span class="clock-pill glass">${timeHM(this.s.now)}</span>
      </header>
      <main class="page-main">
        <section class="col">
          <div class="banner" style="background:${m.color};box-shadow:0 14px 32px ${m.shadow};--banner-color:${m.color}">
            <div class="row" style="gap:14px">
              <span class="b-icon">${icon("lock", 28)}</span>
              <div style="display:flex;flex-direction:column;gap:2px"><strong>${m.title}</strong><span style="font-size:16px;opacity:0.95">${m.sub}</span></div>
            </div>
            <div class="seg three modes" role="group" aria-label="Mode de l'alarme">
              ${MODE_ORDER.map((k) => html`<button type="button" data-action="mode" data-mode="${k}" aria-pressed="${mode === k ? "true" : "false"}">${MODES[k].short}</button>`)}
            </div>
            ${warn ? html`<div class="warnline" role="alert">${icon("warn", 22)}<span>Attention : ${open.map((o) => o.name.toLowerCase()).join(", ")} ${open.length > 1 ? "sont ouvertes" : "est ouverte"}.</span></div>` : ""}
          </div>

          <div class="glass card" style="border-radius:22px">
            <div class="row wrap" style="justify-content:space-between">
              <h2 class="h2">Portes et fenêtres</h2>
              <span class="sub" style="font-size:15px">${ops.length === 0 ? "" : open.length === 0 ? "Tout est fermé" : open.length === 1 ? "1 ouverture" : `${open.length} ouvertures`}</span>
            </div>
            ${ops.length
              ? html`<ul class="openings" style="list-style:none;margin:0;padding:0">${ops.map((o) => html`<li class="opening ${o.unknown ? "unk" : o.open ? "open" : ""}" data-key="${o.entity_id}">
                  <span class="o-dot" aria-hidden="true"></span>
                  <span class="o-name">${o.name}${o.room && !o.name.toLowerCase().includes(o.room.toLowerCase()) ? html` <span class="sub" style="font-weight:400">· ${o.room}</span>` : ""}</span>
                  <span class="o-state">${o.unknown ? "Ne répond plus" : o.open ? "Ouverte" : "Fermée"}</span>
                </li>`)}</ul>`
              : html`<p class="sub">Aucun détecteur d'ouverture pour l'instant.</p>`}
          </div>

          ${cams.length
            ? html`<div class="cams">${cams.slice(0, 4).map(({ device, entity_id }) => {
                const url = this.cameraSrc(entity_id, cameraUrl);
                return html`<div class="cam" data-key="${entity_id}">
                  ${url ? html`<img data-cam="${entity_id}" alt="Image en direct : ${device.name}" src="${url}"><span class="live"><i></i>EN DIRECT</span>` : html`<span data-cam-off="${entity_id}">Image indisponible pour le moment</span>`}
                  <span class="cam-name">${device.name}</span>
                </div>`;
              })}</div>`
            : ""}
        </section>

        <aside class="side" style="width:380px">
          ${this.smokeCard(smokes, get)}
          ${this.s.historyHidden
            ? ""
            : html`<div class="glass card" style="flex:1;min-height:0;overflow:auto;border-radius:22px">
                <h2 class="h2">Ce qui s'est passé aujourd'hui</h2>
                ${this.s.history === null
                  ? html`<p class="sub">Chargement…</p>`
                  : (() => {
                      const items = this.historyItems();
                      return items.length
                        ? html`<ol class="history">${items.map((h) => html`<li data-key="${h.key}"><span class="h-time">${timeHM(h.when)}</span><span class="h-dot" style="background:${h.color}" aria-hidden="true"></span><span class="h-text">${h.text}</span></li>`)}</ol>`
                        : html`<p class="sub">Rien de particulier aujourd'hui.</p>`;
                    })()}
              </div>`}
        </aside>
      </main>`;
  }

  smokeCard(smokes, get) {
    if (!smokes.length) {
      return html`<div class="glass card" style="border-radius:22px"><div class="row"><span class="badge" style="width:44px;height:44px;border-radius:14px;background:#C42B1C">${icon("flame", 24)}</span><div><strong style="font-size:18px">Détecteurs de fumée</strong><br><span class="sub" style="font-size:15px">Aucun détecteur installé</span></div></div></div>`;
    }
    const alarm = smokes.filter((s) => isOn(get(s.entity_id)));
    const working = smokes.filter((s) => !isUnavailable(get(s.entity_id)) && s.device.available !== false);
    const lowBatt = smokes.filter((s) => typeof s.device.battery === "number" && s.device.battery < 15);
    let line;
    let color = "var(--ok-text)";
    if (alarm.length) {
      line = `FUMÉE DÉTECTÉE : ${alarm.map((a) => a.device.name).join(", ")}`;
      color = "#C42B1C";
    } else {
      line = `${working.length} sur ${smokes.length} fonctionne${working.length > 1 ? "nt" : ""}`;
      line += lowBatt.length ? ` · pile faible : ${lowBatt.map((b) => b.device.name).join(", ")}` : " · piles OK";
      if (working.length < smokes.length || lowBatt.length) color = "var(--open-text)";
    }
    return html`<div class="glass card" style="border-radius:22px;${alarm.length ? "border:3px solid #C42B1C" : ""}" ${alarm.length ? html`role="alert"` : ""}>
      <div class="row"><span class="badge" style="width:44px;height:44px;border-radius:14px;background:#C42B1C">${icon("flame", 24)}</span>
      <div style="display:flex;flex-direction:column"><strong style="font-size:18px">Détecteurs de fumée</strong><span style="font-size:15px;font-weight:700;color:${color}">${line}</span></div></div>
    </div>`;
  }

  async onAction(action, el) {
    if (action !== "mode") return;
    const option = el.dataset.mode;
    if (option === currentMode(this.hass)) return;
    this.setState({ pendingMode: option });
    await this.app.callService("select", "select_option", { entity_id: MODE_ENTITY, option }, "Impossible de changer le mode de l'alarme.");
    this.setState({ pendingMode: null });
    this.loadHistory();
  }
}
