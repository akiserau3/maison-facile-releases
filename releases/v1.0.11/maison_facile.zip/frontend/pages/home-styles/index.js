// The four extra home styles (Réglages › Apparence › Style de l'accueil).
// Maison Facile (pages/home.js) stays the default style.
import { renderOrbite, ORBITE_CSS } from "./orbite.js";
import { renderNeon, NEON_CSS } from "./neon.js";
import { renderJumeau, JUMEAU_CSS } from "./jumeau.js";
import { renderHolo, HOLO_CSS } from "./holo.js";

export { tubeLevel } from "./neon.js";

export const STYLE_RENDERERS = {
  orbite: renderOrbite,
  neon: renderNeon,
  jumeau: renderJumeau,
  holo: renderHolo,
};

const COMMON_CSS = `
/* Every home style: animations stop with "Petites animations" off, reduced motion or a hidden tab. */
.app[data-anim="off"] .hs *, .app[data-anim="off"] .hs *::before, .app[data-anim="off"] .hs *::after,
.app.mf-hidden .hs *, .app.mf-hidden .hs *::before, .app.mf-hidden .hs *::after { animation-play-state: paused !important; }
.app[data-anim="off"] .hs *, .app[data-anim="off"] .hs *::before, .app[data-anim="off"] .hs *::after { animation: none !important; }
@media (prefers-reduced-motion: reduce) { .hs *, .hs *::before, .hs *::after { animation: none !important; transition: none !important; } }
.hs button { font-family: inherit; cursor: pointer; }
.hs button:disabled { opacity: 0.6; cursor: default; }
.hs :focus-visible { outline: 3px solid currentColor; outline-offset: 3px; }
`;

export const HOME_STYLES_CSS = COMMON_CSS + ORBITE_CSS + NEON_CSS + JUMEAU_CSS + HOLO_CSS;
