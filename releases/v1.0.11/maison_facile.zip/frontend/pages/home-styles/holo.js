// Style d'accueil « Holo » (design-mockups/styles-v2/H-Holo-tel.dc.html), adapted:
// pastel iridescent home, one card per room that turns over (CSS 3D rotateY) to its
// holographic side when the light is on. Softened: static clock gradient (no repaint
// every frame), no blend modes, dark text (>= 4.5:1) on every pastel.
import { html, icon, temp, roomClimate, lightText, lightsSummary, roomAria, modeButtons, modeSub, quickButtons, heatingAction, tileRows, energyLine, clockText, weatherText, dateLong, greetingHtml, noRooms } from "./common.js";

const HOLO = [
  "linear-gradient(135deg, #FFB86B 0%, #FF8AC0 50%, #C4AEFF 100%)",
  "linear-gradient(135deg, #D6FF7A 0%, #6FF2C8 50%, #8FD8FF 100%)",
  "linear-gradient(135deg, #C9B2FF 0%, #9FB4FF 50%, #8FEAFF 100%)",
  "linear-gradient(135deg, #FFC2E0 0%, #FF9FD4 45%, #FFD58A 100%)",
  "linear-gradient(135deg, #8FF3FF 0%, #A9BCFF 50%, #E2B4FF 100%)",
  "linear-gradient(135deg, #EEFF96 0%, #96F5B4 50%, #7CE9DE 100%)",
];

function bubble(name, t, i) {
  return html`<span class="ho-bubble ${t >= 19 ? "warm" : "cool"}" style="--i:${i}"><strong>${temp(t)}</strong><span>${name}</span></span>`;
}

export function renderHolo(m, page) {
  const cards = m.rooms.map((r, i) => {
    const face = (back) => html`<span class="ho-face ${back ? "back" : "front"}" aria-hidden="true">
      ${back ? html`<span class="ho-sheen"></span>` : html`<span class="ho-blob"></span>`}
      <span class="ho-top"><span class="ho-bulb">${icon(r.hasLight ? "bulb" : r.icon, 20)}</span><span class="ho-state">${back ? "ALLUMÉE" : r.hasLight ? "ÉTEINTE" : "PAS DE LUMIÈRE"}</span></span>
      <span class="ho-bottom"><span class="ho-name">${r.name}</span><span class="ho-temp">${roomClimate(r)}</span></span>
    </span>`;
    return html`<button type="button" class="ho-card ${r.on ? "on" : ""}" data-key="ho-${r.area_id}" style="--holo:${HOLO[i % HOLO.length]}" data-action="${r.hasLight ? "room-light" : "go-room"}" data-area="${r.area_id}"
        ${r.hasLight ? html`aria-pressed="${r.on ? "true" : "false"}"` : ""} aria-label="${roomAria(r)}">
      <span class="ho-flip">${face(false)}${face(true)}</span>
    </button>`;
  });
  const bubbles = m.rooms.filter((r) => r.temp !== null).slice(0, 3).map((r, i) => bubble(r.name, r.temp, i));
  if (m.weather?.temp !== null && m.weather?.temp !== undefined) bubbles.push(bubble("Dehors", m.weather.temp, bubbles.length));
  const alerts = m.alerts.filter((a) => a.kind !== "heating").slice(0, 4);
  return html`<section class="hs hs-holo" data-key="hs-holo" aria-label="Accueil, style Holo">
    <div class="ho-main">
      <header class="ho-head">
        <div class="hs-grow"><p class="ho-date">${dateLong(m.now)}</p><span class="ho-clock">${clockText(m)}</span><h1 class="ho-hello">${greetingHtml(m.greeting)}</h1></div>
        ${m.weather ? html`<span class="ho-weather">${icon(m.weather.icon, 26)}<strong>${m.weather.temp !== null ? temp(m.weather.temp, 0) : "–"}</strong><span>${m.weather.label || "Dehors"}</span></span>` : ""}
      </header>
      ${alerts.length ? html`<div class="ho-chips" role="list" aria-label="À regarder">${alerts.map((a) => html`<span class="ho-chip ${a.severity}" role="listitem"><i aria-hidden="true"></i>${a.text}</span>`)}</div>` : ""}
      <div class="ho-rooms-head"><h2>Les pièces</h2><span>${lightsSummary(m)} · touchez pour retourner</span></div>
      ${m.rooms.length ? html`<div class="ho-rooms">${cards}</div>` : noRooms("ho-panel")}
    </div>
    <div class="ho-side">
      <p class="ho-wink">${icon("magic", 20)}<span>${m.wink}</span></p>
      ${heatingAction(m, page, "ho-panel ho-heat")}
      ${bubbles.length ? html`<section class="ho-panel ho-temps"><h2>Températures</h2><div class="ho-bubbles">${bubbles}</div></section>` : ""}
      <section class="ho-modes-wrap">
        <div class="ho-modes" role="group" aria-label="Mode de la maison">${modeButtons(m, page, "ho-mode")}</div>
        <span class="ho-mode-sub">${modeSub(m)}</span>
      </section>
      ${tileRows(m, "ho-tile")}
      <div class="ho-quick">${quickButtons(page, "ho-q", { size: 22 })}</div>
      <button type="button" class="ho-energy" data-action="go-energy">${icon("bolt", 20)}<span class="hs-grow">${energyLine(m)}</span></button>
    </div>
  </section>`;
}

export const HOLO_CSS = `
.app[data-page="home"][data-home-style="holo"] { background: #F6F4FB; }
.hs-holo {
  --h-text: #16122B; --h-sub: #4F4A69; --h-card: rgba(255,255,255,0.78); --h-acc: #5B3FD9; --h-acc-text: #FFFFFF;
  --h-sel: linear-gradient(110deg, #FFB86B, #FF8AC8, #B79CFF, #7FE6FF);
  position: relative; flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(0, 1fr) 400px; gap: 22px; padding: 18px 32px 12px; overflow: hidden;
  color: var(--h-text); font-family: 'Segoe UI', 'Noto Sans', system-ui, sans-serif;
  background: radial-gradient(40% 45% at 0% 0%, #FFD6F0, transparent 70%), radial-gradient(40% 45% at 100% 10%, #C9F0FF, transparent 70%), radial-gradient(40% 45% at 10% 100%, #E3FFD9, transparent 70%), radial-gradient(40% 45% at 90% 95%, #E6D9FF, transparent 70%), #F6F4FB;
}
.hs-holo[data-tint] { --h-acc: var(--accent); --h-acc-text: var(--accent-text); --h-sel: var(--accent); }
.hs-holo .hs-grow { flex: 1; min-width: 0; }
.ho-main { min-width: 0; min-height: 0; display: flex; flex-direction: column; gap: 12px; }
.ho-head { display: flex; align-items: flex-start; gap: 14px; }
.ho-date { font-size: 16px; font-weight: 600; color: var(--h-sub); }
.ho-clock { display: inline-block; font-size: 84px; font-weight: 900; letter-spacing: -4px; line-height: 0.95; background: linear-gradient(110deg, #E0408F, #6A4CF0, #1A8FD0, #1F9E6B, #D98A0B); -webkit-background-clip: text; background-clip: text; color: transparent; }
.ho-hello { font-size: 24px; font-weight: 800; }
.ho-weather { display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 12px 16px; border-radius: 24px; background: rgba(255,255,255,0.75); border: 1px solid #FFFFFF; box-shadow: 0 10px 24px rgba(70,50,140,0.10); color: var(--h-text); }
.ho-weather svg { color: #5B3FD9; }
.ho-weather strong { font-size: 22px; font-weight: 800; }
.ho-weather span { font-size: 13px; color: var(--h-sub); }
.ho-chips { display: flex; flex-wrap: wrap; gap: 8px; }
.ho-chip { display: flex; align-items: center; gap: 8px; padding: 8px 14px; border-radius: 16px; font-size: 14px; font-weight: 700; background: #FFFFFF; color: #9A2F15; box-shadow: 0 4px 14px rgba(255,111,80,0.18); }
.ho-chip i { width: 8px; height: 8px; border-radius: 50%; background: #FF6F50; }
.ho-chip.info { color: #1F4F8A; box-shadow: 0 4px 14px rgba(80,140,255,0.15); }
.ho-chip.info i { background: #4C8DFF; }
.ho-chip.danger { color: #FFFFFF; background: #C42B1C; }
.ho-chip.danger i { background: #FFFFFF; }
.ho-rooms-head { display: flex; justify-content: space-between; align-items: baseline; gap: 12px; flex-wrap: wrap; }
.ho-rooms-head h2 { font-size: 26px; font-weight: 900; letter-spacing: -0.5px; }
.ho-rooms-head span { font-size: 14px; color: var(--h-sub); }
.ho-rooms { flex: 1; min-height: 0; overflow: auto; display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); grid-auto-rows: 150px; gap: 14px; padding: 4px 4px 10px; }
.ho-card { height: 100%; padding: 0; border: 0; background: transparent; perspective: 900px; color: var(--h-text); text-align: left; border-radius: 26px; }
.ho-flip { display: block; position: relative; width: 100%; height: 100%; transform-style: preserve-3d; transition: transform 0.7s cubic-bezier(.2,.8,.2,1); }
.ho-card.on .ho-flip { transform: rotateY(180deg); }
.ho-face { position: absolute; inset: 0; border-radius: 26px; padding: 14px 16px; overflow: hidden; display: flex; flex-direction: column; justify-content: space-between; backface-visibility: hidden; -webkit-backface-visibility: hidden; }
.ho-face.front { background: var(--h-card); border: 1px solid #FFFFFF; box-shadow: 0 10px 26px rgba(70,50,140,0.10); }
.ho-face.back { transform: rotateY(180deg); background: var(--holo); box-shadow: 0 16px 30px rgba(120,80,200,0.28); }
.ho-blob { position: absolute; right: -30px; top: -30px; width: 100px; height: 100px; border-radius: 50%; background: var(--holo); opacity: 0.35; filter: blur(14px); }
.ho-sheen { position: absolute; top: -30%; bottom: -30%; left: 30%; width: 40%; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent); animation: hoSheen 4s ease-in-out infinite alternate; }
.ho-top, .ho-bottom { position: relative; display: flex; }
.ho-top { justify-content: space-between; align-items: center; }
.ho-bottom { flex-direction: column; }
.ho-bulb { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: #EEEAF7; color: var(--h-sub); }
.ho-face.back .ho-bulb { background: rgba(255,255,255,0.9); color: var(--h-text); box-shadow: 0 0 16px rgba(255,255,255,0.9); }
.ho-face.back .ho-bulb svg { fill: #FFE27A; }
.ho-state { font-size: 12px; font-weight: 800; letter-spacing: 1px; color: var(--h-sub); }
.ho-face.back .ho-state { color: var(--h-text); }
.ho-name { font-size: 21px; font-weight: 900; line-height: 1.1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ho-temp { font-size: 14px; font-weight: 600; color: var(--h-sub); }
.ho-face.back .ho-temp { color: var(--h-text); }
.ho-card:focus-visible { outline: 3px solid var(--h-acc); outline-offset: 3px; }
.ho-side { min-height: 0; overflow: auto; display: flex; flex-direction: column; gap: 12px; padding: 4px; }
.ho-wink { display: flex; align-items: flex-start; gap: 10px; padding: 14px 16px; border-radius: 22px; background: rgba(255,255,255,0.7); border: 1px solid #FFFFFF; font-size: 16px; line-height: 1.35; }
.ho-wink svg { color: var(--h-acc); flex-shrink: 0; }
.ho-panel { padding: 14px 16px; border-radius: 26px; background: rgba(255,255,255,0.6); border: 1px solid #FFFFFF; display: flex; flex-direction: column; gap: 10px; }
.ho-panel h2 { font-size: 18px; font-weight: 800; }
.ho-panel button { min-height: 48px; padding: 0 16px; border-radius: 16px; border: 0; background: var(--h-acc); color: var(--h-acc-text); font-weight: 800; font-size: 15px; }
.ho-heat { background: #FFF1E8; border-color: #F7A36B; color: #7A2E00; }
.ho-heat.ok { background: #E8F7EC; border-color: #7CC48F; color: #14532D; }
.ho-bubbles { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); justify-items: center; gap: 6px; }
.ho-bubble { width: 78px; height: 78px; border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: var(--h-text); animation: hoBubble 6s ease-in-out infinite; animation-delay: calc(var(--i) * 0.8s);
  background: radial-gradient(circle at 32% 28%, #FFFFFF 0%, #FFD9C4 35%, #FFB0CF 80%); box-shadow: 0 12px 26px rgba(255,111,181,0.30); }
.ho-bubble.cool { background: radial-gradient(circle at 32% 28%, #FFFFFF 0%, #D2F4FF 35%, #A6D8FF 80%); box-shadow: 0 12px 26px rgba(80,160,255,0.30); }
.ho-bubble strong { font-size: 19px; font-weight: 900; line-height: 1; }
.ho-bubble span { font-size: 13px; font-weight: 700; max-width: 78px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ho-modes-wrap { display: flex; flex-direction: column; gap: 6px; }
.ho-modes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 4px; padding: 5px; border-radius: 28px; background: rgba(255,255,255,0.75); border: 1px solid #FFFFFF; box-shadow: 0 10px 24px rgba(70,50,140,0.08); }
.ho-mode { min-height: 52px; display: flex; align-items: center; justify-content: center; gap: 6px; padding: 0 6px; white-space: nowrap; border: 0; border-radius: 24px; background: transparent; color: var(--h-text); font-size: 15px; font-weight: 700; }
.ho-mode[aria-pressed="true"] { background: var(--h-sel); box-shadow: 0 8px 20px rgba(183,156,255,0.40); }
.hs-holo[data-tint] .ho-mode[aria-pressed="true"] { color: var(--h-acc-text); }
.ho-mode-sub { font-size: 13px; color: var(--h-sub); padding-left: 10px; }
.ho-tile { display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 22px; background: rgba(255,255,255,0.78); border: 1px solid #FFFFFF; box-shadow: 0 8px 20px rgba(70,50,140,0.08); }
.ho-tile .hs-grow { display: flex; flex-direction: column; font-size: 14px; color: var(--h-sub); }
.ho-tile strong { color: var(--h-text); font-size: 16px; }
.ho-tile.lit { background: #FFF6D6; border-color: #F5C542; }
.ho-tile.danger { background: #FFE6E3; border-color: #E2574C; }
.ho-tile button { min-height: 48px; padding: 0 16px; border-radius: 16px; border: 0; background: var(--h-acc); color: var(--h-acc-text); font-weight: 800; }
.ho-quick { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.ho-q { min-height: 64px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; border-radius: 24px; border: 1px solid #FFFFFF; background: rgba(255,255,255,0.8); color: var(--h-text); font-size: 14px; font-weight: 800; box-shadow: 0 8px 20px rgba(70,50,140,0.08); }
.ho-q[data-action="all-off"] { background: var(--h-sel); }
.hs-holo[data-tint] .ho-q[data-action="all-off"] { color: var(--h-acc-text); }
.ho-energy { display: flex; align-items: center; gap: 10px; min-height: 52px; padding: 0 16px; border-radius: 22px; border: 1px solid #FFFFFF; background: rgba(255,255,255,0.6); color: var(--h-sub); font-size: 15px; text-align: left; }
.ho-energy strong { color: var(--h-text); }
.ho-energy svg { color: #B36B00; flex-shrink: 0; }
@keyframes hoSheen { 0% { transform: translateX(-70%) rotate(8deg); } 100% { transform: translateX(70%) rotate(8deg); } }
@keyframes hoBubble { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
.app.narrow .hs-holo { grid-template-columns: minmax(0, 1fr); align-content: start; padding: 16px; overflow: visible; }
.app.narrow .ho-clock { font-size: 68px; }
.app.narrow .ho-rooms { grid-template-columns: repeat(2, minmax(0, 1fr)); grid-auto-rows: 140px; overflow: visible; }
.app.narrow .ho-name { font-size: 18px; }
.app.narrow .ho-side { overflow: visible; }
`;
