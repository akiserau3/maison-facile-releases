// Style d'accueil « Néon » (design-mockups/styles-v2/F-Neon-tel.dc.html), adapted:
// one light tube per room (touch the height you want = brightness, real light.turn_on),
// a news band with the real state of the house, the temperature scale, neon mode buttons.
// Softened: no flicker, slower band, readable sizes, 48 px+ targets.
import { html, icon, temp, roomClimate, lightText, lightsSummary, modeButtons, modeSub, quickButtons, heatingAction, tileRows, energyLine, clockText, weatherText, dateLong, greetingHtml, noRooms, MODE_SHORT } from "./common.js";

const TUBES = [
  ["#FFB86B", "#FF3D7F"],
  ["#7CFFCB", "#00B3A4"],
  ["#C79BFF", "#6A3DFF"],
  ["#7DF9FF", "#0077FF"],
  ["#FF9EE6", "#D62BFF"],
  ["#D9FF6B", "#3DDC5A"],
  ["#FFD27A", "#FF7A00"],
  ["#9EC1FF", "#3D5BFF"],
];

const MARK_COLORS = ["#7DF9FF", "#7CFFCB", "#FFD27A", "#FF9EE6", "#C79BFF", "#FFB86B", "#D9FF6B"];
const T_MIN = 10;
const T_MAX = 30;

function bandItems(m) {
  const items = [];
  for (const a of m.alerts) items.push({ text: a.short.toUpperCase(), c: a.severity === "info" ? "#7DF9FF" : "#FFB86B" });
  items.push({ text: `MODE ${MODE_SHORT[m.mode.id].toUpperCase()}`, c: "#C79BFF" });
  items.push({ text: lightsSummary(m).toUpperCase(), c: "#FFD27A" });
  for (const r of m.rooms) if (r.temp !== null) items.push({ text: `${r.name.toUpperCase()} ${temp(r.temp)}`, c: "#7CFFCB" });
  if (m.weather) items.push({ text: weatherText(m).toUpperCase(), c: "#7DF9FF" });
  if (m.energy.state === "ok") items.push({ text: `${String(m.energy.total_kwh.toFixed(1)).replace(".", ",")} KWH AUJOURD'HUI`, c: "#D9FF6B" });
  return items;
}

export function renderNeon(m, page) {
  const lit = m.rooms.filter((r) => r.hasLight);
  const items = bandItems(m);
  const band = items.map((it) => html`<span style="--c:${it.c}">${it.text}</span>`);
  const marks = m.rooms.filter((r) => r.temp !== null).slice(0, 6).map((r) => ({ name: r.name, t: r.temp }));
  if (m.weather?.temp !== null && m.weather?.temp !== undefined) marks.push({ name: "Dehors", t: m.weather.temp, out: true });
  marks.sort((a, b) => a.t - b.t);
  return html`<section class="hs hs-neon" data-key="hs-neon" aria-label="Accueil, style Néon">
    <div class="neo-band" aria-hidden="true"><div class="neo-band-track">${band}${band}</div></div>
    <p class="sr-only">${items.map((i) => i.text).join(" · ")}</p>
    <div class="neo-grid">
      <div class="neo-left">
        <header class="neo-head">
          <span class="neo-clock">${clockText(m)}</span>
          <div class="neo-head-txt"><h1 class="neo-hello">${greetingHtml(m.greeting)}</h1><p class="neo-date">${dateLong(m.now)}${m.weather ? ` · ${weatherText(m)}` : ""}</p></div>
        </header>
        <p class="neo-wink"><span aria-hidden="true">▸</span> ${m.wink}</p>
        <section class="neo-lights" aria-label="Lumières">
          <div class="neo-title"><h2>LUMIÈRES</h2><span>${lightsSummary(m)} · touchez la hauteur voulue</span></div>
          ${lit.length
            ? html`<div class="neo-tubes">${lit.map((r, i) => {
                const c = TUBES[i % TUBES.length];
                const level = r.on ? Math.max(r.level ?? 100, 8) : 0;
                return html`<div class="neo-tube-col" data-key="tube-${r.area_id}">
                  <span class="neo-tube-temp">${r.temp !== null ? temp(r.temp) : ""}</span>
                  <button type="button" class="neo-tube ${r.on ? "on" : ""}" style="--c1:${c[0]};--c2:${c[1]};--h:${level}%" data-action="tube" data-area="${r.area_id}"
                    aria-pressed="${r.on ? "true" : "false"}" aria-label="Lumière ${r.name}, ${lightText(r)}. Toucher en haut pour plus fort, en bas pour éteindre ; Entrée pour allumer ou éteindre.">
                    <span class="neo-fill"><i></i></span>
                  </button>
                  <span class="neo-tube-name">${r.name}</span>
                  <span class="neo-tube-level ${r.on ? "on" : ""}">${r.on ? (r.level !== null ? `${r.level} %` : "ON") : "OFF"}</span>
                </div>`;
              })}</div>`
            : m.rooms.length
              ? html`<p class="neo-empty">Aucune lumière dans vos pièces pour l'instant.</p>`
              : noRooms("neo-empty")}
        </section>
      </div>
      <div class="neo-right">
        ${heatingAction(m, page, "neo-card neo-heat")}
        ${marks.length
          ? html`<section class="neo-card"><h2 class="neo-sub-title">TEMPÉRATURES</h2>
              <div class="neo-scale" role="list">
                <span class="neo-bar" aria-hidden="true"></span>
                <span class="neo-scale-min" aria-hidden="true">${T_MIN}°</span><span class="neo-scale-max" aria-hidden="true">${T_MAX}°</span>
                ${marks.map((k, i) => {
                  const pos = Math.max(0, Math.min(100, ((k.t - T_MIN) / (T_MAX - T_MIN)) * 100));
                  return html`<i class="neo-tick" aria-hidden="true" style="--p:${pos.toFixed(1)}%;--c:${MARK_COLORS[i % MARK_COLORS.length]}"></i>`;
                })}
              </div>
              <div class="neo-legend">${marks.map((k, i) => html`<span class="neo-mark" role="listitem"><i aria-hidden="true" style="--c:${MARK_COLORS[i % MARK_COLORS.length]}"></i><span>${k.name}</span><strong>${temp(k.t)}</strong></span>`)}</div></section>`
          : ""}
        <section class="neo-card">
          <div class="neo-title"><h2 class="neo-sub-title">MODE DE LA MAISON</h2><span>${modeSub(m)}</span></div>
          <div class="neo-modes" role="group" aria-label="Mode de la maison">${modeButtons(m, page, "neo-mode")}</div>
        </section>
        <div class="neo-scenes">${quickButtons(page, "neo-scene")}</div>
        ${m.alerts.filter((a) => a.kind !== "heating").slice(0, 3).map((a) => html`<div class="neo-row ${a.severity}" role="status" data-key="al-${a.key}">${icon(a.severity === "info" ? "door" : "warn", 22)}<span class="hs-grow">${a.text}</span></div>`)}
        ${tileRows(m, "neo-row neo-tile")}
        <button type="button" class="neo-row neo-energy" data-action="go-energy">${icon("bolt", 22)}<span class="hs-grow">${energyLine(m)}</span></button>
      </div>
    </div>
  </section>`;
}

/** Brightness from where the tube was touched (keyboard = on / off). */
export function tubeLevel(el, ev) {
  if (!ev || ev.detail === 0 || typeof ev.clientY !== "number") return null;
  const r = el.getBoundingClientRect();
  if (!r.height) return null;
  let v = Math.round(((1 - (ev.clientY - r.top) / r.height) * 100) / 5) * 5;
  if (v < 8) v = 0;
  return Math.max(0, Math.min(100, v));
}

export const NEON_CSS = `
.app[data-page="home"][data-home-style="neon"] { background: #05050A; }
.hs-neon {
  --n-text: #F2F4FF; --n-sub: #B4B9D6; --n-line: rgba(255,255,255,0.10); --n-card: rgba(255,255,255,0.04);
  --n-acc: #7DF9FF; --n-acc-2: #FF3D7F;
  position: relative; flex: 1; min-height: 0; display: flex; flex-direction: column; color: var(--n-text); overflow: hidden;
  font-family: 'Segoe UI', 'Noto Sans', system-ui, sans-serif;
  background: radial-gradient(50% 40% at 30% 60%, rgba(255,61,127,0.12), transparent 70%), radial-gradient(40% 40% at 70% 50%, rgba(0,119,255,0.12), transparent 70%), #05050A;
}
.hs-neon[data-tint] { --n-acc: var(--accent); --n-acc-2: var(--accent); }
.hs-neon .hs-grow { flex: 1; min-width: 0; }
.neo-band { height: 40px; flex-shrink: 0; overflow: hidden; display: flex; align-items: center; border-bottom: 1px solid var(--n-line); background: rgba(255,255,255,0.02); }
.neo-band-track { display: flex; gap: 36px; width: max-content; padding-left: 24px; white-space: nowrap; animation: neoScroll 45s linear infinite; }
.neo-band-track span { font-size: 14px; font-weight: 700; letter-spacing: 1.5px; color: var(--c); }
.neo-grid { flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(0, 1fr) 440px; gap: 24px; padding: 14px 32px 12px; }
.neo-left { min-width: 0; min-height: 0; display: flex; flex-direction: column; gap: 10px; }
.neo-head { display: flex; align-items: flex-end; gap: 22px; flex-wrap: wrap; }
.neo-clock { font-size: 96px; font-weight: 800; letter-spacing: -3px; line-height: 0.9; background: linear-gradient(100deg, #7DF9FF 0%, #C79BFF 45%, #FF6FA0 100%); -webkit-background-clip: text; background-clip: text; color: transparent; }
.neo-head-txt { display: flex; flex-direction: column; gap: 4px; padding-bottom: 6px; }
.neo-hello { font-size: 24px; font-weight: 700; }
.neo-date { font-size: 15px; letter-spacing: 1px; color: var(--n-sub); }
.neo-wink { font-size: 16px; color: var(--n-text); }
.neo-wink span { color: var(--n-acc); }
.neo-lights { flex: 1; min-height: 0; display: flex; flex-direction: column; gap: 10px; }
.neo-title { display: flex; justify-content: space-between; align-items: baseline; gap: 12px; flex-wrap: wrap; }
.neo-title h2 { font-size: 18px; font-weight: 800; letter-spacing: 3px; }
.neo-title span { font-size: 14px; color: var(--n-sub); }
.neo-tubes { flex: 1; min-height: 0; display: flex; gap: 18px; justify-content: space-around; align-items: stretch; overflow-x: auto; padding: 6px 4px 4px; }
.neo-tube-col { flex: 0 1 96px; min-width: 70px; min-height: 0; display: flex; flex-direction: column; align-items: center; gap: 8px; }
.neo-tube-temp { height: 20px; font-size: 15px; font-weight: 700; color: var(--n-sub); }
.neo-tube { position: relative; flex: 1; min-height: 160px; max-height: 380px; width: 68px; padding: 0; border-radius: 34px; overflow: hidden; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.18); cursor: ns-resize;
  background-image: repeating-linear-gradient(to top, rgba(255,255,255,0.05) 0 1px, transparent 1px 28px); }
.neo-tube.on { border-color: var(--c1); }
.neo-fill { position: absolute; left: 0; right: 0; bottom: 0; height: var(--h); border-radius: 29px; background: linear-gradient(to top, var(--c2), var(--c1)); box-shadow: 0 0 18px var(--c1); transition: height 0.25s ease-out; }
.neo-fill i { position: absolute; left: 50%; top: 6px; width: 24px; height: 6px; margin-left: -12px; border-radius: 3px; background: #FFFFFF; box-shadow: 0 0 8px #FFFFFF; }
.neo-tube:not(.on) .neo-fill i { display: none; }
.neo-tube:focus-visible { outline: 3px solid #FFFFFF; outline-offset: 3px; }
.neo-tube-name { font-size: 15px; font-weight: 700; text-align: center; max-width: 86px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.neo-tube-level { font-size: 14px; font-weight: 700; letter-spacing: 1px; color: var(--n-sub); }
.neo-tube-level.on { color: #FFFFFF; }
.neo-empty { padding: 20px; border-radius: 20px; border: 1px solid var(--n-line); background: var(--n-card); font-size: 16px; display: flex; flex-direction: column; gap: 12px; align-items: flex-start; }
.neo-empty button { min-height: 48px; padding: 0 18px; border-radius: 14px; border: 1px solid var(--n-acc); background: transparent; color: var(--n-text); font-weight: 700; }
.neo-right { min-height: 0; overflow: auto; display: flex; flex-direction: column; gap: 12px; padding: 2px; }
.neo-card { padding: 14px 16px; border-radius: 22px; background: var(--n-card); border: 1px solid var(--n-line); display: flex; flex-direction: column; gap: 10px; }
.neo-sub-title { font-size: 15px; font-weight: 800; letter-spacing: 3px; color: var(--n-sub); }
.neo-heat { border-color: rgba(255,140,60,0.55); background: rgba(255,122,0,0.08); }
.neo-heat.ok { border-color: rgba(124,255,203,0.5); background: rgba(0,179,164,0.08); }
.neo-heat button { min-height: 48px; border-radius: 14px; border: 1px solid #FFB86B; background: transparent; color: #FFD9B0; font-size: 15px; font-weight: 700; }
.neo-scale { position: relative; height: 54px; margin: 0 12px; }
.neo-bar { position: absolute; left: 0; right: 0; top: 14px; height: 10px; border-radius: 5px; background: linear-gradient(90deg, #0077FF, #7DF9FF 28%, #7CFFCB 45%, #FFB86B 72%, #FF3D7F); box-shadow: 0 0 14px rgba(125,249,255,0.25); }
.neo-scale-min, .neo-scale-max { position: absolute; top: 32px; font-size: 12px; color: var(--n-sub); }
.neo-scale-min { left: -8px; } .neo-scale-max { right: -8px; }
.neo-tick { position: absolute; left: var(--p); top: 6px; width: 4px; height: 26px; margin-left: -2px; border-radius: 2px; background: var(--c); box-shadow: 0 0 8px var(--c); border: 1px solid #05050A; }
.neo-legend { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px 14px; }
.neo-mark { display: flex; align-items: center; gap: 8px; font-size: 15px; min-width: 0; }
.neo-mark i { width: 10px; height: 10px; border-radius: 50%; background: var(--c); box-shadow: 0 0 6px var(--c); flex-shrink: 0; }
.neo-mark span { color: var(--n-sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.neo-mark strong { margin-left: auto; font-size: 17px; font-weight: 800; }
.neo-modes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.neo-mode { min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.14); background: transparent; color: var(--n-sub); font-size: 15px; font-weight: 700; letter-spacing: 0.5px; transition: background 0.25s ease, color 0.25s ease; }
.neo-mode[aria-pressed="true"] { color: #FFFFFF; border-color: var(--n-acc); background: rgba(125,249,255,0.10); box-shadow: 0 0 16px rgba(125,249,255,0.30), inset 0 0 10px rgba(125,249,255,0.15); }
.hs-neon[data-tint] .neo-mode[aria-pressed="true"] { background: var(--accent); color: var(--accent-text); box-shadow: 0 0 16px var(--accent); }
.neo-scenes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
.neo-scene { min-height: 60px; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 0 10px; border-radius: 18px; border: 1px solid transparent; color: var(--n-text); font-size: 15px; font-weight: 700;
  background: linear-gradient(#0A0A12, #0A0A12) padding-box, linear-gradient(110deg, var(--n-acc), var(--n-acc-2)) border-box; }
.neo-scene svg { color: var(--n-acc); flex-shrink: 0; }
.neo-row { display: flex; align-items: center; gap: 12px; min-height: 56px; padding: 8px 14px; border-radius: 18px; background: var(--n-card); border: 1px solid var(--n-line); color: var(--n-text); font-size: 15px; text-align: left; }
.neo-row.warn, .neo-row.danger { border-color: rgba(255,140,60,0.55); background: rgba(255,122,0,0.07); }
.neo-row.warn svg, .neo-row.danger svg { color: #FFB86B; flex-shrink: 0; }
.neo-row.info svg { color: #7DF9FF; flex-shrink: 0; }
.neo-tile .hs-grow { display: flex; flex-direction: column; color: var(--n-sub); font-size: 14px; }
.neo-tile strong { color: var(--n-text); font-size: 16px; }
.neo-tile.lit { border-color: #FFD27A; box-shadow: 0 0 14px rgba(255,210,122,0.25); }
.neo-tile.danger { border-color: #FF5A6E; }
.neo-tile button { min-height: 48px; padding: 0 16px; border-radius: 14px; border: 1px solid #FFD27A; background: transparent; color: #FFE3A8; font-weight: 700; }
.neo-energy { width: 100%; }
.neo-energy svg { color: #D9FF6B; flex-shrink: 0; }
.neo-energy strong { color: #FFFFFF; }
@keyframes neoScroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }
.app.narrow .hs-neon { overflow: visible; }
.app.narrow .neo-grid { grid-template-columns: minmax(0, 1fr); padding: 12px 16px; gap: 16px; }
.app.narrow .neo-clock { font-size: 72px; }
.app.narrow .neo-tubes { min-height: 0; }
.app.narrow .neo-tube-col { flex-basis: 60px; }
.app.narrow .neo-tube { width: 50px; height: 240px; flex: none; }
.app.narrow .neo-right { overflow: visible; }
.app.narrow .neo-scenes { grid-template-columns: minmax(0, 1fr); }
`;
