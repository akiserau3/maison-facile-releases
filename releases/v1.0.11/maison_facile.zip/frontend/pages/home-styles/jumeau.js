// Style d'accueil « Jumeau 3D » (design-mockups/styles-v2/G-Jumeau-tel.dc.html), adapted:
// the house seen from above in relief, drawn with CSS 3D only (perspective + transforms,
// no WebGL): one block per room, its floor glows in the room color when a light is on,
// tap = on / off. Room labels always face the viewer. Right column: lights, inside
// temperature, alerts, climate gauges, « Périmètre » (mode + live camera).
import { html, icon, temp, roomClimate, lightText, lightsSummary, roomAria, modeButtons, modeSub, quickButtons, heatingAction, tileRows, energyLine, clockText, weatherText, dateLong, greetingHtml, noRooms, cameraImg } from "./common.js";

const GLOWS = ["#FFB547", "#4DFFC3", "#B48CFF", "#5CE1FF", "#FF7AD9", "#9DFF6B", "#FFD27A", "#7FA8FF"];

function gauge(name, t) {
  // 10° .. 30° on a 270° arc.
  const deg = Math.max(8, Math.min(270, ((t - 10) / 20) * 270));
  return html`<div class="jm-gauge" role="listitem"><span class="jm-ring" style="--deg:${deg.toFixed(0)}deg;--c2:${t >= 19 ? "#FFB547" : "#4DFFC3"}" aria-hidden="true"><span>${temp(t)}</span></span><span class="jm-gname">${name}<span class="sr-only"> : ${temp(t)}</span></span></div>`;
}

export function renderJumeau(m, page) {
  const n = m.rooms.length;
  const cols = n <= 1 ? 1 : n <= 4 ? 2 : 3;
  const blocks = m.rooms.map((r, i) => {
    const c = GLOWS[i % GLOWS.length];
    return html`<button type="button" class="jm-room ${r.on ? "lit" : ""}" data-key="jm-${r.area_id}" style="--g:${c}" data-action="${r.hasLight ? "room-light" : "go-room"}" data-area="${r.area_id}"
        ${r.hasLight ? html`aria-pressed="${r.on ? "true" : "false"}"` : ""} aria-label="${roomAria(r)}">
      <span class="jm-floor" aria-hidden="true"></span>
      <span class="jm-wall n" aria-hidden="true"></span><span class="jm-wall w" aria-hidden="true"></span>
      <span class="jm-tag" aria-hidden="true"><i></i>${r.name}${r.temp !== null ? html`<b>${temp(r.temp)}</b>` : ""}</span>
    </button>`;
  });
  const gauges = m.rooms.filter((r) => r.temp !== null).slice(0, 3).map((r) => gauge(r.name, r.temp));
  if (m.weather?.temp !== null && m.weather?.temp !== undefined && gauges.length < 4) gauges.push(gauge("Dehors", m.weather.temp));
  const serious = m.alerts.filter((a) => a.severity !== "info").length;
  return html`<section class="hs hs-jumeau" data-key="hs-jumeau" aria-label="Accueil, style Jumeau 3D">
    <div class="jm-left">
      <header class="jm-head">
        <div class="hs-grow">
          <p class="jm-live"><i aria-hidden="true"></i>JUMEAU NUMÉRIQUE · EN DIRECT</p>
          <div class="jm-clockline"><span class="jm-clock">${clockText(m)}</span><span class="jm-date">${dateLong(m.now)}</span></div>
          <h1 class="jm-hello">${greetingHtml(m.greeting)}</h1>
        </div>
        ${m.weather ? html`<span class="jm-weather">${icon(m.weather.icon, 22)}<span>${weatherText(m)}</span></span>` : ""}
      </header>
      <div class="jm-stage" role="group" aria-label="Plan de la maison : touchez une pièce pour allumer ou éteindre">
        <span class="jm-corner tl" aria-hidden="true"></span><span class="jm-corner tr" aria-hidden="true"></span><span class="jm-corner bl" aria-hidden="true"></span><span class="jm-corner br" aria-hidden="true"></span>
        ${n
          ? html`<div class="jm-plane" style="--cols:${cols}">${blocks}</div>`
          : html`<div class="jm-empty">${noRooms("jm-card")}</div>`}
        <span class="jm-scan" aria-hidden="true"></span>
      </div>
      <p class="jm-wink"><i aria-hidden="true"></i>${m.wink}</p>
      <div class="jm-quick">${quickButtons(page, "jm-q", { size: 22 })}</div>
    </div>
    <div class="jm-right">
      <div class="jm-kpis">
        <div class="jm-kpi"><span>LUMIÈRES</span><strong class="amber">${m.lightsOn}</strong></div>
        <div class="jm-kpi"><span>INTÉRIEUR</span><strong class="cyan">${m.indoorTemp !== null ? temp(m.indoorTemp) : "–"}</strong></div>
        <div class="jm-kpi ${serious ? "alert" : ""}"><span>ALERTES</span><strong class="${serious ? "coral" : "mint"}">${serious}</strong></div>
      </div>
      ${heatingAction(m, page, "jm-card jm-heat")}
      ${m.alerts.filter((a) => a.kind !== "heating").slice(0, 3).map((a) => html`<div class="jm-row ${a.severity}" role="status" data-key="al-${a.key}">${icon(a.severity === "info" ? "door" : "warn", 20)}<span class="hs-grow">${a.text}</span></div>`)}
      ${gauges.length ? html`<section class="jm-card"><h2>Climat</h2><div class="jm-gauges" role="list">${gauges}</div></section>` : ""}
      <section class="jm-card">
        <div class="jm-card-head"><h2>Périmètre</h2><span>${modeSub(m)}</span></div>
        <div class="jm-modes" role="group" aria-label="Mode de la maison">${modeButtons(m, page, "jm-mode")}</div>
        ${m.camera ? html`<div class="jm-cam"><span class="jm-live-dot" aria-hidden="true"><i></i>EN DIRECT</span>${cameraImg(m, page)}<span class="jm-cam-name">${m.camera.name}</span></div>` : ""}
      </section>
      ${tileRows(m, "jm-row jm-tile")}
      <button type="button" class="jm-row jm-energy" data-action="go-energy">${icon("bolt", 20)}<span class="hs-grow">${energyLine(m)}</span></button>
    </div>
  </section>`;
}

export const JUMEAU_CSS = `
.app[data-page="home"][data-home-style="jumeau"] { background: #030A14; }
.hs-jumeau {
  --j-text: #E6FBFF; --j-sub: #A5C9D6; --j-line: rgba(92,225,255,0.22); --j-card: rgba(8,28,40,0.72); --j-acc: #5CE1FF; --j-acc-text: #03141C;
  position: relative; flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(0, 1fr) 430px; gap: 22px; padding: 18px 32px 12px; overflow: hidden;
  color: var(--j-text); font-family: 'Segoe UI', 'Noto Sans', system-ui, sans-serif;
  background: radial-gradient(55% 45% at 35% 45%, rgba(92,225,255,0.16), transparent 70%), radial-gradient(40% 40% at 0% 90%, rgba(180,140,255,0.10), transparent 70%), radial-gradient(40% 40% at 100% 100%, rgba(77,255,195,0.08), transparent 70%), #030A14;
}
.hs-jumeau[data-tint] { --j-acc: var(--accent); --j-acc-text: var(--accent-text); }
.hs-jumeau .hs-grow { flex: 1; min-width: 0; }
.jm-left { min-width: 0; min-height: 0; display: flex; flex-direction: column; gap: 8px; }
.jm-head { display: flex; align-items: flex-start; gap: 16px; }
.jm-live { font-size: 13px; letter-spacing: 2px; color: var(--j-acc); font-weight: 700; display: flex; align-items: center; gap: 8px; }
.jm-live i { width: 8px; height: 8px; border-radius: 50%; background: #4DFFC3; box-shadow: 0 0 8px #4DFFC3; animation: jmBlink 2.4s ease-in-out infinite; }
.jm-clockline { display: flex; align-items: baseline; gap: 16px; flex-wrap: wrap; }
.jm-clock { font-size: 54px; font-weight: 800; letter-spacing: -2px; line-height: 1; }
.jm-date { font-size: 16px; color: var(--j-sub); }
.jm-hello { font-size: 22px; font-weight: 700; margin-top: 2px; }
.jm-weather { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-radius: 16px; border: 1px solid var(--j-line); background: var(--j-card); font-size: 15px; font-weight: 600; white-space: nowrap; }
.jm-weather svg { color: #FFB547; }
.jm-stage { position: relative; flex: 1; min-height: 260px; display: flex; align-items: center; justify-content: center; perspective: 1600px; overflow: hidden; border-radius: 24px; }
.jm-corner { position: absolute; width: 24px; height: 24px; border: 0 solid var(--j-acc); opacity: 0.7; }
.jm-corner.tl { left: 10px; top: 10px; border-left-width: 2px; border-top-width: 2px; }
.jm-corner.tr { right: 10px; top: 10px; border-right-width: 2px; border-top-width: 2px; }
.jm-corner.bl { left: 10px; bottom: 10px; border-left-width: 2px; border-bottom-width: 2px; }
.jm-corner.br { right: 10px; bottom: 10px; border-right-width: 2px; border-bottom-width: 2px; }
.jm-plane { --cell: 185px; display: grid; grid-template-columns: repeat(var(--cols), var(--cell)); grid-auto-rows: var(--cell); gap: 14px; padding: 18px; transform-style: preserve-3d;
  transform: rotateX(56deg) rotateZ(-38deg); border-radius: 12px;
  background-color: rgba(92,225,255,0.03); background-image: linear-gradient(rgba(92,225,255,0.13) 1px, transparent 1px), linear-gradient(90deg, rgba(92,225,255,0.13) 1px, transparent 1px); background-size: 30px 30px; }
.jm-room { position: relative; padding: 0; border: 0; background: transparent; transform-style: preserve-3d; color: var(--j-text); }
.jm-floor { position: absolute; inset: 0; border-radius: 6px; background: #0E2F42; border: 1.5px solid rgba(92,225,255,0.45); transition: background 0.4s ease, box-shadow 0.4s ease; }
.jm-room.lit .jm-floor { background: var(--g); border-color: var(--g); box-shadow: 0 0 34px var(--g); }
.jm-wall { position: absolute; background: rgba(92,225,255,0.07); border: 1px solid rgba(92,225,255,0.45); }
.jm-wall.n { left: 0; right: 0; top: 0; height: 34px; transform-origin: top; transform: rotateX(90deg); }
.jm-wall.w { top: 0; bottom: 0; left: 0; width: 34px; transform-origin: left; transform: rotateY(-90deg); }
.jm-room.lit .jm-wall { background: rgba(255,255,255,0.10); border-color: var(--g); }
.jm-tag { position: absolute; left: 50%; top: 50%; display: flex; align-items: center; gap: 7px; min-height: 40px; padding: 0 14px 0 11px; border-radius: 20px; white-space: nowrap; font-size: 15px; font-weight: 700;
  background: rgba(6,24,34,0.9); border: 1px solid rgba(92,225,255,0.45); color: var(--j-text);
  transform: translate(-50%, -50%) translateZ(46px) rotateZ(38deg) rotateX(-56deg); }
.jm-tag i { width: 9px; height: 9px; border-radius: 50%; background: #3D6577; }
.jm-tag b { font-weight: 600; color: var(--j-sub); }
.jm-room.lit .jm-tag { border-color: var(--g); box-shadow: 0 0 14px var(--g); }
.jm-room.lit .jm-tag i { background: var(--g); box-shadow: 0 0 8px var(--g); }
.jm-room.lit .jm-tag b { color: #FFFFFF; }
.jm-room:focus-visible { outline: none; }
.jm-room:focus-visible .jm-tag { outline: 3px solid #FFFFFF; outline-offset: 2px; }
.jm-scan { position: absolute; left: 0; right: 0; top: 0; height: 46px; pointer-events: none; background: linear-gradient(to bottom, transparent, rgba(92,225,255,0.04), transparent); border-bottom: 1px solid rgba(92,225,255,0.12); animation: jmScan 9s linear infinite; }
.jm-empty { position: relative; z-index: 1; }
.jm-wink { display: flex; align-items: center; gap: 10px; font-size: 16px; }
.jm-wink i { width: 9px; height: 9px; border-radius: 50%; background: var(--j-acc); box-shadow: 0 0 8px var(--j-acc); flex-shrink: 0; }
.jm-right { min-height: 0; overflow: auto; display: flex; flex-direction: column; gap: 10px; padding: 2px; }
.jm-kpis { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.jm-kpi { padding: 12px; border-radius: 16px; background: rgba(92,225,255,0.06); border: 1px solid var(--j-line); display: flex; flex-direction: column; gap: 4px; }
.jm-kpi span { font-size: 12px; letter-spacing: 1.5px; color: var(--j-sub); font-weight: 700; }
.jm-kpi strong { font-size: 28px; font-weight: 800; }
.jm-kpi.alert { background: rgba(255,120,90,0.08); border-color: rgba(255,140,100,0.45); }
.jm-kpi .amber { color: #FFB547; } .jm-kpi .cyan { color: #5CE1FF; } .jm-kpi .coral { color: #FF9A80; } .jm-kpi .mint { color: #4DFFC3; }
.jm-card { padding: 14px 16px; border-radius: 22px; background: var(--j-card); border: 1px solid var(--j-line); display: flex; flex-direction: column; gap: 10px; }
.jm-card h2 { font-size: 18px; font-weight: 800; }
.jm-card-head { display: flex; justify-content: space-between; align-items: baseline; gap: 10px; }
.jm-card-head span { font-size: 13px; color: var(--j-sub); text-align: right; }
.jm-card button { min-height: 48px; padding: 0 16px; border-radius: 14px; border: 1px solid var(--j-acc); background: rgba(92,225,255,0.10); color: var(--j-text); font-weight: 700; font-size: 15px; }
.jm-heat { border-color: rgba(255,140,100,0.55); background: rgba(255,120,90,0.10); }
.jm-heat.ok { border-color: rgba(77,255,195,0.5); background: rgba(77,255,195,0.06); }
.jm-gauges { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 6px; }
.jm-gauge { display: flex; flex-direction: column; align-items: center; gap: 6px; }
.jm-ring { width: 80px; height: 80px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: conic-gradient(from 225deg, #5CE1FF 0deg, var(--c2) var(--deg), rgba(255,255,255,0.10) var(--deg) 270deg, transparent 270deg); }
.jm-ring span { width: 66px; height: 66px; border-radius: 50%; background: #071822; display: flex; align-items: center; justify-content: center; font-size: 17px; font-weight: 800; }
.jm-gname { font-size: 13px; color: var(--j-sub); max-width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.jm-modes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; }
.jm-card .jm-mode { min-height: 56px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; padding: 4px; border-radius: 14px; border: 1px solid rgba(92,225,255,0.20); background: transparent; color: var(--j-sub); font-size: 14px; font-weight: 700; }
.jm-card .jm-mode[aria-pressed="true"] { background: var(--j-acc); border-color: var(--j-acc); color: var(--j-acc-text); box-shadow: 0 0 14px rgba(92,225,255,0.35); }
.jm-cam { position: relative; height: 120px; border-radius: 14px; overflow: hidden; border: 1px solid var(--j-line); background: repeating-linear-gradient(0deg, rgba(92,225,255,0.05) 0 1px, transparent 1px 4px), #061520; display: flex; align-items: center; justify-content: center; color: var(--j-sub); font-size: 14px; }
.jm-cam img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.jm-live-dot { position: absolute; z-index: 1; top: 8px; left: 8px; display: flex; align-items: center; gap: 6px; padding: 3px 9px; border-radius: 999px; background: rgba(0,0,0,0.65); color: #FFFFFF; font-size: 12px; font-weight: 700; }
.jm-live-dot i { width: 7px; height: 7px; border-radius: 50%; background: #FF5A4A; }
.jm-cam-name { position: absolute; z-index: 1; left: 8px; bottom: 8px; padding: 3px 10px; border-radius: 999px; background: rgba(0,0,0,0.65); color: #FFFFFF; font-size: 13px; font-weight: 600; }
.jm-row { display: flex; align-items: center; gap: 12px; min-height: 54px; padding: 8px 14px; border-radius: 16px; background: var(--j-card); border: 1px solid var(--j-line); color: var(--j-text); font-size: 15px; text-align: left; }
.jm-row.warn, .jm-row.danger { border-color: rgba(255,140,100,0.55); }
.jm-row.warn svg, .jm-row.danger svg { color: #FF9A80; flex-shrink: 0; }
.jm-row.info svg { color: #5CE1FF; flex-shrink: 0; }
.jm-tile .hs-grow { display: flex; flex-direction: column; color: var(--j-sub); font-size: 14px; }
.jm-tile strong { color: var(--j-text); font-size: 16px; }
.jm-tile.lit { border-color: #FFB547; }
.jm-tile.danger { border-color: #FF5A6E; }
.jm-tile button { min-height: 48px; padding: 0 14px; border-radius: 12px; border: 1px solid #4DFFC3; background: rgba(77,255,195,0.10); color: #C9FFEC; font-weight: 700; }
.jm-quick { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.jm-q { min-height: 56px; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 0 8px; border-radius: 16px; border: 1px solid var(--j-line); background: rgba(92,225,255,0.06); color: var(--j-text); font-size: 15px; font-weight: 700; }
.jm-q svg { color: var(--j-acc); }
.jm-energy { width: 100%; }
.jm-energy svg { color: #FFB547; flex-shrink: 0; }
.jm-energy strong { color: #FFFFFF; }
@keyframes jmScan { 0% { transform: translateY(-50px); opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { transform: translateY(520px); opacity: 0; } }
@keyframes jmBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
.app.narrow .hs-jumeau { grid-template-columns: minmax(0, 1fr); align-content: start; padding: 14px 16px; overflow: visible; }
.app.narrow .jm-stage { min-height: 330px; }
.app.narrow .jm-plane { --cell: 100px; gap: 10px; padding: 12px; }
.app.narrow .jm-tag { font-size: 13px; min-height: 34px; padding: 0 10px 0 8px; }
.app.narrow .jm-clock { font-size: 44px; }
.app.narrow .jm-right { overflow: visible; }
.app.narrow .jm-gauges { grid-template-columns: repeat(2, minmax(0, 1fr)); }
`;
