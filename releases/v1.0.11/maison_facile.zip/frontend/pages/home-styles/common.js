// Pieces shared by the home styles (Orbite, Néon, Jumeau 3D, Holo).
// Every style receives the same home model (components/model.js buildHomeModel) and the
// home page (actions, cameras, busy flags). All names coming from Home Assistant go
// through html`` (escaped).
import { html, fmtNum, fmtEur, timeHM, dateLong } from "../../lib.js";
import { icon } from "../../icons.js";
import { MODES } from "../../components/model.js";
import { greetingHtml } from "../../components/appearance.js";

export { html, icon, fmtNum, fmtEur, timeHM, dateLong, greetingHtml };

export const MODE_IDS = ["maison", "absent", "nuit"];
export const MODE_ICON = { maison: "home", absent: "leave", nuit: "moon" };
export const MODE_SHORT = { maison: "À la maison", absent: "Absent", nuit: "Nuit" };

export function temp(t, digits = 1) {
  return t === null || t === undefined ? "–" : `${fmtNum(t, digits)}°`;
}

/** "21,5° · 48 %" or "pas de capteur". */
export function roomClimate(r) {
  if (r.temp !== null) return `${temp(r.temp)}${r.hum !== null ? ` · ${fmtNum(r.hum, 0)} %` : ""}`;
  if (r.hum !== null) return `${fmtNum(r.hum, 0)} % d'humidité`;
  return "pas de thermomètre";
}

export function lightText(r) {
  if (!r.hasLight) return "pas de lumière";
  if (!r.on) return "éteinte";
  return r.level !== null && r.level < 100 ? `allumée · ${r.level} %` : r.lightsOn > 1 ? `${r.lightsOn} allumées` : "allumée";
}

export function lightsSummary(m) {
  return m.lightsOn === 0 ? "tout est éteint" : m.lightsOn === 1 ? "1 lumière allumée" : `${m.lightsOn} lumières allumées`;
}

/** aria-label of a room button. */
export function roomAria(r) {
  if (!r.hasLight) return `${r.name} : ${roomClimate(r)}, pas de lumière à allumer`;
  return `${r.on ? "Éteindre" : "Allumer"} la lumière : ${r.name} (${lightText(r)}${r.temp !== null ? `, ${temp(r.temp)}` : ""})`;
}

/** Mode buttons (real select.maison_facile_mode). `cls` = class of each button. */
export function modeButtons(m, page, cls) {
  return MODE_IDS.map((id) => {
    const on = m.mode.id === id;
    return html`<button type="button" class="${cls}" data-action="set-mode" data-mode="${id}" aria-pressed="${on ? "true" : "false"}" ${page.isBusy("mode") ? "disabled" : ""}>${icon(MODE_ICON[id], 22)}<span>${MODE_SHORT[id]}</span></button>`;
  });
}

export function modeSub(m) {
  return MODES[m.mode.id]?.sub || "";
}

/** The three actions of « En un clic » (same actions as Maison Facile). */
export const QUICK = [
  { action: "all-off", icon: "power", title: "Tout éteindre", sub: "Toutes les lumières" },
  { action: "leave", icon: "leave", title: "Je pars", sub: "Éteint et surveille" },
  { action: "night", icon: "moon", title: "Bonne nuit", sub: "Tout s'éteint, mode nuit" },
];

export function quickButtons(page, cls, { sub = false, size = 24 } = {}) {
  return QUICK.map(
    (q) => html`<button type="button" class="${cls}" data-action="${q.action}" ${page.isBusy(q.action) ? "disabled" : ""}>${icon(q.icon, size)}<span class="q-t">${q.title}</span>${sub ? html`<span class="q-s">${q.sub}</span>` : ""}</button>`
  );
}

/** Heating + open window: the same « Mettre le chauffage en pause » as Maison Facile. */
export function heatingAction(m, page, cls) {
  if (m.heatingAlert) {
    return html`<div class="${cls}" role="alert" data-key="heat-alert"><span class="hs-alert-text">${icon("warn", 22)}${m.heatingAlert.text}</span>
      <button type="button" data-action="pause-heating" ${page.isBusy("pause") ? "disabled" : ""}>${page.isBusy("pause") ? "Un instant…" : "Mettre le chauffage en pause"}</button></div>`;
  }
  if (m.paused) {
    return html`<div class="${cls} ok" role="status" data-key="heat-ok"><span class="hs-alert-text">${icon("check", 22)}C'est fait : chauffage en pause, il se rallumera quand la fenêtre sera fermée.</span></div>`;
  }
  return "";
}

/** Idea tiles in the style's look: [{tile, view}] -> rows with the action button. */
export function tileRows(m, cls) {
  return m.tiles.map(({ tile, view }) => html`<div class="${cls} ${view.tone || ""}" data-key="tile-${tile.key || tile.idea_id}" role="status">
    <span class="hs-tile-icon" style="--c:${tile.kind === "flag" ? "#E0A100" : tile.color || "#0067C0"}">${icon(tile.icon || (tile.kind === "birthday" ? "cake" : "room"), 22)}</span>
    <span class="hs-grow"><strong>${tile.title}</strong><span>${view.text}</span></span>
    ${view.action ? html`<button type="button" data-action="tile-action" data-idea="${tile.idea_id}">${view.action.label}</button>` : ""}
    ${tile.page ? html`<button type="button" data-action="tile-action" data-idea="${tile.idea_id}" data-tile-key="${tile.key || ""}">Voir</button>` : ""}
  </div>`);
}

export function energyLine(m) {
  const e = m.energy;
  if (e.state === "ok") return html`<strong>${fmtNum(e.total_kwh, 1)} kWh</strong> aujourd'hui · ≈ ${fmtEur(e.cost_eur)}`;
  if (e.state === "none") return "Pas encore de mesure d'électricité";
  if (e.state === "error") return "Consommation indisponible";
  return "Chargement…";
}

/** Live camera picture (refreshed in place by the home page every 2 s). */
export function cameraImg(m, page) {
  if (!m.camera) return "";
  const url = page.cameraSrc(m.camera.entity_id, page.cameraToUrl);
  return url
    ? html`<img data-cam="${m.camera.entity_id}" alt="Image en direct : ${m.camera.name}" src="${url}">`
    : html`<span data-cam-off="${m.camera.entity_id}">Image indisponible pour le moment</span>`;
}

/** Header pieces. */
export function clockText(m) {
  return timeHM(m.now);
}

export function weatherText(m) {
  const w = m.weather;
  if (!w) return "";
  return `${w.temp !== null ? `${fmtNum(w.temp, 0)}° dehors` : "Dehors"}${w.label ? ` · ${w.label}` : ""}`;
}

/** Stable pseudo-random 0..1 from a string (positions that do not jump between renders). */
export function hash01(s) {
  let h = 2166136261;
  for (const c of String(s)) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return ((h >>> 0) % 1000) / 1000;
}

/** "Vous n'avez pas encore de pièce" in the style. */
export function noRooms(cls) {
  return html`<div class="${cls}"><p>Aucune pièce pour l'instant.</p><button type="button" data-action="go-rooms-settings">Ajouter mes pièces</button></div>`;
}
