// Style d'accueil « Orbite » (design-mockups/styles-v2/E-Orbite-tel.dc.html), adapted:
// rooms = planets around the clock (lit planet = light on, tap = on/off), mode = « Bouclier »,
// temperature bubbles, alerts as glowing chips. Real data only; animations are slow and
// cheap (transform / opacity), all stopped by "animations: off", reduced motion or a hidden tab.
import { html, icon, temp, roomClimate, lightText, lightsSummary, roomAria, modeButtons, modeSub, quickButtons, heatingAction, tileRows, energyLine, clockText, weatherText, dateLong, greetingHtml, noRooms } from "./common.js";

/** Planet position on one or two rings around the sun (percent of the system box). */
function planetPos(i, n) {
  const outer = Math.min(n, 8);
  const ring = i < outer ? 0 : 1;
  const count = ring === 0 ? outer : n - outer;
  const k = ring === 0 ? i : i - outer;
  const a = -Math.PI / 2 + (k / count) * Math.PI * 2 + (ring ? Math.PI / count : 0);
  const r = ring === 0 ? 39 : 25;
  return { x: 50 + Math.cos(a) * r, y: 50 + Math.sin(a) * r };
}

// Lit planet colors (light, mid, deep) by room index.
const SPHERES = [
  ["#FF8A5B", "#FF3D7F", "#8A1452"],
  ["#C6FF6B", "#2EE6A8", "#0B6B5A"],
  ["#B79CFF", "#7B5CFF", "#2E1A8A"],
  ["#7DF0FF", "#3B9BFF", "#143A8A"],
  ["#FFB3D9", "#FF6FB5", "#8A1F5C"],
  ["#9BFFB8", "#22C27A", "#0A5A3A"],
  ["#FFD27A", "#FF9A3C", "#8A4A10"],
  ["#A5C8FF", "#5B7BFF", "#1E2A8A"],
];

function bubble(label, t, i) {
  const warm = t >= 19;
  return html`<span class="orb-bubble ${warm ? "warm" : "cool"}" style="--i:${i}"><strong>${temp(t)}</strong><span>${label}</span></span>`;
}

export function renderOrbite(m, page) {
  const planets = m.rooms.map((r, i) => {
    const p = planetPos(i, m.rooms.length);
    const c = SPHERES[i % SPHERES.length];
    return html`<button type="button" class="orb-planet ${r.on ? "lit" : ""}" data-key="pl-${r.area_id}" style="--x:${p.x.toFixed(2)}%;--y:${p.y.toFixed(2)}%;--c1:${c[0]};--c2:${c[1]};--c3:${c[2]};--d:${(6 + (i % 4) * 0.8).toFixed(1)}s"
        data-action="${r.hasLight ? "room-light" : "go-room"}" data-area="${r.area_id}" ${r.hasLight ? html`aria-pressed="${r.on ? "true" : "false"}"` : ""} aria-label="${roomAria(r)}">
      <span class="orb-sphere" aria-hidden="true"></span>
      <span class="orb-label"><span class="orb-name">${r.name}</span><span class="orb-sub">${r.temp !== null ? temp(r.temp) : lightText(r)}</span></span>
    </button>`;
  });
  const bubbles = m.rooms.filter((r) => r.temp !== null).slice(0, 3).map((r, i) => bubble(r.name, r.temp, i));
  if (m.weather?.temp !== null && m.weather?.temp !== undefined) bubbles.push(bubble("Dehors", m.weather.temp, bubbles.length));
  const alerts = m.alerts.filter((a) => a.kind !== "heating").slice(0, 4);
  return html`<section class="hs hs-orbite" data-key="hs-orbite" aria-label="Accueil, style Orbite">
    <div class="orb-stars" aria-hidden="true"></div>
    <div class="orb-main">
      <div class="orb-system" role="group" aria-label="Mes pièces : touchez une planète pour allumer ou éteindre">
        <span class="orb-ring outer" aria-hidden="true"></span>
        <span class="orb-ring inner" aria-hidden="true"><i></i></span>
        <span class="orb-halo" aria-hidden="true"></span>
        <div class="orb-sun"><span class="orb-clock">${clockText(m)}</span><span class="orb-sun-sub">${lightsSummary(m)}</span></div>
        ${m.rooms.length ? planets : html`<div class="orb-empty">${noRooms("orb-panel")}</div>`}
      </div>
      <div class="orb-quick">${quickButtons(page, "orb-q")}</div>
    </div>
    <div class="orb-side">
      <header class="orb-head">
        <div class="hs-grow"><p class="orb-date">${dateLong(m.now)}</p><h1 class="orb-hello">${greetingHtml(m.greeting)}</h1></div>
        ${m.weather ? html`<span class="orb-pill">${icon(m.weather.icon, 20)}<span>${weatherText(m)}</span></span>` : ""}
      </header>
      <p class="orb-wink"><span class="orb-dot" aria-hidden="true"></span>${m.wink}</p>
      ${alerts.length ? html`<div class="orb-chips" role="list" aria-label="À regarder">${alerts.map((a) => html`<span class="orb-chip ${a.severity}" role="listitem"><i aria-hidden="true"></i>${a.text}</span>`)}</div>` : ""}
      ${heatingAction(m, page, "orb-panel orb-heat")}
      <section class="orb-panel">
        <div class="orb-panel-head"><h2>Bouclier</h2><span>${modeSub(m)}</span></div>
        <div class="orb-modes" role="group" aria-label="Mode de la maison">${modeButtons(m, page, "orb-mode")}</div>
      </section>
      ${bubbles.length ? html`<section class="orb-panel orb-temps"><h2>Températures</h2><div class="orb-bubbles">${bubbles}</div></section>` : ""}
      ${tileRows(m, "orb-tile")}
      <button type="button" class="orb-energy" data-action="go-energy">${icon("bolt", 20)}<span>${energyLine(m)}</span></button>
    </div>
  </section>`;
}

export const ORBITE_CSS = `
.app[data-page="home"][data-home-style="orbite"] { background: #07051A; }
.hs-orbite {
  --o-text: #F4F1FF; --o-sub: #C9C3E8; --o-line: rgba(255,255,255,0.14); --o-panel: rgba(255,255,255,0.06);
  --o-acc: #A6FF3B; --o-acc-2: #3BA81E; --o-acc-text: #0A1A05; --o-acc-soft: #C8FF7A;
  position: relative; flex: 1; min-height: 0; display: grid; grid-template-columns: minmax(0, 1fr) 460px; gap: 20px; padding: 18px 32px 12px;
  color: var(--o-text); font-family: 'Segoe UI', 'Noto Sans', system-ui, sans-serif; overflow: hidden;
  background: radial-gradient(60% 70% at 25% 40%, rgba(124,58,237,0.30), transparent 65%), radial-gradient(50% 60% at 100% 10%, rgba(14,165,233,0.16), transparent 62%), radial-gradient(50% 50% at 0% 100%, rgba(236,72,153,0.14), transparent 60%), #07051A;
}
.hs-orbite[data-tint] { --o-acc: var(--accent); --o-acc-2: var(--accent); --o-acc-text: var(--accent-text); --o-acc-soft: var(--accent); }
.hs-orbite .hs-grow { flex: 1; min-width: 0; }
.orb-stars, .orb-stars::after { position: absolute; left: 0; top: 0; width: 2px; height: 2px; border-radius: 1px; pointer-events: none;
  box-shadow: 40px 60px #FFF, 140px 180px #C9BFFF, 260px 40px #FFF, 380px 120px #9DE6FF, 520px 70px #FFF, 640px 200px #FFD9F0, 760px 30px #FFF, 880px 150px #FFF, 1000px 90px #C9BFFF, 1180px 40px #FFF, 90px 420px #FFF, 330px 560px #9DE6FF, 600px 640px #FFF, 820px 520px #FFF, 1100px 600px #FFD9F0, 1220px 380px #FFF, 200px 700px #FFF, 980px 700px #C9BFFF;
  animation: orbTwinkle 6s ease-in-out infinite; }
.orb-stars::after { content: ""; left: 37px; top: 23px; width: 1px; height: 1px; animation-delay: 2s; }
.orb-main { position: relative; min-height: 0; min-width: 0; display: flex; flex-direction: column; align-items: center; gap: 18px; }
.orb-system { position: relative; flex: 1; min-height: 0; aspect-ratio: 1 / 1; max-width: 100%; max-height: 620px; }
.orb-main .orb-quick { width: min(100%, 640px); flex-shrink: 0; }
.orb-ring { position: absolute; border-radius: 50%; pointer-events: none; }
.orb-ring.outer { inset: 4%; border: 1px dashed rgba(183,156,255,0.38); animation: orbSpin 120s linear infinite; }
.orb-ring.inner { inset: 22%; border: 1px solid rgba(255,255,255,0.10); animation: orbSpin 40s linear infinite; }
.orb-ring.inner i { position: absolute; left: 50%; top: -5px; width: 10px; height: 10px; margin-left: -5px; border-radius: 50%; background: #FFF; box-shadow: 0 0 10px #B79CFF, 0 0 22px #7B5CFF; }
.orb-halo { position: absolute; inset: 30%; border-radius: 50%; background: radial-gradient(circle, rgba(255,150,80,0.30) 0%, rgba(255,80,140,0.10) 45%, transparent 70%); animation: orbPulse 6s ease-in-out infinite; pointer-events: none; }
.orb-sun { position: absolute; left: 50%; top: 50%; width: 30%; aspect-ratio: 1 / 1; transform: translate(-50%, -50%); border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; text-align: center; color: #2A0A12;
  background: radial-gradient(circle at 38% 32%, #FFF6DD 0%, #FFD27A 30%, #FF9A5C 66%, #E86A8A 96%); box-shadow: 0 0 50px rgba(255,140,70,0.45), 0 0 110px rgba(255,80,140,0.25); }
.orb-clock { font-size: clamp(30px, 4.6vw, 60px); font-weight: 800; letter-spacing: -1.5px; line-height: 1; }
.orb-sun-sub { font-size: 15px; font-weight: 700; max-width: 80%; }
.orb-planet { position: absolute; left: var(--x); top: var(--y); transform: translate(-50%, -50%); display: flex; align-items: center; justify-content: center; width: 80px; height: 80px; padding: 0; border: 0; background: transparent; color: var(--o-text); border-radius: 50%; animation: orbFloat var(--d) ease-in-out infinite; z-index: 1; }
.orb-sphere { width: 58px; height: 58px; border-radius: 50%; background: radial-gradient(circle at 32% 28%, #3A3560 0%, #1A1734 55%, #0D0B20 100%); box-shadow: inset -4px -6px 10px rgba(0,0,0,0.5), 0 0 0 2px var(--c3); transition: width 0.4s ease, height 0.4s ease, box-shadow 0.4s ease; }
.orb-planet.lit .orb-sphere { width: 76px; height: 76px; background: radial-gradient(circle at 32% 28%, #FFFFFF 0%, var(--c1) 24%, var(--c2) 68%, var(--c3) 100%); box-shadow: 0 0 18px var(--c1), 0 0 40px var(--c3); }
.orb-label { position: absolute; top: calc(100% - 2px); left: 50%; transform: translateX(-50%); display: flex; flex-direction: column; align-items: center; padding: 4px 12px; border-radius: 14px; background: rgba(7,5,26,0.86); border: 1px solid var(--o-line); max-width: 150px; }
.orb-name { font-size: 15px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 126px; }
.orb-sub { font-size: 13px; color: var(--o-sub); white-space: nowrap; }
.orb-planet.lit .orb-sub { color: #FFFFFF; }
.orb-planet:focus-visible { outline: 3px solid var(--o-acc-soft); outline-offset: 2px; }
.orb-empty { position: absolute; left: 50%; bottom: 4%; transform: translateX(-50%); }
.orb-side { position: relative; min-height: 0; overflow: auto; display: flex; flex-direction: column; gap: 12px; padding: 4px 4px 8px; }
.orb-head { display: flex; align-items: flex-start; gap: 12px; }
.orb-date { font-size: 15px; color: var(--o-sub); }
.orb-hello { font-size: 26px; font-weight: 800; line-height: 1.15; }
.orb-pill { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-radius: 22px; background: rgba(255,255,255,0.08); border: 1px solid var(--o-line); font-size: 15px; font-weight: 600; white-space: nowrap; color: var(--o-text); }
.orb-pill svg { color: #9DE6FF; }
.orb-wink { display: flex; align-items: center; gap: 10px; font-size: 16px; line-height: 1.35; color: var(--o-text); }
.orb-dot { width: 10px; height: 10px; flex-shrink: 0; border-radius: 50%; background: var(--o-acc); box-shadow: 0 0 10px var(--o-acc); }
.orb-chips { display: flex; flex-wrap: wrap; gap: 8px; }
.orb-chip { display: flex; align-items: center; gap: 8px; padding: 8px 14px; border-radius: 16px; font-size: 14px; font-weight: 600; color: #FFE0CC; background: rgba(255,120,60,0.14); border: 1px solid rgba(255,140,80,0.5); }
.orb-chip i { width: 8px; height: 8px; border-radius: 50%; background: #FF8A4C; box-shadow: 0 0 8px #FF8A4C; }
.orb-chip.danger { color: #FFE1E5; background: rgba(255,60,90,0.20); border-color: #FF5A6E; }
.orb-chip.info { color: #D8EEFF; background: rgba(90,170,255,0.12); border-color: rgba(125,200,255,0.45); }
.orb-chip.info i { background: #7DC8FF; box-shadow: 0 0 8px #7DC8FF; }
.orb-panel { display: flex; flex-direction: column; gap: 10px; padding: 16px; border-radius: 24px; background: var(--o-panel); border: 1px solid var(--o-line); }
.orb-panel h2 { font-size: 18px; font-weight: 800; }
.orb-panel-head { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; }
.orb-panel-head span { font-size: 13px; color: var(--o-sub); text-align: right; }
.orb-panel button, .orb-tile button { min-height: 48px; padding: 0 16px; border-radius: 16px; border: 1px solid var(--o-acc-soft); background: rgba(166,255,59,0.10); color: var(--o-text); font-size: 15px; font-weight: 700; }
.orb-heat { border-color: rgba(255,140,80,0.6); background: rgba(255,120,60,0.12); }
.orb-heat.ok { border-color: rgba(166,255,59,0.5); background: rgba(166,255,59,0.08); }
.hs-alert-text { display: flex; align-items: flex-start; gap: 10px; font-size: 16px; font-weight: 600; line-height: 1.35; }
.hs-alert-text svg { flex-shrink: 0; }
.orb-modes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
.orb-panel .orb-mode { min-height: 72px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; padding: 6px; border-radius: 58% 42% 55% 45% / 52% 60% 40% 48%; background: rgba(166,255,59,0.06); border: 1px solid rgba(166,255,59,0.32); color: #D9F9B8; font-size: 15px; font-weight: 700; transition: background 0.3s ease, color 0.3s ease; }
.orb-panel .orb-mode[aria-pressed="true"] { background: radial-gradient(circle at 40% 30%, rgba(255,255,255,0.55) 0%, rgba(255,255,255,0) 45%), linear-gradient(160deg, var(--o-acc) 40%, var(--o-acc-2) 100%); color: var(--o-acc-text); border-color: var(--o-acc-soft); box-shadow: 0 0 16px var(--o-acc); }
.orb-bubbles { display: flex; align-items: flex-end; justify-content: space-around; gap: 8px; flex-wrap: wrap; }
.orb-bubble { width: 92px; height: 92px; border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #FFFFFF; text-shadow: 0 1px 6px rgba(20,0,30,0.55); animation: orbBob 6s ease-in-out infinite; animation-delay: calc(var(--i) * 0.8s);
  background: radial-gradient(circle at 30% 24%, #FFC2A0 0%, #D23F76 32%, #A01F5C 66%, #3F0B33 100%); box-shadow: 0 0 26px rgba(255,80,140,0.40), inset -8px -12px 22px rgba(20,0,30,0.5); }
.orb-bubble.cool { background: radial-gradient(circle at 30% 24%, #C9F0FF 0%, #2F66C8 32%, #1B3F94 66%, #0B1A4A 100%); box-shadow: 0 0 26px rgba(90,190,255,0.40), inset -8px -12px 22px rgba(0,8,30,0.5); }
.orb-bubble strong { font-size: 22px; font-weight: 800; line-height: 1; }
.orb-bubble span { font-size: 13px; font-weight: 700; max-width: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.orb-tile { display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 20px; background: var(--o-panel); border: 1px solid var(--o-line); }
.orb-tile.lit { border-color: #FFD27A; box-shadow: 0 0 18px rgba(255,210,122,0.25); }
.orb-tile.danger { border-color: #FF5A6E; background: rgba(255,60,90,0.16); }
.orb-tile .hs-grow { display: flex; flex-direction: column; font-size: 14px; color: var(--o-sub); }
.orb-tile strong { font-size: 16px; color: var(--o-text); }
.hs-tile-icon { width: 42px; height: 42px; flex-shrink: 0; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #FFFFFF; background: var(--c); }
.orb-quick { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; }
.orb-q { min-height: 56px; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 0 10px; border-radius: 28px; border: 1px solid var(--o-line); background: rgba(255,255,255,0.08); color: var(--o-text); font-size: 15px; font-weight: 700; }
.orb-q[data-action="all-off"] { background: radial-gradient(circle at 40% 30%, rgba(255,255,255,0.55) 0%, rgba(255,255,255,0) 45%), linear-gradient(160deg, var(--o-acc) 40%, var(--o-acc-2) 100%); color: var(--o-acc-text); border-color: var(--o-acc-soft); }
.orb-energy { display: flex; align-items: center; gap: 10px; min-height: 48px; padding: 0 14px; border-radius: 16px; border: 1px solid var(--o-line); background: transparent; color: var(--o-sub); font-size: 15px; text-align: left; }
.orb-energy strong { color: var(--o-text); }
.orb-energy svg { color: #FFD27A; flex-shrink: 0; }
@keyframes orbSpin { to { transform: rotate(360deg); } }
@keyframes orbFloat { 0%, 100% { transform: translate(-50%, -50%); } 50% { transform: translate(-50%, calc(-50% - 5px)); } }
@keyframes orbPulse { 0%, 100% { opacity: 0.6; transform: scale(1); } 50% { opacity: 1; transform: scale(1.06); } }
@keyframes orbTwinkle { 0%, 100% { opacity: 0.35; } 50% { opacity: 0.9; } }
@keyframes orbBob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
.app.narrow .hs-orbite { grid-template-columns: minmax(0, 1fr); align-content: start; padding: 14px 16px 10px; gap: 14px; overflow: visible; }
.app.narrow .orb-side { display: contents; }
.app.narrow .orb-side > * { order: 2; }
.app.narrow .orb-side > .orb-head { order: 0; }
.app.narrow .orb-main { order: 1; }
.app.narrow .orb-main .orb-quick { margin-top: 30px; }
.app.narrow .orb-system { width: 100%; height: auto; flex: none; }
.app.narrow .orb-head { flex-wrap: wrap; }
.app.narrow .orb-planet { width: 64px; height: 64px; }
.app.narrow .orb-sphere { width: 46px; height: 46px; }
.app.narrow .orb-planet.lit .orb-sphere { width: 58px; height: 58px; }
.app.narrow .orb-name { font-size: 13px; max-width: 90px; }
.app.narrow .orb-sub { font-size: 12px; }
.app.narrow .orb-label { padding: 3px 9px; }
.app.narrow .orb-clock { font-size: 30px; }
.app.narrow .orb-sun-sub { font-size: 12px; }
.app.narrow .orb-hello { font-size: 24px; }
.app.narrow .orb-bubble { width: 80px; height: 80px; }
.app.narrow .orb-quick { grid-template-columns: minmax(0, 1fr); }
`;
