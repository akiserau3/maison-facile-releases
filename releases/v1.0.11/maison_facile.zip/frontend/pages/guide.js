// « Bien choisir ses appareils » (NOTES_guide.md): Zigbee / Wi-Fi explained simply, and
// « Quoi acheter ? » generated from buying_guide.yaml (websocket guide/get).
// Opened from Réglages (embedded section), « Ajouter un appareil » and an idea whose need is missing.
// No external image, no link to a shop: the optional « Où l'acheter ? » address is the installer's.
import { Page, html, raw } from "../lib.js";
import { icon } from "../icons.js";
import { shopLink } from "../components/shop-url.js";
import { say } from "../components/audience.js";

const TABS = [
  { id: "learn", label: "Comprendre", icon: "help" },
  { id: "buy", label: "Quoi acheter ?", icon: "plug" },
];

// ----- illustrations (inline SVG, colors from the theme) -----------------------------

/** A small icon of icons.js placed inside an illustration, centered on (cx, cy). */
function dot(cx, cy, name, cls = "s-dev") {
  const ic = String(icon(name, 18, { stroke: 2.2 })).replace("<svg ", `<svg class="s-ic" x="${cx - 9}" y="${cy - 9}" `);
  return `<circle class="${cls}" cx="${cx}" cy="${cy}" r="15"/>${ic}`;
}

const SVG_ZIGBEE = raw(`<svg class="gd-svg" viewBox="0 0 320 190" role="img" aria-label="Dessin : dans la maison, la box et son antenne parlent aux capteurs. Les prises et ampoules relaient le signal. Internet n'est pas nécessaire." focusable="false">
  <path class="s-house" d="M20 88 L130 20 L240 88 V184 H20 Z"/>
  <path class="s-link" d="M130 124 L62 102 M130 124 L198 102 M130 124 L76 150 M130 124 L184 150 M62 102 L76 150 M198 102 L184 150"/>
  <rect class="s-boxdev" x="108" y="110" width="44" height="28" rx="8"/>
  <rect class="s-key" x="150" y="118" width="13" height="10" rx="2"/>
  <circle class="s-led" cx="120" cy="124" r="3"/>
  ${dot(62, 102, "door")}${dot(198, 102, "motion")}${dot(76, 150, "plug")}${dot(184, 150, "bulb")}
  <path class="s-cloud" d="M262 58h38a12 12 0 0 0 1-24 18 18 0 0 0-34-4 12 12 0 0 0-5 28z"/><path class="s-cross" d="M258 24 L306 66"/>
  <text class="s-txt" x="281" y="88" text-anchor="middle">Internet :</text>
  <text class="s-txt" x="281" y="102" text-anchor="middle">pas besoin</text>
  <text class="s-txt b" x="130" y="174" text-anchor="middle">Votre box</text>
</svg>`);

const SVG_WIFI = raw(`<svg class="gd-svg" viewBox="0 0 320 190" role="img" aria-label="Dessin : un appareil Wi-Fi envoie tout au serveur du fabricant, loin de chez vous, puis à son appli. Si Internet ou ce serveur tombe, il ne répond plus." focusable="false">
  <path class="s-house" d="M14 110 L80 62 L146 110 V170 H14 Z"/>
  ${dot(50, 144, "plug", "s-dev warn")}
  <rect class="s-boxdev" x="86" y="132" width="40" height="24" rx="6"/><circle class="s-led" cx="96" cy="144" r="3"/>
  <path class="s-path" d="M108 130 C 120 60, 180 36, 224 46"/>
  <path class="s-path" d="M276 58 C 300 80, 300 100, 292 128"/>
  <path class="s-cloud warn" d="M228 58h44a13 13 0 0 0 1-26 20 20 0 0 0-39-4 13 13 0 0 0-6 30z"/>
  <path class="s-warn" d="M251 32v10M251 48v1"/>
  <rect class="s-phone" x="278" y="132" width="26" height="42" rx="6"/><path class="s-ico" d="M287 166h8"/>
  <text class="s-txt" x="238" y="78" text-anchor="middle">Serveur du</text>
  <text class="s-txt" x="238" y="92" text-anchor="middle">fabricant</text>
  <text class="s-txt" x="270" y="160" text-anchor="end">Appli</text>
  <text class="s-txt b" x="80" y="186" text-anchor="middle">Chez vous</text>
</svg>`);

const SVG_LABEL = raw(`<svg class="gd-svg gd-svg-sm" viewBox="0 0 220 140" role="img" aria-label="Dessin : une boîte d'appareil. Sur l'étiquette, le mot Zigbee est écrit en toutes lettres." focusable="false">
  <path class="s-pack-side" d="M150 30 L190 14 V108 L150 124 Z"/>
  <path class="s-pack-top" d="M30 30 L70 14 H190 L150 30 Z"/>
  <rect class="s-pack" x="30" y="30" width="120" height="94" rx="4"/>
  <rect class="s-tag" x="42" y="86" width="96" height="26" rx="13"/>
  <text class="s-tag-txt" x="90" y="104" text-anchor="middle">Zigbee 3.0</text>
  <path class="s-ico" d="M60 48h60M60 60h40"/>
  <circle class="s-lens" cx="164" cy="98" r="22"/><path class="s-lens-h" d="M180 114 L204 134"/>
</svg>`);

// ----- comparison table: every cell = an icon + a word (never color alone) ------------

const YES = { k: "yes", t: "Oui" };
const NO = { k: "no", t: "Non" };
const COMPARE = [
  { name: "Zigbee", note: "Recommandé", cells: [YES, { k: "yes", t: "Longue durée" }, { k: "yes", t: "€" }, YES] },
  { name: "Wi-Fi avec appli", note: "Tuya / Smart Life, eWeLink…", cells: [NO, { k: "no", t: "Courte" }, { k: "yes", t: "€" }, { k: "mid", t: "Moyen" }] },
  { name: "Wi-Fi sans appli", note: "Shelly, Matter, ESPHome", cells: [YES, { k: "mid", t: "Sur secteur" }, { k: "mid", t: "€€" }, YES] },
  { name: "Matter / Thread", note: "Pour plus tard", cells: [YES, { k: "yes", t: "Longue durée" }, { k: "mid", t: "€€" }, { k: "mid", t: "Antenne en plus" }] },
  { name: "Bluetooth", note: "Courte portée", cells: [YES, { k: "mid", t: "Moyenne" }, { k: "yes", t: "€" }, NO] },
];
const COMPARE_HEAD = ["Fonctionne sans Internet", "Sur pile", "Prix", "Facile"];

function cell(c, i) {
  const ic = c.k === "yes" ? icon("check", 18, { stroke: 3 }) : c.k === "no" ? icon("minus", 18, { stroke: 3 }) : icon("warn", 16, { stroke: 2.4 });
  return html`<td class="gd-cell ${c.k}" data-label="${COMPARE_HEAD[i]}"><span class="gd-c">${ic}<span>${c.t}</span></span></td>`;
}

function euros(price) {
  return price ? `${price.min} à ${price.max} €` : "";
}

export class GuidePage extends Page {
  init() {
    this.embedded = !!this.params.embedded;
    this.s = { tab: this.params.tab === "buy" || this.params.need ? "buy" : "learn", guide: null, error: false };
    this._scrolled = false;
    this._onTabKey = (ev) => {
      const tab = ev.target.closest?.('[role="tab"]');
      if (!tab || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(ev.key)) return;
      ev.preventDefault();
      const i = TABS.findIndex((t) => t.id === this.s.tab);
      const next = ev.key === "Home" ? 0 : ev.key === "End" ? TABS.length - 1 : (i + (ev.key === "ArrowRight" ? 1 : TABS.length - 1)) % TABS.length;
      this.setTab(TABS[next].id, true);
    };
    this.el.addEventListener("keydown", this._onTabKey);
    this.onCleanup(() => this.el?.removeEventListener("keydown", this._onTabKey));
    this.load();
  }

  async load() {
    try {
      const g = await this.api.getGuide();
      if (!this.destroyed) this.setState({ guide: g, error: false });
    } catch (e) {
      console.warn("[maison-facile] guide/get", e);
      if (!this.destroyed) this.setState({ error: true });
    }
  }

  setTab(id, focus) {
    this.setState({ tab: id });
    if (focus) this.el.querySelector(`[role="tab"][data-tab="${id}"]`)?.focus();
  }

  // ----- templates -------------------------------------------------------------------

  template() {
    const tab = this.s.tab;
    const tabs = html`<div class="ap-tabs gd-tabs" role="tablist" aria-label="Bien choisir ses appareils">
      ${TABS.map((t) => html`<button type="button" role="tab" class="ap-tab" id="gd-tab-${t.id}" data-tab="${t.id}" data-action="tab" aria-controls="gd-panel" aria-selected="${tab === t.id ? "true" : "false"}" tabindex="${tab === t.id ? "0" : "-1"}">${icon(t.icon, 20)}${t.label}</button>`)}
    </div>`;
    const body = html`${tabs}<div role="tabpanel" id="gd-panel" aria-labelledby="gd-tab-${tab}" data-key="gd-${tab}" class="gd-panel">${tab === "learn" ? this.learn() : this.buy()}</div>`;
    if (this.embedded) {
      return html`<div class="stack gd">
        <div><h2 class="sec-title">Bien choisir ses appareils</h2><p class="sub" style="font-size:15px">Avant d'acheter : ce qui marche bien avec votre box, et ce qu'il vaut mieux éviter.</p></div>
        ${body}
      </div>`;
    }
    return html`
      <header class="page-head">
        <div class="title">
          <button type="button" class="back-btn glass" data-action="back" aria-label="${this.backLabel()}">${icon("back", 24)}</button>
          <span class="page-icon" style="background:#0E7A0D;box-shadow:0 8px 18px rgba(14,122,13,0.35)">${icon("check", 28, { stroke: 2.6 })}</span>
          <div><h1>Bien choisir ses appareils</h1><span class="sub" style="font-size:15px">Avant d'acheter : ce qui marche bien avec votre box</span></div>
        </div>
      </header>
      <main class="gd-main stack gd">${body}</main>`;
  }

  backLabel() {
    const back = this.params.back;
    if (back === "ideas") return "Retour à l'idée";
    if (back === "add") return "Retour à l'ajout d'appareil";
    if (back === "wizard") return "Retour à l'installation";
    if (back === "home") return "Retour à l'accueil";
    return "Retour aux réglages";
  }

  learn() {
    return html`<div class="stack" style="gap:16px">
      <section class="gd-hero" aria-labelledby="gd-hero-t">
        <span class="gd-hero-ic">${icon("check", 30, { stroke: 2.8 })}</span>
        <div class="stack" style="gap:6px">
          <h3 id="gd-hero-t" class="gd-hero-title">Si vous hésitez, choisissez Zigbee.</h3>
          <p class="gd-hero-text">${this.data.status?.radio_found ? "Votre box a déjà son antenne Zigbee." : "Il suffit d'ajouter une petite antenne Zigbee (clé USB) sur la box."} Les appareils Zigbee marchent même sans Internet, et leurs piles durent longtemps.</p>
        </div>
      </section>

      <div class="gd-two">
        <section class="glass card gd-card gd-zigbee" aria-labelledby="gd-zb">
          <div class="row wrap" style="justify-content:space-between"><h3 id="gd-zb" class="h2">Zigbee</h3><span class="st-badge actif">Recommandé</span></div>
          ${SVG_ZIGBEE}
          <ul class="gd-list">
            <li>${icon("check", 20, { stroke: 2.8 })}<span><strong>Marche sans Internet.</strong> Tout reste dans la maison.</span></li>
            <li>${icon("check", 20, { stroke: 2.8 })}<span><strong>Piles longue durée :</strong> souvent 1 à 2 ans, parfois plus.</span></li>
            <li>${icon("check", 20, { stroke: 2.8 })}<span><strong>Maillage :</strong> les prises et ampoules relaient le signal. Plus vous avez d'appareils, plus ça porte loin.</span></li>
            <li>${icon("signal", 20)}<span><strong>Il faut l'antenne Zigbee :</strong> ${this.data.status?.radio_found ? "la petite clé USB fournie avec votre box. Elle est déjà branchée." : "une petite clé USB à brancher sur la box (voir « Quoi acheter ? »)."}</span></li>
          </ul>
          <p class="gd-brands"><strong>Marques courantes compatibles :</strong> Sonoff, Aqara, IKEA, Philips Hue, Tuya Zigbee… Vérifiez quand même le mot « Zigbee » : certaines gammes de ces marques sont en Wi-Fi.</p>
        </section>

        <section class="glass card gd-card gd-wifi" aria-labelledby="gd-wf">
          <div class="row wrap" style="justify-content:space-between"><h3 id="gd-wf" class="h2">Wi-Fi</h3><span class="st-badge manque">Attention</span></div>
          ${SVG_WIFI}
          <ul class="gd-list warn">
            <li>${icon("warn", 20)}<span>Souvent piloté par <strong>une appli et un serveur du fabricant</strong> (Tuya / Smart Life, eWeLink…).</span></li>
            <li>${icon("warn", 20)}<span>Si Internet ou ce serveur tombe, il <strong>marche mal ou plus du tout</strong>.</span></li>
            <li>${icon("warn", 20)}<span><strong>Compte en ligne obligatoire.</strong> Vos données partent hors de chez vous.</span></li>
            <li>${icon("warn", 20)}<span><strong>Sur pile, il s'use vite :</strong> quelques semaines à quelques mois.</span></li>
          </ul>
          <div class="gd-ok-ko">
            <div class="gd-ok"><strong>${icon("check", 18, { stroke: 3 })}Marche bien en Wi-Fi</strong><span>Ce qui est branché : prises, ampoules, caméras.</span></div>
            <div class="gd-ko"><strong>${icon("minus", 18, { stroke: 3 })}Marche mal en Wi-Fi</strong><span>Les capteurs sur pile : ouverture, mouvement, fuite, thermomètre.</span></div>
          </div>
          <p class="gd-brands"><strong>Les bonnes exceptions :</strong> Shelly, les appareils « Matter » en Wi-Fi, ESPHome et WLED. Ils marchent sans appli ni serveur : la box les trouve toute seule.</p>
        </section>
      </div>

      <section class="glass card gd-card gd-label" aria-labelledby="gd-lb">
        ${SVG_LABEL}
        <div class="stack" style="gap:8px">
          <h3 id="gd-lb" class="h2">À repérer sur la boîte</h3>
          <p class="gd-p">Cherchez le mot <strong>« Zigbee »</strong> écrit sur la boîte ou dans la fiche du produit. Il est souvent suivi de « 3.0 », parfois à côté d'un petit logo. « Zigbee 3.0 » est le meilleur choix.</p>
          <p class="gd-p">La boîte dit « passerelle » ou « hub » nécessaire ? Pas besoin de l'acheter : votre box et son antenne font ce travail.</p>
        </div>
      </section>

      <div class="gd-two">
        <section class="glass card gd-card" aria-labelledby="gd-mt">
          <h3 id="gd-mt" class="h2">${icon("magic", 22)} Matter et Thread</h3>
          <p class="gd-p">C'est l'avenir, compatible avec beaucoup de marques. Mais Thread demande une antenne en plus : pour l'instant, évitez-le, sauf les appareils « Matter » en Wi-Fi.</p>
        </section>
        <section class="glass card gd-card" aria-labelledby="gd-bt">
          <h3 id="gd-bt" class="h2">${icon("signal", 22)} Bluetooth</h3>
          <p class="gd-p">Il porte à quelques mètres seulement : l'appareil doit rester tout près de la box. ${say(this.app, "Gardez-le pour un cas précis, conseillé par votre installateur.")}</p>
        </section>
      </div>

      <section class="glass card gd-card" aria-labelledby="gd-cmp">
        <h3 id="gd-cmp" class="h2">En un coup d'œil</h3>
        <div class="gd-table-wrap">
          <table class="gd-table">
            <caption class="sr-only">Comparaison des technologies sans fil</caption>
            <thead><tr><th scope="col">Technologie</th>${COMPARE_HEAD.map((h) => html`<th scope="col">${h}</th>`)}</tr></thead>
            <tbody>${COMPARE.map((r, i) => html`<tr class="${i === 0 ? "best" : ""}"><th scope="row"><span class="gd-tname">${r.name}</span><span class="gd-tnote">${r.note}</span></th>${r.cells.map((c, i) => cell(c, i))}</tr>`)}</tbody>
          </table>
        </div>
      </section>

      <section class="gd-summary" aria-labelledby="gd-sum">
        <div class="stack" style="gap:4px"><h3 id="gd-sum" class="gd-sum-title">En résumé : si vous hésitez, choisissez Zigbee.</h3>
        <span class="gd-sum-text">Pour une prise, une ampoule ou une caméra, le Wi-Fi sans appli convient aussi.</span></div>
        <button type="button" class="btn primary" data-action="tab" data-tab="buy">${icon("arrow", 20, { stroke: 2.4 })}Voir quoi acheter</button>
      </section>
    </div>`;
  }

  buy() {
    if (this.s.error && !this.s.guide) {
      return html`<div class="glass empty"><span>Impossible de charger le guide.</span><button type="button" class="btn primary sm" data-action="retry">Réessayer</button></div>`;
    }
    const g = this.s.guide;
    if (!g) return html`<div class="loading" role="status"><span class="spinner" aria-hidden="true"></span>Chargement du guide…</div>`;
    const items = g.items || [];
    const focus = this.params.need && items.some((i) => i.id === this.params.need) ? this.params.need : null;
    const ordered = focus ? [items.find((i) => i.id === focus), ...items.filter((i) => i.id !== focus)] : items;
    const hasShop = !!shopLink(g.shop_url || "", "x");
    return html`<div class="stack" style="gap:14px">
      ${this.starter(g, items)}
      <p class="sub" style="font-size:16px;line-height:1.45">Pour chaque appareil : quoi chercher, le prix indicatif et le piège à éviter. Aucun lien ici n'est publicitaire.</p>
      ${hasShop ? html`<p class="gd-ext-note">${icon("arrow", 18)}Les boutons « Où l'acheter ? » ouvrent ${say(this.app, "un site externe choisi par votre installateur.")} Maison Facile ne vend rien.</p>` : ""}
      <div class="gd-grid">${ordered.map((it) => this.item(it, g, it.id === focus))}</div>
    </div>`;
  }

  /**
   * « Pour commencer » (buying_guide.yaml starter): the antenna + 2 or 3 essential sensors and
   * the total budget. Shown first while the box has no antenna (box installed without hardware).
   */
  starter(g, items) {
    const st = g.starter;
    if (!st || this.data.status?.radio_found) return "";
    const byId = Object.fromEntries(items.map((i) => [i.id, i]));
    const list = (st.items || []).map((id) => byId[id]).filter(Boolean);
    if (!list.length) return "";
    return html`<section class="glass card disc-starter" data-key="gd-starter" aria-labelledby="gd-starter-t">
      <div class="row wrap" style="justify-content:space-between;gap:8px">
        <h3 id="gd-starter-t" class="h2" style="margin:0">${st.title || "Pour commencer"}</h3>
        ${st.budget ? html`<span class="st-badge actif">Environ ${st.budget.min} à ${st.budget.max} € en tout</span>` : ""}
      </div>
      ${st.intro ? html`<p class="gd-p">${st.intro}</p>` : ""}
      <ol class="disc-list">${list.map((it, i) => html`<li>
        <span class="li-icon" style="background:${it.color}" aria-hidden="true">${icon(it.icon, 20)}</span>
        <span class="grow"><strong>${i + 1}. ${it.title}</strong>${it.price ? html`<span class="s">${euros(it.price)}</span>` : ""}</span>
        <button type="button" class="btn link" data-action="see" data-id="${it.id}" aria-label="Voir la fiche : ${it.title}">Voir</button>
      </li>`)}</ol>
    </section>`;
  }

  item(it, g, focused) {
    const link = shopLink(g.shop_url || "", it.id);
    const ideas = (it.ideas || []).slice(0, 3);
    return html`<article class="gd-item ${focused ? "focus" : ""}" data-key="gi-${it.id}" id="gd-item-${it.id}" aria-labelledby="gd-it-${it.id}" ${focused ? html`tabindex="-1"` : ""}>
      <div class="row" style="gap:12px;align-items:flex-start">
        <span class="li-icon" style="background:${it.color}">${icon(it.icon, 22)}</span>
        <div class="grow stack" style="gap:4px">
          <h3 id="gd-it-${it.id}" class="gd-it-title">${it.title}</h3>
          <span class="row wrap" style="gap:6px">
            <span class="st-badge ${it.protocol === "network" ? "" : "actif"}">${it.protocol_fr}</span>
            ${focused ? html`<span class="st-badge attente">Pour votre idée</span>` : ""}
          </span>
        </div>
      </div>
      <p class="gd-p">${it.what}</p>
      <div class="stack" style="gap:6px">
        <strong style="font-size:15px">À chercher</strong>
        <ul class="gd-list small">${(it.look_for || []).map((t) => html`<li>${icon("check", 18, { stroke: 2.8 })}<span>${t}</span></li>`)}</ul>
      </div>
      <p class="gd-price"><strong>Prix indicatif :</strong> ${it.price ? euros(it.price) : it.price_note}</p>
      <p class="gd-trap">${icon("warn", 18)}<span><strong>Piège à éviter :</strong> ${it.trap}</span></p>
      ${ideas.length ? html`<div class="gd-for"><span>Sert pour :</span>${ideas.map((x) => html`<button type="button" class="gd-idea" data-action="idea" data-id="${x.id}" aria-label="Voir l'idée ${x.title}">${icon("bulb", 16)}${x.title}</button>`)}${(it.ideas || []).length > 3 ? html`<span>…</span>` : ""}</div>` : ""}
      ${link
        ? html`<a class="btn secondary sm gd-shop" href="${link}" target="_blank" rel="noopener noreferrer external" aria-label="Où l'acheter ? ${it.title} (lien externe, nouvel onglet)">Où l'acheter ?<span class="gd-ext">lien externe</span></a>`
        : ""}
    </article>`;
  }

  afterRender() {
    // Opened for one idea need: show its card first, focused once.
    if (this._scrolled || this.s.tab !== "buy" || !this.s.guide || !this.params.need) return;
    const card = this.el.querySelector(`#gd-item-${CSS.escape(this.params.need)}`);
    if (!card) return;
    this._scrolled = true;
    try {
      card.focus({ preventScroll: false });
    } catch (e) {
      /* ignore */
    }
  }

  onAction(action, el) {
    switch (action) {
      case "tab":
        this.setTab(el.dataset.tab, el.getAttribute("role") === "tab");
        if (el.getAttribute("role") !== "tab") this.el.querySelector(`[role="tab"][data-tab="${el.dataset.tab}"]`)?.focus();
        return undefined;
      case "retry":
        this.setState({ error: false });
        return this.load();
      case "idea":
        return this.app.navigate("ideas", { id: el.dataset.id });
      case "see": {
        const card = this.el.querySelector(`#gd-item-${CSS.escape(el.dataset.id)}`);
        if (card) {
          card.setAttribute("tabindex", "-1");
          card.focus({ preventScroll: false });
          card.scrollIntoView({ block: "start", behavior: "smooth" });
        }
        return undefined;
      }
      case "back": {
        const back = this.params.back || "settings";
        return this.app.navigate(back, this.params.backParams || (back === "settings" ? { section: "guide" } : {}));
      }
      default:
    }
    return undefined;
  }
}

/** Réglages › « Bien choisir ses appareils » (same page, without its own header). */
export class GuideSection extends GuidePage {
  constructor(app, params = {}) {
    super(app, { ...params, embedded: true });
  }
}

/**
 * Friendly notice of « Ajouter un appareil » for Wi-Fi / cloud devices (never blocks anything).
 * `cloud`: state/get.cloud entries ([{label_fr, devices}]) or null for the « Appareil Wi-Fi » choice.
 */
export function cloudNotice(cloud) {
  const names = (cloud || []).map((c) => c.label_fr);
  const n = (cloud || []).reduce((sum, c) => sum + (c.devices || 0), 0);
  const intro = names.length
    ? `Votre box utilise ${n > 1 ? `${n} appareils` : n === 1 ? "1 appareil" : "des appareils"} ${names.join(" et ")}.`
    : "";
  return html`<div class="gd-notice" role="note">
    <span class="gd-notice-ic">${icon("cloud", 26)}</span>
    <div class="grow stack" style="gap:6px">
      <strong class="gd-notice-title">${names.length ? "Ces appareils dépendent d'Internet et de l'appli du fabricant" : "Cet appareil dépend d'Internet et de l'appli du fabricant"}</strong>
      <span class="gd-notice-text">${intro ? `${intro} Ils peuvent très bien marcher. Mais si Internet ou le serveur du fabricant tombe, ils ne répondent plus.` : "Il peut très bien marcher. Mais si Internet ou le serveur du fabricant tombe, il ne répond plus."} Pour vos prochains achats, le Zigbee garde tout chez vous.</span>
      <span><button type="button" class="btn link" style="padding:0;min-height:44px" data-action="open-guide">Comprendre la différence</button></span>
    </div>
  </div>`;
}
