import { Page, html, fmtNum, fmtEur, fmtSmart } from "../lib.js";
import { icon } from "../icons.js";

const PERIODS = {
  day: { label: "Jour", conso: "Aujourd'hui", compare: "Par rapport à hier", chart: "Heure par heure" },
  week: { label: "Semaine", conso: "Cette semaine", compare: "Par rapport à la semaine dernière", chart: "Jour par jour" },
  month: { label: "Mois", conso: "Ce mois-ci", compare: "Par rapport au mois dernier", chart: "Semaine par semaine" },
};

const SHARE_COLORS = ["#E8590C", "#FFB900", "#6B47B8", "#0067C0", "#00838F", "#C2185B"];

/** calm / medium / strong colours, `ratio` = value / max. */
export function energyBarColor(ratio, mini = false) {
  if (ratio >= 0.75) return mini ? "#F7630C" : "#E8590C";
  if (ratio >= 0.45) return "#FFB900";
  return "var(--accent)";
}

export class EnergyPage extends Page {
  init() {
    this.s = { period: "week", data: {}, error: false, tip: null };
    this.load();
  }

  async load() {
    const period = this.s.period;
    this.setState({ error: false });
    try {
      const r = await this.api.energySummary(period);
      this.setState({ data: { ...this.s.data, [period]: r } });
    } catch (e) {
      console.warn("[maison-facile] energy", e);
      this.setState({ error: true });
    }
  }

  template() {
    const p = PERIODS[this.s.period];
    const d = this.s.data[this.s.period];
    return html`
      <header class="page-head">
        <div class="title">
          <span class="page-icon" style="background:#FFB900;color:#3A2A00;box-shadow:0 8px 18px rgba(255,185,0,0.45)">${icon("bolt", 28)}</span>
          <div><h1>Énergie</h1><span class="sub" style="font-size:15px">Ce que consomme la maison, en clair</span></div>
        </div>
        <div class="period glass" role="group" aria-label="Période">
          ${Object.entries(PERIODS).map(([k, v]) => html`<button type="button" data-action="period" data-period="${k}" aria-pressed="${this.s.period === k ? "true" : "false"}">${v.label}</button>`)}
        </div>
      </header>
      <main class="page-main">${this.body(p, d)}</main>`;
  }

  body(p, d) {
    if (this.s.error) {
      return html`<div class="glass empty" style="flex:1" role="alert"><span class="big-icon" style="background:#F7630C">${icon("warn", 34)}</span><strong style="color:var(--text);font-size:19px">Impossible de lire la consommation.</strong><button type="button" class="btn primary sm" data-action="retry">Réessayer</button></div>`;
    }
    if (!d) {
      return html`<div class="loading"><span class="spinner" aria-hidden="true"></span>Chargement…</div>`;
    }
    if (!d.has_data) {
      return html`<div class="glass empty" style="flex:1;gap:16px">
        <span class="big-icon" style="background:#FFB900;color:#3A2A00">${icon("plug", 36)}</span>
        <strong style="color:var(--text);font-size:22px">Pas encore de mesure</strong>
        <span style="max-width:520px;line-height:1.5">Dès qu'une prise connectée ou un compteur mesure l'électricité, vous verrez ici combien consomme la maison et ce que ça coûte.</span>
        <button type="button" class="btn primary" data-action="add-device">${icon("plus", 20)}Ajouter une prise connectée</button>
      </div>`;
    }
    const buckets = d.buckets || [];
    const max = Math.max(0.0001, ...buckets.map((b) => b.kwh || 0));
    const change = typeof d.change_pct === "number" && Number.isFinite(d.change_pct) ? d.change_pct : null;
    const down = change !== null && change <= 0;
    const top = d.top || [];
    const desc = buckets.map((b) => `${b.label} : ${fmtSmart(b.kwh)} kWh`).join(", ");
    return html`
      <section class="col">
        <div class="kpis">
          <div class="kpi glass"><span class="k-label">${p.conso}</span><span class="k-value">${fmtNum(d.total_kwh, 1)} kWh</span></div>
          <div class="kpi gold"><span class="k-label">Ça coûte environ</span><span class="k-value">${fmtEur(d.cost_eur)}</span></div>
          <div class="kpi glass"><span class="k-label">${p.compare}</span>
            ${change === null
              ? html`<span class="trend" style="font-size:20px;color:var(--sub)">Pas encore de comparaison</span>`
              : html`<span class="trend ${down ? "down" : "up"}">${icon(down ? "down" : "up", 26, { stroke: 2.6 })}${fmtNum(Math.abs(change), 0)} % ${down ? "moins" : "plus"}</span>`}
          </div>
        </div>
        <div class="glass card" style="flex:1;min-height:0;border-radius:22px;gap:12px">
          <div class="row wrap" style="justify-content:space-between">
            <h2 class="h2">${p.chart}</h2>
            <span class="legend"><span><i style="background:var(--accent)"></i>Calme</span><span><i style="background:#FFB900"></i>Moyen</span><span><i style="background:#E8590C"></i>Fort</span></span>
          </div>
          <div class="chart" role="img" aria-label="${p.chart} : ${desc}">
            ${buckets.map((b, i) => {
              const r = (b.kwh || 0) / max;
              const last = i === buckets.length - 1;
              return html`<div class="bar-col ${last ? "last" : ""}"><div class="bar" title="${b.label} : ${fmtSmart(b.kwh)} kWh" style="height:${Math.max(2, Math.round(r * 100))}%;background:${energyBarColor(r)};${last ? "box-shadow:0 8px 18px rgba(30,50,90,0.20)" : ""}"></div><span class="bar-label">${b.label}</span></div>`;
            })}
          </div>
        </div>
      </section>
      <aside class="side" style="width:400px">
        <div class="glass card" style="border-radius:22px;gap:12px">
          <h2 class="h2">Qui consomme le plus ?</h2>
          ${top.length
            ? top.slice(0, 6).map((u, i) => html`<div class="share">
                <div class="sh-top"><strong>${u.name}</strong><span class="sub">${fmtNum(u.share_pct, 0)} % · ${fmtSmart(u.kwh)} kWh</span></div>
                <div class="track" aria-hidden="true"><div style="width:${Math.max(2, Math.min(100, u.share_pct || 0))}%;background:${SHARE_COLORS[i % SHARE_COLORS.length]}"></div></div>
              </div>`)
            : html`<p class="sub">Pas assez de détails pour le moment.</p>`}
        </div>
        ${this.tipCard(top)}
      </aside>`;
  }

  tipCard(top) {
    const reco = this.s.tip;
    if (reco === "done") {
      return html`<div class="glass card row" style="flex-direction:row;border:2px solid var(--mf-green);font-size:16px"><span class="ok-icon round">${icon("check", 22, { stroke: 2.6 })}</span><span>C'est activé : l'appareil en veille sera coupé chaque nuit de 1 h à 7 h.</span></div>`;
    }
    if (reco === "no") return "";
    const hasPlug = (this.data.devices || []).some((d) => d.entities?.switch && d.entities?.power);
    if (!hasPlug) return "";
    return html`<div class="tip">
      <span class="row" style="gap:10px;font-size:15px;font-weight:700">${icon("bulb", 22)}Une idée pour économiser</span>
      <span style="font-size:18px;font-weight:700;line-height:1.35">Un appareil branché reste peut-être en veille toute la nuit. On le coupe de 1 h à 7 h ?</span>
      <div class="row wrap" style="gap:10px">
        <button type="button" class="btn sm white" data-action="tip-yes">${this.isBusy("tip") ? "Un instant…" : "Oui, activer"}</button>
        <button type="button" class="btn sm outline" data-action="tip-no">Non merci</button>
      </div>
    </div>`;
  }

  async onAction(action, el) {
    switch (action) {
      case "period":
        this.setState({ period: el.dataset.period });
        if (!this.s.data[this.s.period]) this.load();
        return;
      case "retry":
        return this.load();
      case "add-device":
        return this.app.navigate("add", { back: "energy" });
      case "tip-no":
        return this.setState({ tip: "no" });
      case "tip-yes":
        return this.run("tip", async () => {
          const items = await this.api.listRecommendations();
          const r = items.find((x) => x.id === "veille_nuit");
          if (!r) throw new Error("no veille_nuit");
          const options = {};
          for (const o of r.options || []) {
            const c = (o.choices || []).find((x) => x.recommended) || (o.choices || [])[0];
            if (c) options[o.key] = c.value;
          }
          await this.api.applyRecommendations([{ id: "veille_nuit", enabled: true, options }]);
          this.setState({ tip: "done" });
        }, "Impossible d'activer cet automatisme.");
      default:
    }
  }
}
