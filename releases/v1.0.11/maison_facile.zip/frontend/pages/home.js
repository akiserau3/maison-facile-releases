import { Page, html, raw, fmtNum, fmtEur, timeHM, dateLong } from "../lib.js";
import { icon } from "../icons.js";
import { MODES, MODE_ENTITY, currentMode, roomSummary, roomColor, allRoomLights, roleEntities, weather, cameraUrl, buildHomeModel, findHeatingAlert } from "../components/model.js";
import { energyBarColor } from "./energy.js";
import { tileView, ideaTileHtml } from "../components/idea-tile.js";
import { greeting, greetingHtml, wink, styleDef } from "../components/appearance.js";
import { STYLE_RENDERERS, tubeLevel } from "./home-styles/index.js";

export class HomePage extends Page {
  init() {
    this.s = { now: new Date(), energy: null, energyError: false, alertDone: null };
    this.cameraToUrl = cameraUrl;
    this.every(15000, () => this.setState({ now: new Date() }));
    this.startCameras(cameraUrl);
    this.loadEnergy();
    this.every(300000, () => this.loadEnergy());
  }

  async loadEnergy() {
    try {
      const r = await this.api.energySummary("day");
      this.setState({ energy: r, energyError: false });
    } catch (e) {
      this.setState({ energyError: true });
    }
  }

  cameraEntity() {
    const cams = roleEntities(this.data?.devices, "camera");
    return cams[0] || null;
  }

  /** Window open while heating runs in the same room (and not already paused by us). */
  findAlert() {
    return findHeatingAlert(this.data, (id) => this.st(id));
  }

  /** Same data for every home style (components/model.js), + greeting and wink of the theme. */
  model() {
    const get = (id) => this.st(id);
    const alert = this.findAlert();
    const paused = this.activePause(get);
    const m = buildHomeModel(this.data, this.hass, get, { now: this.s.now, energy: this.s.energy, energyError: this.s.energyError, heatingAlert: alert, paused, tileView });
    const appearance = this.app.appearance;
    const theme = this.app.theme;
    m.greeting = greeting(theme, appearance, m.userName, m.now);
    m.wink = wink(theme, appearance, m, get);
    m.pausedId = paused;
    return m;
  }

  /** « Vous essayez le style Néon — Garder / Revenir » after « Essayer » in Réglages. */
  trialBanner() {
    const id = this.app.styleTrial;
    if (!id) return "";
    return html`<div class="style-trial" role="status" data-key="trial">
      <span class="st-text">${icon("palette", 22)}Vous essayez le style ${styleDef(id).name}</span>
      <button type="button" class="btn primary sm" data-action="keep-style">Garder</button>
      <button type="button" class="btn secondary sm" data-action="end-trial">Revenir</button>
    </div>`;
  }

  /**
   * Window whose heating we paused and that is still open. When it closes, the
   * confirmation disappears and the pause is forgotten locally (the backend resumes).
   */
  activePause(get) {
    const pauses = this.data.heating_pauses || {};
    let shown = null;
    for (const id of Object.keys(pauses)) {
      const s = get(id);
      if (s && s.state === "off") {
        if (this.s.alertDone === id) this.s.alertDone = null;
        Promise.resolve().then(() => this.api.forgetHeatingPause(id));
      } else if (!shown) {
        shown = id;
      }
    }
    if (!shown && this.s.alertDone) {
      const s = get(this.s.alertDone);
      if (!s || s.state === "off") this.s.alertDone = null;
      else shown = this.s.alertDone;
    }
    return shown;
  }

  template() {
    const model = this.model();
    const style = this.app.homeStyle;
    const tint = ["clair", "sombre", "contraste"].includes(this.app.theme) ? "" : this.app.theme;
    const render = STYLE_RENDERERS[style];
    if (render) {
      const out = String(render(model, this));
      // data-tint: holiday / season colors on top of the style (accents only).
      return html`${this.trialBanner()}${this.emptyHome()}${raw(tint ? out.replace('class="hs ', `data-tint="${tint}" class="hs `) : out)}`;
    }
    const state = this.data;
    const hass = this.hass;
    const mode = currentMode(hass);
    const m = MODES[mode];
    const w = model.weather;
    const get = (id) => this.st(id);
    const rooms = state.rooms || [];
    const alert = model.heatingAlert;
    const paused = model.pausedId;
    const cam = this.cameraEntity();

    return html`${this.trialBanner()}
      <header class="home-head">
        <div class="row" style="align-items: baseline; gap: 18px">
          <span class="clock" aria-label="Il est ${timeHM(this.s.now)}">${timeHM(this.s.now)}</span>
          <div style="display:flex;flex-direction:column;gap:2px">
            <h1 style="font-size:24px;font-weight:600">${greetingHtml(model.greeting)}</h1>
            <p class="sub" style="font-size:16px">${dateLong(this.s.now)}</p>
            <p class="wink"><span class="wink-dot" aria-hidden="true"></span>${model.wink}</p>
          </div>
        </div>
        <div class="row wrap">
          ${w ? html`<div class="pill glass"><span class="badge gold round" style="width:40px;height:40px">${icon(w.icon, 24)}</span><span>${w.temp !== null ? html`<strong style="font-size:20px">${fmtNum(w.temp, 0)} °C</strong> dehors` : "Dehors"}${w.label ? ` · ${w.label}` : ""}</span></div>` : ""}
          <button type="button" class="pill mode glass" data-action="go-security" aria-label="Mode actuel : ${m.label}. Ouvrir la sécurité">
            <span class="mode-dot" style="background:${m.dot}" aria-hidden="true"></span><strong>${m.label}</strong>
          </button>
        </div>
      </header>

      ${this.emptyHome()}
      <main class="page-main">
        <section class="col" aria-label="Pièces et actions">
          <h2 class="h2">Mes pièces</h2>
          ${rooms.length
            ? html`<div class="rooms-grid">${rooms.map((r, i) => this.roomTile(r, i, get))}</div>`
            : html`<div class="glass empty"><span class="big-icon" style="background:#F7630C">${icon("grid", 34)}</span><span>Aucune pièce pour l'instant.</span><button type="button" class="btn primary sm" data-action="go-rooms-settings">Ajouter mes pièces</button></div>`}

          <h2 class="h2" style="margin-top:6px">En un clic</h2>
          <div class="quick-grid">
            <button type="button" class="quick blue" data-action="all-off" ${this.isBusy("all-off") ? "disabled" : ""}>
              ${icon("power", 32)}<span style="display:flex;flex-direction:column;gap:2px"><span class="q-title">Tout éteindre</span><span class="q-sub">Toutes les lumières</span></span>
            </button>
            <button type="button" class="quick green" data-action="leave" ${this.isBusy("leave") ? "disabled" : ""}>
              ${icon("leave", 32)}<span style="display:flex;flex-direction:column;gap:2px"><span class="q-title">Je pars</span><span class="q-sub">Éteint et surveille</span></span>
            </button>
            <button type="button" class="quick violet" data-action="night" ${this.isBusy("night") ? "disabled" : ""}>
              ${icon("moon", 32)}<span style="display:flex;flex-direction:column;gap:2px"><span class="q-title">Bonne nuit</span><span class="q-sub">Tout s'éteint, mode nuit</span></span>
            </button>
          </div>
        </section>

        <aside class="side" aria-label="Infos">
          ${this.ideaTiles(get)}
          ${alert
            ? html`<div class="alert" role="alert">
                <div class="row" style="align-items:flex-start"><span class="alert-icon">${icon("warn", 22)}</span><span style="font-size:16px;font-weight:600;line-height:1.35">${alert.text}</span></div>
                <button type="button" class="btn" data-action="pause-heating" data-key="pause">${this.isBusy("pause") ? "Un instant…" : "Mettre le chauffage en pause"}</button>
              </div>`
            : ""}
          ${paused
            ? html`<div class="glass card row" style="flex-direction:row;font-size:16px" role="status"><span class="ok-icon">${icon("check", 22, { stroke: 2.2 })}</span><span>C'est fait : chauffage en pause, il se rallumera quand la fenêtre sera fermée.</span></div>`
            : ""}
          ${this.energyCard()}
          ${cam ? this.cameraCard(cam) : ""}
        </aside>
      </main>`;
  }

  /**
   * No device yet (often a box installed without hardware, installer v1.4): a welcoming card
   * instead of an empty dashboard that looks broken.
   */
  emptyHome() {
    if ((this.data.devices || []).length) return "";
    const noRadio = !this.data.status?.radio_found;
    return html`<section class="glass home-empty" data-key="home-empty" aria-labelledby="he-title">
      <span class="he-icon" aria-hidden="true">${icon("homeDoor", 32)}</span>
      <div class="grow stack" style="gap:6px">
        <h2 id="he-title" class="he-title">Votre maison est prête</h2>
        <p class="he-text">Ajoutez votre premier appareil quand vous voulez. En attendant, la météo, les rappels et les thèmes de fêtes marchent déjà.${noRadio ? " Pas encore d'antenne Zigbee ? Commencez par « Quoi acheter ? »." : ""}</p>
        <div class="row wrap" style="gap:10px;margin-top:4px">
          <button type="button" class="btn primary" data-action="add-device">${icon("plus", 20)}Ajouter un appareil</button>
          <button type="button" class="btn secondary" data-action="open-buy">${icon("plug", 20)}Quoi acheter ?</button>
        </div>
      </div>
    </section>`;
  }

  /** Tiles of the active ideas (« Courrier arrivé · Aujourd'hui à 10:42 » + « Relevé »…). */
  ideaTiles(get) {
    const out = [];
    for (const tile of this.data.idea_tiles || []) {
      const view = tileView(tile, get);
      if (view) out.push(ideaTileHtml(tile, view));
    }
    return out;
  }

  roomTile(room, index, get) {
    const sum = roomSummary(this.data, room, get);
    const on = sum.anyLightOn;
    const color = roomColor(room, index);
    const hasLight = sum.lights.length > 0;
    const meta =
      sum.temp !== null
        ? html`<strong>${fmtNum(sum.temp, 1)}°</strong>${sum.hum !== null ? html`  ·  ${fmtNum(sum.hum, 0)} % d'humidité` : ""}`
        : sum.hum !== null
          ? html`${fmtNum(sum.hum, 0)} % d'humidité`
          : html`${sum.devices.length} appareil${sum.devices.length > 1 ? "s" : ""}`;
    return html`<div class="room-tile ${on ? "lit" : ""}" data-key="room-${room.area_id}">
      <span class="room-icon" style="background:${color};box-shadow:0 6px 14px ${color}59">${icon(room.icon, 30, { stroke: 1.9 })}</span>
      <div class="grow" style="display:flex;flex-direction:column;gap:4px">
        <span class="room-name">${room.name}</span>
        <span class="room-meta">${meta}</span>
        ${hasLight ? html`<span class="chip ${on ? "on" : ""}">${on ? (sum.lightsOn > 1 ? `${sum.lightsOn} lumières allumées` : "Lumière allumée") : "Lumière éteinte"}</span>` : ""}
      </div>
      ${hasLight
        ? html`<button type="button" class="light-btn" data-action="room-light" data-area="${room.area_id}" aria-pressed="${on ? "true" : "false"}" aria-label="${on ? "Éteindre la lumière" : "Allumer la lumière"} : ${room.name}">${icon("bulb", 30)}</button>`
        : ""}
    </div>`;
  }

  energyCard() {
    const e = this.s.energy;
    let body;
    if (this.s.energyError) {
      body = html`<p class="sub" style="font-size:15px">Impossible de lire la consommation. <button type="button" class="btn link" data-action="retry-energy">Réessayer</button></p>`;
    } else if (!e) {
      body = html`<p class="sub">Chargement…</p>`;
    } else if (!e.has_data) {
      body = html`<p class="sub" style="font-size:15px;line-height:1.4">Pas encore de mesure. Branchez une prise qui mesure la consommation pour voir ce chiffre.</p>`;
    } else {
      const buckets = e.buckets || [];
      const max = Math.max(0.0001, ...buckets.map((b) => b.kwh || 0));
      body = html`<p class="kwh">${fmtNum(e.total_kwh, 1)} kWh <small>≈ ${fmtEur(e.cost_eur)}</small></p>
        <div class="mini-bars" aria-hidden="true">${buckets.map((b) => {
          const r = (b.kwh || 0) / max;
          return html`<div style="height:${Math.max(6, Math.round(r * 100))}%;background:${energyBarColor(r, true)}"></div>`;
        })}</div>
        <span class="muted">De minuit à maintenant</span>`;
    }
    return html`<button type="button" class="glass card" data-action="go-energy" style="text-align:left;color:var(--text);width:100%" aria-label="Électricité aujourd'hui, ouvrir l'écran Énergie">
      <span class="h2-icon"><span class="badge gold">${icon("bolt", 20)}</span>Électricité aujourd'hui</span>
      ${body}
    </button>`;
  }

  cameraCard(cam) {
    // The camera entity is NOT watched with st(): its token / picture changes often and
    // must not re-render the page. tickCameras() swaps the <img src> in place.
    const url = this.cameraSrc(cam.entity_id, cameraUrl);
    const name = cam.device.name || "Caméra";
    return html`<div class="glass card" style="flex:1;min-height:0">
      <h2 class="h2-icon"><span class="badge" style="background:#00838F">${icon("camera", 20)}</span>${name}</h2>
      <div class="cam">
        ${url
          ? html`<img data-cam="${cam.entity_id}" alt="Image en direct : ${name}" src="${url}"><span class="live"><i></i>EN DIRECT</span>`
          : html`<span data-cam-off="${cam.entity_id}">Image indisponible pour le moment</span>`}
      </div>
    </div>`;
  }

  async onAction(action, el, ev) {
    const app = this.app;
    switch (action) {
      case "keep-style":
        return app.keepStyle();
      case "end-trial":
        return app.endTrial();
      case "go-room":
        return app.navigate("rooms", { area: el.dataset.area });
      case "set-mode":
        return this.run("mode", () => this.hass.callService("select", "select_option", { entity_id: MODE_ENTITY, option: el.dataset.mode }), "Impossible de changer le mode.");
      case "tube": {
        // Néon: the height touched on the tube = brightness; keyboard = on / off.
        const room = (this.data.rooms || []).find((r) => r.area_id === el.dataset.area);
        if (!room) return undefined;
        const sum = roomSummary(this.data, room, (id) => this.hass.states[id]);
        const ids = sum.lights.map((l) => l.entity_id);
        if (!ids.length) return undefined;
        const level = tubeLevel(el, ev);
        if (level === null) return app.callService("light", sum.anyLightOn ? "turn_off" : "turn_on", { entity_id: ids }, "Impossible de changer la lumière.");
        if (level === 0) return app.callService("light", "turn_off", { entity_id: ids }, "Impossible de changer la lumière.");
        return app.callService("light", "turn_on", { entity_id: ids, brightness_pct: level }, "Impossible de changer la lumière.");
      }
      case "go-security":
        return app.navigate("security");
      case "tile-action": {
        const tiles = this.data.idea_tiles || [];
        const tile = (el.dataset.tileKey && tiles.find((t) => t.key === el.dataset.tileKey)) || tiles.find((t) => t.idea_id === el.dataset.idea);
        // Tiles that open a page (« Anniversaires »: birthdays_rules.py tile.page).
        if (tile?.page?.page) return app.navigate(tile.page.page, tile.page.params || {});
        const action = tile?.action;
        if (!action?.service) return undefined;
        const [domain, service] = action.service.split(".");
        const ok = await app.callService(domain, service, { entity_id: tile.entity_ids }, "Impossible d'effectuer cette action.");
        if (ok && tile.idea_id === "courrier") app.notify("Courrier relevé.");
        return undefined;
      }
      case "go-energy":
        return app.navigate("energy");
      case "add-device":
        return app.navigate("add", { back: "home" });
      case "open-buy":
        return app.navigate("guide", { tab: "buy", back: "home" });
      case "go-rooms-settings":
        return app.navigate("settings", { section: "rooms" });
      case "retry-energy":
        this.setState({ energyError: false, energy: null });
        return this.loadEnergy();
      case "room-light": {
        const room = (this.data.rooms || []).find((r) => r.area_id === el.dataset.area);
        if (!room) return;
        const sum = roomSummary(this.data, room, (id) => this.hass.states[id]);
        const ids = sum.lights.map((l) => l.entity_id);
        if (!ids.length) return;
        return app.callService("light", sum.anyLightOn ? "turn_off" : "turn_on", { entity_id: ids }, "Impossible de changer la lumière.");
      }
      case "all-off":
        return this.run("all-off", () => this.allOff(), "Impossible de tout éteindre.");
      case "leave":
        return this.run("leave", async () => {
          await this.allOff();
          await this.hass.callService("select", "select_option", { entity_id: MODE_ENTITY, option: "absent" });
          app.notify("Bonne journée ! La maison est surveillée.");
        }, "Impossible d'activer le mode absent.");
      case "night":
        return this.run("night", async () => {
          await this.allOff();
          await this.hass.callService("select", "select_option", { entity_id: MODE_ENTITY, option: "nuit" });
          app.notify("Bonne nuit !");
        }, "Impossible d'activer le mode nuit.");
      case "pause-heating": {
        const alert = this.findAlert();
        if (!alert) return;
        return this.run("pause", async () => {
          const r = await this.api.pauseHeating(alert.key);
          if (r?.ok === false) {
            app.toast(r.message_fr || "Impossible de mettre le chauffage en pause.", null);
            return;
          }
          this.setState({ alertDone: alert.key });
        }, "Impossible de mettre le chauffage en pause.");
      }
      default:
    }
  }

  async allOff() {
    const ids = allRoomLights(this.data);
    if (ids.length) await this.hass.callService("light", "turn_off", { entity_id: ids });
  }
}

