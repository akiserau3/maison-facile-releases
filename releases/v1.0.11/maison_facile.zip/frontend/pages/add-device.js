import { Page, html } from "../lib.js";
import { icon, deviceIcon } from "../icons.js";
import { typeInfo } from "../components/model.js";
import { cloudNotice } from "./guide.js";
import { say } from "../components/audience.js";

// Per-type demo: 3 gestures synchronised with the 3 s CSS animation loop.
const TYPES = {
  ouverture: {
    name: "Détecteur d'ouverture", hint: "Pour une porte ou une fenêtre", color: "#6B47B8", shadow: "rgba(107,71,184,0.35)", shape: "",
    steps: ["Retirez la languette en plastique de la pile.", "Appuyez 5 secondes sur le petit bouton.", "Lâchez quand la lumière bleue clignote."],
    reco: "fenetre_chauffage", recoTitle: "Prévenir si elle reste ouverte avec le chauffage allumé",
  },
  mouvement: {
    name: "Détecteur de mouvement", hint: "Voit quand quelqu'un passe", color: "#E8590C", shadow: "rgba(232,89,12,0.35)", shape: "",
    steps: ["Ouvrez le capteur et retirez la languette de la pile.", "Appuyez 5 secondes sur le petit bouton.", "Lâchez quand la lumière bleue clignote."],
    reco: "lumiere_nuit_mouvement", recoTitle: "Allumer doucement la lumière quand on passe la nuit",
  },
  thermo: {
    name: "Thermomètre", hint: "Température et humidité", color: "#0067C0", shadow: "rgba(0,103,192,0.35)", shape: "thermo",
    steps: ["Retirez la languette en plastique de la pile.", "Appuyez 5 secondes sur le bouton au dos.", "Lâchez quand le petit symbole clignote à l'écran."],
    reco: "alerte_froid_humide", recoTitle: "Prévenir s'il fait trop froid ou trop humide",
  },
  prise: {
    name: "Prise connectée", hint: "Allume, éteint, mesure la conso", color: "#B8860B", shadow: "rgba(184,134,11,0.35)", shape: "plug",
    steps: ["Branchez la prise dans le mur.", "Appuyez 5 secondes sur son bouton.", "Lâchez quand la lumière clignote vite."],
    reco: "veille_nuit", recoTitle: "Couper l'appareil branché s'il reste en veille la nuit",
  },
  fumee: {
    name: "Détecteur de fumée", hint: "Sonne en cas de fumée", color: "#C42B1C", shadow: "rgba(196,43,28,0.35)", shape: "",
    steps: ["Retirez la languette en plastique de la pile.", "Appuyez 5 secondes sur le bouton test.", "Lâchez quand la lumière clignote."],
    reco: "alerte_fumee", recoTitle: "Prévenir tout de suite sur le téléphone en cas de fumée",
  },
  fuite: {
    name: "Détecteur de fuite d'eau", hint: "Sous l'évier ou la machine", color: "#C42B1C", shadow: "rgba(196,43,28,0.35)", shape: "",
    steps: ["Retirez la languette en plastique de la pile.", "Appuyez 5 secondes sur le bouton du dessus.", "Lâchez quand la lumière clignote."],
    reco: null, recoTitle: "",
  },
  lumiere: {
    name: "Ampoule connectée", hint: "S'allume depuis l'écran", color: "#5D6B7A", shadow: "rgba(93,107,122,0.35)", shape: "",
    steps: ["Vissez l'ampoule et allumez l'interrupteur.", "Éteignez et rallumez 5 fois de suite.", "Attendez que l'ampoule clignote."],
    reco: "lumiere_nuit_mouvement", recoTitle: "Allumer doucement la lumière quand on passe la nuit",
  },
};

const ORDER = ["ouverture", "mouvement", "thermo", "prise", "fumee", "lumiere", "fuite"];

export class AddDevicePage extends Page {
  init() {
    this.s = { phase: "choose", type: null, help: false, remaining: 0, method: null, device: null, room: null, reco: null, recoOn: true };
    this._unsub = null;
    // Opened from an idea (« Ajouter le capteur »): the type is already chosen.
    if (this.params.type && TYPES[this.params.type]) this.later(0, () => this.pick(this.params.type));
  }

  destroy() {
    this.stopPairing(true);
    super.destroy();
  }

  async stopPairing(silent) {
    if (this._tick) clearInterval(this._tick);
    this._tick = null;
    if (this._unsub) {
      try {
        this._unsub();
      } catch (e) {
        /* ignore */
      }
      this._unsub = null;
    }
    if (this.s.method && this.s.method !== "none") {
      this.s.method = null;
      try {
        await this.api.stopPairing();
      } catch (e) {
        if (!silent) console.warn("[maison-facile] pairing/stop", e);
      }
    }
  }

  template() {
    const phase = this.s.phase;
    return html`<div class="sheet-wrap"><div class="sheet add-sheet">
      <header class="add-head">
        <div class="row"><span class="li-icon" style="background:#0067C0;width:44px;height:44px;border-radius:14px">${icon("plus", 24, { stroke: 2.4 })}</span><h1>Ajouter un appareil</h1></div>
        <button type="button" class="btn secondary sm" data-action="cancel">${phase === "found" ? "Fermer" : "Annuler"}</button>
      </header>
      <div class="add-body" data-key="phase-${phase}">
        ${phase === "choose" ? this.choose() : phase === "wifi" ? this.wifi() : phase === "pair" ? this.pair() : phase === "noradio" ? this.noRadio() : this.found()}
      </div>
    </div></div>`;
  }

  choose() {
    return html`<div class="stack" style="gap:20px">
      <h2>Quel appareil voulez-vous ajouter ?</h2>
      <p class="lead sub" style="font-size:17px">Touchez celui qui ressemble au vôtre. On vous montre ensuite comment faire, en image.</p>
      ${(this.data.cloud || []).length ? cloudNotice(this.data.cloud) : ""}
      <div class="type-grid">${ORDER.map((k) => {
        const t = TYPES[k];
        return html`<button type="button" class="type-card" data-action="pick" data-type="${k}">
          <span class="tc-icon" style="background:${t.color};box-shadow:0 8px 18px ${t.shadow}">${icon(deviceIcon(k), 30)}</span>
          <span><span class="tc-name">${t.name}</span><span class="tc-hint">${t.hint}</span></span>
        </button>`;
      })}
        <button type="button" class="type-card" data-action="wifi" data-key="type-wifi">
          <span class="tc-icon" style="background:#00838F;box-shadow:0 8px 18px rgba(0,131,143,0.35)">${icon("cloud", 30)}</span>
          <span><span class="tc-name">Appareil Wi-Fi</span><span class="tc-hint">Avec une appli : Smart Life, eWeLink…</span></span>
        </button>
      </div>
      <p class="sub" style="font-size:15px">Vous ne savez pas ? ${say(this.app, "Regardez l'étiquette sous l'appareil, ou demandez à votre installateur.")}</p>
      <div class="gd-before"><span class="grow">${icon("help", 20)} Pas encore acheté ? Voyez ce qui marche bien avec votre box.</span>
        <button type="button" class="btn secondary sm" data-action="open-guide">Bien choisir ses appareils</button></div>
    </div>`;
  }

  /** « Appareil Wi-Fi »: friendly explanation, nothing is blocked. */
  wifi() {
    return html`<div class="stack" style="gap:18px;max-width:780px">
      <h2>Un appareil Wi-Fi</h2>
      ${cloudNotice(null)}
      <div class="stack" style="gap:10px">
        <strong style="font-size:18px">Que faire ?</strong>
        <ol class="numbered">
          <li>Shelly, appareil « Matter » ou ESPHome : branchez-le et reliez-le au Wi-Fi de la maison. La box le trouve souvent toute seule (voyez « Idées », rubrique « Trouvées chez vous »).</li>
          <li>Appareil avec une appli (Smart Life, eWeLink…) : il marche avec son appli. ${say(this.app, "Pour le voir ici, demandez à votre installateur de le relier.")}</li>
          <li>Pas encore acheté ? Préférez la version « Zigbee » : elle s'ajoute ici en 3 gestes.</li>
        </ol>
      </div>
      <div class="row wrap" style="gap:12px">
        <button type="button" class="btn primary" data-action="open-guide">Bien choisir ses appareils</button>
        <button type="button" class="btn secondary" data-action="back">Choisir un autre appareil</button>
      </div>
    </div>`;
  }

  demo(t) {
    return html`<div class="demo" role="img" aria-label="Démonstration animée : un doigt appuie sur le bouton du ${t.name.toLowerCase()}, la lumière clignote et la box le reconnaît.">
      <div class="device ${t.shape}">
        ${t.shape === "thermo" ? html`<span class="screen">21,5°</span>` : ""}
        <span class="led"></span>
        <span class="press"></span>
        <span class="dev-label">${t.name}</span>
      </div>
      <div class="finger"></div>
      <span class="wave"></span><span class="wave w2"></span>
      <div class="box"><span class="bled"></span><span>Votre box</span></div>
    </div>`;
  }

  /** « 2 min 30 », « 45 s », or null when the time is over. */
  leftText(remaining) {
    const min = Math.floor(remaining / 60);
    const sec = remaining % 60;
    return remaining <= 0 ? null : min >= 1 ? `${min} min${sec >= 30 ? " 30" : ""}` : `${sec} s`;
  }

  pair() {
    const t = TYPES[this.s.type];
    const left = this.leftText(this.s.remaining);
    return html`<div class="pair">
      <div class="demo-col">
        ${this.demo(t)}
        <div class="row sub" style="gap:10px;font-size:15px">${icon("play", 18)}Démo de 3 secondes qui tourne en boucle</div>
      </div>
      <div class="grow stack" style="gap:14px">
        <h2 style="font-size:28px">${t.name} : 3 gestes</h2>
        <ol class="gestures">${t.steps.map((s, i) => html`<li style="animation-delay:${i}s"><span class="gn">${i + 1}</span>${s}</li>`)}</ol>
        ${this.s.method === null
          ? html`<div class="listening"><span class="spinner" aria-hidden="true" style="width:18px;height:18px"></span>La box se prépare…</div>`
          : left
            ? html`<div class="listening" role="status"><span class="pulse" aria-hidden="true"></span>La box écoute… il vous reste <span class="pair-left">${left}</span> pour faire ces gestes.</div>`
            : html`<div class="alert" style="gap:10px"><span style="font-weight:700;font-size:16px">Le temps est écoulé. Pas grave : on recommence.</span><button type="button" class="btn" data-action="restart-pair">Recommencer</button></div>`}
        <div class="row wrap" style="gap:12px;margin-top:auto">
          <button type="button" class="btn secondary sm" data-action="help" aria-expanded="${this.s.help ? "true" : "false"}">Ça ne marche pas ?</button>
          <button type="button" class="btn ghost" data-action="back">Choisir un autre appareil</button>
        </div>
        ${this.s.help
          ? html`<ul class="help-list">
              <li>Rapprochez l'appareil à moins de 2 mètres de la box.</li>
              <li>Vérifiez que la petite lumière clignote bien. Sinon, gardez le doigt appuyé plus longtemps.</li>
              <li>Toujours rien ? Changez la pile, puis recommencez.</li>
              <li>Si l'appareil était déjà utilisé ailleurs, remettez-le à zéro (voir sa notice).</li>
            </ul>`
          : ""}
      </div>
    </div>`;
  }

  noRadio() {
    if (this.data.discovery) {
      // Box installed without hardware: nothing is broken, the antenna is still to buy.
      return html`<div class="stack" style="gap:18px;max-width:720px">
        <div class="found-hero"><span class="fh" style="background:#0067C0">${icon("signal", 38)}</span><h2>Pas encore d'antenne Zigbee</h2></div>
        <p style="font-size:17px;line-height:1.5">C'est normal : votre box n'a pas encore sa petite antenne (une clé USB). Elle sert aux capteurs, prises et lumières sans fil. Branchez-la quand vous l'aurez : la box la reconnaît toute seule.</p>
        <div class="row wrap"><button type="button" class="btn primary" data-action="open-buy">${icon("plug", 20)}Quoi acheter ?</button><button type="button" class="btn secondary" data-action="restart-pair">Elle est branchée, réessayer</button><button type="button" class="btn secondary" data-action="back">Retour</button></div>
      </div>`;
    }
    return html`<div class="stack" style="gap:18px;max-width:720px">
      <div class="found-hero"><span class="fh" style="background:#F7630C">${icon("warn", 38)}</span><h2>Aucune antenne sans fil trouvée</h2></div>
      <p style="font-size:17px;line-height:1.5">Pour ajouter un appareil, la box a besoin de sa petite antenne sans fil (une clé branchée sur la box). Vérifiez qu'elle est bien enfoncée, puis réessayez. ${say(this.app, "Si cela ne suffit pas, demandez à votre installateur.")}</p>
      <div class="row wrap"><button type="button" class="btn primary" data-action="restart-pair">Réessayer</button><button type="button" class="btn secondary" data-action="back">Retour</button></div>
    </div>`;
  }

  found() {
    const d = this.s.device;
    const t = TYPES[this.s.type] || null;
    const info = typeInfo(d.type);
    const rooms = this.data.rooms || [];
    const reco = this.s.reco;
    return html`<div class="stack" style="gap:20px;max-width:780px">
      <div class="found-hero" role="status">
        <span class="fh">${icon("check", 40, { stroke: 2.6 })}</span>
        <div class="stack" style="gap:4px"><h2>${d.type_label || info.label} trouvé !</h2><p class="sub" style="font-size:17px">« ${d.name} » fonctionne déjà. Dernière question :</p></div>
      </div>
      <div class="stack" style="gap:10px">
        <strong style="font-size:18px" id="mf-room-q">Dans quelle pièce l'avez-vous mis ?</strong>
        <div class="pick-row" role="group" aria-labelledby="mf-room-q">
          ${rooms.map((r) => html`<button type="button" class="opt" data-action="room" data-area="${r.area_id}" aria-pressed="${this.s.room === r.area_id ? "true" : "false"}" ${this.isBusy("assign") ? "disabled" : ""}>${r.name}</button>`)}
        </div>
        ${!rooms.length ? html`<p class="sub">Aucune pièce : vous pourrez la choisir plus tard dans Réglages.</p>` : ""}
      </div>
      ${reco
        ? html`<button type="button" class="check-row" data-action="reco" aria-pressed="${this.s.recoOn ? "true" : "false"}" style="background:var(--surface)">
            <span class="check-box">${this.s.recoOn ? icon("check", 18, { stroke: 3 }) : ""}</span>
            <span class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="cr-title">${reco.title || (t && t.recoTitle)}</strong><span class="cr-why">Automatisme conseillé pour cet appareil</span></span>
            ${reco.recommended ? html`<span class="tag">Recommandé</span>` : ""}
          </button>`
        : ""}
      <div class="row wrap" style="gap:12px">
        <button type="button" class="btn primary" data-action="finish" ${this.isBusy("finish") ? "disabled" : ""}>${this.isBusy("finish") ? "Un instant…" : "Terminer"}</button>
        <button type="button" class="btn secondary" data-action="again">Ajouter un autre appareil</button>
      </div>
    </div>`;
  }

  async startPairing() {
    await this.stopPairing(true);
    this.setState({ phase: "pair", method: null, remaining: 0, help: false });
    try {
      this._unsub = await this.api.subscribe("pairing/subscribe", (msg) => this.onPairingMessage(msg));
      if (this.destroyed) return this.stopPairing(true);
    } catch (e) {
      console.warn("[maison-facile] pairing/subscribe", e);
    }
    try {
      const r = await this.api.startPairing(this.s.type);
      if (this.destroyed) return undefined;
      if (!r || r.method === "none") {
        await this.stopPairing(true);
        return this.setState({ phase: "noradio", method: "none" });
      }
      const end = Date.now() + (r.duration || 180) * 1000;
      this.setState({ method: r.method, remaining: r.duration || 180 });
      this._tick = setInterval(() => {
        // Hidden tab: nothing to paint (the end time is absolute, the next tick catches up).
        if (typeof document !== "undefined" && document.hidden) return;
        const remaining = Math.max(0, Math.round((end - Date.now()) / 1000));
        const before = this.leftText(this.s.remaining);
        this.s.remaining = remaining;
        if (remaining <= 0) {
          clearInterval(this._tick);
          this._tick = null;
          this.setState({ method: "expired" });
          return;
        }
        // Only the countdown text changes: no full page render every second.
        const text = this.leftText(remaining);
        const el = this.el?.querySelector(".pair-left");
        if (!el) this.render();
        else if (text !== before) el.textContent = text;
      }, 1000);
    } catch (e) {
      await this.stopPairing(true);
      this.setState({ phase: "choose" });
      this.app.toast(this.app.errorText(e, "Impossible de lancer la recherche d'appareil."), () => this.pick(this.s.type));
    }
    return undefined;
  }

  async onPairingMessage(msg) {
    if (!msg || msg.event !== "device_found" || !msg.device || this.s.phase !== "pair") return;
    const device = msg.device;
    await this.stopPairing(true);
    const room = device.area_id || device.suggested_area_id || null;
    this.api.replaceDevice(device);
    this.setState({ phase: "found", device, room, reco: null, recoOn: true });
    if (room) this.assign(room);
    // Opened from an idea: the device is for that idea, no other suggestion.
    if (this.params.back !== "ideas") this.loadReco(device);
  }

  async loadReco(device) {
    try {
      const items = await this.api.listRecommendations();
      const t = TYPES[this.s.type];
      const wanted = t?.reco || TYPES[device.type]?.reco;
      const r = items.find((x) => x.id === wanted);
      if (r) this.setState({ reco: r, recoOn: true });
    } catch (e) {
      /* the suggestion is optional */
    }
  }

  async assign(area) {
    const d = this.s.device;
    await this.run("assign", async () => {
      const dev = await this.api.assignDevice(d.device_id, area);
      if (dev) this.s.device = dev;
    }, "Impossible de ranger l'appareil dans cette pièce.");
  }

  pick(type) {
    this.s.type = type;
    this.startPairing();
  }

  async onAction(action, el) {
    switch (action) {
      case "pick":
        return this.pick(el.dataset.type);
      case "wifi":
        return this.setState({ phase: "wifi", type: null });
      case "open-guide":
        await this.stopPairing();
        return this.app.navigate("guide", { back: "add", backParams: { back: this.params.back, backParams: this.params.backParams } });
      case "open-buy":
        await this.stopPairing();
        return this.app.navigate("guide", { tab: "buy", need: "antenne", back: "add", backParams: { back: this.params.back, backParams: this.params.backParams } });
      case "help":
        return this.setState({ help: !this.s.help });
      case "back":
        await this.stopPairing();
        if (this.params.back === "ideas") return this.leave();
        return this.setState({ phase: "choose" });
      case "restart-pair":
        return this.startPairing();
      case "room":
        this.setState({ room: el.dataset.area });
        return this.assign(el.dataset.area);
      case "reco":
        return this.setState({ recoOn: !this.s.recoOn });
      case "again":
        await this.saveReco();
        return this.setState({ phase: "choose", device: null, reco: null, type: null });
      case "finish":
        await this.saveReco();
        return this.leave();
      case "cancel":
        await this.stopPairing();
        return this.leave();
      default:
    }
  }

  async saveReco() {
    // Only switch the suggestion on; unticking never disables an automation used by other devices.
    const r = this.s.reco;
    if (!r || !this.s.recoOn || r.enabled) return;
    await this.run("finish", () => this.api.applyRecommendations([{ id: r.id, enabled: !!this.s.recoOn, options: r.values || {} }]), "Impossible d'activer l'automatisme conseillé.");
  }

  leave() {
    const back = this.params.back || "home";
    this.app.navigate(this.data.onboarded ? back : "wizard", this.params.backParams || {});
  }
}
