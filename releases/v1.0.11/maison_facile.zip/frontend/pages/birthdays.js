// « Anniversaires » : upcoming birthdays, manual entry, contacts file (.vcf) and calendar
// import, reminder settings (websocket maison_facile/birthdays/*, CONTRACT.md §12).
// Reached from the idea « Anniversaires » (ideas.js, view "birthdays") or as its own page.
import { Page, html, raw } from "../lib.js";
import { icon } from "../icons.js";
import { smsHref } from "../components/idea-tile.js";
import { say } from "../components/audience.js";

const MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
const DAYS_BEFORE = [[0, "Pas de rappel avant"], [1, "1 jour avant"], [2, "2 jours avant"], [3, "3 jours avant"], [5, "5 jours avant"], [7, "1 semaine avant"], [14, "2 semaines avant"]];
const HOURS = Array.from({ length: 16 }, (_, i) => i + 6); // 6 h – 21 h
const MAX_BYTES = 2 * 1024 * 1024;
const PALETTE = ["#C2185B", "#6B47B8", "#0067C0", "#00838F", "#0E7A0D", "#E8590C", "#B8860B", "#5D6B7A"];

const CSS = `
.bd-list { display: flex; flex-direction: column; gap: 10px; }
.bd-row { display: flex; align-items: center; gap: 14px; padding: 12px 14px; border-radius: 16px; background: var(--surface-soft); border: 1px solid var(--line); }
.bd-row.today { background: var(--lit); border-color: var(--lit-border); }
.bd-avatar { width: 46px; height: 46px; flex-shrink: 0; border-radius: 50%; color: #FFFFFF; font-weight: 700; font-size: 20px; display: flex; align-items: center; justify-content: center; }
.bd-when { font-weight: 700; color: var(--text); }
.bd-actions { display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
.bd-actions a { text-decoration: none; }
.bd-form { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.bd-form label { display: flex; flex-direction: column; gap: 6px; font-weight: 600; font-size: 15px; }
.bd-form .full { grid-column: 1 / -1; }
.bd-date { display: grid; grid-template-columns: 80px 1fr 100px; gap: 8px; }
.bd-pick { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 12px; border: 1px solid var(--line); background: var(--surface-soft); cursor: pointer; }
.bd-pick input { width: 22px; height: 22px; flex-shrink: 0; }
.bd-pick.already { opacity: 0.6; }
.bd-picks { display: flex; flex-direction: column; gap: 8px; max-height: 420px; overflow: auto; }
.bd-side-btn { justify-content: flex-start; width: 100%; }
.bd-file { position: absolute; width: 1px; height: 1px; opacity: 0; overflow: hidden; }
.bd-note { display: flex; gap: 10px; align-items: flex-start; padding: 12px 14px; border-radius: 14px; background: var(--info-bg); color: var(--info-text); font-size: 15px; }
@media (max-width: 760px) { .bd-form { grid-template-columns: 1fr; } .bd-row { flex-wrap: wrap; } .bd-actions { width: 100%; justify-content: flex-start; } }
`;

function colorOf(name) {
  let h = 0;
  for (const c of String(name || "")) h = (h * 31 + c.charCodeAt(0)) % 997;
  return PALETTE[h % PALETTE.length];
}

/** Read a .vcf file as text: UTF-8, or Windows-1252 for old phones. */
export async function readVcfFile(file) {
  if (file.size > MAX_BYTES) throw new Error("too_big");
  const buf = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(buf);
  } catch (e) {
    return new TextDecoder("windows-1252").decode(buf);
  }
}

export class BirthdaysPage extends Page {
  init() {
    this.s = { data: null, error: false, form: null, importer: null, confirmClear: false, busy: {} };
    this.load();
  }

  async load() {
    try {
      const data = await this.api.ws("birthdays/list");
      if (!this.destroyed) this.setState({ data, error: false });
    } catch (e) {
      console.warn("[maison-facile] birthdays/list", e);
      if (!this.destroyed) this.setState({ error: true });
    }
  }

  // ----- templates ---------------------------------------------------------------

  template() {
    return html`<style>${raw(CSS)}</style>
      <header class="page-head">
        <div class="title">
          <button type="button" class="back-btn glass" data-action="bd-back" aria-label="Retour à l'idée Anniversaires">${icon("back", 24)}</button>
          <span class="page-icon" style="background:#C2185B;color:#FFFFFF;box-shadow:0 8px 18px rgba(194,24,91,0.35)">${icon("cake", 28)}</span>
          <div><h1>Anniversaires</h1><span class="sub" style="font-size:15px">Ne plus oublier les anniversaires de vos proches</span></div>
        </div>
      </header>
      <main class="ideas-main" data-key="birthdays">${this.body()}</main>`;
  }

  body() {
    if (this.s.error) {
      return html`<div class="glass empty"><span>Impossible de charger les anniversaires.</span><button type="button" class="btn primary sm" data-action="bd-retry">Réessayer</button></div>`;
    }
    const d = this.s.data;
    if (!d) return html`<div class="loading" role="status"><span class="spinner" aria-hidden="true"></span>Chargement…</div>`;
    return html`<div class="idea-detail">
      <section class="col">
        ${this.s.form ? this.formCard() : ""}
        ${this.s.importer ? this.importCard() : ""}
        ${this.listCard(d)}
      </section>
      <aside class="side ideas-side">
        ${this.app.isAdmin ? this.addCard() : ""}
        ${this.settingsCard(d)}
        ${this.app.isAdmin ? this.privacyCard(d) : ""}
      </aside>
    </div>`;
  }

  listCard(d) {
    const items = d.items || [];
    return html`<div class="glass card idea-card-block" data-key="list">
      <div class="row" style="justify-content:space-between"><h2 class="h2">Prochains anniversaires</h2>${items.length ? html`<span class="st-badge actif">${items.length}</span>` : ""}</div>
      <p class="bd-note" data-key="note">${icon("shield", 20)}<span>${d.no_auto_send_fr} Tout reste sur votre box.</span></p>
      ${items.length
        ? html`<div class="bd-list">${items.map((i) => this.row(i))}</div>`
        : html`<div class="empty" style="padding:18px 0"><span>Aucun anniversaire pour l'instant.</span>
            ${this.app.isAdmin ? html`<button type="button" class="btn primary sm" data-action="bd-new">${icon("plus", 18)}Ajouter un anniversaire</button>` : ""}</div>`}
    </div>`;
  }

  row(i) {
    const who = i.relation ? `${i.relation} (${i.name})` : i.name;
    const meta = [i.today ? "" : i.date_fr.replace(/^\w/, (c) => c.toUpperCase()), i.age_fr].filter(Boolean).join(" · ");
    const sms = smsHref(i.links);
    const links = i.today && sms
      ? [html`<a class="btn primary sm" href="${sms}">${icon("chat", 18)}SMS</a>`, html`<a class="btn secondary sm" href="${i.links.whatsapp}" target="_blank" rel="noopener">WhatsApp</a>`]
      : [];
    if (i.channel === "whatsapp") links.reverse();
    return html`<div class="bd-row ${i.today ? "today" : ""}" data-key="bd-${i.birthday_id}">
      <span class="bd-avatar" style="background:${colorOf(i.name)}" aria-hidden="true">${i.today ? icon("cake", 24) : (i.call_name || "?").charAt(0).toUpperCase()}</span>
      <span class="grow" style="display:flex;flex-direction:column;gap:2px;min-width:0">
        <strong style="font-size:17px">${who}</strong>
        <span style="font-size:15px"><span class="bd-when">${i.when_fr}</span>${meta ? html` · <span class="sub">${meta}</span>` : ""}</span>
        ${i.today ? html`<span class="sub" style="font-size:14px">Message prêt : « ${i.text} »</span>` : ""}
      </span>
      <span class="bd-actions">
        ${links}
        ${this.app.isAdmin
          ? html`<button type="button" class="btn secondary sm" data-action="bd-edit" data-id="${i.birthday_id}" aria-label="Modifier ${i.name}">Modifier</button>
            <button type="button" class="icon-btn" data-action="bd-delete" data-id="${i.birthday_id}" aria-label="Supprimer ${i.name}" ${this.isBusy(`del-${i.birthday_id}`) ? "disabled" : ""}>${icon("trash", 20)}</button>`
          : ""}
      </span>
    </div>`;
  }

  formCard() {
    const f = this.s.form;
    const title = f.birthday_id ? "Modifier l'anniversaire" : "Nouvel anniversaire";
    return html`<div class="glass card idea-card-block" data-key="form-${f.birthday_id || "new"}">
      <h2 class="h2">${title}</h2>
      <div class="bd-form">
        <label>Prénom (et nom)<input class="input" data-field="f" data-k="name" value="${f.name}" maxlength="60" autocomplete="off" placeholder="Josette"></label>
        <label>Lien ou petit nom (facultatif)<input class="input" data-field="f" data-k="relation" value="${f.relation}" maxlength="40" placeholder="Mamie"></label>
        <label class="full">Date d'anniversaire
          <span class="bd-date">
            <select class="select" data-field="f" data-k="day" data-value="${f.day}" aria-label="Jour">${Array.from({ length: 31 }, (_, n) => html`<option value="${n + 1}" ${n + 1 === Number(f.day) ? "selected" : ""}>${n + 1}</option>`)}</select>
            <select class="select" data-field="f" data-k="month" data-value="${f.month}" aria-label="Mois">${MONTHS.map((m, n) => html`<option value="${n + 1}" ${n + 1 === Number(f.month) ? "selected" : ""}>${m}</option>`)}</select>
            <input class="input" data-field="f" data-k="year" value="${f.year || ""}" inputmode="numeric" maxlength="4" placeholder="Année" aria-label="Année de naissance (facultative)">
          </span>
          <span class="sub" style="font-size:13px;font-weight:400">L'année est facultative : avec elle, on vous dit l'âge (« 80 ans ! »).</span>
        </label>
        <label>Téléphone (facultatif)<input class="input" type="tel" data-field="f" data-k="phone" value="${f.phone}" placeholder="06 12 34 56 78"></label>
        <label>Pour lui écrire
          <select class="select" data-field="f" data-k="channel" data-value="${f.channel}">
            <option value="sms" ${f.channel !== "whatsapp" ? "selected" : ""}>SMS</option>
            <option value="whatsapp" ${f.channel === "whatsapp" ? "selected" : ""}>WhatsApp</option>
          </select></label>
        <label class="full">Votre message (facultatif)
          <input class="input" data-field="f" data-k="message" value="${f.message}" maxlength="300" placeholder="Joyeux anniversaire {nom} !">
          <span class="sub" style="font-size:13px;font-weight:400">Laissez vide pour un message différent chaque année. {nom} = le petit nom, {age} = l'âge.</span>
        </label>
      </div>
      ${f.error ? html`<p class="form-error" role="alert">${f.error}</p>` : ""}
      <div class="row" style="justify-content:flex-end;gap:10px">
        <button type="button" class="btn secondary" data-action="bd-cancel">Annuler</button>
        <button type="button" class="btn primary" data-action="bd-save" ${this.isBusy("save") ? "disabled" : ""}>${this.isBusy("save") ? "Un instant…" : "Enregistrer"}</button>
      </div>
    </div>`;
  }

  importCard() {
    const im = this.s.importer;
    if (im.kind === "calendars") {
      const cals = im.calendars || [];
      return html`<div class="glass card idea-card-block" data-key="import-cals">
        <h2 class="h2">Depuis un agenda</h2>
        ${cals.length
          ? html`<p class="sub" style="font-size:15px">Choisissez l'agenda qui contient les anniversaires (Google Agenda : « Anniversaires »).</p>
            <div class="bd-picks">${cals.map((c) => html`<button type="button" class="bd-pick" data-action="bd-cal" data-entity="${c.entity_id}" data-key="cal-${c.entity_id}">${icon("cake", 20)}<span class="grow" style="text-align:left"><strong>${c.name}</strong>${c.birthdays ? html`<br><span class="sub" style="font-size:13px">Agenda d'anniversaires</span>` : ""}</span></button>`)}</div>`
          : html`<p class="sub" style="font-size:15px">Aucun agenda n'est encore relié à la maison. Vous pouvez relier Google Agenda (ou un agenda CalDAV) ${say(this.app, "dans les réglages avancés : demandez à votre installateur.")}</p>`}
        <div class="row" style="justify-content:flex-end"><button type="button" class="btn secondary" data-action="bd-import-cancel">Fermer</button></div>
      </div>`;
    }
    const cands = im.candidates || [];
    const fresh = cands.filter((c) => !c.already);
    const n = fresh.filter((c) => im.checked.has(c.key)).length;
    const source = im.kind === "vcf" ? "dans vos contacts" : "dans l'agenda";
    return html`<div class="glass card idea-card-block" data-key="import-${im.kind}">
      <h2 class="h2">${im.kind === "vcf" ? "Importer mes contacts" : "Importer depuis l'agenda"}</h2>
      <p class="sub" style="font-size:15px">${cands.length
        ? `${cands.length} anniversaire${cands.length > 1 ? "s trouvés" : " trouvé"} ${source}. Cochez ceux à garder : seuls le nom, la date et le numéro de portable sont enregistrés.`
        : `Aucun anniversaire trouvé ${source}.`}
        ${im.without_date ? ` ${im.without_date} contact${im.without_date > 1 ? "s" : ""} sans date d'anniversaire ignoré${im.without_date > 1 ? "s" : ""}.` : ""}</p>
      ${fresh.length > 1 ? html`<div class="row" style="gap:10px"><button type="button" class="btn link" data-action="bd-check-all">Tout cocher</button><button type="button" class="btn link" data-action="bd-check-none">Tout décocher</button></div>` : ""}
      <div class="bd-picks">${cands.map((c) => html`<label class="bd-pick ${c.already ? "already" : ""}" data-key="c-${c.key}">
        <input type="checkbox" data-field="pick" data-k="${c.key}" ${c.already ? "disabled" : im.checked.has(c.key) ? "checked" : ""}>
        <span class="grow" style="display:flex;flex-direction:column"><strong>${c.name}</strong>
          <span class="sub" style="font-size:14px">${c.day} ${MONTHS[c.month - 1]}${c.year ? ` ${c.year}` : ""}${c.phone ? " · portable" : ""}${c.already ? " · déjà enregistré" : ""}</span></span>
      </label>`)}</div>
      <div class="row" style="justify-content:flex-end;gap:10px">
        <button type="button" class="btn secondary" data-action="bd-import-cancel">Annuler</button>
        <button type="button" class="btn primary" data-action="bd-import-confirm" ${!n || this.isBusy("import") ? "disabled" : ""}>${this.isBusy("import") ? "Un instant…" : `Ajouter ${n || ""}`.trim()}</button>
      </div>
    </div>`;
  }

  addCard() {
    return html`<div class="glass card idea-card-block" data-key="add" style="gap:10px">
      <h2 class="h2">Ajouter</h2>
      <button type="button" class="btn primary bd-side-btn" data-action="bd-new">${icon("plus", 20)}Ajouter à la main</button>
      <label class="btn secondary bd-side-btn" ${this.isBusy("vcf") ? "aria-disabled=\"true\"" : ""}>
        ${icon("devices", 20)}${this.isBusy("vcf") ? "Lecture du fichier…" : "Importer mes contacts (.vcf)"}
        <input class="bd-file" type="file" accept=".vcf,text/vcard,text/x-vcard" data-field="vcf-file">
      </label>
      <button type="button" class="btn secondary bd-side-btn" data-action="bd-calendars" ${this.isBusy("cals") ? "disabled" : ""}>${icon("cake", 20)}Depuis un agenda</button>
      <span class="sub" style="font-size:13px">Contacts : sur votre téléphone, « Exporter » ou « Partager » vos contacts en fichier .vcf. Le fichier n'est pas gardé.</span>
    </div>`;
  }

  settingsCard(d) {
    const st = d.settings || {};
    const admin = this.app.isAdmin;
    const dis = admin ? "" : "disabled";
    const first = (d.items || []).find((i) => i.phone) || (d.items || [])[0];
    return html`<div class="glass card idea-card-block" data-key="settings" style="gap:10px">
      <h2 class="h2">Rappels</h2>
      <label class="opt-row">Rappels activés<input type="checkbox" data-field="set" data-k="enabled" ${st.enabled ? "checked" : ""} ${dis}></label>
      <label class="opt-row">Pour avoir le temps d'acheter un cadeau
        <select class="select" data-field="set" data-k="days_before" data-value="${st.days_before}" ${dis}>${DAYS_BEFORE.map(([v, l]) => html`<option value="${v}" ${v === st.days_before ? "selected" : ""}>${l}</option>`)}</select></label>
      <label class="opt-row">Heure du message
        <select class="select" data-field="set" data-k="hour" data-value="${st.hour}" ${dis}>${HOURS.map((h) => html`<option value="${h}" ${h === st.hour ? "selected" : ""}>${h} h</option>`)}</select></label>
      ${st.calendar_entity ? html`<label class="opt-row">Reprendre chaque jour les nouveaux anniversaires de l'agenda<input type="checkbox" data-field="set" data-k="sync_calendar" ${st.sync_calendar ? "checked" : ""} ${dis}></label>` : ""}
      <span class="sub" style="font-size:14px">${d.announce ? "Le jour J, l'enceinte l'annonce aussi à voix haute." : "Avec une enceinte (idée « Annonces à voix haute »), la maison l'annonce aussi à voix haute."}</span>
      ${!d.notify?.service_ok ? html`<span class="sub" style="font-size:14px">Aucun téléphone relié : installez l'application Home Assistant sur votre téléphone pour recevoir le message prêt à envoyer.</span>` : ""}
      ${admin && first && d.notify?.service_ok
        ? html`<button type="button" class="btn secondary" data-action="bd-test" data-id="${first.birthday_id}" ${this.isBusy("test") ? "disabled" : ""}>${icon("phone", 20)}${this.isBusy("test") ? "Un instant…" : "Tester sur mon téléphone"}</button>`
        : ""}
    </div>`;
  }

  privacyCard(d) {
    if (!(d.items || []).length) return "";
    return html`<div class="glass card idea-card-block" data-key="privacy" style="gap:10px">
      <h2 class="h2">Vos données</h2>
      <span class="sub" style="font-size:14px">Les dates et numéros restent sur votre box : ils ne sont jamais envoyés ailleurs, ni dans les rapports d'aide.</span>
      ${this.s.confirmClear
        ? html`<strong>Effacer les ${d.items.length} anniversaires ?</strong>
          <div class="row" style="gap:10px"><button type="button" class="btn secondary" data-action="bd-clear-cancel">Non</button><button type="button" class="btn primary" style="background:var(--mf-red)" data-action="bd-clear-yes" ${this.isBusy("clear") ? "disabled" : ""}>Oui, tout effacer</button></div>`
        : html`<button type="button" class="btn link" style="align-self:flex-start" data-action="bd-clear">${icon("trash", 18)}Tout effacer</button>`}
    </div>`;
  }

  // ----- actions -----------------------------------------------------------------

  emptyForm() {
    const now = new Date();
    return { birthday_id: null, name: "", relation: "", day: now.getDate(), month: now.getMonth() + 1, year: "", phone: "", channel: "sms", message: "", error: "" };
  }

  apply(r) {
    if (r && Array.isArray(r.items)) this.setState({ data: { ...this.s.data, ...r } });
    this.app.reload?.();
  }

  async onAction(action, el) {
    const app = this.app;
    switch (action) {
      case "bd-back":
        return this.params.onBack ? this.params.onBack() : app.navigate("ideas", { id: "anniversaire" });
      case "bd-retry":
        this.setState({ error: false });
        return this.load();
      case "bd-new":
        this.setState({ form: this.emptyForm(), importer: null });
        return this.focusForm();
      case "bd-edit": {
        const i = (this.s.data.items || []).find((x) => x.birthday_id === el.dataset.id);
        if (!i) return undefined;
        this.setState({ form: { birthday_id: i.birthday_id, name: i.name, relation: i.relation, day: i.day, month: i.month, year: i.year || "", phone: i.phone_display || "", channel: i.channel, message: i.message, error: "" }, importer: null });
        return this.focusForm();
      }
      case "bd-cancel":
        return this.setState({ form: null });
      case "bd-save":
        return this.save();
      case "bd-delete": {
        const id = el.dataset.id;
        const i = (this.s.data.items || []).find((x) => x.birthday_id === id);
        return this.run(`del-${id}`, async () => {
          const r = await this.api.ws("birthdays/delete", { birthday_id: id });
          this.apply(r);
          app.notify(`Anniversaire ${i ? `de ${i.call_name} ` : ""}supprimé.`);
        }, "Impossible de supprimer cet anniversaire.");
      }
      case "bd-calendars":
        return this.run("cals", async () => {
          const r = await this.api.ws("birthdays/calendars");
          this.setState({ importer: { kind: "calendars", calendars: r.calendars || [] }, form: null });
        }, "Impossible de lister les agendas.");
      case "bd-cal":
        return this.run("cals", async () => {
          const r = await this.api.ws("birthdays/import_calendar", { entity_id: el.dataset.entity });
          this.openImporter("calendar", r.candidates || [], 0, el.dataset.entity);
        }, "Impossible de lire cet agenda.");
      case "bd-import-cancel":
        return this.setState({ importer: null });
      case "bd-check-all":
        return this.setState({ importer: { ...this.s.importer, checked: new Set(this.s.importer.candidates.filter((c) => !c.already).map((c) => c.key)) } });
      case "bd-check-none":
        return this.setState({ importer: { ...this.s.importer, checked: new Set() } });
      case "bd-import-confirm":
        return this.confirmImport();
      case "bd-test":
        return this.run("test", async () => {
          const r = await this.api.ws("birthdays/test_notify", { birthday_id: el.dataset.id });
          app.notify(r.message_fr || "C'est envoyé.");
        }, "Le message n'a pas pu partir.");
      case "bd-clear":
        return this.setState({ confirmClear: true });
      case "bd-clear-cancel":
        return this.setState({ confirmClear: false });
      case "bd-clear-yes":
        return this.run("clear", async () => {
          const r = await this.api.ws("birthdays/clear");
          this.setState({ confirmClear: false, form: null, importer: null });
          this.apply(r);
          app.notify("Tous les anniversaires sont effacés.");
        }, "Impossible de tout effacer.");
      default:
    }
    return undefined;
  }

  focusForm() {
    this.later(30, () => this.el?.querySelector('[data-k="name"]')?.focus?.());
  }

  openImporter(kind, candidates, withoutDate, entity) {
    const checked = new Set(candidates.filter((c) => !c.already).map((c) => c.key));
    this.setState({ importer: { kind, candidates, without_date: withoutDate, checked, entity }, form: null });
  }

  async save() {
    const f = this.s.form;
    if (!f.name.trim()) return this.setState({ form: { ...f, error: "Indiquez le prénom de la personne." } });
    const item = { name: f.name, relation: f.relation, day: Number(f.day), month: Number(f.month), year: f.year ? String(f.year).trim() : null, phone: f.phone, channel: f.channel, message: f.message };
    if (f.birthday_id) item.birthday_id = f.birthday_id;
    this.s.busy = { ...this.s.busy, save: true };
    this.render();
    try {
      const r = await this.api.ws("birthdays/save", { item });
      this.setState({ form: null, busy: { ...this.s.busy, save: false } });
      this.apply(r);
      this.app.notify(f.birthday_id ? "C'est modifié." : `C'est noté : on vous préviendra pour ${r.item?.call_name || f.name}.`);
    } catch (err) {
      // Validation messages (date, phone…) are shown in the form itself.
      this.setState({ form: { ...f, error: this.app.errorText(err, "Impossible d'enregistrer cet anniversaire.") }, busy: { ...this.s.busy, save: false } });
    }
    return undefined;
  }

  async confirmImport() {
    const im = this.s.importer;
    const items = im.candidates.filter((c) => !c.already && im.checked.has(c.key)).map((c) => ({ name: c.name, day: c.day, month: c.month, year: c.year, phone: c.phone, source: im.kind }));
    return this.run("import", async () => {
      const r = await this.api.ws("birthdays/import_confirm", { items });
      this.setState({ importer: null });
      this.apply(r);
      this.app.notify(`${r.added} anniversaire${r.added > 1 ? "s ajoutés" : " ajouté"}.`);
      if (im.kind === "calendar" && im.entity) {
        const s2 = await this.api.ws("birthdays/settings", { calendar_entity: im.entity });
        this.apply(s2);
      }
    }, "Impossible d'ajouter ces anniversaires.");
  }

  async onInput(field, el, ev) {
    if (field === "f" && this.s.form) {
      this.s.form[el.dataset.k] = el.value; // no re-render while typing
      return;
    }
    if (ev.type !== "change") return;
    if (field === "pick" && this.s.importer) {
      const checked = new Set(this.s.importer.checked);
      if (el.checked) checked.add(el.dataset.k);
      else checked.delete(el.dataset.k);
      this.setState({ importer: { ...this.s.importer, checked } });
    } else if (field === "vcf-file") {
      const file = el.files && el.files[0];
      el.value = "";
      if (!file) return;
      await this.run("vcf", async () => {
        let content;
        try {
          content = await readVcfFile(file);
        } catch (e) {
          const err = new Error(e.message === "too_big" ? "Ce fichier est trop gros (2 Mo au plus)." : "Impossible de lire ce fichier.");
          err.code = "invalid_format";
          throw err;
        }
        const r = await this.api.ws("birthdays/import_vcf", { content });
        this.openImporter("vcf", r.candidates || [], r.without_date || 0);
      }, "Impossible de lire ce fichier de contacts.");
    } else if (field === "set") {
      const k = el.dataset.k;
      const value = el.type === "checkbox" ? !!el.checked : Number(el.value);
      await this.run("settings", async () => {
        const r = await this.api.ws("birthdays/settings", { [k]: value });
        this.apply(r);
        this.app.notify("Réglage enregistré.");
      }, "Impossible d'enregistrer ce réglage.");
    }
  }
}
