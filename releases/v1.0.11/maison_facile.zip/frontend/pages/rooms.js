import { Page, html, fmtNum, num, timeHM } from "../lib.js";
import { icon, deviceIcon } from "../icons.js";
import { roomSummary, roomColor, isOn, isUnavailable, typeInfo, deviceStateText } from "../components/model.js";

export class RoomsPage extends Page {
  init() {
    const rooms = this.data.rooms || [];
    const narrow = this.app.isNarrow;
    this.s = { sel: this.params.area || (narrow ? null : rooms[0]?.area_id || null), now: new Date() };
    this.every(15000, () => this.setState({ now: new Date() }));
  }

  dataChanged() {
    const rooms = this.data.rooms || [];
    if (this.s.sel && !rooms.some((r) => r.area_id === this.s.sel)) this.s.sel = this.app.isNarrow ? null : rooms[0]?.area_id || null;
    super.dataChanged();
  }

  template() {
    const rooms = this.data.rooms || [];
    const get = (id) => this.st(id);
    const selIndex = rooms.findIndex((r) => r.area_id === this.s.sel);
    const sel = rooms[selIndex];
    return html`
      <header class="page-head">
        <div class="title">
          <span class="page-icon" style="background:#F7630C;box-shadow:0 8px 18px rgba(247,99,12,0.35)">${icon("grid", 28)}</span>
          <div><h1>Mes pièces</h1><span class="sub" style="font-size:15px">Touchez une pièce pour la régler</span></div>
        </div>
        <span class="clock-pill glass">${timeHM(this.s.now)}</span>
      </header>
      <main class="page-main">
        <section class="room-list ${sel ? "has-sel" : ""}" aria-label="Liste des pièces">
          ${rooms.map((r, i) => {
            const sum = roomSummary(this.data, r, get);
            const count = sum.lightsOn + sum.switchesOn;
            const color = roomColor(r, i);
            const pressed = r.area_id === this.s.sel;
            return html`<button type="button" class="room-pick" data-key="${r.area_id}" data-action="pick" data-area="${r.area_id}" aria-pressed="${pressed ? "true" : "false"}" style="${pressed ? `border-color:${color}` : ""}">
              <span class="initial" style="background:${color}">${icon(r.icon, 28, { stroke: 1.9 })}</span>
              <span class="grow" style="display:flex;flex-direction:column;gap:2px"><span class="rp-name">${r.name}</span><span class="sub" style="font-size:15px">${count === 0 ? "Tout est éteint" : count === 1 ? "1 appareil allumé" : `${count} appareils allumés`}</span></span>
              ${sum.temp !== null ? html`<span class="rp-temp">${fmtNum(sum.temp, 1)}°</span>` : ""}
            </button>`;
          })}
          ${rooms.length === 0 ? html`<p class="glass card sub">Aucune pièce pour l'instant. Ajoutez-les dans Réglages.</p>` : ""}
          <button type="button" class="add-dashed" data-action="add">${icon("plus", 20, { stroke: 2.4 })}Ajouter un appareil</button>
        </section>
        ${sel ? this.detail(sel, selIndex, get) : html`<section class="detail glass no-sel" aria-label="Détail de la pièce"><div class="empty">Choisissez une pièce.</div></section>`}
      </main>`;
  }

  detail(room, index, get) {
    const sum = roomSummary(this.data, room, get);
    const color = roomColor(room, index);
    const climate = sum.climates[0];
    const cs = climate ? get(climate.entity_id) : null;
    const setpoint = cs ? num(cs.attributes?.temperature) : null;
    const toggles = [
      ...sum.lights.map((l) => ({ ...l, domain: "light" })),
      ...sum.switches.map((l) => ({ ...l, domain: "switch" })),
    ];
    const others = sum.devices.filter((d) => !d.entities?.light && !d.entities?.switch && !d.entities?.climate);
    return html`<section class="detail glass" aria-label="Détail de la pièce : ${room.name}">
      <div class="row">
        <button type="button" class="icon-btn back-link" data-action="unpick" aria-label="Retour à la liste des pièces">${icon("back", 24)}</button>
        <span class="color-bar" style="background:${color}" aria-hidden="true"></span>
        <h2>${room.name}</h2>
      </div>
      <div class="stats3">
        <div class="stat"><span class="label">Il fait</span><span class="value">${sum.temp !== null ? `${fmtNum(sum.temp, 1)}°` : "–"}</span></div>
        <div class="stat"><span class="label">Humidité</span><span class="value">${sum.hum !== null ? `${fmtNum(sum.hum, 0)} %` : "–"}</span></div>
        <div class="stat" style="padding:12px 16px;gap:8px">
          <span class="label">Chauffage demandé</span>
          ${climate && !isUnavailable(cs) && setpoint !== null
            ? html`<div class="thermo-ctl">
                <button type="button" class="round-btn cold" data-action="temp" data-delta="-0.5" data-entity="${climate.entity_id}" aria-label="Baisser d'un demi-degré">${icon("minus", 26, { stroke: 2.6 })}</button>
                <span class="setpoint" aria-live="polite">${fmtNum(setpoint, 1)}°</span>
                <button type="button" class="round-btn hot" data-action="temp" data-delta="0.5" data-entity="${climate.entity_id}" aria-label="Monter d'un demi-degré">${icon("plus", 26, { stroke: 2.6 })}</button>
              </div>`
            : html`<span class="sub" style="font-size:15px;padding:8px 0">${climate ? "Indisponible pour le moment" : "Pas de chauffage connecté"}</span>`}
        </div>
      </div>

      <h3 class="h2" style="font-size:18px;margin-top:4px">Lumières et prises</h3>
      ${toggles.length
        ? html`<div class="devices-grid">${toggles.map((t) => {
            const s = get(t.entity_id);
            const on = isOn(s);
            const unav = isUnavailable(s);
            return html`<button type="button" class="dev-toggle" data-key="${t.entity_id}" data-action="toggle" data-domain="${t.domain}" data-entity="${t.entity_id}" aria-pressed="${on ? "true" : "false"}" ${unav ? "disabled" : ""}>
              <span class="di">${icon(t.domain === "light" ? "bulb" : "plug", 24)}</span>
              <span style="display:flex;flex-direction:column;gap:2px"><span class="dn">${t.device.name}</span><span class="ds">${unav ? "Ne répond plus" : on ? "Allumé" : "Éteint"}</span></span>
            </button>`;
          })}</div>`
        : html`<p class="sub">Aucune lumière ni prise dans cette pièce.</p>`}

      ${others.length
        ? html`<h3 class="h2" style="font-size:18px;margin-top:4px">Capteurs</h3>
          <div class="stack" style="gap:8px">${others.map((d) => {
            const info = typeInfo(d.type);
            Object.values(d.entities || {}).forEach((id) => get(id));
            return html`<div class="sensor-line" data-key="${d.device_id}"><span class="sl-icon" style="background:${info.color}">${icon(deviceIcon(d.type), 20)}</span><span class="grow"><strong>${d.name}</strong><br><span class="sub" style="font-size:14px">${d.type_label || info.label}</span></span><span style="font-weight:700">${deviceStateText(this.hass, d)}</span>${d.battery !== null && d.battery !== undefined && d.battery <= 20 ? html`<span class="tag" style="background:#FFF0E2;color:#8A3B00">Pile faible</span>` : ""}</div>`;
          })}</div>`
        : ""}
    </section>`;
  }

  async onAction(action, el) {
    switch (action) {
      case "pick":
        this.setState({ sel: el.dataset.area });
        if (this.app.isNarrow) this.el.closest(".content")?.scrollTo?.(0, 0);
        return;
      case "unpick":
        return this.setState({ sel: null });
      case "add":
        return this.app.navigate("add", { back: "rooms" });
      case "toggle":
        return this.app.callService(el.dataset.domain, "toggle", { entity_id: el.dataset.entity }, "Impossible de changer cet appareil.");
      case "temp": {
        const id = el.dataset.entity;
        const s = this.hass.states[id];
        const cur = num(s?.attributes?.temperature);
        if (cur === null) return;
        const min = num(s.attributes?.min_temp) ?? 7;
        const max = num(s.attributes?.max_temp) ?? 30;
        const next = Math.max(min, Math.min(max, Math.round((cur + parseFloat(el.dataset.delta)) * 2) / 2));
        return this.app.callService("climate", "set_temperature", { entity_id: id, temperature: next }, "Impossible de régler le chauffage.");
      }
      default:
    }
  }
}
