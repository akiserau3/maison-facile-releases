import { Page, html } from "../lib.js";
import { icon, deviceIcon } from "../icons.js";
import { PALETTE } from "../styles.js";
import { typeInfo } from "../components/model.js";
import { say } from "../components/audience.js";

// Step keys and their labels. "prepare" only exists on a box prepared by the
// installer (provisioning, CONTRACT_KIT §5), right after "Bienvenue".
// "discover" (« Votre maison sans matériel ») replaces the devices step and « Avant
// d'acheter » on a box installed without hardware (state/get.discovery, installer v1.4).
const STEP_LABELS = {
  welcome: "Bienvenue",
  prepare: "Préparation",
  rooms: "Vos pièces",
  devices: "Vos appareils",
  discover: "Sans matériel",
  autos: "Automatismes",
  buy: "Avant d'acheter",
  phone: "Téléphone",
  done: "Terminé",
};
const PREP_STATE_TEXT = { pending: "En attente", running: "En cours…", done: "Fait", skipped: "Pas prévu", error: "À revoir" };
const SKIP_WAIT_MS = 60000; // "Continuer sans attendre" shows up after one minute

const SUGGESTED_ROOMS = [
  { name: "Salon", icon: "sofa" },
  { name: "Cuisine", icon: "kitchen" },
  { name: "Chambre", icon: "bed" },
  { name: "Bureau", icon: "desk" },
  { name: "Salle de bain", icon: "bath" },
  { name: "Entrée", icon: "door" },
  { name: "Garage", icon: "garage" },
  { name: "Chambre d'enfant", icon: "child" },
];

const norm = (s) => String(s || "").trim().toLowerCase();
const capitalize = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const DEVICES_SHOWN = 8;

export class WizardPage extends Page {
  init() {
    const state = this.data;
    const existing = state.rooms || [];
    const choices = [];
    for (const r of existing) choices.push({ name: r.name, area_id: r.area_id, icon: r.icon || "room", on: true });
    for (const r of SUGGESTED_ROOMS) {
      if (!choices.some((c) => norm(c.name) === norm(r.name))) choices.push({ name: r.name, icon: r.icon, on: existing.length === 0 && ["Salon", "Cuisine", "Chambre"].includes(r.name) });
    }
    const assign = {};
    for (const d of state.devices || []) assign[d.device_id] = d.area_id || d.suggested_area_id || "";
    const prov = state.provision || {};
    const withPrepare = !!(prov.active || prov.done);
    this.discovery = !!state.discovery;
    const hasDevices = (state.devices || []).length > 0;
    this.stepKeys = Object.keys(STEP_LABELS).filter((k) => {
      if (k === "prepare") return withPrepare;
      if (k === "discover") return this.discovery;
      if (k === "buy") return !this.discovery; // « Pour commencer » is in the discover step
      if (k === "devices") return !this.discovery || hasDevices; // TV, speaker… found on the network
      return true;
    });
    // Back from the buying guide (« Voir le guide complet »): same step again.
    const startStep = Math.max(0, this.stepKeys.indexOf(this.params.step));
    this.s = {
      step: startStep,
      prov: null,
      provError: false,
      canSkipWait: false,
      rooms: choices,
      newRoom: "",
      assign,
      showAll: false,
      recos: null,
      recoError: false,
      recoOn: {},
      night: state.settings?.night_mode === "voice" ? "voice" : "hour",
      updates: state.settings?.update_mode === "ask" ? "ask" : "auto",
      summary: null,
      disc: null, // discover step: {ideas, detected, starter, guide}
      discError: false,
    };
    // Follow the provisioning from the start: the checks are often done before "Commencer".
    if (withPrepare) this.startProvisionWatch();
    // Back from the buying guide on « Votre maison sans matériel ».
    if (this.key === "discover") this.loadDiscover();
  }

  // ----- rendering -------------------------------------------------------------

  /** Key of the current step ("welcome", "prepare", "rooms"…). */
  get key() {
    return this.stepKeys[this.s.step];
  }

  template() {
    const step = this.s.step;
    const key = this.key;
    const keys = this.stepKeys;
    return html`<div class="sheet-wrap"><div class="sheet">
      <aside class="wiz-steps" aria-label="Étapes">
        <div class="brand"><span class="logo">${icon("homeDoor", 26)}</span><span><b>Maison Facile</b><span>Installation</span></span></div>
        <ol>${keys.map((k, i) => html`<li class="${i < step ? "done" : i === step ? "cur" : ""}" ${i === step ? html`aria-current="step"` : ""}><span class="dotn">${i < step ? icon("check", 16, { stroke: 3 }) : i + 1}</span><span class="wl">${STEP_LABELS[k]}</span></li>`)}</ol>
      </aside>
      <section class="wiz-main">
        <div class="wiz-body" data-key="step-${key}">${this.stepBody(key)}</div>
        ${key !== "done"
          ? html`<footer class="wiz-foot">
              <span class="sub" style="font-size:15px">Étape ${step + 1} sur ${keys.length}</span>
              <div class="row wrap">
                ${key === "prepare" && this.prepRunning() && this.s.canSkipWait ? html`<button type="button" class="btn link" data-action="skip-wait">Continuer sans attendre</button>` : ""}
                ${key === "buy" ? html`<button type="button" class="btn link" data-action="later">Plus tard</button>` : ""}
                ${step > 0 ? html`<button type="button" class="btn secondary" data-action="prev">Précédent</button>` : ""}
                <button type="button" class="btn primary" data-action="next" ${this.isBusy("next") || !this.canNext() ? "disabled" : ""}>${this.nextLabel()}${icon("arrow", 20, { stroke: 2.4 })}</button>
              </div>
            </footer>`
          : ""}
      </section>
    </div></div>`;
  }

  nextLabel() {
    if (this.isBusy("next")) return "Un instant…";
    switch (this.key) {
      case "welcome":
        return "Commencer";
      case "prepare":
        if (this.prepRunning()) return "Préparation en cours…";
        return this.prepErrors().length ? "Continuer quand même" : "Suivant";
      case "phone":
        return "Terminer";
      default:
        return "Suivant";
    }
  }

  canNext() {
    if (this.key === "rooms") return this.s.rooms.some((r) => r.on);
    if (this.key === "prepare") return !this.prepRunning();
    return true;
  }

  stepBody(key) {
    switch (key) {
      case "welcome":
        return this.welcome();
      case "prepare":
        return this.prepareStep();
      case "rooms":
        return this.roomsStep();
      case "devices":
        return this.devicesStep();
      case "autos":
        return this.autosStep();
      case "buy":
        return this.buyStep();
      case "discover":
        return this.discoverStep();
      case "phone":
        return this.phoneStep();
      default:
        return this.doneStep();
    }
  }

  // ----- "On prépare votre maison…" (provisioning) ----------------------------------

  prepSteps() {
    return this.s.prov?.steps || [];
  }

  /** True while something is still being done (or the first status has not arrived). */
  prepRunning() {
    if (this.s.provError) return false;
    if (!this.s.prov) return true;
    return this.prepSteps().some((st) => st.state === "running" || st.state === "pending");
  }

  prepErrors() {
    return this.prepSteps().filter((st) => st.state === "error");
  }

  prepareStep() {
    const steps = this.prepSteps();
    const running = this.prepRunning();
    const errors = this.prepErrors();
    const admin = !!this.hass?.user?.is_admin;
    let list;
    if (this.s.provError && !steps.length) {
      list = html`<div class="glass card"><p>Impossible de savoir où en est la préparation.</p><button type="button" class="btn secondary sm" data-action="prep-reload">Réessayer</button></div>`;
    } else if (!this.s.prov) {
      list = html`<div class="row" style="gap:14px"><span class="spinner" aria-hidden="true"></span><span class="sub">Chargement…</span></div>`;
    } else {
      list = html`<ol class="prep-list">${steps.map((st) => {
        const glyph =
          st.state === "running"
            ? html`<span class="spinner" aria-hidden="true"></span>`
            : st.state === "done"
              ? icon("check", 20, { stroke: 3 })
              : st.state === "skipped"
                ? icon("minus", 18, { stroke: 2.6 })
                : st.state === "error"
                  ? icon("warn", 20, { stroke: 2.2 })
                  : "";
        return html`<li class="prep-item" data-key="${st.id}" data-state="${st.state}">
          <span class="pi-icon" aria-hidden="true">${glyph}</span>
          <span class="pi-text">
            <strong>${st.label_fr}</strong>
            ${st.message_fr ? html`<span class="pi-msg">${st.message_fr}</span>` : ""}
            ${st.state === "error" && admin ? html`<span><button type="button" class="btn link" style="padding:0;min-height:40px" data-action="prep-retry" data-id="${st.id}" ${this.isBusy("retry-" + st.id) ? "disabled" : ""}>${icon("refresh", 16)} Réessayer</button></span>` : ""}
          </span>
          <span class="pi-state">${PREP_STATE_TEXT[st.state] || ""}</span>
        </li>`;
      })}</ol>`;
    }
    let footer = "";
    if (this.s.prov && !running) {
      footer = errors.length
        ? html`<p class="prep-note" role="status">${errors.length > 1 ? "Certaines étapes n'ont" : "Une étape n'a"} pas abouti. Vous pouvez continuer : ${errors.length > 1 ? "elles sont expliquées" : "elle est expliquée"} dans Réglages, rubrique Dépannage.</p>`
        : html`<p class="prep-ok" role="status">${icon("check", 18, { stroke: 3 })} Tout est prêt.</p>`;
    }
    return html`<div class="stack" style="gap:18px">
      <h1>On prépare votre maison…</h1>
      ${running || !this.s.prov ? html`<p class="lead">${say(this.app, "La box installe et règle ce que votre installateur a prévu pour vous.")} Cela peut prendre quelques minutes : vous n'avez rien à faire.</p>` : ""}
      ${footer}
      <div aria-live="polite">${list}</div>
    </div>`;
  }

  async startProvisionWatch() {
    if (this._provWatch) return;
    this._provWatch = true;
    this.later(SKIP_WAIT_MS, () => this.setState({ canSkipWait: true }));
    try {
      const unsub = await this.api.subscribe("provision/subscribe", (msg) => this.setState({ prov: msg, provError: false }));
      if (this.destroyed) unsub();
      else this.onCleanup(unsub);
    } catch (e) {
      // No live updates: read the status now and every 5 s instead.
      console.warn("[maison-facile] provision/subscribe", e);
      this.loadProvision();
      this.every(5000, () => {
        if (this.prepRunning()) this.loadProvision();
      });
    }
  }

  async loadProvision() {
    try {
      this.setState({ prov: await this.api.provisionStatus(), provError: false });
    } catch (e) {
      this.setState({ provError: true });
    }
  }

  welcome() {
    const st = this.data.status || {};
    const n = st.device_count || (this.data.devices || []).length;
    const checks = [
      st.network_ok
        ? { ok: true, title: "Connectée à Internet", sub: "Par le câble réseau, automatiquement" }
        : { ok: false, title: "Pas encore d'Internet", sub: "Vérifiez le câble réseau. Vous pouvez continuer quand même." },
      st.radio_found
        ? { ok: true, title: "Antenne sans fil trouvée", sub: "Elle parle à vos capteurs" }
        : this.discovery
          ? { ok: "info", title: "Pas encore d'antenne Zigbee : c'est normal", sub: "Vous la brancherez quand vous voudrez. On vous montre quoi acheter." }
          : { ok: false, title: "Antenne sans fil introuvable", sub: say(this.app, "Vérifiez qu'elle est bien branchée sur la box, ou demandez à votre installateur.") },
      n > 0
        ? { ok: true, title: `${n} appareil${n > 1 ? "s" : ""} ${this.discovery ? "trouvé" : "de votre kit reconnu"}${n > 1 ? "s" : ""}`, sub: this.discovery ? "Sur le réseau de la maison" : "Capteurs, prises et lumières" }
        : this.discovery
          ? { ok: "info", title: "Aucun appareil pour l'instant", sub: "Beaucoup de choses marchent déjà sans rien acheter." }
          : { ok: false, title: "Aucun appareil pour l'instant", sub: "Vous pourrez les ajouter juste après, c'est guidé." },
    ];
    const lead = this.discovery
      ? "Votre box est prête, même sans matériel. En quelques minutes, nous allons créer vos pièces, vous montrer ce qui marche déjà et quoi acheter pour commencer."
      : "Votre box est prête. En quelques minutes, nous allons ranger vos appareils par pièce et activer les automatismes utiles. Vous n'avez rien à brancher de plus.";
    return html`<div class="stack" style="gap:22px">
      <h1 style="font-size:34px">Bienvenue chez vous !</h1>
      <p class="lead" style="font-size:18px">${lead}</p>
      <div class="stack" style="gap:12px">${checks.map((c) => html`<div class="check-card">
        <span class="cc-icon" style="background:${c.ok === "info" ? "#0067C0" : c.ok ? "#0E7A0D" : "#F7630C"}">${icon(c.ok === "info" ? "help" : c.ok ? "check" : "warn", 22, { stroke: c.ok ? 2.6 : 2 })}</span>
        <span><strong>${c.title}</strong><span class="s">${c.sub}</span></span>
        <span class="sr-only">${c.ok === "info" ? "Pour information." : c.ok ? "C'est bon." : "À vérifier."}</span>
      </div>`)}</div>
    </div>`;
  }

  roomsStep() {
    return html`<div class="stack" style="gap:20px">
      <h1>Quelles pièces avez-vous ?</h1>
      <p class="lead">Touchez une pièce pour l'ajouter ou la retirer.${(this.data.rooms || []).length ? " Celles déjà connues sont cochées." : ""}</p>
      <div class="room-choices">${this.s.rooms.map((r, i) => {
        const c = PALETTE[i % PALETTE.length];
        return html`<button type="button" class="room-choice" data-key="${r.name}" data-action="room" data-index="${i}" aria-pressed="${r.on ? "true" : "false"}" style="--rc:${c}">
          <span class="rc-icon">${icon(r.on ? "check" : "plus", 20, { stroke: r.on ? 3 : 2.6 })}</span>
          <span class="rc-name">${r.name}</span>
        </button>`;
      })}</div>
      <div class="add-room">
        <label style="flex:1;max-width:340px"><span class="sr-only">Autre pièce</span><input class="input" type="text" maxlength="50" placeholder="Autre pièce, par exemple : Buanderie" value="${this.s.newRoom}" data-field="newRoom" data-enter="add-room"></label>
        <button type="button" class="btn secondary sm" data-action="add-room">${icon("plus", 20)}Ajouter</button>
      </div>
    </div>`;
  }

  devicesStep() {
    const devices = this.data.devices || [];
    const rooms = this.data.rooms || [];
    if (!devices.length) {
      return html`<div class="stack" style="gap:16px"><h1>Où sont vos appareils ?</h1>
        <div class="glass empty"><span class="big-icon" style="background:#0067C0">${icon("signal", 34)}</span><span>Aucun appareil n'est encore connecté. Vous pourrez en ajouter à tout moment avec « Ajouter un appareil ».</span></div></div>`;
    }
    // Devices whose room was guessed (or missing) first: these are the ones to check.
    const sorted = devices.slice().sort((a, b) => Number(!!a.area_id) - Number(!!b.area_id));
    const shown = this.s.showAll ? sorted : sorted.slice(0, DEVICES_SHOWN);
    const rest = sorted.length - shown.length;
    return html`<div class="stack" style="gap:16px">
      <h1>Où sont vos appareils ?</h1>
      <p class="lead">Nous avons fait une proposition. Corrigez seulement si elle est fausse.</p>
      <div class="stack" style="gap:10px">
        ${shown.map((d) => {
          const info = typeInfo(d.type);
          return html`<div class="list-item" data-key="${d.device_id}">
            <span class="li-icon" style="background:${info.color}">${icon(deviceIcon(d.type), 22)}</span>
            <span class="grow" style="display:flex;flex-direction:column"><strong class="li-title">${d.name}</strong><span class="li-sub">${info.what}</span></span>
            <label class="field-label">Pièce
              <select class="select" data-field="assign" data-device="${d.device_id}" data-value="${this.s.assign[d.device_id] || ""}">
                <option value="">À choisir</option>
                ${rooms.map((r) => html`<option value="${r.area_id}" ${r.area_id === this.s.assign[d.device_id] ? "selected" : ""}>${r.name}</option>`)}
              </select>
            </label>
          </div>`;
        })}
        ${rest > 0 ? html`<p class="sub" style="font-size:15px">+ ${rest} autre${rest > 1 ? "s" : ""} appareil${rest > 1 ? "s" : ""} déjà rangé${rest > 1 ? "s" : ""} automatiquement · <button type="button" class="btn link" data-action="show-all" style="padding:0 4px">Tout voir</button></p>` : ""}
      </div>
    </div>`;
  }

  autosStep() {
    let list;
    if (this.s.recoError) list = html`<div class="glass card"><p>Impossible de lire les automatismes conseillés.</p><button type="button" class="btn secondary sm" data-action="retry-recos">Réessayer</button></div>`;
    else if (!this.s.recos) list = html`<p class="sub">Chargement…</p>`;
    else if (!this.s.recos.length) list = html`<p class="glass card sub">Pas d'automatisme conseillé pour le moment : ajoutez des appareils, on vous en proposera.</p>`;
    else
      list = html`<div class="stack" style="gap:10px">${this.s.recos.filter((r) => r.id !== "mode_nuit_heure").map((r) => {
        const on = !!this.s.recoOn[r.id];
        return html`<button type="button" class="check-row" data-key="${r.id}" data-action="reco" data-id="${r.id}" aria-pressed="${on ? "true" : "false"}">
          <span class="check-box">${on ? icon("check", 18, { stroke: 3 }) : ""}</span>
          <span class="grow" style="display:flex;flex-direction:column;gap:2px"><strong class="cr-title">${r.title}</strong><span class="cr-why">${r.why}</span></span>
          ${r.recommended ? html`<span class="tag">Recommandé</span>` : ""}
        </button>`;
      })}</div>`;
    const nightTime = (this.data.settings?.night_time || "23:00").replace(":00", " h").replace(":", " h ");
    return html`<div class="stack" style="gap:14px">
      <h1>Automatismes conseillés</h1>
      <p class="lead">Choisis d'après vos appareils. Vous pourrez tout changer plus tard.</p>
      ${list}
      <div class="check-card" style="flex-direction:column;align-items:stretch;gap:10px">
        <strong>Le mode nuit se déclenche…</strong>
        <div class="seg" role="group" aria-label="Déclenchement du mode nuit">
          <button type="button" class="opt center" data-action="night" data-value="hour" aria-pressed="${this.s.night === "hour" ? "true" : "false"}">Tous les soirs à ${nightTime} · Recommandé</button>
          <button type="button" class="opt center violet" data-action="night" data-value="voice" aria-pressed="${this.s.night === "voice" ? "true" : "false"}">Seulement avec « Bonne nuit »</button>
        </div>
      </div>
      <div class="check-card" style="flex-direction:column;align-items:stretch;gap:10px">
        <strong>Les mises à jour s'installent…</strong>
        <div class="seg" role="group" aria-label="Installation des mises à jour">
          <button type="button" class="opt center green" data-action="updates" data-value="auto" aria-pressed="${this.s.updates === "auto" ? "true" : "false"}">Toutes seules la nuit · Recommandé</button>
          <button type="button" class="opt center" data-action="updates" data-value="ask" aria-pressed="${this.s.updates === "ask" ? "true" : "false"}">Me demander avant</button>
        </div>
        <span class="sub" style="font-size:14px">Une sauvegarde de votre maison est faite avant chaque mise à jour.</span>
      </div>
    </div>`;
  }

  /** Optional, one screen: « Avant d'acheter vos appareils » (full guide: pages/guide.js). */
  buyStep() {
    const tips = [
      { ok: "yes", title: "Choisissez « Zigbee »", sub: `Il marche sans Internet et ses piles durent longtemps. ${this.data.status?.radio_found ? "Votre box a déjà l'antenne." : "Il faut une petite antenne Zigbee (clé USB) sur la box."}` },
      { ok: "warn", title: "Méfiez-vous du Wi-Fi avec appli", sub: "Smart Life, eWeLink… : il dépend d'Internet et du serveur du fabricant." },
      { ok: "mid", title: "Prise, ampoule, caméra : le Wi-Fi sans appli convient", sub: "Shelly, appareils « Matter » : la box les trouve toute seule." },
    ];
    return html`<div class="stack" style="gap:18px">
      <h1>Avant d'acheter vos appareils</h1>
      <p class="lead">Une règle simple évite les mauvaises surprises. Cette étape est facultative.</p>
      <div class="stack" style="gap:12px">${tips.map((t) => html`<div class="check-card">
        <span class="cc-icon" style="background:${t.ok === "yes" ? "#0E7A0D" : t.ok === "warn" ? "#F7630C" : "#0067C0"}">${icon(t.ok === "yes" ? "check" : t.ok === "warn" ? "warn" : "plug", 22, { stroke: t.ok === "yes" ? 2.6 : 2 })}</span>
        <span><strong>${t.title}</strong><span class="s">${t.sub}</span></span>
      </div>`)}</div>
      <div class="row wrap" style="gap:12px">
        <button type="button" class="btn secondary" data-action="open-guide">${icon("help", 20)}Voir le guide complet</button>
        <span class="sub" style="font-size:15px">Il reste dans Réglages, rubrique « Bien choisir ses appareils ».</span>
      </div>
    </div>`;
  }

  // ----- « Votre maison sans matériel » (discovery, installer v1.4) ---------------------

  async loadDiscover() {
    this.setState({ discError: false });
    const [ideas, guide] = await Promise.all([
      this.api.listIdeas().catch(() => null),
      this.api.getGuide().catch(() => null),
    ]);
    if (this.destroyed) return;
    if (!ideas && !guide) return this.setState({ discError: true });
    this.setState({ disc: { ideas, guide } });
  }

  discoverStep() {
    const d = this.s.disc;
    const ideas = d?.ideas?.items || [];
    const free = ideas.filter((i) => i.no_hardware && i.status !== "non_pertinent").slice(0, 4);
    const detectedIdeas = new Set((d?.ideas?.detected || []).flatMap((x) => x.ideas || []));
    const found = (d?.ideas?.detected || []).map((x) => x.label_fr).filter(Boolean);
    const netDevices = this.data.devices || []; // without antenna: found on the network (TV, speaker, printer…)
    const foundIdeas = ideas.filter((i) => detectedIdeas.has(i.id) && i.status !== "non_pertinent").slice(0, 3);
    const already = [
      { icon: "sun", color: "#B8860B", title: "Météo de votre maison", sub: "La température dehors sur l'accueil, prévisions comprises." },
      { icon: "moon", color: "#6B47B8", title: "Lever et coucher du soleil", sub: "Le mode nuit et les rappels du soir suivent la journée." },
      { icon: "cake", color: "#C2185B", title: "Anniversaires", sub: "Un rappel quelques jours avant, et le message prêt le jour J." },
      { icon: "palette", color: "#E8590C", title: "Thèmes de fêtes et de saisons", sub: "Noël, Halloween, printemps… l'accueil change tout seul." },
    ];
    const starter = d?.guide?.starter || null;
    const byId = Object.fromEntries((d?.guide?.items || []).map((i) => [i.id, i]));
    const starterItems = starter ? starter.items.map((id) => byId[id]).filter(Boolean) : [];
    let starterHtml;
    if (this.s.discError) starterHtml = html`<div class="glass card"><p>Impossible de charger le guide d'achat.</p><button type="button" class="btn secondary sm" data-action="disc-reload">Réessayer</button></div>`;
    else if (!d) starterHtml = html`<div class="row" style="gap:14px"><span class="spinner" aria-hidden="true"></span><span class="sub">Chargement…</span></div>`;
    else
      starterHtml = html`<div class="disc-starter glass card">
        <div class="row wrap" style="justify-content:space-between;gap:8px">
          <h2 class="h2" style="margin:0">${starter?.title || "Pour commencer"}</h2>
          ${starter?.budget ? html`<span class="st-badge actif">Environ ${starter.budget.min} à ${starter.budget.max} € en tout</span>` : ""}
        </div>
        ${starter?.intro ? html`<p class="sub" style="font-size:15px;line-height:1.45">${starter.intro}</p>` : ""}
        <ul class="disc-list">${starterItems.map((it) => html`<li data-key="st-${it.id}">
          <span class="li-icon" style="background:${it.color}">${icon(it.icon, 20)}</span>
          <span class="grow"><strong>${it.title}</strong>${it.price ? html`<span class="s">${it.price.min} à ${it.price.max} €</span>` : ""}</span>
        </li>`)}</ul>
        <div class="row wrap" style="gap:10px">
          <button type="button" class="btn primary" data-action="open-buy">${icon("plug", 20)}Voir le guide d'achat</button>
          <button type="button" class="btn secondary" data-action="open-guide">${icon("help", 20)}Zigbee, Wi-Fi : comprendre</button>
        </div>
      </div>`;
    return html`<div class="stack" style="gap:18px">
      <h1>Votre maison sans matériel</h1>
      <p class="lead">Pas encore d'antenne ni de capteur ? Aucun souci. Voici ce qui marche déjà, et quoi acheter pour commencer.</p>
      <section class="stack" style="gap:10px" aria-labelledby="disc-ok">
        <h2 id="disc-ok" class="h2" style="margin:0">Ce qui marche déjà, sans rien acheter</h2>
        <div class="disc-grid">${already.map((a) => html`<div class="check-card">
          <span class="cc-icon" style="background:${a.color}">${icon(a.icon, 22)}</span>
          <span><strong>${a.title}</strong><span class="s">${a.sub}</span></span>
        </div>`)}</div>
        ${netDevices.length || found.length
          ? html`<div class="check-card" data-key="disc-found">
              <span class="cc-icon" style="background:#0067C0">${icon("tv", 22)}</span>
              <span><strong>Trouvé chez vous</strong><span class="s">${capitalize([...new Set([...found, ...netDevices.map((x) => x.name)])].slice(0, 4).join(", "))}${foundIdeas.length ? ` · idées possibles : ${foundIdeas.map((i) => i.short || i.title).join(", ")}` : ""}</span></span>
            </div>`
          : ""}
        ${free.length
          ? html`<p class="sub" style="font-size:15px">Idées sans achat : ${free.map((i) => i.title).join(", ")}. Vous les trouverez dans « Idées », rubrique « Sans rien acheter ».</p>`
          : ""}
      </section>
      ${starterHtml}
    </div>`;
  }

  phoneStep() {
    const address = window.location.origin;
    return html`<div class="row phone-row" style="gap:36px;align-items:flex-start">
      <div class="grow stack" style="gap:18px">
        <h1>Votre maison sur votre téléphone</h1>
        <p class="lead">Avec l'application, vous recevez les alertes (fenêtre ouverte, fumée…) et vous pilotez la maison, même hors de chez vous.</p>
        <ol class="numbered">
          <li>Sur votre téléphone, installez l'application gratuite <strong>Home Assistant</strong> (App Store ou Google Play).</li>
          <li>Ouvrez-la, chez vous, connecté au WiFi de la maison : elle trouve la box toute seule.</li>
          <li>Si elle ne la trouve pas, tapez l'adresse ci-contre.</li>
          <li>Connectez-vous avec le même nom et mot de passe que sur cet écran, puis acceptez les notifications.</li>
        </ol>
        <p class="sub" style="font-size:15px">Pas de téléphone sous la main ? Vous pourrez le faire plus tard : l'adresse reste visible dans Réglages.</p>
      </div>
      <div class="phone-box">
        <span class="li-icon" style="background:#0067C0;width:56px;height:56px;border-radius:16px">${icon("phone", 30)}</span>
        <strong style="font-size:17px">Adresse de la maison</strong>
        <span class="address">${address}</span>
        <span class="sub" style="font-size:14px">À taper seulement si l'application ne trouve pas la box.</span>
      </div>
    </div>`;
  }

  doneStep() {
    const sm = this.s.summary || { rooms: 0, devices: 0, autos: 0 };
    return html`<div class="done-hero">
      <span class="hero-ok">${icon("check", 52, { stroke: 2.6 })}</span>
      <h1>C'est terminé !</h1>
      <p class="sub" style="font-size:18px">${sm.rooms} pièce${sm.rooms > 1 ? "s" : ""}, ${sm.devices} appareil${sm.devices > 1 ? "s" : ""} et ${sm.autos} automatisme${sm.autos > 1 ? "s" : ""} ${sm.rooms + sm.devices + sm.autos > 1 ? "sont prêts" : "est prêt"}. Tout est modifiable dans Réglages.</p>
      <div class="row wrap" style="justify-content:center">
        <button type="button" class="btn primary" style="min-height:56px;padding:0 30px;font-size:18px" data-action="open-home">Ouvrir ma maison${icon("arrow", 22, { stroke: 2.4 })}</button>
        <button type="button" class="btn secondary" data-action="add-device">${icon("plus", 20)}Ajouter un appareil</button>
      </div>
    </div>`;
  }

  // ----- behaviour ---------------------------------------------------------------

  afterRender() {
    if (this._focusStep !== this.s.step) {
      this._focusStep = this.s.step;
      const h = this.el.querySelector(".wiz-body h1");
      if (h && this._moved) {
        h.setAttribute("tabindex", "-1");
        h.focus({ preventScroll: true });
      }
      const body = this.el.querySelector(".wiz-body");
      if (body) body.scrollTop = 0;
    }
  }

  async loadRecos() {
    this.setState({ recoError: false });
    try {
      const items = await this.api.listRecommendations();
      const recoOn = {};
      for (const r of items) recoOn[r.id] = !!r.enabled;
      this.setState({ recos: items, recoOn });
    } catch (e) {
      this.setState({ recoError: true });
    }
  }

  go(step) {
    this._moved = true;
    this.setState({ step });
    if (this.key === "autos" && !this.s.recos) this.loadRecos();
    if (this.key === "discover" && !this.s.disc) this.loadDiscover();
  }

  onInput(field, el, ev) {
    if (field === "newRoom") this.s.newRoom = el.value;
    else if (field === "assign" && ev.type === "change") this.s.assign[el.dataset.device] = el.value;
  }

  async onAction(action, el) {
    switch (action) {
      case "room": {
        const rooms = this.s.rooms.slice();
        const i = Number(el.dataset.index);
        rooms[i] = { ...rooms[i], on: !rooms[i].on };
        return this.setState({ rooms });
      }
      case "add-room": {
        const name = (this.s.newRoom || "").trim();
        if (!name) return;
        const rooms = this.s.rooms.slice();
        const found = rooms.findIndex((r) => norm(r.name) === norm(name));
        if (found >= 0) rooms[found] = { ...rooms[found], on: true };
        else rooms.push({ name, icon: "room", on: true });
        return this.setState({ rooms, newRoom: "" });
      }
      case "show-all":
        return this.setState({ showAll: true });
      case "reco":
        return this.setState({ recoOn: { ...this.s.recoOn, [el.dataset.id]: !this.s.recoOn[el.dataset.id] } });
      case "retry-recos":
        return this.loadRecos();
      case "night":
        return this.setState({ night: el.dataset.value });
      case "updates":
        return this.setState({ updates: el.dataset.value });
      case "prep-retry": {
        const id = el.dataset.id;
        return this.run("retry-" + id, () => this.api.retryProvision(id).then((st) => st && this.setState({ prov: st })), "Impossible de relancer cette étape.");
      }
      case "prep-reload":
        return this.loadProvision();
      case "skip-wait":
      case "later":
        return this.go(this.s.step + 1);
      case "open-guide":
        return this.app.navigate("guide", { back: "wizard", backParams: { step: this.key } });
      case "open-buy":
        return this.app.navigate("guide", { tab: "buy", back: "wizard", backParams: { step: this.key } });
      case "disc-reload":
        return this.loadDiscover();
      case "prev":
        return this.go(Math.max(0, this.s.step - 1));
      case "next":
        return this.next();
      case "open-home":
        return this.app.navigate("home");
      case "add-device":
        return this.app.navigate("add", { back: "home" });
      default:
    }
  }

  async next() {
    const step = this.s.step;
    const key = this.key;
    if (key === "rooms") {
      const payload = this.s.rooms.filter((r) => r.on).map((r) => (r.area_id ? { name: r.name, area_id: r.area_id } : { name: r.name }));
      const ok = await this.run("next", async () => {
        const rooms = await this.api.setRooms(payload);
        // Refresh devices: suggested rooms may now point to the created areas.
        await this.api.loadState(true);
        const assign = { ...this.s.assign };
        for (const d of this.data.devices || []) {
          if (!assign[d.device_id] || !rooms.some((r) => r.area_id === assign[d.device_id])) assign[d.device_id] = d.area_id || d.suggested_area_id || "";
        }
        this.s.assign = assign;
        return true;
      }, "Impossible d'enregistrer les pièces.");
      if (ok) this.go(step + 1);
      return;
    }
    if (key === "devices") {
      const changes = (this.data.devices || []).filter((d) => (this.s.assign[d.device_id] || null) !== (d.area_id || null) && this.s.assign[d.device_id]);
      const ok = await this.run("next", async () => {
        for (const d of changes) await this.api.assignDevice(d.device_id, this.s.assign[d.device_id]);
        return true;
      }, "Impossible de ranger les appareils.");
      if (ok) this.go(step + 1);
      return;
    }
    if (key === "autos") {
      const ok = await this.run("next", async () => {
        await this.api.setSettings({ night_mode: this.s.night, update_mode: this.s.updates });
        if (this.s.recos && this.s.recos.length) {
          const items = this.s.recos.map((r) => ({
            id: r.id,
            enabled: r.id === "mode_nuit_heure" ? this.s.night === "hour" : !!this.s.recoOn[r.id],
            options: r.values || {},
          }));
          await this.api.applyRecommendations(items);
        }
        return true;
      }, "Impossible d'activer les automatismes.");
      if (ok) this.go(step + 1);
      return;
    }
    if (key === "phone") {
      const ok = await this.run("next", async () => {
        await this.api.completeOnboarding();
        return true;
      }, "Impossible de terminer l'installation.");
      if (ok) {
        const autos = (this.s.recos || []).filter((r) => (r.id === "mode_nuit_heure" ? this.s.night === "hour" : this.s.recoOn[r.id])).length;
        this.s.summary = { rooms: (this.data.rooms || []).length, devices: (this.data.devices || []).length, autos };
        this.go(step + 1);
      }
      return;
    }
    this.go(step + 1);
  }
}
