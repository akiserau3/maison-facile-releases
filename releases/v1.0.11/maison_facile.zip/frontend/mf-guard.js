// Maison Facile — commercial-mode guard (NOTES_commercial.md, CONTRACT.md §10).
//
// Loaded on EVERY page of Home Assistant's frontend through the official
// `frontend.add_extra_js_url` (registered by the integration at setup).
// While commercial mode is on and the advanced settings are locked for this
// user, it sends every Home Assistant page back to "Ma maison" (except /profile)
// and hides HA's sidebar (kiosk mode + a CSS fallback). In installer mode it
// only shows a small "Ma maison · Verrouiller" bar on HA's pages.
//
// Never breaks Home Assistant: every step is in try/catch, it does nothing when
// our websocket command does not answer (integration not loaded / old backend),
// and it can never loop (at most 4 redirections in 15 s).
(() => {
  "use strict";
  if (window.__maisonFacileGuard) return; // loaded twice (version change): keep the first

  const PANEL = "maison-facile";
  const PANEL_PATH = "/" + PANEL;
  const STATUS_CMD = "maison_facile/advanced/status";
  const LOCK_CMD = "maison_facile/advanced/lock";
  const SYNC_EVENT = "maison-facile-advanced"; // shared with the panel (api.js)
  const STYLE_ID = "mf-guard-style";
  const REFRESH_MS = 60000;
  const ROUTE_REFRESH_MS = 5000;
  const LOOP_MAX = 4;
  const LOOP_WINDOW_MS = 15000;

  // Pages a locked user may still see. Everything else goes back to Ma maison.
  const ALLOWED = [/^\/maison-facile(\/|$)/, /^\/profile(\/|$)/, /^\/auth(\/|$)/, /^\/onboarding/];

  // Inside <home-assistant-main>'s shadow root: the sidebar and its width.
  const MAIN_CSS =
    ":host{--ha-sidebar-width:0px!important;--mdc-drawer-width:0px!important;--ha-top-app-bar-width:100%!important}" +
    "ha-sidebar{display:none!important}";
  // Inside <ha-drawer>'s shadow root: new drawer (2026.10: .sidebar-shell / wa-drawer)
  // and older mwc drawer (2026.2: .mdc-drawer / .mdc-drawer-app-content).
  const DRAWER_CSS =
    ".sidebar-shell,.mdc-drawer,wa-drawer{display:none!important}" +
    ".app-content,.mdc-drawer-app-content{padding-inline-start:0!important;margin-left:0!important;margin-inline-start:0!important}";

  const g = {
    version: 1,
    status: null, // last answer of advanced/status (null = unknown)
    ready: false, // true once the integration answered: the panel then lets us handle the kiosk
    mode: "off", // "off" | "locked" | "installer"
    ownKiosk: false,
    lastRefresh: 0,
    retryConn: false,
    redirects: [],
    pausedUntil: 0,
    refreshing: null,
    timers: { wait: 0, refresh: 0, expiry: 0, retry: 0, settle: 0, keep: 0 },
    bar: null,
  };
  window.__maisonFacileGuard = g;

  const log = (...a) => {
    try {
      console.warn("[maison-facile guard]", ...a);
    } catch (e) {
      /* ignore */
    }
  };
  const shell = () => document.querySelector("home-assistant");
  const hassObj = () => {
    const h = shell()?.hass;
    return h && typeof h.callWS === "function" ? h : null;
  };
  const path = () => window.location.pathname || "/";
  const allowed = (p) => ALLOWED.some((re) => re.test(p));

  function computeMode() {
    const st = g.status;
    if (!st || !st.commercial_mode) return "off";
    const h = hassObj();
    // Our panel is not registered (integration unloaded): never trap anybody.
    if (h?.panels && !h.panels[PANEL]) return "off";
    return st.is_admin && st.unlocked ? "installer" : "locked";
  }

  // ----- status ------------------------------------------------------------------

  function setStatus(st) {
    g.status = st && typeof st === "object" ? { ...(g.status || {}), ...st } : null;
    if (g.status && g.status.is_admin === undefined) g.status.is_admin = !!hassObj()?.user?.is_admin;
    g.ready = !!g.status;
    scheduleExpiry();
    apply();
  }

  async function refresh() {
    const h = hassObj();
    if (!h) return;
    if (g.refreshing) return g.refreshing;
    g.lastRefresh = Date.now();
    g.refreshing = (async () => {
      try {
        const st = await h.callWS({ type: STATUS_CMD });
        g.retryConn = false;
        setStatus(st);
      } catch (err) {
        if (typeof err?.code === "string") {
          // The box answered (unknown_command, not_ready…): commercial mode is not active.
          g.retryConn = false;
          g.status = null;
          g.ready = false;
          apply();
        } else {
          // Connection lost: keep what we knew, try again soon.
          g.retryConn = true;
          clearTimeout(g.timers.retry);
          g.timers.retry = setTimeout(refresh, 10000);
        }
      } finally {
        g.refreshing = null;
        armInterval();
      }
    })();
    return g.refreshing;
  }

  function armInterval() {
    clearInterval(g.timers.refresh);
    g.timers.refresh = 0;
    // Only when something is hidden or shown by us (or the box was unreachable).
    if (g.mode !== "off" || g.retryConn) g.timers.refresh = setInterval(refresh, REFRESH_MS);
  }

  function scheduleExpiry() {
    clearTimeout(g.timers.expiry);
    const until = g.status?.unlocked && g.status.until ? new Date(g.status.until).getTime() : 0;
    if (!until) return;
    const delay = Math.max(1000, Math.min(until - Date.now() + 1000, 2 ** 31 - 1));
    g.timers.expiry = setTimeout(refresh, delay);
  }

  // ----- applying ------------------------------------------------------------------

  function apply() {
    try {
      const mode = computeMode();
      g.mode = mode;
      if (mode === "locked") {
        if (!allowed(path())) redirect();
        kiosk(true);
        css(true);
      } else {
        kiosk(false);
        css(false);
      }
      renderBar();
      // While locked, re-check cheaply (HA may re-render its shell or a panel may turn
      // the kiosk off when it is removed). Nothing runs when nothing is hidden.
      if (mode === "locked" && !g.timers.keep) g.timers.keep = setInterval(apply, 2000);
      else if (mode !== "locked" && g.timers.keep) {
        clearInterval(g.timers.keep);
        g.timers.keep = 0;
      }
    } catch (e) {
      log("apply", e);
    }
  }

  function redirect() {
    const now = Date.now();
    if (now < g.pausedUntil) return;
    const h = hassObj();
    if (!h?.panels) return; // panels not loaded yet: the next apply will do it
    g.redirects = g.redirects.filter((t) => now - t < LOOP_WINDOW_MS);
    if (g.redirects.length >= LOOP_MAX) {
      g.pausedUntil = now + 60000;
      log("too many redirections, pausing for 60 s");
      return;
    }
    g.redirects.push(now);
    // Same mechanism as HA's navigate(path, {replace: true}).
    const state = window.history.state;
    window.history.replaceState(state && state.root ? { root: true } : null, "", PANEL_PATH);
    window.dispatchEvent(new CustomEvent("location-changed", { detail: { replace: true } }));
  }

  function kiosk(on) {
    const h = hassObj();
    if (!h) return;
    if (on) {
      if (h.kioskMode !== true) {
        window.dispatchEvent(new CustomEvent("hass-kiosk-mode", { detail: { enable: true } }));
      }
      g.ownKiosk = true;
    } else if (g.ownKiosk) {
      g.ownKiosk = false;
      if (h.kioskMode) window.dispatchEvent(new CustomEvent("hass-kiosk-mode", { detail: { enable: false } }));
    }
  }

  function roots() {
    const ha = shell();
    const main = ha?.shadowRoot?.querySelector("home-assistant-main") || ha?.querySelector?.("home-assistant-main");
    const drawer = main?.shadowRoot?.querySelector("ha-drawer");
    return [
      [main?.shadowRoot, MAIN_CSS],
      [drawer?.shadowRoot, DRAWER_CSS],
    ];
  }

  function css(on) {
    for (const [root, text] of roots()) {
      if (!root) continue;
      try {
        const el = root.getElementById ? root.getElementById(STYLE_ID) : root.querySelector("#" + STYLE_ID);
        if (on && !el) {
          const s = document.createElement("style");
          s.id = STYLE_ID;
          s.textContent = text;
          root.appendChild(s);
        } else if (!on && el) {
          el.remove();
        }
      } catch (e) {
        log("css", e);
      }
    }
  }

  // ----- small floating bar ---------------------------------------------------------

  function goHome() {
    try {
      window.history.pushState(null, "", PANEL_PATH);
      window.dispatchEvent(new CustomEvent("location-changed", { detail: { replace: false } }));
    } catch (e) {
      window.location.assign(PANEL_PATH);
    }
  }

  async function lockNow(btn) {
    const h = hassObj();
    if (!h) return;
    if (btn) btn.disabled = true;
    try {
      const st = await h.callWS({ type: LOCK_CMD });
      setStatus(st);
      window.dispatchEvent(new CustomEvent(SYNC_EVENT, { detail: { source: "guard", status: g.status } }));
    } catch (e) {
      log("lock", e);
      if (btn) btn.disabled = false;
    }
  }

  function renderBar() {
    const p = path();
    const onPanel = /^\/maison-facile(\/|$)/.test(p);
    let kind = "";
    if (!onPanel && g.mode === "installer") kind = "installer";
    else if (!onPanel && g.mode === "locked" && allowed(p)) kind = "back";
    if (!kind) {
      if (g.bar) {
        g.bar.remove();
        g.bar = null;
      }
      return;
    }
    if (g.bar && g.bar.dataset.kind === kind && g.bar.isConnected) return;
    if (g.bar) g.bar.remove();
    const host = document.createElement("div");
    host.id = "mf-guard-bar";
    host.dataset.kind = kind;
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>
      .bar{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(16px + env(safe-area-inset-bottom,0px));z-index:7;
        display:flex;align-items:center;gap:8px;padding:6px 6px 6px 14px;border-radius:999px;max-width:calc(100vw - 32px);box-sizing:border-box;
        background:#1f2933;color:#fff;font:500 14px/1.2 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.25)}
      .bar.back{padding-left:6px}
      span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      button{font:inherit;min-height:40px;padding:0 14px;border-radius:999px;border:0;cursor:pointer;white-space:nowrap}
      .home{background:#fff;color:#1f2933}.lock{background:#E8590C;color:#fff}
      button:focus-visible{outline:3px solid #8ab4f8;outline-offset:2px}
      button[disabled]{opacity:.6;cursor:default}
    </style>${
      kind === "installer"
        ? `<div class="bar" role="region" aria-label="Mode installateur Maison Facile"><span>Mode installateur</span>
            <button type="button" class="home" data-a="home">Revenir à Ma maison</button>
            <button type="button" class="lock" data-a="lock">Verrouiller</button></div>`
        : `<div class="bar back" role="region" aria-label="Maison Facile">
            <button type="button" class="home" data-a="home">‹ Revenir à Ma maison</button></div>`
    }`;
    root.addEventListener("click", (ev) => {
      const b = ev.target.closest && ev.target.closest("button[data-a]");
      if (!b) return;
      if (b.dataset.a === "home") goHome();
      else if (b.dataset.a === "lock") lockNow(b).then(goHome);
    });
    document.body.appendChild(host);
    g.bar = host;
  }

  // ----- events -------------------------------------------------------------------

  function onRoute() {
    apply();
    // HA may still be swapping panels / re-rendering: check again a little later.
    clearTimeout(g.timers.settle);
    g.timers.settle = setTimeout(apply, 400);
    if (Date.now() - g.lastRefresh > ROUTE_REFRESH_MS) refresh();
  }

  function start() {
    window.addEventListener("location-changed", onRoute);
    window.addEventListener("popstate", onRoute);
    window.addEventListener(SYNC_EVENT, (ev) => {
      const d = ev.detail || {};
      if (d.source === "guard") return;
      if (d.status) setStatus(d.status);
      else refresh();
    });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden && g.ready) refresh();
    });
    refresh();
  }

  // Wait for <home-assistant> and its hass object (light polling, then slower).
  const t0 = Date.now();
  (function wait() {
    try {
      if (hassObj()) return start();
    } catch (e) {
      log("start", e);
      return;
    }
    g.timers.wait = setTimeout(wait, Date.now() - t0 < 30000 ? 250 : 2000);
  })();

  // Used by the panel (maison-facile-panel.js) and the tests.
  g.sync = () => apply();
  g.refresh = refresh;
  g.setStatus = setStatus;
})();
