// Maison Facile — Home Assistant custom panel (panel_custom entry point).
// Receives `hass`, `narrow`, `panel`, `route` from Home Assistant.
import { STYLES, THEME_DEFS } from "./styles.js";
import { Api, friendlyError } from "./api.js";
import { esc, html, morph, Page } from "./lib.js";
import { icon } from "./icons.js";
import { HomePage } from "./pages/home.js";
import { RoomsPage } from "./pages/rooms.js";
import { EnergyPage } from "./pages/energy.js";
import { SecurityPage } from "./pages/security.js";
import { SettingsPage } from "./pages/settings.js";
import { WizardPage } from "./pages/wizard.js";
import { AddDevicePage } from "./pages/add-device.js";
import { IdeasPage } from "./pages/ideas.js";
import { BirthdaysPage } from "./pages/birthdays.js";
import { GuidePage } from "./pages/guide.js";
import { HOME_STYLES_CSS } from "./pages/home-styles/index.js";
import { currentAppearance, particlesHtml, styleDef } from "./components/appearance.js";
import { say } from "./components/audience.js";

// First start opened from a family (non-admin) account: nothing can be configured from here.
class NotAdminPage extends Page {
  template() {
    return html`<div class="sheet-wrap"><div class="sheet" style="min-height:0;max-width:760px">
      <div class="done-hero" style="padding:44px 36px;gap:16px">
        <span class="hero-ok" style="background:#0067C0;box-shadow:0 14px 34px rgba(0,103,192,0.35)">${icon("lock", 46)}</span>
        <h1 style="font-size:30px;font-weight:800">L'installation doit être faite depuis le compte principal de la maison</h1>
        <p class="sub" style="font-size:18px;line-height:1.5;max-width:560px">Connectez-vous avec le compte principal (celui créé à la mise en service de la box) pour terminer l'installation. ${say(this.app, "Si vous ne le connaissez pas, demandez à votre installateur.")}</p>
        <button type="button" class="btn secondary" data-action="retry">${icon("refresh", 20)}Vérifier à nouveau</button>
      </div>
    </div></div>`;
  }
  onAction(action) {
    if (action === "retry") this.app.reload().then(() => this.app.data?.onboarded && this.app.navigate("home"));
  }
}

const PAGES = {
  notadmin: NotAdminPage,
  home: HomePage,
  rooms: RoomsPage,
  energy: EnergyPage,
  security: SecurityPage,
  ideas: IdeasPage,
  settings: SettingsPage,
  wizard: WizardPage,
  add: AddDevicePage,
  birthdays: BirthdaysPage,
  guide: GuidePage,
};

const TABS = [
  { id: "home", label: "Accueil", icon: "home", color: "#0067C0" },
  { id: "rooms", label: "Pièces", icon: "grid", color: "#F7630C" },
  { id: "energy", label: "Énergie", icon: "bolt", color: "#E0A100" },
  { id: "security", label: "Sécurité", icon: "shield", color: "#13A10E" },
  { id: "ideas", label: "Idées", icon: "bulb", color: "#E0A100" },
  { id: "settings", label: "Réglages", icon: "gear", color: "#8764B8" },
];


class MaisonFacilePanel extends HTMLElement {
  constructor() {
    super();
    this._hass = null;
    this._narrow = false;
    this.panel = null;
    this.route = null;
    this.api = new Api(() => this._hass);
    this.page = null;
    this.pageId = null;
    this.params = {};
    this.themePreview = null; // {theme?, theme_auto?} shown before the box answers
    this.styleTrial = null; // home style being tried (not saved): « Vous essayez le style Néon »
    this.problemCount = 0;
    this._toasts = [];
    this._toastSeq = 0;
    this._booted = false;
    this._loadError = false;
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `<style>${STYLES}${HOME_STYLES_CSS}</style><div class="app" data-theme="clair" data-tone="light"><div class="fx" id="fx" aria-hidden="true"></div><div class="app-banner" id="banner" hidden></div><div class="content" id="content"></div><nav class="taskbar" id="taskbar" aria-label="Navigation principale"></nav><div class="toasts" id="toasts" role="status" aria-live="polite"></div></div>`;
    this.$app = this.shadowRoot.querySelector(".app");
    this.$content = this.shadowRoot.getElementById("content");
    this.$taskbar = this.shadowRoot.getElementById("taskbar");
    this.$toasts = this.shadowRoot.getElementById("toasts");
    this.$banner = this.shadowRoot.getElementById("banner");
    this.$fx = this.shadowRoot.getElementById("fx");
    this._kiosk = null; // what we changed in Home Assistant's shell (see _enableKiosk)
    this.$banner.addEventListener("click", (ev) => {
      const b = ev.target.closest("button[data-banner]");
      if (!b) return;
      if (b.dataset.banner === "open-ha") this.openHomeAssistant();
      else if (b.dataset.banner === "lock") this.lockAdvanced();
    });
    this.$taskbar.addEventListener("click", (ev) => {
      const a = ev.target.closest("a[data-tab]");
      if (!a) return;
      ev.preventDefault();
      this.navigate(a.dataset.tab);
    });
    this.$toasts.addEventListener("click", (ev) => {
      const b = ev.target.closest("button[data-toast]");
      if (!b) return;
      const t = this._toasts.find((x) => String(x.id) === b.dataset.toast);
      this._dismissToast(Number(b.dataset.toast));
      if (t && b.dataset.kind === "retry" && t.retry) t.retry();
    });
    this.api.onState(() => this._onDataChanged());
    // "Verrouiller" pressed on the guard's bar of an HA page (mf-guard.js).
    this._onGuardSync = (ev) => {
      if (ev.detail?.source === "guard" && ev.detail.status && this.api.state) this.api._patchAdvanced(ev.detail.status, true);
    };
  }

  // ----- properties set by Home Assistant -----------------------------------

  set hass(hass) {
    const first = !this._hass;
    this._hass = hass;
    if (first) this._boot();
    else if (this.page) this.page.hassChanged(hass);
    this._renderTaskbar();
    // Home Assistant confirmed its kiosk mode: no fallback needed.
    if (this._kiosk && hass?.kioskMode) clearTimeout(this._kiosk.check);
  }
  get hass() {
    return this._hass;
  }

  set narrow(v) {
    this._narrow = !!v;
    this._applyLayout();
  }
  get narrow() {
    return this._narrow;
  }

  get data() {
    return this.api.state;
  }

  connectedCallback() {
    window.addEventListener("maison-facile-advanced", this._onGuardSync);
    this._mq = window.matchMedia ? window.matchMedia("(max-width: 760px)") : null;
    this._mqHandler = () => this._applyLayout();
    if (this._mq?.addEventListener) this._mq.addEventListener("change", this._mqHandler);
    this._onVisibility = () => {
      // Hidden tab / screen off: every CSS animation is paused (cheap tablets).
      this.$app.classList.toggle("mf-hidden", !!document.hidden);
      if (!document.hidden && this.page) this.page.onVisible();
    };
    document.addEventListener("visibilitychange", this._onVisibility);
    this._applyLayout();
    if (this._booted && this.api.state) {
      this._subscribeAppearance();
      this._syncAdvanced();
      this.api.advancedStatus().catch(() => {});
    }
    // Re-attached after a disconnect (HA keeps the element when switching panels): rebuild the page.
    if (this._booted && !this.page && this.api.state && this._detachedPage) {
      const { id, params } = this._detachedPage;
      this._detachedPage = null;
      this.navigate(id, { ...params, focus: false });
    }
  }

  disconnectedCallback() {
    window.removeEventListener("maison-facile-advanced", this._onGuardSync);
    if (this._mq?.removeEventListener) this._mq.removeEventListener("change", this._mqHandler);
    if (this._onVisibility) document.removeEventListener("visibilitychange", this._onVisibility);
    // Leaving Maison Facile (another Home Assistant page): give HA its chrome back.
    this._disableKiosk();
    clearTimeout(this._expiryTimer);
    clearInterval(this._bannerTimer);
    this._unsubscribeAppearance();
    // Stop clocks, camera / energy timers and websocket subscriptions of the current page.
    if (this.page) {
      this._detachedPage = { id: this.pageId, params: this.params };
      this._destroyPage();
    }
  }

  get isNarrow() {
    return this._narrow || !!this._mq?.matches;
  }

  // ----- boot & data ---------------------------------------------------------

  async _boot() {
    if (this._booted) return;
    this._booted = true;
    this._showLoading();
    try {
      await this.api.loadState();
      this._loadError = false;
    } catch (err) {
      console.warn("[maison-facile] state/get", err);
      this._loadError = true;
      this._showLoadError();
      return;
    }
    this._applyTheme();
    this._syncAdvanced();
    this._subscribeAppearance();
    this.api.advancedStatus().catch(() => {});
    if (!this.isConnected) {
      // Detached while loading: connectedCallback will build the page.
      this._detachedPage = { id: this.api.state.onboarded ? "home" : "wizard", params: {} };
      return;
    }
    this.navigate(this.api.state.onboarded ? "home" : "wizard");
    if (this.api.state.onboarded || this.isAdmin) this._loadProblemCount();
  }

  async _loadProblemCount() {
    try {
      const r = await this.api.doctorList();
      this.setProblemCount((r?.problems || []).filter((p) => p.severity !== "info").length);
    } catch (e) {
      /* silent: badge only */
    }
  }

  /** New ideas badge of the taskbar (state/get.ideas_unseen). */
  setIdeasUnseen(n) {
    if (!this.api.state) return;
    this.api.state.ideas_unseen = n || 0;
    this._renderTaskbar();
  }

  setProblemCount(n) {
    this.problemCount = n || 0;
    this._renderTaskbar();
    if (this.page?.problemCountChanged) this.page.problemCountChanged();
  }

  _onDataChanged() {
    this._applyTheme();
    this._syncAdvanced();
    if (this.page) this.page.dataChanged();
  }

  async reload() {
    try {
      await this.api.loadState(true);
    } catch (e) {
      this.toast("Impossible de mettre à jour les informations.", () => this.reload());
    }
  }

  _showLoading() {
    this._destroyPage();
    this.$content.innerHTML = `<div class="loading" role="status"><span class="spinner" aria-hidden="true"></span>Chargement de votre maison…</div>`;
    this.$taskbar.hidden = true;
  }

  _showLoadError() {
    this._destroyPage();
    this.$content.innerHTML = `<div class="loading" role="alert"><div class="empty"><span class="big-icon" style="background:#F7630C">${icon("warn", 36)}</span><strong style="font-size:20px;color:var(--text)">Impossible d'ouvrir votre maison pour le moment.</strong><span>La box est peut-être en train de redémarrer.</span><button type="button" class="btn primary" id="retry">Réessayer</button></div></div>`;
    this.$content.querySelector("#retry").addEventListener("click", () => {
      this._booted = false;
      this._boot();
    });
  }

  // ----- routing --------------------------------------------------------------

  /** Admin unless Home Assistant explicitly says otherwise. */
  get isAdmin() {
    return this._hass?.user?.is_admin !== false;
  }

  navigate(pageId, params = {}) {
    if (!PAGES[pageId]) pageId = "home";
    // Before the first start is finished: only the wizard, adding a device and the buying guide.
    if (pageId !== "wizard" && this.api.state && !this.api.state.onboarded && pageId !== "add" && pageId !== "guide") pageId = "wizard";
    if (this.api.state && !this.api.state.onboarded && !this.isAdmin) pageId = "notadmin";
    this._destroyPage();
    this.pageId = pageId;
    this.params = params;
    this.$content.innerHTML = "";
    const host = document.createElement("div");
    this.$content.appendChild(host);
    this.$content.scrollTop = 0;
    this.$app.setAttribute("data-page", pageId);
    this._applyEffects();
    const Page = PAGES[pageId];
    this.page = new Page(this, params);
    this.page.mount(host);
    this._renderTaskbar();
    this._renderBanner();
    const h = host.querySelector("h1");
    if (h && params.focus !== false) {
      h.setAttribute("tabindex", "-1");
      try {
        h.focus({ preventScroll: true });
      } catch (e) {
        /* ignore */
      }
    }
  }

  _destroyPage() {
    if (this.page) this.page.destroy();
    this.page = null;
  }

  _renderTaskbar() {
    const hide = !this.page || this.pageId === "wizard" || this.pageId === "add" || this.pageId === "notadmin" || (this.pageId === "guide" && !this.api.state?.onboarded);
    this.$taskbar.hidden = hide;
    if (hide) return;
    const markup = html`<div class="bar glass">${TABS.map((t) => {
      const cur = this.pageId === t.id;
      const unseen = this.api.state?.ideas_unseen || 0;
      const badge = t.id === "settings" && this.problemCount > 0
        ? html`<span class="dot" aria-hidden="true">${this.problemCount}</span><span class="sr-only">, ${this.problemCount} problème${this.problemCount > 1 ? "s" : ""} à régler</span>`
        : t.id === "ideas" && unseen > 0
          ? html`<span class="dot info" aria-hidden="true">${unseen}</span><span class="sr-only">, ${unseen} nouvelle${unseen > 1 ? "s" : ""} idée${unseen > 1 ? "s" : ""}</span>`
          : "";
      return html`<a href="#" data-tab="${t.id}" data-key="${t.id}" ${cur ? html`aria-current="page"` : ""}>${icon(t.icon, 22, { color: cur ? "currentColor" : t.color })}<span>${t.label}</span>${badge}</a>`;
    })}</div>`;
    morph(this.$taskbar, markup);
  }

  // ----- theme & layout -------------------------------------------------------

  /** Effective theme of the day (box answer, or local preview while a choice is saved). */
  get appearance() {
    return currentAppearance(this.api.state, this.themePreview);
  }

  get theme() {
    const t = this.appearance?.theme_effective;
    return THEME_DEFS[t] ? t : "clair";
  }

  /** Show {theme?, theme_auto?} right away; null = back to the saved settings. */
  previewTheme(patch) {
    this.themePreview = patch && typeof patch === "object" ? patch : patch ? { theme: patch, theme_auto: "non" } : null;
    this._applyTheme();
  }

  get animationsOn() {
    return this.api.state?.settings?.animations !== false;
  }

  /** Home style shown now: the one being tried, else the saved one. Contrast theme: always Maison Facile. */
  get homeStyle() {
    if (this.theme === "contraste") return "maison_facile";
    const id = this.styleTrial || this.api.state?.settings?.home_style;
    return styleDef(id).id;
  }

  /** « Essayer » a style: shown on the home screen, saved only with « Garder ». */
  tryStyle(id) {
    const saved = styleDef(this.api.state?.settings?.home_style).id;
    this.styleTrial = id === saved ? null : styleDef(id).id;
    this._applyTheme();
    this.navigate("home");
  }

  async keepStyle() {
    const id = this.styleTrial;
    if (!id) return;
    try {
      await this.api.setSettings({ home_style: id });
      this.styleTrial = null;
      this.notify(`C'est gardé : l'accueil reste en style ${styleDef(id).name}.`);
    } catch (err) {
      this.toast(this.errorText(err, "Impossible d'enregistrer ce style."), () => this.keepStyle());
    }
    this._applyTheme();
    if (this.page) this.page.dataChanged();
  }

  endTrial() {
    this.styleTrial = null;
    this._applyTheme();
    if (this.page) this.page.dataChanged();
  }

  _applyTheme() {
    const id = this.theme;
    this.$app.setAttribute("data-theme", id);
    this.$app.setAttribute("data-tone", THEME_DEFS[id].tone);
    this.$app.setAttribute("data-anim", this.animationsOn ? "on" : "off");
    this.$app.setAttribute("data-home-style", this.homeStyle);
    this._applyEffects();
  }

  /** Falling flakes / leaves of the theme: home screen only, never with "animations: off". */
  _applyEffects() {
    if (!this.$fx) return;
    const want = this.animationsOn && this.pageId === "home" ? `${this.theme}` : "";
    if (this.$fx.dataset.fx === want) return;
    this.$fx.dataset.fx = want;
    this.$fx.innerHTML = want ? particlesHtml(want) : "";
  }

  /** The box tells every panel when the theme of the day changes (midnight, other tablet). */
  async _subscribeAppearance() {
    if (this._appearanceSub || !this._hass?.connection) return;
    this._appearanceSub = "pending";
    try {
      const unsub = await this.api.subscribe("appearance/subscribe", (msg) => {
        if (msg?.appearance) this.api.patchState({ appearance: msg.appearance });
      });
      if (this._appearanceSub !== "pending") unsub();
      else this._appearanceSub = unsub;
    } catch (e) {
      // Older box: reload the state a little after local midnight.
      this._appearanceSub = null;
      const now = new Date();
      const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 30);
      clearTimeout(this._midnightTimer);
      this._midnightTimer = setTimeout(() => this.reload().then(() => this._subscribeAppearance()), next - now);
    }
  }

  _unsubscribeAppearance() {
    clearTimeout(this._midnightTimer);
    const u = this._appearanceSub;
    this._appearanceSub = null;
    if (typeof u === "function") {
      try {
        u();
      } catch (e) {
        /* ignore */
      }
    }
  }

  _applyLayout() {
    this.$app.classList.toggle("narrow", this.isNarrow);
  }

  // ----- commercial mode: Home Assistant hidden behind "Réglages avancés" -----------
  // Uses two events of Home Assistant's shell (internal API, see NOTES_commercial.md):
  // window "hass-kiosk-mode" {enable} and, as a fallback, "hass-dock-sidebar" {dock}.

  get advanced() {
    return this.api.state?.advanced || { commercial_mode: false, unlocked: false };
  }

  /** Home Assistant must be hidden right now (commercial mode, not unlocked). */
  get commercialLocked() {
    return !!this.advanced.commercial_mode && !this.advanced.unlocked;
  }

  _syncAdvanced() {
    if (this.isConnected && this.api.state && this.commercialLocked) this._enableKiosk();
    else this._disableKiosk();
    this._renderBanner();
    clearTimeout(this._expiryTimer);
    const until = this.advanced.unlocked && this.advanced.until ? new Date(this.advanced.until).getTime() : 0;
    if (until && this.isConnected) {
      // Unlock ends after 30 min: ask the box again, which hides Home Assistant.
      const delay = Math.max(1000, Math.min(until - Date.now() + 1000, 2 ** 31 - 1));
      this._expiryTimer = setTimeout(
        () => this.api.advancedStatus().catch(() => this.api.patchState({ advanced: { ...this.advanced, unlocked: false } })),
        delay
      );
    }
  }

  _shell() {
    return document.querySelector("home-assistant") || this;
  }

  _fireShell(type, detail) {
    this._shell().dispatchEvent(new CustomEvent(type, { detail, bubbles: true, composed: true }));
  }

  /** mf-guard.js (loaded on every HA page) answered: it owns the kiosk and the redirections. */
  get _guard() {
    const g = window.__maisonFacileGuard;
    return g && g.ready ? g : null;
  }

  _enableKiosk() {
    if (this._guard) {
      this._disableOwnKiosk();
      return this._guard.sync();
    }
    if (this._kiosk) return;
    const k = { kioskEvent: false, dockBefore: null, check: 0 };
    this._kiosk = k;
    if (!this._hass?.kioskMode) {
      window.dispatchEvent(new CustomEvent("hass-kiosk-mode", { detail: { enable: true } }));
      k.kioskEvent = true;
    }
    k.check = setTimeout(() => {
      if (this._kiosk !== k || this._hass?.kioskMode) return;
      // This Home Assistant version ignored the kiosk event: hide the sidebar instead.
      const before = this._hass?.dockedSidebar;
      if (before && before !== "always_hidden") {
        k.dockBefore = before;
        this._fireShell("hass-dock-sidebar", { dock: "always_hidden" });
      }
    }, 600);
  }

  _disableKiosk() {
    this._disableOwnKiosk();
    if (this._guard) this._guard.sync();
  }

  /** Fallback kiosk of the panel alone (no guard: older box, guard not loaded). */
  _disableOwnKiosk() {
    const k = this._kiosk;
    if (!k) return;
    this._kiosk = null;
    clearTimeout(k.check);
    if (k.kioskEvent) window.dispatchEvent(new CustomEvent("hass-kiosk-mode", { detail: { enable: false } }));
    if (k.dockBefore) this._fireShell("hass-dock-sidebar", { dock: k.dockBefore });
  }

  /** Minutes left in installer mode (rounded up), or 0. */
  get unlockMinutesLeft() {
    if (!this.advanced.unlocked || !this.advanced.until) return 0;
    return Math.max(0, Math.ceil((new Date(this.advanced.until).getTime() - Date.now()) / 60000));
  }

  /** "Mode installateur actif" strip on every page (the Réglages page shows its own). */
  _renderBanner() {
    const show = !!this.advanced.unlocked && this.isAdmin && !!this.page && this.pageId !== "settings";
    this.$banner.hidden = !show;
    clearInterval(this._bannerTimer);
    if (!show) {
      this.$banner.innerHTML = "";
      return;
    }
    const paint = () => {
      const n = this.unlockMinutesLeft;
      morph(this.$banner, html`<div class="install-banner" role="status">
        <span class="ib-text">${icon("wrench", 22)}${say(this, "Mode installateur actif")}${n ? ` (encore ${n} min)` : ""}</span>
        <button type="button" class="btn secondary sm" data-banner="open-ha">Ouvrir Home Assistant</button>
        <button type="button" class="btn primary sm" data-banner="lock">${icon("lock", 20)}Verrouiller</button>
      </div>`);
    };
    paint();
    this._bannerTimer = setInterval(paint, 30000);
  }

  /** Go to Home Assistant's own pages, the way HA's navigate() does it. */
  openHomeAssistant(path = "/config") {
    this._disableKiosk();
    window.history.pushState(null, "", path);
    window.dispatchEvent(new CustomEvent("location-changed", { detail: { replace: false } }));
  }

  async lockAdvanced() {
    try {
      await this.api.lockAdvanced();
      this.notify("Réglages avancés verrouillés.");
    } catch (err) {
      this.toast(this.errorText(err, "Impossible de verrouiller pour le moment."), () => this.lockAdvanced());
    }
  }

  // ----- toasts -----------------------------------------------------------------

  /** Discreet French message; `retry` adds a "Réessayer" button. */
  toast(message, retry, kind = "error") {
    const id = ++this._toastSeq;
    this._toasts = this._toasts.filter((t) => t.message !== message);
    this._toasts.push({ id, message, retry, kind });
    if (this._toasts.length > 3) this._toasts.shift();
    this._renderToasts();
    setTimeout(() => this._dismissToast(id), retry ? 9000 : 4500);
  }

  /** Backend French message when there is one, else our own text. */
  errorText(err, fallback) {
    return friendlyError(err) || fallback;
  }

  notify(message) {
    this.toast(message, null, "ok");
  }

  _dismissToast(id) {
    const before = this._toasts.length;
    this._toasts = this._toasts.filter((t) => t.id !== id);
    if (before !== this._toasts.length) this._renderToasts();
  }

  _renderToasts() {
    this.$toasts.innerHTML = this._toasts
      .map(
        (t) => `<div class="toast ${t.kind === "ok" ? "ok" : ""}"><span class="grow">${esc(t.message)}</span>${
          t.retry ? `<button type="button" class="btn secondary" data-toast="${t.id}" data-kind="retry">Réessayer</button>` : ""
        }<button type="button" class="btn ghost" data-toast="${t.id}" aria-label="Fermer le message">${icon("plus", 20).s.replace("<svg", '<svg style="transform:rotate(45deg)"')}</button></div>`
      )
      .join("");
  }

  // ----- shared actions ------------------------------------------------------------

  async callService(domain, service, data, errorText = "Impossible d'effectuer cette action.") {
    try {
      await this._hass.callService(domain, service, data);
      return true;
    } catch (err) {
      console.warn("[maison-facile] service", domain, service, err);
      this.toast(errorText, () => this.callService(domain, service, data, errorText));
      return false;
    }
  }
}

if (!customElements.get("maison-facile-panel")) {
  customElements.define("maison-facile-panel", MaisonFacilePanel);
}
