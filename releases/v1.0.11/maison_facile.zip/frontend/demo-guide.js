// Generated from custom_components/maison_facile/buying_guide.yaml (demo only; the box reads the YAML file).
// Regenerate: python3 scripts/make_demo_guide.py
export const DEMO_GUIDE = [
 {
  "id": "antenne",
  "title": "Antenne Zigbee (clé USB)",
  "icon": "signal",
  "what": "La petite clé USB qui permet à la box de parler aux appareils Zigbee. Une seule suffit pour toute la maison.",
  "trap": "Une « passerelle » ou un « hub » Zigbee en Wi-Fi d'une marque (Tuya, Smart Life…) ne convient pas : il faut une clé USB à brancher sur la box.",
  "price_note": null,
  "color": "#0067C0",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "radio"
  ],
  "add_types": [],
  "look_for": [
   "« Zigbee 3.0 » et « coordinateur » dans la fiche du produit.",
   "Compatible « ZHA » ou « Home Assistant » (par exemple Sonoff Dongle, ou Connect ZBT de Home Assistant).",
   "Une petite rallonge USB : l'antenne capte mieux un peu à l'écart de la box."
  ],
  "price": {
   "min": 20,
   "max": 45
  }
 },
 {
  "id": "ouverture",
  "title": "Détecteur d'ouverture",
  "icon": "door",
  "what": "Deux petites pièces collées sur une porte ou une fenêtre. Il sait si elle est ouverte.",
  "trap": "Évitez les modèles Wi-Fi : leur pile s'use en quelques mois et ils passent par l'appli du fabricant.",
  "price_note": null,
  "color": "#6B47B8",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "contact"
  ],
  "add_types": [
   "ouverture"
  ],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Une pile bouton courante (CR2032 ou CR1632).",
   "Petit et discret : il se colle avec un adhésif fourni."
  ],
  "price": {
   "min": 8,
   "max": 20
  }
 },
 {
  "id": "mouvement",
  "title": "Détecteur de mouvement",
  "icon": "motion",
  "what": "Il voit quand quelqu'un passe dans la pièce. Idéal pour allumer une lumière la nuit.",
  "trap": "Un détecteur « de présence » sur prise électrique est plus cher : il ne sert que pour un bureau ou une salle de bain.",
  "price_note": null,
  "color": "#E8590C",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "motion"
  ],
  "add_types": [
   "mouvement"
  ],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Un capteur de luminosité intégré : la lumière ne s'allume pas en plein jour.",
   "Une pile qui dure au moins un an."
  ],
  "price": {
   "min": 10,
   "max": 30
  }
 },
 {
  "id": "thermo",
  "title": "Thermomètre (température et humidité)",
  "icon": "thermo",
  "what": "Il mesure la température et l'humidité d'une pièce. Il sert au chauffage, à l'aération et aux alertes de gel.",
  "trap": "Les thermomètres Bluetooth seuls doivent rester tout près de la box : prenez du Zigbee.",
  "price_note": null,
  "color": "#0067C0",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "temperature",
   "humidity"
  ],
  "add_types": [
   "thermo"
  ],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Un petit écran : pratique pour lire la température d'un coup d'œil.",
   "L'humidité en plus de la température (pour la salle de bain)."
  ],
  "price": {
   "min": 8,
   "max": 25
  }
 },
 {
  "id": "fuite",
  "title": "Détecteur de fuite d'eau",
  "icon": "drop",
  "what": "Un petit boîtier posé au sol. Il prévient dès qu'une goutte d'eau le touche.",
  "trap": "Ne le cachez pas dans un placard fermé loin de la box : vérifiez qu'il répond après l'avoir posé.",
  "price_note": null,
  "color": "#C42B1C",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "leak"
  ],
  "add_types": [
   "fuite"
  ],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Des contacts sous le boîtier (il doit toucher le sol).",
   "Une petite sirène intégrée, si possible."
  ],
  "price": {
   "min": 10,
   "max": 25
  }
 },
 {
  "id": "fumee",
  "title": "Détecteur de fumée",
  "icon": "flame",
  "what": "Il sonne en cas de fumée et vous prévient aussi sur le téléphone, même absent.",
  "trap": "Un détecteur sans la norme NF EN 14604 ne compte pas comme le détecteur obligatoire du logement.",
  "price_note": null,
  "color": "#C42B1C",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "smoke",
   "smoke_battery"
  ],
  "add_types": [
   "fumee"
  ],
  "look_for": [
   "La norme « NF EN 14604 » écrite sur la boîte : elle est obligatoire.",
   "Le mot « Zigbee » sur la boîte.",
   "Une pile longue durée (5 à 10 ans si possible)."
  ],
  "price": {
   "min": 20,
   "max": 50
  }
 },
 {
  "id": "prise",
  "title": "Prise connectée",
  "icon": "plug",
  "what": "Elle se branche entre le mur et l'appareil. Elle l'allume, l'éteint et mesure ce qu'il consomme.",
  "trap": "Les prises Wi-Fi « Smart Life » très bon marché passent par Internet : si le serveur du fabricant tombe, plus rien ne marche.",
  "price_note": null,
  "color": "#B8860B",
  "protocol": "zigbee_local",
  "protocol_fr": "Zigbee, ou Wi-Fi sans appli",
  "roles": [
   "switch",
   "power",
   "energy",
   "energy_meter"
  ],
  "add_types": [
   "prise"
  ],
  "look_for": [
   "« Mesure de consommation » écrit sur la boîte (utile pour la machine à laver et les économies).",
   "16 A et une prise française avec broche de terre.",
   "Zigbee de préférence. En Wi-Fi : Shelly ou « Matter » (sans appli obligatoire)."
  ],
  "price": {
   "min": 10,
   "max": 25
  }
 },
 {
  "id": "lumiere",
  "title": "Ampoule connectée",
  "icon": "bulb",
  "what": "Une ampoule que la box allume, éteint et règle (plus ou moins fort, blanc chaud ou froid).",
  "trap": "L'interrupteur du mur doit rester allumé. Sinon l'ampoule ne répond plus : prévenez la famille.",
  "price_note": null,
  "color": "#5D6B7A",
  "protocol": "zigbee_local",
  "protocol_fr": "Zigbee, ou Wi-Fi sans appli",
  "roles": [
   "light"
  ],
  "add_types": [
   "lumiere"
  ],
  "look_for": [
   "Le bon culot : E27 (gros), E14 (petit) ou GU10 (spot). Regardez votre ampoule actuelle.",
   "Zigbee de préférence. En Wi-Fi : « Matter » ou WLED.",
   "« Blanc réglable » si vous voulez une lumière douce le soir."
  ],
  "price": {
   "min": 8,
   "max": 25
  }
 },
 {
  "id": "bouton",
  "title": "Bouton sans fil ou sonnette",
  "icon": "bell",
  "what": "Un petit bouton à coller où vous voulez : il lance une action (sonnette, « Bonne nuit », tout éteindre…).",
  "trap": "Les sonnettes vidéo Wi-Fi demandent souvent un abonnement et l'appli du fabricant : vérifiez avant d'acheter.",
  "price_note": null,
  "color": "#00838F",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "button",
   "doorbell"
  ],
  "add_types": [],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Plusieurs gestes possibles (un appui, deux appuis, appui long).",
   "Une pile bouton courante (CR2032)."
  ],
  "price": {
   "min": 8,
   "max": 20
  }
 },
 {
  "id": "chauffage",
  "title": "Tête de radiateur ou module fil pilote",
  "icon": "heater",
  "what": "Elle règle votre chauffage pièce par pièce : moins chaud la nuit ou quand vous êtes absent.",
  "trap": "Vérifiez le modèle de robinet de vos radiateurs avant d'acheter (photo à montrer au vendeur).",
  "price_note": null,
  "color": "#E8590C",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "climate"
  ],
  "add_types": [],
  "look_for": [
   "Radiateur à eau : une tête thermostatique « Zigbee » qui se visse à la place de l'ancienne.",
   "Radiateur électrique : un module « fil pilote » Zigbee, posé par un électricien.",
   "Les bagues d'adaptation fournies pour votre marque de robinet."
  ],
  "price": {
   "min": 25,
   "max": 60
  }
 },
 {
  "id": "camera",
  "title": "Caméra",
  "icon": "camera",
  "what": "Elle filme l'entrée ou le jardin. Vous voyez l'image sur l'écran de la maison.",
  "trap": "Évitez les caméras sur batterie qui ne marchent qu'avec l'appli du fabricant : la box ne pourra pas les afficher.",
  "price_note": null,
  "color": "#5D6B7A",
  "protocol": "network",
  "protocol_fr": "Relié par le réseau de la maison",
  "roles": [
   "camera"
  ],
  "add_types": [],
  "look_for": [
   "« RTSP » ou « ONVIF » dans la fiche : l'image reste chez vous, sans passer par Internet.",
   "Elle marche sans abonnement.",
   "Un câble réseau (« PoE ») si possible, sinon un bon Wi-Fi à l'endroit choisi."
  ],
  "price": {
   "min": 30,
   "max": 90
  }
 },
 {
  "id": "sirene",
  "title": "Sirène",
  "icon": "siren",
  "what": "Elle sonne fort en cas d'intrusion, de fumée ou de fuite d'eau.",
  "trap": "Une sirène sur pile seule s'use vite : préférez un modèle branché.",
  "price_note": null,
  "color": "#C42B1C",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "siren"
  ],
  "add_types": [],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Branchée sur une prise, avec une batterie de secours si possible.",
   "Un son fort (au moins 90 dB)."
  ],
  "price": {
   "min": 20,
   "max": 45
  }
 },
 {
  "id": "vanne_eau",
  "title": "Vanne d'arrivée d'eau motorisée",
  "icon": "drop",
  "what": "Elle coupe l'eau toute seule en cas de fuite. Elle se pose sur le tuyau d'arrivée.",
  "trap": "Ne l'installez pas vous-même sur l'arrivée générale si vous n'êtes pas sûr : une erreur peut provoquer une fuite.",
  "price_note": null,
  "color": "#00838F",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "valve"
  ],
  "add_types": [],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Le bon diamètre de tuyau (demandez à votre plombier).",
   "Une pose par un plombier."
  ],
  "price": {
   "min": 40,
   "max": 90
  }
 },
 {
  "id": "co2",
  "title": "Capteur de CO₂ (qualité de l'air)",
  "icon": "air",
  "what": "Il mesure l'air « confiné » d'une pièce et vous dit quand ouvrir la fenêtre.",
  "trap": "« eCO₂ » ou « COV » n'est pas un vrai CO₂ : la mesure est seulement estimée.",
  "price_note": null,
  "color": "#0E7A0D",
  "protocol": "zigbee_local",
  "protocol_fr": "Zigbee, ou Wi-Fi sans appli",
  "roles": [
   "co2"
  ],
  "add_types": [],
  "look_for": [
   "« Capteur NDIR » dans la fiche : c'est un vrai capteur de CO₂.",
   "Zigbee de préférence, ou un modèle Wi-Fi « ESPHome » (sans appli).",
   "Branché sur secteur ou par câble USB."
  ],
  "price": {
   "min": 40,
   "max": 100
  }
 },
 {
  "id": "humidite_sol",
  "title": "Capteur d'humidité de la terre",
  "icon": "plant",
  "what": "Il se plante dans le pot. Il vous dit quand arroser.",
  "trap": "Les modèles Bluetooth seuls doivent rester près de la box : prenez du Zigbee.",
  "price_note": null,
  "color": "#0E7A0D",
  "protocol": "zigbee",
  "protocol_fr": "Zigbee de préférence",
  "roles": [
   "soil"
  ],
  "add_types": [],
  "look_for": [
   "Le mot « Zigbee » sur la boîte.",
   "Résistant à l'eau pour le balcon ou le jardin."
  ],
  "price": {
   "min": 10,
   "max": 25
  }
 },
 {
  "id": "enceinte",
  "title": "Enceinte connectée",
  "icon": "speaker",
  "what": "Elle annonce à voix haute les alertes de la maison (fuite, courrier, porte ouverte…).",
  "trap": "Les enceintes Echo ne peuvent pas lire les annonces de la box.",
  "price_note": null,
  "color": "#6B47B8",
  "protocol": "network",
  "protocol_fr": "Relié par le réseau de la maison",
  "roles": [
   "speaker"
  ],
  "add_types": [],
  "look_for": [
   "Une enceinte compatible « Chromecast » ou Sonos : la box la trouve toute seule.",
   "Branchée sur secteur, dans une pièce de vie."
  ],
  "price": {
   "min": 30,
   "max": 120
  }
 },
 {
  "id": "tele",
  "title": "Télévision connectée",
  "icon": "tv",
  "what": "La box peut mettre votre télé en pause ou l'éteindre quand vous partez.",
  "trap": "Laissez la télé en veille (pas débranchée) : sinon la box ne la voit plus.",
  "price_note": "Rien à acheter : votre télé actuelle convient souvent.",
  "color": "#0067C0",
  "protocol": "network",
  "protocol_fr": "Relié par le réseau de la maison",
  "roles": [
   "tv",
   "media"
  ],
  "add_types": [],
  "look_for": [
   "Une télé récente reliée au Wi-Fi ou au câble réseau de la maison.",
   "Google TV, Android TV, Samsung ou LG : la box la trouve souvent toute seule."
  ],
  "price": null
 },
 {
  "id": "aspirateur",
  "title": "Robot aspirateur",
  "icon": "vacuum",
  "what": "Il fait le ménage quand vous êtes absent, puis retourne à sa base.",
  "trap": "Ici, le Wi-Fi et l'appli du fabricant sont normaux : le robot en a besoin pour sa carte.",
  "price_note": null,
  "color": "#5D6B7A",
  "protocol": "network",
  "protocol_fr": "Relié par le réseau de la maison",
  "roles": [
   "vacuum"
  ],
  "add_types": [],
  "look_for": [
   "Compatible Home Assistant : demandez à votre installateur avant d'acheter.",
   "Une base de vidage automatique, si vous voulez y penser moins souvent."
  ],
  "price": {
   "min": 150,
   "max": 450
  }
 },
 {
  "id": "imprimante",
  "title": "Imprimante réseau",
  "icon": "printer",
  "what": "La box surveille l'encre et vous prévient avant qu'elle soit vide.",
  "trap": "Une imprimante branchée seulement en USB sur l'ordinateur n'est pas visible par la box.",
  "price_note": "Rien à acheter : votre imprimante actuelle convient souvent.",
  "color": "#5D6B7A",
  "protocol": "network",
  "protocol_fr": "Relié par le réseau de la maison",
  "roles": [
   "ink"
  ],
  "add_types": [],
  "look_for": [
   "Une imprimante reliée au Wi-Fi ou au câble réseau de la maison.",
   "« AirPrint » ou « IPP » dans la fiche : la box la trouve toute seule."
  ],
  "price": null
 },
 {
  "id": "borne",
  "title": "Borne de recharge connectée",
  "icon": "car",
  "what": "Elle recharge la voiture pendant les heures creuses, toute seule.",
  "trap": "Ne rechargez jamais une voiture avec une prise connectée ordinaire : risque d'échauffement.",
  "price_note": null,
  "color": "#0E7A0D",
  "protocol": "network",
  "protocol_fr": "Relié par le réseau de la maison",
  "roles": [
   "charger"
  ],
  "add_types": [],
  "look_for": [
   "Une borne posée par un électricien qualifié (mention « IRVE »).",
   "Compatible Home Assistant : demandez à votre installateur avant d'acheter."
  ],
  "price": {
   "min": 500,
   "max": 1500
  }
 }
];
export const NO_PURCHASE_ROLES = ["birthday", "person", "phone", "tempo", "weather", "weather_alert"];
export const DEMO_STARTER = {
 "title": "Pour commencer",
 "intro": "L'antenne d'abord, puis 2 ou 3 capteurs utiles tout de suite. Vous compléterez plus tard, à votre rythme.",
 "items": [
  "antenne",
  "ouverture",
  "mouvement",
  "thermo"
 ],
 "budget": {
  "min": 46,
  "max": 120
 }
};
