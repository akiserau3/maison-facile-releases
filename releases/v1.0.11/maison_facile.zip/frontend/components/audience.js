// Who installed the box, and the texts that depend on it (same rules as audience.py).
// A private person (profile "particulier", the free ISO) has no installer to call: texts point
// to « Réglages avancés » or the community. A pro keeps the texts, with his name if he left one.
// state/get.audience = {profile, installer_name}; absent (older box): pro if an installer name
// is set, otherwise particulier. Every frontend text that names « installateur » goes through
// say() (checked by tests/test_audience.py).

const PROFILES = ["particulier", "pro"];

/** {profile, installer_name} of a cached state/get. */
export function audienceOf(data) {
  const a = data?.audience;
  const settings = data?.settings || {};
  const name = String(a?.installer_name ?? settings.installer_name ?? "").trim();
  if (a && PROFILES.includes(a.profile)) return { profile: a.profile, installer_name: name };
  if (PROFILES.includes(settings.profile)) return { profile: settings.profile, installer_name: name };
  return { profile: name ? "pro" : "particulier", installer_name: name };
}

/** True for a box installed by a professional. */
export function isPro(app) {
  return audienceOf(app?.data || app?.api?.state).profile === "pro";
}

// Private person: [pattern, replacement], most specific first.
const PARTICULIER = [
  [/Si vous ne le connaissez pas, demandez à votre installateur\./g, "Si vous ne le connaissez pas, demandez à la personne qui a installé la box."],
  [/Mode installateur actif/g, "Réglages avancés ouverts"],
  [/La box installe et règle ce que votre installateur a prévu pour vous\./g, "La box installe et règle ce que vous avez choisi à l'installation."],
  [/Vérifiez qu'elle est bien branchée sur la box, ou demandez à votre installateur\./g, "Vérifiez qu'elle est bien branchée sur la box."],
  [/Version testée par votre installateur\./g, "Version déjà testée par d'autres box."],
  [/En test chez l'installateur/g, "Pas encore testée"],
  [/Seulement celles testées par votre installateur/g, "Seulement celles déjà testées"],
  [/ · testée par votre installateur le /g, " · testée le "],
  [/Toujours bloqué \? Votre installateur reçoit le rapport complet, sans vos mots de passe\./g, "Toujours bloqué ? Le rapport complet, sans vos mots de passe, vous aide à demander de l'aide sur le forum de la communauté."],
  [/Détails pour l'installateur/g, "Détails techniques"],
  [/Rapport pour votre installateur/g, "Rapport pour demander de l'aide"],
  [/Appelez votre installateur, il saura vous aider\./g, "Ouvrez la box avec le compte principal, puis réessayez."],
  [/Copiez ce texte et envoyez-le à votre installateur \(par message ou par e-mail\)\./g, "Copiez ce texte et collez-le dans votre message sur le forum de la communauté."],
  [/votre installateur les voit dans le rapport d'aide\./g, "ils figurent dans le rapport d'aide."],
  [/Ces réglages sont pour votre installateur\./g, "Ces réglages sont pour les connaisseurs."],
  [/Le code de l'installateur est enregistré\./g, "Le code des réglages avancés est enregistré."],
  [/Le code de l'installateur est supprimé\./g, "Le code des réglages avancés est supprimé."],
  [/Code de l'installateur/g, "Code des réglages avancés"],
  [/Regardez l'étiquette sous l'appareil, ou demandez à votre installateur\./g, "Regardez l'étiquette sous l'appareil, ou sa notice."],
  [/Pour le voir ici, demandez à votre installateur de le relier\./g, "Pour le voir ici, reliez son appli dans Réglages avancés (Paramètres > Appareils et services)."],
  [/Si cela ne suffit pas, demandez à votre installateur\./g, "Si cela ne suffit pas, débranchez-la puis rebranchez-la."],
  [/dans les réglages avancés : demandez à votre installateur\./g, "dans les réglages avancés (Paramètres > Appareils et services)."],
  [/Gardez-le pour un cas précis, conseillé par votre installateur\./g, "Gardez-le pour un cas précis."],
  [/un site externe choisi par votre installateur\./g, "un site externe choisi par la communauté."],
];
const VOTRE = /\b([Vv])otre installateur\b/g;

/** Text for this profile (pro without a name: unchanged). Same rules as audience.adapt. */
export function adaptText(text, who) {
  if (typeof text !== "string" || !text.includes("nstallateur")) return text;
  if (who?.profile === "pro") {
    const name = String(who.installer_name || "").trim();
    return name ? text.replace(VOTRE, name) : text;
  }
  let out = text;
  for (const [re, rep] of PARTICULIER) out = out.replace(re, rep);
  return out;
}

/** say(app, "…votre installateur…"): the text for the box of this panel. */
export function say(app, text) {
  return adaptText(text, audienceOf(app?.data || app?.api?.state));
}
