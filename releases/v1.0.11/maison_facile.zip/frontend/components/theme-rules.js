// Mirror of theme_rules.py (PURE): holidays, seasons, effective theme.
// Used for the instant preview in Réglages › Apparence and by the demo; the box's answer
// (state/get.appearance) always wins. tests/test_theme_rules.py checks that both agree.

export const THEME_AUTO_MODES = ["fetes_saisons", "fetes", "saisons", "non"];
export const HOME_STYLES = ["maison_facile", "orbite", "neon", "jumeau", "holo"];
export const THEMES = ["clair", "sombre", "contraste", "printemps", "ete", "automne", "hiver", "halloween", "noel", "nouvelan", "valentin", "paques", "quatorze"];

const HOLIDAY_REASON_FR = {
  halloween: "Halloween (du 24 au 31 octobre)",
  noel: "Noël (du 1er au 26 décembre)",
  nouvelan: "le Nouvel an (du 27 décembre au 2 janvier)",
  valentin: "la Saint-Valentin (du 12 au 14 février)",
  paques: "Pâques (du vendredi saint au lundi de Pâques)",
  quatorze: "le 14 Juillet",
};
const SEASON_REASON_FR = { printemps: "c'est le printemps", ete: "c'est l'été", automne: "c'est l'automne", hiver: "c'est l'hiver" };

/** Local calendar date {y, m, d} from "YYYY-MM-DD" or a Date. */
export function toYMD(v) {
  if (typeof v === "string") {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v);
    if (m) return { y: Number(m[1]), m: Number(m[2]), d: Number(m[3]) };
  }
  const d = v instanceof Date ? v : new Date();
  return { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() };
}

const dayNum = (y, m, d) => Math.round(Date.UTC(y, m - 1, d) / 86400000);

/** Gregorian Easter Sunday (Meeus/Jones/Butcher), {m, d}. */
export function easterSunday(year) {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return { m: month, d: day };
}

export function holidayFor(ymd) {
  const { y, m, d } = ymd;
  if (m === 10 && d >= 24) return "halloween";
  if (m === 12 && d <= 26) return "noel";
  if ((m === 12 && d >= 27) || (m === 1 && d <= 2)) return "nouvelan";
  if (m === 2 && d >= 12 && d <= 14) return "valentin";
  if (m === 7 && (d === 13 || d === 14)) return "quatorze";
  const e = easterSunday(y);
  const n = dayNum(y, m, d);
  const en = dayNum(y, e.m, e.d);
  if (n >= en - 2 && n <= en + 1) return "paques";
  return null;
}

export function seasonFor(ymd) {
  const md = ymd.m * 100 + ymd.d;
  if (md >= 1221 || md < 320) return "hiver";
  if (md < 621) return "printemps";
  if (md < 922) return "ete";
  return "automne";
}

/** Same result as theme_rules.effective_theme (without "date"). */
export function effectiveTheme(settings, ymd) {
  let chosen = settings?.theme;
  if (!THEMES.includes(chosen)) chosen = "clair";
  let auto = settings?.theme_auto;
  if (!THEME_AUTO_MODES.includes(auto)) auto = "fetes_saisons";
  const occasion = holidayFor(ymd);
  const season = seasonFor(ymd);
  const base = { occasion, season, auto };
  const manual = (reason_fr) => ({ ...base, theme_effective: chosen, reason_fr });
  if (chosen === "contraste") return manual("Contraste élevé : le thème ne change jamais tout seul.");
  if (auto === "non") return manual("Thème choisi à la main.");
  if ((auto === "fetes_saisons" || auto === "fetes") && occasion) return { ...base, theme_effective: occasion, reason_fr: `Choisi automatiquement : ${HOLIDAY_REASON_FR[occasion]}.` };
  if (auto === "fetes_saisons" || auto === "saisons") return { ...base, theme_effective: season, reason_fr: `Choisi automatiquement : ${SEASON_REASON_FR[season]}.` };
  return manual("Votre thème habituel (pas de fête aujourd'hui).");
}

export function appearanceSummary(settings, ymd) {
  const pad = (n) => String(n).padStart(2, "0");
  return { ...effectiveTheme(settings, ymd), date: `${ymd.y}-${pad(ymd.m)}-${pad(ymd.d)}` };
}
