// Apparence: theme of the day, greeting and « clin d'œil » (Themes.dc.html), falling
// particles, catalog of the home styles. Texts come from the validated mockup; a wink is
// only shown when it is TRUE for this house, otherwise a neutral sentence.
import { html } from "../lib.js";
import { THEME_DEFS } from "../styles.js";
import { toYMD, effectiveTheme } from "./theme-rules.js";

export const HOME_STYLE_DEFS = [
  { id: "maison_facile", name: "Maison Facile", tagline: "Le style d'origine : clair, simple, tuiles colorées.", dark: false },
  { id: "orbite", name: "Orbite", tagline: "Vos pièces tournent comme des planètes autour de l'heure.", dark: true },
  { id: "neon", name: "Néon", tagline: "Des tubes de lumière à régler du bout du doigt.", dark: true },
  { id: "jumeau", name: "Jumeau 3D", tagline: "Votre maison vue d'en haut, en relief.", dark: true },
  { id: "holo", name: "Holo", tagline: "Des cartes irisées qui se retournent quand la lumière s'allume.", dark: false },
];

export function styleDef(id) {
  return HOME_STYLE_DEFS.find((s) => s.id === id) || HOME_STYLE_DEFS[0];
}

export function themeDef(id) {
  return THEME_DEFS[id] || THEME_DEFS.clair;
}

/**
 * Appearance of today: the box's answer (state/get.appearance) when it is for the same
 * settings, else the same rules computed here (instant preview before the answer).
 */
export function currentAppearance(state, previewSettings) {
  const settings = { ...(state?.settings || {}), ...(previewSettings || {}) };
  const box = state?.appearance;
  if (box && !previewSettings) return box;
  return effectiveTheme(settings, toYMD(box?.date || new Date()));
}

const hello = (now) => {
  const h = now.getHours();
  return h >= 18 || h < 5 ? "Bonsoir" : "Bonjour";
};

/**
 * Greeting of the home screen. Holiday greetings only on the holiday itself
 * (a « Noël » theme chosen by hand in July says « Bonjour »).
 * Returns {text, emoji} — the emoji is decorative (aria-hidden).
 */
export function greeting(themeId, appearance, name, now = new Date()) {
  const who = name ? `, ${name}` : "";
  const today = appearance?.occasion === themeId;
  if (today) {
    switch (themeId) {
      case "halloween":
        return { text: `${hello(now)}${who}…`, emoji: "🎃" };
      case "noel":
        return { text: `Joyeux Noël${who} !`, emoji: "" };
      case "nouvelan":
        return { text: now.getMonth() === 11 ? `Bonnes fêtes de fin d'année${who} !` : `Bonne année${who} !`, emoji: "" };
      case "paques":
        return { text: `Joyeuses Pâques${who} !`, emoji: "" };
      case "quatorze":
        return { text: `Bonne fête nationale${who} !`, emoji: "" };
      default:
    }
  }
  return { text: `${hello(now)}${who}`, emoji: "" };
}

const has = (text, words) => {
  const t = String(text || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  return words.some((w) => t.includes(w));
};

/** Neutral sentence, always true. */
export function neutralWink(m) {
  const danger = m.alerts.filter((a) => a.severity !== "info").length;
  if (danger) return danger > 1 ? `${danger} choses à regarder dans la maison.` : "Une chose à regarder dans la maison.";
  if (m.lightsOn) return `Tout va bien à la maison · ${m.lightsOn > 1 ? `${m.lightsOn} lumières allumées` : "1 lumière allumée"}.`;
  return "Tout va bien à la maison.";
}

/**
 * « Clin d'œil » of the theme, only when it is true for this house (model.js buildHomeModel).
 * `get` reads live states (for the Christmas tree).
 */
export function wink(themeId, appearance, m, get) {
  const isHoliday = appearance?.occasion === themeId;
  const isSeason = appearance?.season === themeId;
  const cam = (words) => (m.cameras || []).find((c) => has(c.name, words));
  const dev = (words, roles) => (m.devices || []).find((d) => has(d.name, words) && roles.some((r) => d.entities?.[r]));
  if (isHoliday) {
    switch (themeId) {
      case "halloween": {
        if (cam(["entree", "porte"])) return "Des visiteurs pour les bonbons ? La caméra de l'entrée veille.";
        if (dev(["entree"], ["contact"])) return "Des visiteurs pour les bonbons ? La porte d'entrée est surveillée.";
        break;
      }
      case "noel": {
        const tree = dev(["sapin"], ["light", "switch"]);
        if (tree) {
          const s = get(tree.entities.light || tree.entities.switch);
          return s?.state === "on" ? "Le sapin est allumé." : "Le sapin est éteint : touchez sa pièce pour l'allumer.";
        }
        break;
      }
      case "nouvelan":
        if (m.energy?.state === "ok") return "Nouvelle année : la consommation de la maison est à suivre dans « Énergie ».";
        break;
      case "valentin": {
        const salon = m.rooms.find((r) => r.hasLight && has(r.name, ["salon", "sejour"]));
        if (salon) return `Soirée en amoureux ? La lumière du ${salon.name.toLowerCase()} s'éteint d'un geste.`;
        break;
      }
      case "paques":
        if (cam(["jardin"])) return "Chasse aux œufs ? Le jardin est surveillé par la caméra.";
        break;
      case "quatorze":
        if (m.mode.id === "absent") return "Feu d'artifice ce soir : la maison reste surveillée pendant votre absence.";
        break;
      default:
    }
  } else if (isSeason) {
    switch (themeId) {
      case "printemps":
        return "Les jours rallongent : profitez de la lumière du jour.";
      case "ete":
        if (m.weather?.temp !== null && m.weather?.temp >= 26) return "Pensez à fermer les volets côté soleil cet après-midi.";
        break;
      case "automne":
        if (m.hasClimate) return "Il fait plus frais : le chauffage du soir est prêt.";
        break;
      case "hiver":
        if ((m.activeIdeas || []).includes("gel_canalisations")) return "Il peut geler : les canalisations sont surveillées.";
        break;
      default:
    }
  }
  return neutralWink(m);
}

/** Falling flakes / leaves / confetti of a theme (purely decorative). */
export function particlesHtml(themeId) {
  const t = themeDef(themeId);
  if (!t.particle) return "";
  const shape = t.shape || "round";
  const out = [];
  for (let i = 0; i < 12; i++) {
    const size = 6 + (i % 3) * 3;
    out.push(
      `<span class="fx-p ${shape}" style="left:${4 + i * 8}%;width:${size}px;height:${size}px;--dur:${9 + (i % 4) * 3}s;--delay:${(i * 1.1).toFixed(1)}s;--drift:${(i % 2 ? 1 : -1) * (10 + (i % 3) * 8)}px"></span>`
    );
  }
  return out.join("");
}

/** Greeting markup (the emoji is decorative). */
export function greetingHtml(g) {
  return html`${g.text}${g.emoji ? html` <span aria-hidden="true">${g.emoji}</span>` : ""}`;
}
