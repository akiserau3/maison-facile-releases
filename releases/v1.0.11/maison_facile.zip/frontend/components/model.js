// Derived data from Maison Facile state + live hass.states.
import { num } from "../lib.js";
import { PALETTE } from "../styles.js";

export const MODE_ENTITY = "select.maison_facile_mode";

export const MODES = {
  maison: { label: "À la maison", short: "Désactivée", dot: "#13A10E", color: "#0067C0", shadow: "rgba(0,103,192,0.35)", title: "Alarme désactivée", sub: "Vous êtes à la maison, rien ne sonne." },
  absent: { label: "Absent · surveillance", short: "Absent", dot: "#F7630C", color: "#C2410C", shadow: "rgba(194,65,12,0.35)", title: "Alarme activée", sub: "Toute la maison est surveillée. Vous êtes prévenu sur votre téléphone." },
  nuit: { label: "Mode nuit", short: "Nuit", dot: "#8764B8", color: "#6B47B8", shadow: "rgba(107,71,184,0.35)", title: "Mode nuit", sub: "Portes et fenêtres surveillées, vous pouvez circuler à l'intérieur." },
};

export const TYPE_INFO = {
  ouverture: { label: "Détecteur d'ouverture", what: "Fenêtre ou porte", color: "#6B47B8" },
  mouvement: { label: "Détecteur de mouvement", what: "Voit quand quelqu'un passe", color: "#E8590C" },
  thermo: { label: "Thermomètre", what: "Température et humidité", color: "#0067C0" },
  prise: { label: "Prise connectée", what: "Allume, éteint, mesure la conso", color: "#B8860B" },
  lumiere: { label: "Lumière", what: "S'allume et s'éteint", color: "#B8860B" },
  fumee: { label: "Détecteur de fumée", what: "Sonne en cas de fumée", color: "#C42B1C" },
  camera: { label: "Caméra", what: "Image en direct", color: "#00838F" },
  chauffage: { label: "Chauffage", what: "Règle la température", color: "#E8590C" },
  sirene: { label: "Sirène", what: "Sonne en cas d'alerte", color: "#C2185B" },
  fuite: { label: "Détecteur de fuite d'eau", what: "Prévient si de l'eau coule", color: "#C42B1C" },
  vanne: { label: "Vanne d'eau", what: "Coupe l'arrivée d'eau", color: "#0067C0" },
  tv: { label: "Télévision", what: "Télé connectée", color: "#0067C0" },
  enceinte: { label: "Enceinte connectée", what: "Musique et annonces", color: "#6B47B8" },
  sonnette: { label: "Sonnette", what: "Quelqu'un sonne", color: "#E8590C" },
  bouton: { label: "Bouton", what: "Un appui, une action", color: "#5D6B7A" },
  autre: { label: "Appareil", what: "Appareil connecté", color: "#5D6B7A" },
};

export function typeInfo(type) {
  return TYPE_INFO[type] || TYPE_INFO.autre;
}

export function roomColor(room, index = 0) {
  return room?.color || PALETTE[index % PALETTE.length];
}

export function currentMode(hass) {
  const s = hass?.states?.[MODE_ENTITY];
  const v = s?.state;
  return MODES[v] ? v : "maison";
}

export function isOn(stateObj) {
  return !!stateObj && stateObj.state === "on";
}

export function isUnavailable(stateObj) {
  return !stateObj || stateObj.state === "unavailable" || stateObj.state === "unknown";
}

export function devicesInRoom(state, areaId) {
  return (state?.devices || []).filter((d) => d.area_id === areaId);
}

export function friendly(hass, entityId, fallback) {
  return hass?.states?.[entityId]?.attributes?.friendly_name || fallback || entityId;
}

/** Collect entity ids of a role in a list of devices. */
export function roleEntities(devices, role) {
  const out = [];
  for (const d of devices || []) {
    const e = d.entities?.[role];
    if (e) out.push({ device: d, entity_id: e });
  }
  return out;
}

/** Live summary of one room, reading states through `get` (Page.st for watching). */
export function roomSummary(state, room, get) {
  const devices = devicesInRoom(state, room.area_id);
  const lights = roleEntities(devices, "light");
  const switches = roleEntities(devices.filter((d) => d.type === "prise" || !d.entities?.light), "switch");
  let temp = null;
  let hum = null;
  for (const t of roleEntities(devices, "temperature")) {
    const v = num(get(t.entity_id)?.state);
    if (v !== null) {
      temp = v;
      break;
    }
  }
  const climates = roleEntities(devices, "climate");
  if (temp === null) {
    for (const c of climates) {
      const v = num(get(c.entity_id)?.attributes?.current_temperature);
      if (v !== null) {
        temp = v;
        break;
      }
    }
  }
  for (const h of roleEntities(devices, "humidity")) {
    const v = num(get(h.entity_id)?.state);
    if (v !== null) {
      hum = v;
      break;
    }
  }
  const lightsOn = lights.filter((l) => isOn(get(l.entity_id))).length;
  const switchesOn = switches.filter((l) => isOn(get(l.entity_id))).length;
  return { devices, lights, switches, climates, temp, hum, lightsOn, switchesOn, anyLightOn: lightsOn > 0 };
}

/** All light entity ids belonging to Maison Facile rooms. */
export function allRoomLights(state) {
  const areas = new Set((state?.rooms || []).map((r) => r.area_id));
  return roleEntities((state?.devices || []).filter((d) => areas.has(d.area_id)), "light").map((x) => x.entity_id);
}

export function roomName(state, areaId) {
  return (state?.rooms || []).find((r) => r.area_id === areaId)?.name || "";
}

/** Contact sensors (doors / windows) with their live state. */
export function openings(state, get) {
  return roleEntities(state?.devices, "contact").map(({ device, entity_id }) => {
    const s = get(entity_id);
    return {
      device,
      entity_id,
      name: device.name || friendly(null, entity_id),
      room: roomName(state, device.area_id),
      open: isOn(s),
      unknown: isUnavailable(s),
    };
  });
}

/** Add a refresh parameter (not for data: URLs). */
export function withTick(url, tick) {
  if (!url || url.startsWith("data:")) return url;
  return `${url}${url.includes("?") ? "&" : "?"}_=${tick}`;
}

export function cameraUrl(stateObj) {
  if (!stateObj || isUnavailable(stateObj)) return null;
  const token = stateObj.attributes?.access_token;
  if (!token) return stateObj.attributes?.entity_picture || null;
  return `/api/camera_proxy/${encodeURIComponent(stateObj.entity_id)}?token=${encodeURIComponent(token)}`;
}

const WEATHER_FR = {
  "clear-night": ["Nuit claire", "moon"],
  cloudy: ["Nuageux", "cloud"],
  exceptional: ["Temps exceptionnel", "warn"],
  fog: ["Brouillard", "cloud"],
  hail: ["Grêle", "snow"],
  lightning: ["Orage", "rain"],
  "lightning-rainy": ["Orage et pluie", "rain"],
  partlycloudy: ["Éclaircies", "sun"],
  pouring: ["Grosse pluie", "rain"],
  rainy: ["Pluie", "rain"],
  snowy: ["Neige", "snow"],
  "snowy-rainy": ["Neige et pluie", "snow"],
  sunny: ["Ensoleillé", "sun"],
  windy: ["Venteux", "cloud"],
  "windy-variant": ["Venteux", "cloud"],
};

export function weather(hass) {
  const states = hass?.states || {};
  const id = Object.keys(states).find((k) => k.startsWith("weather."));
  if (!id) return null;
  const s = states[id];
  const [label, ic] = WEATHER_FR[s.state] || ["", "sun"];
  return { entity_id: id, temp: num(s.attributes?.temperature), label, icon: ic };
}

export function deviceStateText(hass, device) {
  const e = device.entities || {};
  const st = (id) => hass?.states?.[id];
  if (!device.available) return "Ne répond plus";
  if (e.light) return isOn(st(e.light)) ? "Allumée" : "Éteinte";
  if (e.switch) return isOn(st(e.switch)) ? "Allumée" : "Éteinte";
  if (e.contact) return isOn(st(e.contact)) ? "Ouvert" : "Fermé";
  if (e.smoke) return isOn(st(e.smoke)) ? "FUMÉE DÉTECTÉE" : "Rien à signaler";
  if (e.motion) return isOn(st(e.motion)) ? "Quelqu'un passe" : "Calme";
  if (e.leak) return isOn(st(e.leak)) ? "FUITE D'EAU" : "Rien à signaler";
  if (e.media) {
    const m = st(e.media)?.state;
    return m === "playing" ? "En lecture" : m === "paused" ? "En pause" : m === "off" || m === "standby" ? "Éteinte" : "Allumée";
  }
  if (e.temperature) {
    const t = num(st(e.temperature)?.state);
    return t === null ? "" : `${t.toLocaleString("fr-FR", { maximumFractionDigits: 1 })} °C`;
  }
  return "";
}

// ---------------------------------------------------------------------------
// Home model: ONE description of the home screen shared by every home style
// (pages/home.js = Maison Facile, pages/home-styles/*.js = Orbite, Néon, Jumeau 3D, Holo).
// Only real data of the house: rooms, lights, temperature, humidity, mode, alerts, idea tiles.
// ---------------------------------------------------------------------------

/** Average brightness (0-100) of the lights that are on, or null (unknown / all off). */
export function lightLevel(lights, get) {
  const vals = [];
  for (const l of lights) {
    const s = get(l.entity_id);
    if (!isOn(s)) continue;
    const b = num(s.attributes?.brightness);
    vals.push(b === null ? 100 : Math.round((b / 255) * 100));
  }
  if (!vals.length) return null;
  return Math.max(1, Math.round(vals.reduce((a, b) => a + b, 0) / vals.length));
}

/** Window open while heating runs in the same room (and not already paused by us). */
export function findHeatingAlert(state, get) {
  const pauses = state.heating_pauses || {};
  for (const o of openings(state, get)) {
    if (!o.open || o.entity_id in pauses) continue;
    const roomDevices = (state.devices || []).filter((d) => d.area_id && d.area_id === o.device.area_id);
    const climates = roleEntities(roomDevices, "climate").filter(({ entity_id }) => {
      const s = get(entity_id);
      return s && !isUnavailable(s) && s.state !== "off";
    });
    if (climates.length) {
      const where = o.room && !o.name.toLowerCase().includes(o.room.toLowerCase()) ? ` (${o.room})` : "";
      return { key: o.entity_id, text: `${o.name}${where} est ouverte, et le chauffage tourne.`, climates: climates.map((c) => c.entity_id), room: o.room };
    }
  }
  return null;
}

/**
 * Things to look at, most serious first: smoke, water leak, heating + open window,
 * open doors / windows, devices that stopped answering, low batteries.
 * Each: {key, kind, severity: "danger"|"warn"|"info", text, short}.
 */
export function homeAlerts(state, get, heatingAlert) {
  const out = [];
  for (const d of state.devices || []) {
    const e = d.entities || {};
    if (e.smoke && isOn(get(e.smoke))) out.push({ key: `smoke-${d.device_id}`, kind: "smoke", severity: "danger", text: `Fumée détectée : ${d.name}`, short: "Fumée !" });
    if (e.leak && isOn(get(e.leak))) out.push({ key: `leak-${d.device_id}`, kind: "leak", severity: "danger", text: `Fuite d'eau : ${d.name}`, short: "Fuite d'eau !" });
  }
  if (heatingAlert) out.push({ key: `heat-${heatingAlert.key}`, kind: "heating", severity: "warn", text: heatingAlert.text, short: "Chauffage + fenêtre" });
  for (const o of openings(state, get)) {
    if (o.open && (!heatingAlert || heatingAlert.key !== o.entity_id)) out.push({ key: `open-${o.entity_id}`, kind: "open", severity: "info", text: `${o.name} : ouverte`, short: `${o.name} ouverte` });
  }
  for (const d of state.devices || []) {
    if (d.available === false) out.push({ key: `off-${d.device_id}`, kind: "offline", severity: "warn", text: `${d.name} ne répond plus`, short: `${d.name} ne répond plus` });
    else if (typeof d.battery === "number" && d.battery < 15) out.push({ key: `bat-${d.device_id}`, kind: "battery", severity: "warn", text: `${d.name} : pile faible (${d.battery} %)`, short: `${d.name} ${d.battery} %` });
  }
  return out;
}

/**
 * Everything a home style needs. `get(entity_id)` reads a state (Page.st to re-render on change).
 * `extra` = {now, energy, energyError, heatingAlert, paused} computed by the home page.
 */
export function buildHomeModel(state, hass, get, extra = {}) {
  get(MODE_ENTITY);
  const modeId = currentMode(hass);
  const w = weather(hass);
  if (w) get(w.entity_id);
  const rooms = (state.rooms || []).map((room, index) => {
    const sum = roomSummary(state, room, get);
    return {
      area_id: room.area_id,
      name: room.name,
      icon: room.icon,
      color: roomColor(room, index),
      index,
      temp: sum.temp,
      hum: sum.hum,
      lights: sum.lights.map((l) => l.entity_id),
      hasLight: sum.lights.length > 0,
      lightsOn: sum.lightsOn,
      on: sum.anyLightOn,
      level: lightLevel(sum.lights, get),
      deviceCount: sum.devices.length,
      hasClimate: sum.climates.length > 0,
    };
  });
  const temps = rooms.map((r) => r.temp).filter((t) => t !== null);
  const tiles = [];
  for (const tile of state.idea_tiles || []) {
    // Lazy import cycle avoided: the caller passes tileView through extra.
    const view = extra.tileView ? extra.tileView(tile, get) : null;
    if (view) tiles.push({ tile, view });
  }
  const devices = state.devices || [];
  const cams = roleEntities(devices, "camera");
  const heatingAlert = extra.heatingAlert || null;
  return {
    now: extra.now || new Date(),
    userName: firstName(hass?.user?.name),
    weather: w,
    mode: { id: modeId, ...MODES[modeId] },
    rooms,
    lightsOn: rooms.reduce((a, r) => a + r.lightsOn, 0),
    roomsLit: rooms.filter((r) => r.on).length,
    indoorTemp: temps.length ? temps.reduce((a, b) => a + b, 0) / temps.length : null,
    alerts: homeAlerts(state, get, heatingAlert),
    heatingAlert,
    paused: !!extra.paused,
    tiles,
    activeIdeas: (state.idea_tiles || []).map((t) => t.idea_id),
    energy: extra.energyError ? { state: "error" } : !extra.energy ? { state: "loading" } : !extra.energy.has_data ? { state: "none" } : { state: "ok", ...extra.energy },
    camera: cams[0] ? { entity_id: cams[0].entity_id, name: cams[0].device.name || "Caméra" } : null,
    cameras: cams.map((c) => ({ entity_id: c.entity_id, name: c.device.name || "Caméra" })),
    hasClimate: roleEntities(devices, "climate").length > 0,
    devices,
  };
}

/** "Marie Dupont" -> "Marie" (HA user name; escaped by the templates). */
export function firstName(name) {
  const t = String(name || "").trim();
  return t ? t.split(/\s+/)[0] : "";
}
