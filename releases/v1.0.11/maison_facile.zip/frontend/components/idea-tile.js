// Home-page tiles of the active ideas (state/get.idea_tiles, CONTRACT.md §11).
import { html, raw, num, fmtSmart, toDate, timeHM } from "../lib.js";
import { icon } from "../icons.js";

/** "Aujourd'hui à 10:42", "Hier à 18:05", "le 12 octobre à 9:30". */
export function dayAt(v) {
  const d = toDate(v);
  if (!d) return "";
  const t = timeHM(d);
  const today = new Date();
  const yest = new Date(Date.now() - 86400000);
  if (d.toDateString() === today.toDateString()) return `Aujourd'hui à ${t}`;
  if (d.toDateString() === yest.toDateString()) return `Hier à ${t}`;
  return `Le ${d.toLocaleDateString("fr-FR", { day: "numeric", month: "long" })} à ${t}`;
}

/**
 * What a tile shows right now, or null when it must stay hidden.
 * `get(entity_id)` reads a state (Page.st to re-render on change).
 */
export function tileView(tile, get) {
  // « C'est l'anniversaire de Mamie aujourd'hui » (birthdays.py): no entity behind it.
  if (tile.kind === "birthday") return { tone: "birthday", text: tile.on_text || "", links: tile.links || {} };
  const ids = tile.entity_ids || [];
  const states = ids.map((id) => get(id)).filter(Boolean);
  if (!states.length) return null;
  const s = states[0];
  switch (tile.kind) {
    case "flag": {
      const on = s.state === "on";
      if (tile.show === "on" && !on) return null;
      // « Poubelles » : text attribute (« le bac jaune et le bac vert ») -> « Ce soir : sortez … ».
      const detail = tile.detail_attribute ? s.attributes?.[tile.detail_attribute] : null;
      const text = detail ? `Ce soir : sortez ${detail}` : dayAt(s.attributes?.[tile.attribute || "arrived_at"]) || "En attente";
      return { tone: on ? "lit" : "", text: on ? text : tile.off_text || "", action: on ? tile.action : null };
    }
    case "power": {
      const w = num(s.state);
      const running = w !== null && w > (tile.threshold ?? 10);
      const value = w !== null ? ` · ${fmtSmart(w)} ${tile.unit || "W"}` : "";
      return { tone: running ? "lit" : "", text: `${running ? tile.on_text || "En marche" : tile.off_text || "À l'arrêt"}${running ? value : ""}` };
    }
    case "alarm": {
      const on = states.some((x) => x.state === "on");
      return { tone: on ? "danger" : "ok", text: on ? tile.on_text || "Alerte !" : tile.off_text || "Rien à signaler" };
    }
    default: {
      const v = num(s.state);
      return { tone: "", text: v === null ? "–" : `${fmtSmart(v)} ${tile.unit || ""}`.trim() };
    }
  }
}

/** iPhone / iPad (sms:…&body=) or the rest (sms:…?body=). */
export function isIos() {
  const ua = (typeof navigator !== "undefined" && navigator.userAgent) || "";
  return /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && typeof document !== "undefined" && "ontouchend" in document);
}

/** SMS link of a birthday (links = {sms:{android, ios}, whatsapp}) for this device. */
export function smsHref(links) {
  return links?.sms ? (isIos() ? links.sms.ios : links.sms.android) : "";
}

// Discreet confetti of the birthday tile (no animation with prefers-reduced-motion).
export const BIRTHDAY_CSS = `
.bd-tile { position: relative; overflow: hidden; border-color: color-mix(in srgb, var(--mf-violet) 35%, var(--glass-border)); }
.bd-tile .bd-links { display: flex; gap: 8px; flex-wrap: wrap; }
.bd-tile .bd-links a { text-decoration: none; }
.bd-confetti { position: absolute; inset: 0; pointer-events: none; }
.bd-confetti i { position: absolute; top: -10px; width: 7px; height: 11px; border-radius: 2px; opacity: 0.85; animation: bd-fall 4.5s linear infinite; }
.bd-confetti i:nth-child(1) { left: 8%; background: var(--mf-orange); animation-delay: 0s; }
.bd-confetti i:nth-child(2) { left: 22%; background: var(--mf-gold); animation-delay: 1.2s; }
.bd-confetti i:nth-child(3) { left: 38%; background: var(--mf-teal); animation-delay: 2.6s; }
.bd-confetti i:nth-child(4) { left: 55%; background: var(--mf-violet); animation-delay: 0.7s; }
.bd-confetti i:nth-child(5) { left: 71%; background: var(--mf-green); animation-delay: 3.1s; }
.bd-confetti i:nth-child(6) { left: 86%; background: var(--mf-blue); animation-delay: 1.9s; }
@keyframes bd-fall { 0% { transform: translateY(0) rotate(0); } 100% { transform: translateY(120px) rotate(320deg); } }
@media (prefers-reduced-motion: reduce) { .bd-confetti i { animation: none; top: auto; bottom: 6px; } .bd-confetti i:nth-child(2n) { bottom: 14px; } }
`;

function birthdayTileHtml(tile, view, preview) {
  const links = view.links || {};
  const sms = smsHref(links);
  const order = tile.channel === "whatsapp" ? ["whatsapp", "sms"] : ["sms", "whatsapp"];
  const buttons = !preview && sms
    ? order.map((c) => (c === "sms"
      ? html`<a class="btn secondary sm" href="${sms}">${icon("chat", 18)}SMS</a>`
      : html`<a class="btn secondary sm" href="${links.whatsapp}" target="_blank" rel="noopener">WhatsApp</a>`))
    : [];
  return html`<div class="idea-tile bd-tile" data-key="tile-${tile.key || tile.idea_id}" ${preview ? "" : html`role="status"`}>
    <style>${raw(BIRTHDAY_CSS)}</style>
    <span class="bd-confetti" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></span>
    <span class="it-icon" style="background:${tile.color || "#C2185B"}">${icon(tile.icon || "cake", 26)}</span>
    <span class="grow" style="display:flex;flex-direction:column;gap:6px">
      <span style="display:flex;flex-direction:column"><strong class="it-title">${tile.title}</strong><span class="it-text">${view.text}</span></span>
      ${buttons.length || (!preview && tile.page) ? html`<span class="bd-links">${buttons}${!preview && tile.page ? html`<button type="button" class="btn secondary sm" data-action="tile-action" data-idea="${tile.idea_id}" data-tile-key="${tile.key || ""}">Voir les anniversaires</button>` : ""}</span>` : ""}
    </span>
  </div>`;
}

/** Tile markup. `view` from tileView(), or {text: preview} for the idea page preview. */
export function ideaTileHtml(tile, view, { preview = false } = {}) {
  if (tile.kind === "birthday") return birthdayTileHtml(tile, view, preview);
  const tone = view.tone || (preview && tile.kind === "flag" ? "lit" : "");
  const color = tile.kind === "flag" ? "#B8860B" : tile.color || "#0067C0";
  return html`<div class="idea-tile ${tone}" data-key="tile-${tile.idea_id}" ${preview ? "" : html`role="status"`}>
    <span class="it-icon" style="background:${color}">${icon(tile.icon, 26)}</span>
    <span class="grow" style="display:flex;flex-direction:column"><strong class="it-title">${tile.title}</strong><span class="it-text">${view.text}</span></span>
    ${!preview && view.action
      ? html`<button type="button" class="btn secondary sm" data-action="tile-action" data-idea="${tile.idea_id}">${view.action.label}</button>`
      : ""}
  </div>`;
}
