// « Où l'acheter ? » : same rules as buying_guide.validate_shop_url (Python).
// Pure functions (no DOM): checked against the Python version by tests/test_buying_guide.py.

export const SHOP_URL_MAX = 500;
export const SHOP_PLACEHOLDER = "{need}";
const HOST_RE = /^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/;
const BAD = /[ "'<>\\^`|]/;
const PRINTABLE_ASCII = /^[\x20-\x7E]*$/;

/** Cleaned address, "" (no button) or null when refused (https only, real host name, no login). */
export function validShopUrl(value) {
  if (typeof value !== "string") return null;
  const text = value.trim();
  if (!text) return "";
  if (text.length > SHOP_URL_MAX || !PRINTABLE_ASCII.test(text) || BAD.test(text)) return null;
  const rest = text.split(SHOP_PLACEHOLDER).join("");
  if (rest.includes("{") || rest.includes("}")) return null;
  if (!text.startsWith("https://")) return null;
  const afterScheme = text.slice("https://".length);
  const netloc = afterScheme.split(/[/?#]/)[0];
  if (!netloc || netloc.includes("@") || netloc.includes(SHOP_PLACEHOLDER)) return null;
  let host = netloc;
  const colon = netloc.lastIndexOf(":");
  if (colon >= 0) {
    const port = netloc.slice(colon + 1);
    host = netloc.slice(0, colon);
    if (port !== "" && !(/^[0-9]+$/.test(port) && Number(port) <= 65535)) return null;
  }
  if (!HOST_RE.test(host.toLowerCase())) return null;
  return text;
}

/** Address opened by « Où l'acheter ? » for one kind of device, or null (button hidden). */
export function shopLink(template, guideId) {
  const url = validShopUrl(template);
  if (!url) return null;
  return url.split(SHOP_PLACEHOLDER).join(encodeURIComponent(String(guideId)));
}
