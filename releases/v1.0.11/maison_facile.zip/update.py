"""UpdateEntity "Maison Facile" (installation delegated to the Updater)."""

from __future__ import annotations

from typing import Any

from homeassistant.components.update import UpdateEntity, UpdateEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.device_registry import DeviceEntryType, DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import audience
from .const import DOMAIN, VERSION
from .updater import BUSY_PHASES, Updater, UpdateError


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    updater: Updater | None = getattr(entry.runtime_data, "updater", None)
    if updater is None:
        return
    async_add_entities([MaisonFacileUpdateEntity(entry, updater)])


class MaisonFacileUpdateEntity(UpdateEntity):
    _attr_has_entity_name = True
    _attr_name = None
    _attr_title = "Maison Facile"
    _attr_should_poll = False
    _attr_supported_features = (
        UpdateEntityFeature.INSTALL | UpdateEntityFeature.RELEASE_NOTES | UpdateEntityFeature.PROGRESS
    )

    def __init__(self, entry: ConfigEntry, updater: Updater) -> None:
        self._updater = updater
        self._attr_unique_id = f"{entry.entry_id}_update"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="Maison Facile",
            manufacturer="Maison Facile",
            entry_type=DeviceEntryType.SERVICE,
            sw_version=VERSION,
        )

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(self._updater.async_add_listener(self._handle_progress))

    @callback
    def _handle_progress(self, _payload: dict[str, Any]) -> None:
        self.async_write_ha_state()

    @property
    def installed_version(self) -> str:
        return VERSION

    @property
    def latest_version(self) -> str:
        return self._updater.status()["mf"]["latest"]

    @property
    def in_progress(self) -> bool:
        return self._updater.target == "mf" and self._updater.phase in BUSY_PHASES

    @property
    def update_percentage(self) -> int | None:
        return self._updater.progress if self.in_progress else None

    @property
    def release_summary(self) -> str | None:
        notes = self._updater.status()["mf"]["notes"]
        return notes[0][:255] if notes else None

    async def async_release_notes(self) -> str | None:
        mf = self._updater.status()["mf"]
        if not mf["notes"]:
            return None
        lines = [f"## Maison Facile {mf['latest']}", ""]
        if mf["validated_date"]:
            lines += [f"*Testée par votre installateur le {mf['validated_date']}.*", ""]
        lines += [f"- {note}" for note in mf["notes"]]
        lines += ["", "Une sauvegarde est faite automatiquement avant l'installation."]
        return audience.for_hass("\n".join(lines), self.hass)

    async def async_install(self, version: str | None, backup: bool, **kwargs: Any) -> None:
        # A backup is always made by the updater, whatever ``backup`` says.
        try:
            await self._updater.async_install("mf")
        except UpdateError as err:
            raise HomeAssistantError(audience.for_hass(str(err), self.hass)) from err
