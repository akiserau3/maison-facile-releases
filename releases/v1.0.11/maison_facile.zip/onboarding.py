"""Rooms, device assignment, device listing and start-up status."""

from __future__ import annotations

import logging
import unicodedata
from typing import Any

from homeassistant.config_entries import ConfigEntryState
from homeassistant.const import STATE_UNAVAILABLE
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import area_registry as ar
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er

from . import compat
from .classifier import classify_device, has_primary_entity
from .const import DOMAIN, ROOM_COLORS
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)

Z2M_BRIDGE_MARKER = "zigbee2mqtt_bridge"
Z2M_DEFAULT_BASE_TOPIC = "zigbee2mqtt"

# Integrations whose devices are not "things in the house".
EXCLUDED_DOMAINS = {
    DOMAIN,
    "hassio",
    "mobile_app",
    "sun",
    "met",
    "backup",
    "google_translate",
    "radio_browser",
    "shopping_list",
    "homeassistant_hardware",
    "homeassistant_sky_connect",
    "homeassistant_green",
    "homeassistant_yellow",
    "go2rtc",
    "hacs",
    "thread",
    "otbr",
}

# Order matters: the first match wins ("chambre d'enfant" -> child, not bed).
_ICON_RULES: tuple[tuple[tuple[str, ...], str], ...] = (
    (("enfant", "bebe", "kid"), "child"),
    (("salle de bain", "salle d'eau", "sdb", "douche", "bain"), "bath"),
    (("salon", "sejour"), "sofa"),
    (("cuisine",), "kitchen"),
    (("chambre",), "bed"),
    (("bureau",), "desk"),
    (("entree", "couloir", "hall"), "door"),
    (("garage",), "garage"),
)


def normalize(text: str | None) -> str:
    """Lowercase, strip accents and normalize apostrophes."""
    if not text:
        return ""
    value = unicodedata.normalize("NFKD", str(text).replace("’", "'"))
    value = "".join(c for c in value if not unicodedata.combining(c))
    return " ".join(value.lower().replace("_", " ").split())


def icon_for_room(name: str) -> str:
    norm = normalize(name)
    for words, icon in _ICON_RULES:
        if any(word in norm for word in words):
            return icon
    return "room"


def color_for_index(index: int) -> str:
    return ROOM_COLORS[index % len(ROOM_COLORS)]


# --------------------------------------------------------------------------- rooms


async def async_set_rooms(
    hass: HomeAssistant, store: MaisonFacileStore, wanted: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Create missing HA areas, keep the order, persist the room list."""
    area_reg = ar.async_get(hass)
    rooms: list[dict[str, Any]] = []
    used: set[str] = set()
    for item in wanted:
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        area = None
        if item.get("area_id"):
            # An existing HA area is reused as is: never renamed (its HA name wins).
            area = area_reg.async_get_area(str(item["area_id"]))
        if area is None:
            area = area_reg.async_get_area_by_name(name)
        if area is None:
            area = area_reg.async_create(name)
        if area.id in used:
            continue
        used.add(area.id)
        rooms.append(
            {
                "area_id": area.id,
                "name": area.name,
                "color": color_for_index(len(rooms)),
                "icon": icon_for_room(area.name),
            }
        )
    await store.async_set("rooms", rooms)
    return rooms


# --------------------------------------------------------------------------- devices


def _entry_domains(hass: HomeAssistant, device: dr.DeviceEntry) -> set[str]:
    domains: set[str] = set()
    for entry_id in compat.device_config_entry_ids(device):
        entry = hass.config_entries.async_get_entry(entry_id)
        if entry is not None:
            domains.add(entry.domain)
    return domains


def _is_bridge(device: dr.DeviceEntry) -> bool:
    for identifier in device.identifiers:
        if any(Z2M_BRIDGE_MARKER in str(part) for part in identifier):
            return True
    return "coordinator" in normalize(device.model)


@callback
def describe_device(hass: HomeAssistant, device: dr.DeviceEntry) -> dict[str, Any]:
    """Build the classifier input for one device."""
    ent_reg = er.async_get(hass)
    entities: list[dict[str, Any]] = []
    for entry in er.async_entries_for_device(ent_reg, device.id, include_disabled_entities=True):
        state = hass.states.get(entry.entity_id)
        attrs = state.attributes if state is not None else {}
        entities.append(
            {
                "entity_id": entry.entity_id,
                "domain": entry.domain,
                "device_class": entry.device_class
                or entry.original_device_class
                or attrs.get("device_class"),
                "unit": entry.unit_of_measurement or attrs.get("unit_of_measurement"),
                "original_name": entry.original_name,
                "entity_category": entry.entity_category.value if entry.entity_category else None,
                "disabled": entry.disabled_by is not None,
            }
        )
    return {
        "manufacturer": device.manufacturer,
        "model": device.model,
        "name": device.name_by_user or device.name,
        "entities": entities,
    }


@callback
def is_house_device(hass: HomeAssistant, device: dr.DeviceEntry, description: dict[str, Any]) -> bool:
    if device.entry_type is dr.DeviceEntryType.SERVICE or device.disabled_by is not None:
        return False
    if _entry_domains(hass, device) & EXCLUDED_DOMAINS:
        return False
    if _is_bridge(device):
        return False
    return has_primary_entity(description)


def _battery(hass: HomeAssistant, entity_id: str | None) -> int | None:
    if not entity_id:
        return None
    state = hass.states.get(entity_id)
    if state is None:
        return None
    try:
        return max(0, min(100, round(float(state.state))))
    except (TypeError, ValueError):
        return None


def _available(hass: HomeAssistant, roles: dict[str, str], description: dict[str, Any]) -> bool:
    ids = [eid for role, eid in roles.items() if role != "battery"]
    if not ids:
        ids = [e["entity_id"] for e in description["entities"] if not e.get("disabled")]
    if not ids:
        return False
    for entity_id in ids:
        state = hass.states.get(entity_id)
        if state is not None and state.state != STATE_UNAVAILABLE:
            return True
    return False


def _area_candidates(hass: HomeAssistant, store: MaisonFacileStore) -> list[tuple[str, str]]:
    """(normalized name, area_id), longest names first."""
    seen: dict[str, str] = {}
    for room in store.rooms:
        seen.setdefault(room["area_id"], room["name"])
    for area in ar.async_get(hass).async_list_areas():
        seen.setdefault(area.id, area.name)
    candidates = [(normalize(name), area_id) for area_id, name in seen.items() if name]
    return sorted(candidates, key=lambda c: len(c[0]), reverse=True)


def suggest_area(hass: HomeAssistant, store: MaisonFacileStore, device: dr.DeviceEntry) -> str | None:
    if device.area_id:
        return device.area_id
    text = normalize(device.name_by_user or device.name)
    if not text:
        return None
    for name, area_id in _area_candidates(hass, store):
        if name and name in text:
            return area_id
    return None


@callback
def build_device(
    hass: HomeAssistant,
    store: MaisonFacileStore,
    device: dr.DeviceEntry,
    description: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the Device object of CONTRACT §5."""
    description = description or describe_device(hass, device)
    result = classify_device(description)
    roles: dict[str, str] = result["entities"]
    area_id = device.area_id or store.device_rooms.get(device.id)
    return {
        "device_id": device.id,
        "name": device.name_by_user or device.name or result["type_label"],
        "type": result["type"],
        "type_label": result["type_label"],
        "area_id": area_id,
        "suggested_area_id": area_id or suggest_area(hass, store, device),
        "battery": _battery(hass, roles.get("battery")),
        "available": _available(hass, roles, description),
        "entities": roles,
    }


@callback
def list_devices(hass: HomeAssistant, store: MaisonFacileStore) -> list[dict[str, Any]]:
    dev_reg = dr.async_get(hass)
    devices: list[dict[str, Any]] = []
    for device in compat.iter_devices(dev_reg):
        description = describe_device(hass, device)
        if not is_house_device(hass, device, description):
            continue
        devices.append(build_device(hass, store, device, description))
    devices.sort(key=lambda d: (d["type"], normalize(d["name"])))
    return devices


async def async_assign_device(
    hass: HomeAssistant, store: MaisonFacileStore, device_id: str, area_id: str | None
) -> dict[str, Any]:
    """Assign a device to an area (device registry + store). Raises ValueError (FR)."""
    dev_reg = dr.async_get(hass)
    device = compat.get_main_device(dev_reg, device_id)
    if device is None:
        raise ValueError("Cet appareil est introuvable.")
    if area_id is not None and ar.async_get(hass).async_get_area(area_id) is None:
        raise ValueError("Cette pièce est introuvable.")
    device = dev_reg.async_update_device(device_id, area_id=area_id) or device
    rooms = dict(store.device_rooms)
    if area_id is None:
        rooms.pop(device_id, None)
    else:
        rooms[device_id] = area_id
    await store.async_set("device_rooms", rooms)
    return build_device(hass, store, device)


# --------------------------------------------------------------------------- status


def _entry_loaded(hass: HomeAssistant, domain: str) -> bool:
    return any(
        entry.state is ConfigEntryState.LOADED for entry in hass.config_entries.async_entries(domain)
    )


def _z2m_bridge_devices(hass: HomeAssistant) -> list[dr.DeviceEntry]:
    return [
        device
        for device in compat.iter_devices(dr.async_get(hass))
        if any(Z2M_BRIDGE_MARKER in str(part) for ident in device.identifiers for part in ident)
    ]


def _z2m_present(hass: HomeAssistant) -> bool:
    if _z2m_bridge_devices(hass):
        return True
    if any(Z2M_BRIDGE_MARKER in entry.entity_id for entry in er.async_get(hass).entities.values()):
        return True
    return any(Z2M_BRIDGE_MARKER in state.entity_id for state in hass.states.async_all())


@callback
def detect_radio(hass: HomeAssistant) -> str | None:
    """Return "zha", "z2m" or None.

    Loaded ZHA config entry -> "zha"; otherwise a Zigbee2MQTT bridge device or
    entity present -> "z2m".
    """
    if _entry_loaded(hass, "zha"):
        return "zha"
    if _z2m_present(hass):
        return "z2m"
    return None


async def async_detect_radio(hass: HomeAssistant) -> tuple[bool, str | None]:
    """Public, stable API (used by doctor.py): (radio_found, "zha"|"z2m"|None)."""
    kind = detect_radio(hass)
    return kind is not None, kind


@callback
def z2m_base_topic(hass: HomeAssistant) -> str:
    """Zigbee2MQTT base topic, read from the bridge MQTT subscriptions when possible."""
    try:
        from homeassistant.components.mqtt import debug_info  # noqa: PLC0415

        for device in _z2m_bridge_devices(hass):
            info = debug_info.info_for_device(hass, device.id)
            for entity in info.get("entities", []):
                for sub in entity.get("subscriptions", []):
                    topic = str(sub.get("topic", ""))
                    if "/bridge/" in topic:
                        base = topic.split("/bridge/", 1)[0]
                        if base and "+" not in base and "#" not in base:
                            return base
    except Exception:  # noqa: BLE001 - internal MQTT API, best effort only
        _LOGGER.debug("Could not read the Zigbee2MQTT base topic", exc_info=True)
    return Z2M_DEFAULT_BASE_TOPIC


async def async_network_ok(hass: HomeAssistant) -> bool:
    if hass.config.internal_url:
        return True
    try:
        from homeassistant.components import network  # noqa: PLC0415

        adapters = await network.async_get_adapters(hass)
    except Exception:  # noqa: BLE001 - network component optional
        return True
    for adapter in adapters:
        if adapter.get("enabled") and (adapter.get("ipv4") or adapter.get("ipv6")):
            return True
    return False


async def async_status(hass: HomeAssistant, devices: list[dict[str, Any]]) -> dict[str, Any]:
    radio = detect_radio(hass)
    return {
        "network_ok": await async_network_ok(hass),
        "radio_found": radio is not None,
        "radio_kind": radio,
        "device_count": len(devices),
    }


@callback
def person_entities(hass: HomeAssistant) -> list[str]:
    return sorted(state.entity_id for state in hass.states.async_all("person"))


__all__ = [
    "async_assign_device",
    "async_set_rooms",
    "async_status",
    "build_device",
    "describe_device",
    "async_detect_radio",
    "detect_radio",
    "z2m_base_topic",
    "icon_for_room",
    "is_house_device",
    "list_devices",
    "normalize",
    "person_entities",
]
