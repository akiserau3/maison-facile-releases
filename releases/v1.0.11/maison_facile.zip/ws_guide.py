"""« Bien choisir ses appareils » : websocket ``guide/get`` + cloud integrations (NOTES_guide.md)."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.config_entries import ConfigEntryState
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import device_registry as dr

from . import audience
from . import buying_guide as bg
from . import compat
from .const import DOMAIN, MaisonFacileData

_LOGGER = logging.getLogger(__name__)
_CACHE_KEY = f"{DOMAIN}_buying_guide"
_STARTER_KEY = f"{DOMAIN}_buying_guide_starter"


async def async_guide_items(hass: HomeAssistant) -> list[dict[str, Any]]:
    """Guide entries of ``buying_guide.yaml`` (read once per HA run; invalid entries logged)."""
    cached = hass.data.get(_CACHE_KEY)
    if cached is not None:
        return cached
    items, errors = await hass.async_add_executor_job(bg.load_guide, bg.GUIDE_FILE)
    for error in errors:
        _LOGGER.error("buying_guide.yaml: %s", error)
    hass.data[_CACHE_KEY] = items
    return items


async def async_guide_starter(hass: HomeAssistant) -> dict[str, Any] | None:
    """« Pour commencer » of ``buying_guide.yaml`` (read once per HA run)."""
    if _STARTER_KEY in hass.data:
        return hass.data[_STARTER_KEY]
    items = await async_guide_items(hass)
    starter, errors = await hass.async_add_executor_job(bg.load_starter, bg.GUIDE_FILE, items)
    for error in errors:
        _LOGGER.error("buying_guide.yaml: %s", error)
    hass.data[_STARTER_KEY] = starter
    return starter


@callback
def cloud_integrations(hass: HomeAssistant) -> list[dict[str, Any]]:
    """Loaded cloud integrations (Tuya / Smart Life, eWeLink…) and their number of devices."""
    entry_domain: dict[str, str] = {}
    for domain in bg.CLOUD_INTEGRATIONS:
        for entry in hass.config_entries.async_entries(domain):
            if entry.state is ConfigEntryState.LOADED:
                entry_domain[entry.entry_id] = domain
    if not entry_domain:
        return []
    counts = dict.fromkeys(set(entry_domain.values()), 0)
    for device in compat.iter_devices(dr.async_get(hass)):
        domains = {entry_domain[e] for e in compat.device_config_entry_ids(device) if e in entry_domain}
        for domain in domains:
            counts[domain] += 1
    return bg.cloud_summary(counts)


def _data(hass: HomeAssistant) -> MaisonFacileData | None:
    for entry in hass.config_entries.async_entries(DOMAIN):
        data = getattr(entry, "runtime_data", None)
        if isinstance(data, MaisonFacileData):
            return data
    return None


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/guide/get"})
@websocket_api.async_response
async def ws_guide_get(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    data = _data(hass)
    items = await async_guide_items(hass)
    ideas = data.ideas.ideas if data is not None and data.ideas is not None else []
    shop_url = ""
    settings: dict[str, Any] = {}
    if data is not None and data.store is not None:
        settings = data.store.settings
        shop_url = str(settings.get("shop_url") or "")
    payload = bg.guide_payload(items, ideas, shop_url, await async_guide_starter(hass))
    payload["cloud"] = cloud_integrations(hass)
    connection.send_result(msg["id"], audience.for_settings(payload, settings))


@callback
def async_register(hass: HomeAssistant) -> None:
    websocket_api.async_register_command(hass, ws_guide_get)
