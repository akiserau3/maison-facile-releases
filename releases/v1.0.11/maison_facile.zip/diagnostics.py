"""Redacted diagnostics + plain-text report for the installer."""

from __future__ import annotations

import ipaddress
import re
from collections.abc import Iterable
from typing import Any

from homeassistant.components.diagnostics import async_redact_data
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import __version__ as HA_VERSION
from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .const import DOMAIN, VERSION
from .theme_rules import report_line as theme_report_line

REDACTED = "**REDACTED**"
MAX_LOG_LINES = 15

TO_REDACT: set[str] = {
    "password", "passwd", "pass", "pin", "code", "secret", "token", "access_token",
    "refresh_token", "api_key", "apikey", "key", "auth", "authorization", "credentials",
    "username", "user", "email", "e-mail", "phone", "telephone", "mobile",
    "latitude", "longitude", "installer_contact", "webhook_id", "cloudhook_url",
    "external_url", "internal_url", "ssid", "mac", "serial_number",
}

_URL_CREDS_RE = re.compile(r"(?P<scheme>[a-zA-Z][a-zA-Z0-9+.-]*://)[^\s/@:]+(?::[^\s/@]*)?@")
_URL_TOKEN_RE = re.compile(r"(?i)([?&](?:token|access_token|api_key|apikey|key|auth|password|sig|signature)=)[^&\s]+")
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(
    r"(?<![\w.:+-])(?:(?:\+|00)[1-9]\d{0,2}[ .-]?[1-9](?:[ .-]?\d{2}){4}|0[1-9](?:[ .-]?\d{2}){4})(?![\w.:-])"
)
_IPV4_RE = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])")
_IPV6_RE = re.compile(r"(?<![\w:])[0-9A-Fa-f]{0,4}(?::{1,2}[0-9A-Fa-f]{0,4}){2,7}(?![\w:])")
_BEARER_RE = re.compile(r"(?i)\b(bearer|token)\s+[A-Za-z0-9._\-]{16,}")
_JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\b")


def _ip_sub(match: re.Match[str]) -> str:
    text = match.group(0)
    try:
        ip = ipaddress.ip_address(text)
    except ValueError:
        return text
    if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_unspecified:
        return text
    return "[IP PUBLIQUE]"


def scrub_text(text: str) -> str:
    """Remove credentials, tokens, e-mails, phone numbers and public IPs from text."""
    text = _URL_CREDS_RE.sub(lambda m: f"{m.group('scheme')}{REDACTED}@", text)
    text = _URL_TOKEN_RE.sub(lambda m: f"{m.group(1)}{REDACTED}", text)
    text = _JWT_RE.sub(REDACTED, text)
    text = _BEARER_RE.sub(lambda m: f"{m.group(1)} {REDACTED}", text)
    text = _EMAIL_RE.sub("[E-MAIL]", text)
    text = _IPV4_RE.sub(_ip_sub, text)
    text = _IPV6_RE.sub(_ip_sub, text)
    text = _PHONE_RE.sub("[TÉLÉPHONE]", text)
    return text


def scrub(data: Any) -> Any:
    """Key-based redaction (async_redact_data) + text scrubbing of every string."""
    redacted = async_redact_data(data, TO_REDACT) if isinstance(data, (dict, list)) else data
    return _scrub_values(redacted)


def _scrub_values(data: Any) -> Any:
    if isinstance(data, str):
        return scrub_text(data)
    if isinstance(data, dict):
        return {k: _scrub_values(v) for k, v in data.items()}
    if isinstance(data, (list, tuple)):
        return [_scrub_values(v) for v in data]
    return data


def _runtime(entry: ConfigEntry | None) -> Any:
    return getattr(entry, "runtime_data", None) if entry else None


def _entry(hass: HomeAssistant) -> ConfigEntry | None:
    entries = hass.config_entries.async_entries(DOMAIN)
    return entries[0] if entries else None


async def async_get_config_entry_diagnostics(hass: HomeAssistant, entry: ConfigEntry) -> dict[str, Any]:
    runtime = _runtime(entry)
    store = getattr(runtime, "store", None)
    updater = getattr(runtime, "updater", None)
    doctor = getattr(runtime, "doctor", None)
    data: dict[str, Any] = {
        "ha_version": HA_VERSION,
        "mf_version": VERSION,
        "entry": {"title": entry.title, "options": dict(entry.options)},
        "settings": dict(store.data.get("settings", {})) if store else None,
        "update_state": dict(store.data.get("update", {})) if store else None,
        "rooms": len(store.data.get("rooms", [])) if store else None,
        "recommendations": (
            {k: {"enabled": v.get("enabled")} for k, v in store.data.get("recommendations", {}).items()}
            if store else None
        ),
        "updates": updater.status() if updater else None,
        "doctor": {
            "checked_at": doctor.checked_at,
            "findings": doctor.findings,
            "problems": [{k: p[k] for k in ("id", "severity", "title", "tech")} for p in doctor.problems],
        } if doctor else None,
        "recent_errors": _recent_log_errors(hass, _concerned_domains(doctor)),
    }
    return scrub(data)


# --------------------------------------------------------------------------- report


def _concerned_domains(doctor: Any) -> set[str]:
    domains = {DOMAIN}
    for finding in getattr(doctor, "findings", []) or []:
        for key in ("integration", "domain"):
            if finding.get(key):
                domains.add(str(finding[key]))
    return domains


def _recent_log_errors(hass: HomeAssistant, domains: Iterable[str]) -> list[str]:
    """Last error/warning lines of system_log for ``domains`` (best effort, read-only)."""
    handler = hass.data.get("system_log")
    records = getattr(handler, "records", None)
    if records is None or not hasattr(records, "to_list"):
        return []
    wanted = tuple(f"homeassistant.components.{d}" for d in domains) + tuple(
        f"custom_components.{d}" for d in domains
    )
    lines: list[str] = []
    try:
        for record in records.to_list():
            name = str(record.get("name", ""))
            if not name.startswith(wanted):
                continue
            when = record.get("timestamp")
            stamp = dt_util.utc_from_timestamp(when).strftime("%d/%m %H:%M") if isinstance(when, (int, float)) else "?"
            message = record.get("message") or [""]
            first = message[0] if isinstance(message, list) else str(message)
            lines.append(f"[{stamp}] {record.get('level', '')} {name} : {str(first)[:300]}")
    except Exception:  # noqa: BLE001 - never fail the report because of the log
        return []
    return lines[-MAX_LOG_LINES:]


async def async_build_report(hass: HomeAssistant) -> str:
    """Readable, redacted text report (``doctor/report``)."""
    entry = _entry(hass)
    runtime = _runtime(entry)
    store = getattr(runtime, "store", None)
    updater = getattr(runtime, "updater", None)
    doctor = getattr(runtime, "doctor", None)
    settings = store.data.get("settings", {}) if store else {}

    if doctor is not None and doctor.checked_at is None:
        await doctor.async_analyze()

    out: list[str] = [
        "RAPPORT MAISON FACILE",
        f"Généré le : {dt_util.now().strftime('%d/%m/%Y %H:%M')}",
        f"Home Assistant : {HA_VERSION}",
        f"Maison Facile : {VERSION}",
        f"Mode des mises à jour : {settings.get('update_mode', '?')} (canal {settings.get('update_channel', '?')})",
        theme_report_line(settings),
        "",
    ]

    if updater is not None:
        st = updater.status()
        out += [
            "== Mises à jour ==",
            f"Maison Facile : installée {st['mf']['installed']}, dernière {st['mf']['latest']}"
            f"{' (disponible)' if st['mf']['available'] else ''}",
            f"Système : installé {st['core']['installed']}, dernier {st['core']['latest']}, "
            f"validé : {'oui' if st['core']['validated'] else 'non'}",
            f"Micrologiciels en attente : {st['firmware']['pending']}",
            f"Dernière sauvegarde : {st['last_backup'] or 'aucune'}",
            f"Phase : {st['phase']} ({st['progress']} %)",
        ]
        if st.get("error"):
            out.append(f"Vérification : {st['error']}")
        if st.get("last_failure"):
            out.append(f"Dernier échec : {st['last_failure']}")
        out.append("")

    if doctor is not None:
        out.append(f"== Problèmes ({len(doctor.problems)}) — vérifié le {doctor.checked_at} ==")
        for p in doctor.problems:
            out.append(f"- [{p['severity']}] {p['title']} (id {p['id']}, correction {p['fix']['kind']})")
            for line in str(p.get("tech") or "").splitlines():
                out.append(f"    {line}")
        if not doctor.problems:
            out.append("Aucun problème.")
        out.append("")

        unavailable = [f for f in doctor.findings if f.get("kind") in ("unavailable_device", "camera_unavailable")]
        out.append(f"== Appareils indisponibles ({len(unavailable)}) ==")
        for f in unavailable:
            out.append(
                f"- {f.get('name')} — {f.get('entity_id')} ({f.get('integration') or '?'})"
                + (f", pile {f['battery']:.0f} %" if isinstance(f.get("battery"), (int, float)) else "")
                + (f", depuis {f['last_seen_hours']} h" if f.get("last_seen_hours") is not None else "")
            )
        out.append("")

        disk = doctor.disk
        out.append("== Espace disque ==")
        if disk:
            out.append(
                f"{disk['percent']} % utilisés ({disk['used_gb']} / {disk['total_gb']} Go, libre {disk['free_gb']} Go)"
                + (f", enregistrements vidéo {disk['recordings_gb']} Go" if disk.get("recordings_gb") else "")
            )
        else:
            out.append("inconnu")
        out.append("")

    errors = _recent_log_errors(hass, _concerned_domains(doctor))
    out.append(f"== Dernières erreurs du journal ({len(errors)}) ==")
    out += errors or ["aucune"]

    return scrub_text("\n".join(out))
