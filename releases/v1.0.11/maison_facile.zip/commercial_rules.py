"""Pure logic of the "commercial mode" (Home Assistant hidden behind "Réglages avancés").

This module must NOT import homeassistant: it is unit-tested on its own.

- installer code (PIN): salted PBKDF2-SHA256 hash, constant-time check;
- attempt limiter (5 failures / 5 min per user, in memory);
- frontend system data "core": set or remove our ``default_panel``;
- frontend user data "sidebar": hide every panel except ours, and restore.
"""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
from typing import Any

PIN_RE = re.compile(r"^[0-9]{4,8}$")
PIN_ITERATIONS = 120_000
PIN_ALGO = "pbkdf2_sha256"

UNLOCK_SECONDS = 30 * 60
MAX_ATTEMPTS = 5
ATTEMPT_WINDOW_SECONDS = 5 * 60


# --------------------------------------------------------------------------- installer code


def valid_pin(pin: Any) -> bool:
    """4 to 8 digits (a string: "0042" is not the number 42)."""
    return isinstance(pin, str) and bool(PIN_RE.match(pin))


def hash_pin(pin: str, salt: bytes | None = None, iterations: int | None = None) -> dict[str, Any]:
    """Return the stored record of a PIN. The PIN itself is never stored."""
    if not valid_pin(pin):
        raise ValueError("invalid pin")
    iterations = iterations or PIN_ITERATIONS
    salt = salt if salt is not None else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", pin.encode(), salt, iterations)
    return {"algo": PIN_ALGO, "salt": salt.hex(), "iterations": iterations, "hash": digest.hex()}


def verify_pin(pin: Any, record: dict[str, Any] | None) -> bool:
    """Constant-time check of ``pin`` against a record made by ``hash_pin``."""
    if not record or not isinstance(pin, str):
        return False
    try:
        salt = bytes.fromhex(record["salt"])
        expected = bytes.fromhex(record["hash"])
        iterations = int(record["iterations"])
    except (KeyError, TypeError, ValueError):
        return False
    if record.get("algo") != PIN_ALGO or iterations < 1:
        return False
    # Hash even a malformed PIN so that timing does not reveal the format check.
    digest = hashlib.pbkdf2_hmac("sha256", pin.encode()[:64], salt, iterations)
    return hmac.compare_digest(digest, expected) and valid_pin(pin)


class AttemptLimiter:
    """At most ``max_attempts`` wrong codes per user over a sliding window."""

    def __init__(self, max_attempts: int = MAX_ATTEMPTS, window: float = ATTEMPT_WINDOW_SECONDS) -> None:
        self.max_attempts = max_attempts
        self.window = window
        self._failures: dict[str, list[float]] = {}

    def _recent(self, user_id: str, now: float) -> list[float]:
        kept = [t for t in self._failures.get(user_id, []) if now - t < self.window]
        if kept:
            self._failures[user_id] = kept
        else:
            self._failures.pop(user_id, None)
        return kept

    def retry_after(self, user_id: str, now: float) -> float:
        """Seconds to wait before a new attempt (0 = allowed)."""
        recent = self._recent(user_id, now)
        if len(recent) < self.max_attempts:
            return 0.0
        return max(0.0, self.window - (now - recent[0]))

    def remaining(self, user_id: str, now: float) -> int:
        return max(0, self.max_attempts - len(self._recent(user_id, now)))

    def failure(self, user_id: str, now: float) -> None:
        self._recent(user_id, now)
        self._failures.setdefault(user_id, []).append(now)

    def reset(self, user_id: str) -> None:
        self._failures.pop(user_id, None)


def wait_message_fr(seconds: float) -> str:
    minutes = max(1, int((seconds + 59) // 60))
    return (
        "Trop d'essais avec un mauvais code. "
        f"Réessayez dans {minutes} minute{'s' if minutes > 1 else ''}."
    )


# --------------------------------------------------------------------------- default panel


def plan_system_core(core: Any, enabled: bool, panel: str) -> dict[str, Any] | None:
    """New value of the frontend system data "core", or None when nothing changes.

    ``enabled`` → ``default_panel = panel`` (other keys preserved). Not enabled →
    ``default_panel`` removed only if it is ours (a choice made by someone else stays).
    """
    current: dict[str, Any] = dict(core) if isinstance(core, dict) else {}
    if enabled:
        if current.get("default_panel") == panel:
            return None
        current["default_panel"] = panel
        return current
    if current.get("default_panel") != panel:
        return None
    del current["default_panel"]
    return current


def plan_system_core_restore(core: Any, panel: str) -> dict[str, Any] | None:
    """After someone else rewrote "core": put our ``default_panel`` back only if it is gone.

    Home Assistant's own onboarding (frontend 2026.x) ends with
    ``frontend/set_system_data core = {onboarded_version, onboarded_date}``, which
    REPLACES the whole value and so drops our ``default_panel``. A default panel
    explicitly chosen by an administrator (any other value) is left alone.
    """
    current: dict[str, Any] = dict(core) if isinstance(core, dict) else {}
    if current.get("default_panel"):
        return None
    current["default_panel"] = panel
    return current


# --------------------------------------------------------------------------- sidebar


def hidden_panels(panel_urls: list[str] | set[str], keep: str) -> list[str]:
    """Every registered panel except ``keep`` (sorted, stable for comparisons)."""
    return sorted({url for url in panel_urls if url and url != keep})


def plan_sidebar(current: Any, panel_urls: list[str] | set[str], keep: str) -> dict[str, Any]:
    """Sidebar user data showing only ``keep`` (first in the order)."""
    cur: dict[str, Any] = dict(current) if isinstance(current, dict) else {}
    order = [p for p in (cur.get("panelOrder") or []) if isinstance(p, str) and p != keep]
    cur["panelOrder"] = [keep, *order]
    cur["hiddenPanels"] = hidden_panels(panel_urls, keep)
    return cur


def sidebar_matches(current: Any, applied: Any) -> bool:
    """True when the user did not change the sidebar we applied."""
    if not isinstance(current, dict) or not isinstance(applied, dict):
        return False
    return sorted(current.get("hiddenPanels") or []) == sorted(applied.get("hiddenPanels") or [])


def restore_sidebar(current: Any, saved: Any, applied: Any) -> dict[str, Any] | None:
    """Value to write back when commercial mode ends, or None to leave it alone.

    The value saved before our change comes back (``{}`` = HA default) unless the
    user changed the sidebar since (then their choice is kept).
    """
    if not sidebar_matches(current, applied):
        return None
    return dict(saved) if isinstance(saved, dict) else {}
