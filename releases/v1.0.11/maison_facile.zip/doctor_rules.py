"""Pure troubleshooting rules for Maison Facile (no Home Assistant import).

A *finding* is a raw dict collected by ``doctor.py`` with a ``kind`` key, e.g.::

    {"kind": "low_battery", "name": "Fenêtre chambre", "battery": 8, "entity_id": "..."}

``build_problems`` turns findings into ``Problem`` dicts (CONTRACT §5) written in very
simple French. To support a new kind of finding, write one ``_rule_xxx`` function and
add it to :data:`RULES`. To explain a new Home Assistant repair issue in plain words,
add an entry to :data:`KNOWN_HA_ISSUES`.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable
from typing import Any

Problem = dict[str, Any]
Finding = dict[str, Any]

LOW_BATTERY_THRESHOLD = 15         # strictly below this percentage = low
DISK_WARNING_PERCENT = 80
DISK_ERROR_PERCENT = 90
KEEP_DAYS_CHOICES = (7, 3)          # first one is recommended
DEFAULT_KEEP_DAYS = KEEP_DAYS_CHOICES[0]
MAX_MF_BACKUPS = 3

ACTION_CHECK = "C'est fait, vérifier"
ACTION_FIX = "Réparer pour moi"
ACTION_RETRY = "Réessayer"
ACTION_HELP = "Demander de l'aide"

STATUS_AUTO = "Réparable automatiquement"
STATUS_AUTO_CHOICE = "Réparable automatiquement · un choix à faire"
STATUS_MANUAL = "À faire par vous, 2 minutes"
STATUS_NONE = "Votre installateur peut s'en occuper"

STEP_HELP = "Appuyez sur « Demander de l'aide » : votre installateur recevra les détails, sans vos mots de passe."

_SEVERITY_ORDER = {"error": 0, "warning": 1, "info": 2}

# Device type (CONTRACT §5) -> simple French noun used in titles.
_DEVICE_NOUNS: dict[str, str] = {
    "ouverture": "Le détecteur d'ouverture",
    "mouvement": "Le détecteur de mouvement",
    "thermo": "Le thermomètre",
    "prise": "La prise",
    "lumiere": "La lumière",
    "fumee": "Le détecteur de fumée",
    "camera": "La caméra",
    "chauffage": "Le chauffage",
    "sirene": "La sirène",
    "autre": "L'appareil",
}
# Types that are plugged in (no battery to change).
_MAINS_TYPES = {"prise", "lumiere", "chauffage", "camera"}


# --------------------------------------------------------------------------- helpers


def slug(value: Any) -> str:
    """Lowercase ascii slug usable in ids (issue registry issue_id)."""
    text = str(value or "").lower()
    for src, dst in (("àâä", "a"), ("éèêë", "e"), ("îï", "i"), ("ôö", "o"), ("ùûü", "u"), ("ç", "c")):
        for char in src:
            text = text.replace(char, dst)
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    return text[:80] or "x"


def _fix(kind: str, label: str = "", choices: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    return {"kind": kind, "label": label, "choices": choices or []}


def _problem(
    pid: str,
    severity: str,
    title: str,
    status: str,
    why: str,
    steps: list[str],
    fix: dict[str, Any],
    tech: str,
) -> Problem:
    return {
        "id": pid,
        "severity": severity,
        "title": title,
        "status": status,
        "why": why,
        "steps": steps,
        "fix": fix,
        "tech": tech,
    }


def _name(finding: Finding, default: str = "sans nom") -> str:
    name = str(finding.get("name") or "").strip()
    return name or default


def _as_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def since_text(hours: Any) -> str:
    """'Depuis 3 heures', 'Depuis 2 jours'… ('' if unknown)."""
    value = _as_number(hours)
    if value is None or value < 0:
        return ""
    if value < 1:
        return "Depuis moins d'une heure"
    if value < 24:
        count = int(value)
        return f"Depuis {count} heure{'s' if count > 1 else ''}"
    days = int(value // 24)
    return f"Depuis {days} jour{'s' if days > 1 else ''}"


def _join_status(*parts: str) -> str:
    return " · ".join(p for p in parts if p)


def _tech_lines(finding: Finding, keys: Iterable[str]) -> str:
    lines = []
    for key in keys:
        value = finding.get(key)
        if value not in (None, "", [], {}):
            lines.append(f"{key} : {value}")
    return "\n".join(lines)


def keep_days_choices() -> list[dict[str, Any]]:
    return [
        {"value": str(days), "label": f"Garder {days} jours", "recommended": days == DEFAULT_KEEP_DAYS}
        for days in KEEP_DAYS_CHOICES
    ]


# --------------------------------------------------------------------------- rules


def _rule_unavailable_device(f: Finding) -> Problem:
    name = _name(f)
    dtype = str(f.get("type") or "autre")
    noun = _DEVICE_NOUNS.get(dtype, _DEVICE_NOUNS["autre"])
    battery = _as_number(f.get("battery"))
    key = f.get("device_id") or f.get("entity_id") or name
    title = f"{noun} « {name} » ne répond plus"

    if battery is not None and battery < LOW_BATTERY_THRESHOLD:
        why = f"Sa pile est presque vide : il restait {int(battery)} % lors de son dernier signal."
        steps = [
            "Ouvrez le couvercle de l'appareil (il se fait souvent glisser ou se dévisse).",
            "Remplacez la pile par le même modèle (il est écrit sur l'ancienne).",
            "Appuyez une fois sur le petit bouton de l'appareil.",
            f"Appuyez sur « {ACTION_CHECK} ».",
        ]
    elif dtype in _MAINS_TYPES:
        why = "Il est peut-être débranché, éteint, ou il a perdu le contact avec la box après une coupure de courant."
        steps = [
            "Vérifiez qu'il est bien branché et que la prise murale fonctionne.",
            "Débranchez-le 10 secondes, puis rebranchez-le.",
            "Attendez une minute, puis appuyez sur « C'est fait, vérifier ».",
        ]
    else:
        why = "Sa pile est peut-être vide, ou il est trop loin de la box pour l'entendre."
        steps = [
            "Remplacez sa pile par le même modèle (il est écrit sur l'ancienne).",
            "S'il est loin de la box, rapprochez-le pour essayer.",
            "Appuyez une fois sur le petit bouton de l'appareil.",
            f"Appuyez sur « {ACTION_CHECK} ».",
        ]
    status = _join_status(since_text(f.get("last_seen_hours")), STATUS_MANUAL)
    tech = _tech_lines(f, ("entity_id", "device_id", "integration", "battery", "last_seen_hours"))
    tech = f"{tech}\nétat : unavailable".strip()
    return _problem(
        f"unavailable_device_{slug(key)}", "warning", title, status, why, steps,
        _fix("manual", ACTION_CHECK), tech,
    )


def _rule_low_battery(f: Finding) -> Problem | None:
    battery = _as_number(f.get("battery"))
    if battery is None or battery >= LOW_BATTERY_THRESHOLD:
        return None
    name = _name(f)
    key = f.get("entity_id") or f.get("device_id") or name
    return _problem(
        f"low_battery_{slug(key)}",
        "warning" if battery <= 5 else "info",
        f"La pile de « {name} » est presque vide ({int(battery)} %)",
        STATUS_MANUAL,
        "Quand la pile sera vide, l'appareil ne pourra plus prévenir la box. Mieux vaut la changer maintenant.",
        [
            "Ouvrez le couvercle de l'appareil.",
            "Remplacez la pile par le même modèle (il est écrit sur l'ancienne).",
            f"Appuyez sur « {ACTION_CHECK} ». Le niveau peut mettre quelques minutes à remonter.",
        ],
        _fix("manual", ACTION_CHECK),
        _tech_lines(f, ("entity_id", "device_id", "battery")),
    )


def _rule_disk_usage(f: Finding) -> Problem | None:
    percent = _as_number(f.get("percent"))
    if percent is None or percent < DISK_WARNING_PERCENT:
        return None
    recordings = _as_number(f.get("recordings_gb"))
    if recordings:
        why = (
            f"Les vidéos de la caméra prennent de la place ({recordings:.0f} Go). "
            "Il faut garder moins de jours d'historique."
        )
    else:
        why = "L'historique de la maison et les anciennes sauvegardes prennent de la place. Il faut en garder moins."
    return _problem(
        "disk_usage",
        "error" if percent >= DISK_ERROR_PERCENT else "warning",
        f"La mémoire de la box est presque pleine ({int(percent)} %)",
        STATUS_AUTO_CHOICE,
        why,
        [
            "Choisissez combien de jours d'historique garder.",
            f"Appuyez sur « {ACTION_FIX} » : la box fait le ménage toute seule.",
            f"Les plus anciennes sauvegardes Maison Facile sont aussi supprimées (on garde les {MAX_MF_BACKUPS} dernières).",
        ],
        _fix("auto", ACTION_FIX, keep_days_choices()),
        _tech_lines(f, ("percent", "used_gb", "total_gb", "recordings_gb", "path"))
        + "\nAction auto : recorder.purge keep_days + suppression des anciennes sauvegardes Maison Facile",
    )


def _rule_camera_unavailable(f: Finding) -> Problem:
    name = _name(f)
    key = f.get("entity_id") or name
    can_reload = bool(f.get("entry_id"))
    why = "Elle a sans doute perdu la connexion WiFi, par exemple après une coupure de courant."
    if can_reload:
        steps = [
            f"Appuyez sur « {ACTION_FIX} » : la box relance la connexion avec la caméra.",
            "Si l'image ne revient pas, débranchez la caméra 10 secondes puis rebranchez-la.",
        ]
        fix = _fix("auto", ACTION_FIX)
        status = STATUS_AUTO
    else:
        steps = [
            "Débranchez la caméra 10 secondes, puis rebranchez-la.",
            "Vérifiez que la box internet est allumée.",
            f"Attendez une minute, puis appuyez sur « {ACTION_CHECK} ».",
        ]
        fix = _fix("manual", ACTION_CHECK)
        status = STATUS_MANUAL
    tech = _tech_lines(f, ("entity_id", "integration", "entry_id")) + "\nétat : unavailable"
    if can_reload:
        tech += "\nAction auto : rechargement de l'intégration"
    return _problem(f"camera_unavailable_{slug(key)}", "error",
                    f"La caméra « {name} » n'envoie plus d'image", status, why, steps, fix, tech)


def _rule_update_failed(f: Finding) -> Problem:
    target = f.get("target") or "mf"
    what = "du système de la box" if target == "core" else "de Maison Facile"
    return _problem(
        f"update_failed_{slug(target)}",
        "warning",
        f"La dernière mise à jour {what} n'a pas pu s'installer",
        STATUS_AUTO,
        "Rien n'a été cassé : la box a gardé l'ancienne version, qui continue de fonctionner.",
        [
            "Vérifiez que la box internet fonctionne.",
            f"Appuyez sur « {ACTION_RETRY} ». Une sauvegarde est faite avant, comme toujours.",
            "Si cela échoue encore, votre installateur s'en occupera.",
        ],
        _fix("auto", ACTION_RETRY),
        _tech_lines(f, ("target", "version", "phase", "error", "at")),
    )


def _rule_radio_missing(f: Finding) -> Problem:
    return _problem(
        "radio_missing",
        "warning",
        "L'antenne sans fil n'est pas détectée",
        STATUS_MANUAL,
        "Sans elle, la box ne peut pas parler aux capteurs, prises et lumières sans fil.",
        [
            "Vérifiez que la petite clé USB (l'antenne) est bien branchée sur la box.",
            "Branchez-la de préférence au bout de la rallonge USB, un peu à l'écart de la box.",
            f"Appuyez sur « {ACTION_CHECK} ».",
        ],
        _fix("manual", ACTION_CHECK),
        _tech_lines(f, ("detail",)) or "Aucune intégration ZHA ni Zigbee2MQTT chargée",
    )


# Link of a soft notice to a page of the panel (the Dépannage shows it as a button).
GUIDE_BUY_LINK: dict[str, Any] = {"page": "guide", "params": {"tab": "buy"}, "label": "Quoi acheter ?"}


def _rule_radio_not_yet(f: Finding) -> Problem:
    """Box installed without hardware (installer v1.4): no antenna yet is normal, not a problem."""
    problem = _problem(
        "radio_not_yet",
        "info",
        "Pas encore d'antenne Zigbee : c'est normal",
        "Rien à réparer · voici quoi acheter",
        "Votre box marche déjà : météo, anniversaires, thèmes de fêtes, appareils trouvés sur le réseau. "
        "Pour les capteurs, prises et lumières sans fil, il lui faudra une petite antenne Zigbee (une clé USB).",
        [
            "Regardez « Quoi acheter ? » : l'antenne et 2 ou 3 capteurs pour bien commencer.",
            "Branchez l'antenne sur la box, de préférence au bout d'une petite rallonge USB.",
            "La box la reconnaît toute seule : ce message disparaît.",
        ],
        _fix("none", GUIDE_BUY_LINK["label"]),
        _tech_lines(f, ("detail",)) or "Aucune antenne, aucun appareil, equipment=none ou inconnu",
    )
    problem["notice"] = True  # not counted as a problem (headline, badge, Réparations HA)
    problem["link"] = dict(GUIDE_BUY_LINK, params=dict(GUIDE_BUY_LINK["params"]))
    return problem


def _rule_automations_not_loaded(f: Finding) -> Problem:
    return _problem(
        "automations_not_loaded",
        "warning",
        "Les automatismes Maison Facile ne sont pas chargés",
        STATUS_NONE,
        "Le fichier des automatismes de la box est peut-être découpé autrement que prévu. "
        "Les lumières, alertes et pauses de chauffage automatiques ne marchent peut-être pas.",
        [STEP_HELP],
        _fix("none", ACTION_HELP),
        _tech_lines(f, ("detail",)) or "automations.last_apply_ok = False",
    )


_PROVISION_STEPS_FR: dict[str, list[str]] = {
    "zigbee": [
        "Vérifiez que la petite clé USB (l'antenne) est bien branchée sur la box.",
        f"Appuyez sur « {ACTION_RETRY} » : la box recommence la préparation de l'antenne.",
        "Si cela échoue encore, votre installateur s'en occupera.",
    ],
    "weather": [
        "Vérifiez que la box internet fonctionne.",
        f"Appuyez sur « {ACTION_RETRY} ».",
    ],
    "cameras": [
        "Vérifiez que les caméras sont branchées et allumées.",
        f"Appuyez sur « {ACTION_RETRY} ». Si leurs identifiants ont été effacés, votre installateur les ajoutera.",
    ],
}


def _rule_provision_failed(f: Finding) -> Problem:
    step = slug(f.get("step") or "x")
    label = str(f.get("label") or "une étape")
    message = str(f.get("message") or "").strip()
    steps = list(_PROVISION_STEPS_FR.get(step, [
        f"Appuyez sur « {ACTION_RETRY} ».",
        "Si cela échoue encore, votre installateur s'en occupera.",
    ]))
    return _problem(
        f"provision_failed_{step}",
        "warning",
        f"Préparation de la box : « {label} » n'a pas abouti",
        STATUS_AUTO,
        message or "Une étape de la préparation automatique de la box n'a pas marché.",
        steps,
        _fix("auto", ACTION_RETRY),
        _tech_lines(f, ("step", "detail")) + f"\nAction auto : provision/retry {step}",
    )


def _rule_hacs_not_activated(f: Finding) -> Problem:
    return _problem(
        "hacs_not_activated",
        "info",
        "Les outils de l'installateur ne sont pas encore activés",
        STATUS_NONE,
        "Ils servent à votre installateur pour ajouter des modules en plus. "
        "Tout fonctionne sans eux en attendant.",
        [
            "Rien à faire de votre côté : votre installateur les activera avec son propre compte lors de son passage.",
        ],
        _fix("none", ACTION_HELP),
        _tech_lines(f, ("path",)) or "custom_components/hacs présent, aucune entrée hacs (connexion GitHub à faire par l'installateur)",
    )


# Plain-French explanations of Home Assistant repair issues we know.
# Key: (domain, translation_key) or ("*", translation_key) for any domain.
KNOWN_HA_ISSUES: dict[tuple[str, str], dict[str, Any]] = {
    ("*", "deprecated_yaml"): {
        "title": "Un réglage de « {domain} » est à moderniser",
        "why": "Une ancienne façon de régler ce module ne sera bientôt plus acceptée. Tout marche pour l'instant.",
        "steps": ["Rien à faire de votre côté pour le moment.", STEP_HELP],
    },
    ("homeassistant", "integration_not_found"): {
        "title": "Un module de la box est introuvable",
        "why": "Un module installé autrefois a disparu. Les appareils qui en dépendent peuvent ne plus marcher.",
        "steps": [STEP_HELP],
    },
    ("hassio", "unhealthy"): {
        "title": "Le système de la box signale un souci de santé",
        "why": "La box a détecté quelque chose d'anormal et bloque les mises à jour par prudence.",
        "steps": ["Redémarrez la box : débranchez-la 10 secondes, puis rebranchez-la.", STEP_HELP],
    },
    ("hassio", "unsupported"): {
        "title": "Le système de la box n'est pas dans une configuration prévue",
        "why": "Tout peut fonctionner, mais certaines mises à jour pourraient être refusées.",
        "steps": [STEP_HELP],
    },
    ("backup", "automatic_backup_failed_create"): {
        "title": "La sauvegarde automatique n'a pas pu se faire",
        "why": "La box n'a pas réussi à faire sa copie de sécurité. La mémoire est peut-être pleine.",
        "steps": ["Regardez s'il y a un problème « mémoire presque pleine » dans cette liste.", STEP_HELP],
    },
    ("backup", "automatic_backup_failed_upload_agents"): {
        "title": "La sauvegarde n'a pas pu être envoyée en lieu sûr",
        "why": "La copie de sécurité a été faite sur la box, mais pas envoyée vers l'endroit prévu.",
        "steps": ["Vérifiez que la box internet fonctionne.", STEP_HELP],
    },
}

_HA_SEVERITY = {"critical": "error", "error": "error", "warning": "warning"}


def _rule_ha_issue(f: Finding) -> Problem:
    domain = str(f.get("domain") or "inconnu")
    key = str(f.get("translation_key") or f.get("issue_id") or "")
    severity = _HA_SEVERITY.get(str(f.get("severity") or "").lower(), "info")
    known = KNOWN_HA_ISSUES.get((domain, key)) or KNOWN_HA_ISSUES.get(("*", key))
    if known:
        title = known["title"].format(domain=domain)
        why = known["why"]
        steps = list(known["steps"])
    else:
        title = f"La box signale un problème avec le module « {domain} »"
        why = "Un module de la box a remonté une alerte technique. Ce n'est pas forcément grave."
        steps = ["Notez si quelque chose ne marche plus chez vous depuis peu.", STEP_HELP]
    if ACTION_HELP not in " ".join(steps):
        steps.append(STEP_HELP)
    tech = _tech_lines(f, ("domain", "issue_id", "translation_key", "severity", "is_fixable"))
    return _problem(
        f"ha_issue_{slug(domain)}_{slug(f.get('issue_id') or key)}",
        severity, title, STATUS_NONE, why, steps, _fix("none", ACTION_HELP), tech,
    )


Rule = Callable[[Finding], "Problem | None"]

RULES: dict[str, Rule] = {
    "unavailable_device": _rule_unavailable_device,
    "low_battery": _rule_low_battery,
    "disk_usage": _rule_disk_usage,
    "camera_unavailable": _rule_camera_unavailable,
    "ha_issue": _rule_ha_issue,
    "update_failed": _rule_update_failed,
    "radio_missing": _rule_radio_missing,
    "radio_not_yet": _rule_radio_not_yet,
    "automations_not_loaded": _rule_automations_not_loaded,
    "provision_failed": _rule_provision_failed,
    "hacs_not_activated": _rule_hacs_not_activated,
}


# --------------------------------------------------------------------------- API


def finding_to_problem(finding: Finding) -> Problem | None:
    """Apply the rule for ``finding['kind']``; ``None`` if unknown or below threshold."""
    rule = RULES.get(str(finding.get("kind")))
    if rule is None:
        return None
    return rule(finding)


def build_problems(findings: Iterable[Finding]) -> list[Problem]:
    """Findings -> problems, de-duplicated by id, most severe first.

    A device that is unavailable *and* has a low battery yields only the
    "ne répond plus" problem (the battery is already explained there).
    """
    findings = list(findings)
    unavailable_keys = {
        str(f.get("device_id") or f.get("entity_id"))
        for f in findings
        if f.get("kind") == "unavailable_device" and (f.get("device_id") or f.get("entity_id"))
    }
    problems: dict[str, Problem] = {}
    for finding in findings:
        if finding.get("kind") == "low_battery" and str(finding.get("device_id")) in unavailable_keys:
            continue
        problem = finding_to_problem(finding)
        if problem is not None and problem["id"] not in problems:
            problems[problem["id"]] = problem
    return sorted(problems.values(), key=lambda p: (_SEVERITY_ORDER.get(p["severity"], 3), p["title"]))


def headline(problems: list[Problem]) -> str:
    """Same wording as the Dépannage mock-up (soft notices are not problems)."""
    count = len([p for p in problems if not p.get("notice")])
    if count == 0:
        return "Tout fonctionne, aucun problème"
    if count == 1:
        return "1 problème à régler"
    return f"{count} problèmes à régler"


def resolve_choice(problem: Problem, choice: str | None) -> str | None:
    """Return a valid choice value (the recommended one when ``choice`` is empty).

    Returns ``None`` if the problem has choices and ``choice`` is not one of them.
    """
    choices = problem.get("fix", {}).get("choices") or []
    if not choices:
        return choice
    values = [c["value"] for c in choices]
    if choice in (None, ""):
        recommended = [c["value"] for c in choices if c.get("recommended")]
        return recommended[0] if recommended else values[0]
    return choice if choice in values else None


def fixed_message(problem_id: str, choice: str | None = None) -> str:
    """Message shown after a successful fix."""
    if problem_id == "disk_usage" and choice:
        return f"Réglé : la box garde maintenant {choice} jours d'historique"
    return "Réparé, tout fonctionne"
