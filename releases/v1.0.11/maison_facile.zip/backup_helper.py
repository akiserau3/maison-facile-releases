"""Create a backup before any update (CONTRACT §8: never install without a backup)."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

_LOGGER = logging.getLogger(__name__)

BACKUP_NAME_PREFIX = "Maison Facile avant mise à jour"
BACKUP_TIMEOUT = 3600  # seconds; a full backup of a box with videos can be slow


@dataclass
class BackupResult:
    ok: bool
    message_fr: str
    method: str | None = None
    backup_id: str | None = None
    at: str | None = None


def _backup_manager(hass: HomeAssistant) -> Any | None:
    """Return HA's BackupManager (HA >= 2025.1) or None."""
    try:
        from homeassistant.components.backup.const import DATA_MANAGER  # noqa: PLC0415

        return hass.data.get(DATA_MANAGER)
    except Exception:  # noqa: BLE001 - backup integration missing or API changed
        return hass.data.get("backup")


async def async_list_backups(hass: HomeAssistant) -> list[dict[str, Any]]:
    """Backups known to HA's backup manager: [{backup_id, name, date}] (newest first)."""
    manager = _backup_manager(hass)
    if manager is None or not hasattr(manager, "async_get_backups"):
        return []
    try:
        result = await manager.async_get_backups()
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Cannot list backups: %s", err)
        return []
    backups = result[0] if isinstance(result, tuple) else result
    items = [
        {
            "backup_id": getattr(b, "backup_id", key),
            "name": str(getattr(b, "name", "") or ""),
            "date": str(getattr(b, "date", "") or ""),
        }
        for key, b in (backups or {}).items()
    ]
    return sorted(items, key=lambda b: b["date"], reverse=True)


async def async_delete_backup(hass: HomeAssistant, backup_id: str) -> bool:
    """Delete a backup. The manager returns a dict of per-agent errors instead of raising."""
    manager = _backup_manager(hass)
    if manager is None:
        return False
    try:
        errors = await manager.async_delete_backup(backup_id)
    except Exception as err:  # noqa: BLE001
        _LOGGER.warning("Cannot delete backup %s: %s", backup_id, err)
        return False
    if errors:
        _LOGGER.warning("Backup %s not fully deleted: %s", backup_id, errors)
        return False
    return True


def _store(entry: ConfigEntry) -> Any | None:
    runtime = getattr(entry, "runtime_data", None)
    return getattr(runtime, "store", None)


async def _remember(entry: ConfigEntry, result: BackupResult) -> None:
    store = _store(entry)
    if store is None:
        return
    update = store.data.setdefault("update", {})
    update["last_backup"] = result.at
    if result.backup_id:
        ids = update.setdefault("mf_backup_ids", [])
        if result.backup_id not in ids:
            ids.append(result.backup_id)
    await store.async_save()


def _is_haos(hass: HomeAssistant) -> bool:
    return "hassio" in hass.config.components and hass.services.has_service("hassio", "backup_full")


def _local_agent_id(manager: Any) -> str | None:
    agents = getattr(manager, "backup_agents", None) or {}
    for agent_id in ("backup.local", "hassio.local"):
        if agent_id in agents:
            return agent_id
    return None


async def _via_hassio(hass: HomeAssistant, name: str) -> None:
    await hass.services.async_call("hassio", "backup_full", {"name": name}, blocking=True)


async def _via_manager(hass: HomeAssistant, name: str) -> None:
    """BackupManager.async_create_backup (HA >= 2025.1): waits for the backup to finish.

    Local agent only, no password, without the user's automatic-backup settings.
    """
    manager = _backup_manager(hass)
    agent_id = _local_agent_id(manager) if manager is not None else None
    if manager is None or agent_id is None or not hasattr(manager, "async_create_backup"):
        raise RuntimeError("backup manager or local agent unavailable")
    kwargs: dict[str, Any] = {
        "agent_ids": [agent_id],
        "include_addons": None,
        "include_all_addons": False,
        "include_database": True,
        "include_folders": None,
        "include_homeassistant": True,
        "name": name,
        "password": None,
        "with_automatic_settings": False,
    }
    try:
        await manager.async_create_backup(**kwargs)
    except TypeError:
        # Signature changed in this HA version: retry with the stable core arguments.
        kwargs.pop("with_automatic_settings")
        await manager.async_create_backup(**kwargs)


async def _via_automatic(hass: HomeAssistant, _name: str) -> None:
    await hass.services.async_call("backup", "create_automatic", {}, blocking=True)


async def async_create_backup(hass: HomeAssistant, entry: ConfigEntry) -> BackupResult:
    """Create a full backup and wait for it. Never raises; check ``result.ok``.

    Order: 1) HAOS ``hassio.backup_full`` (named), 2) backup manager on the local
    agent only, 3) ``backup.create_automatic``. Total failure means: no install.
    """
    now = dt_util.now()
    name = f"{BACKUP_NAME_PREFIX} {now.strftime('%d/%m/%Y %H:%M')}"
    before = {b["backup_id"] for b in await async_list_backups(hass)}

    strategies: list[tuple[str, Any]] = []
    if _is_haos(hass):
        strategies.append(("hassio.backup_full", _via_hassio))
    if _backup_manager(hass) is not None:
        strategies.append(("backup_manager.local", _via_manager))
    if hass.services.has_service("backup", "create_automatic"):
        strategies.append(("backup.create_automatic", _via_automatic))
    if not strategies:
        return BackupResult(
            False,
            "Impossible de faire une sauvegarde sur cette box : la mise à jour n'est pas installée par sécurité.",
        )

    used: str | None = None
    timed_out = False
    for method, strategy in strategies:
        try:
            async with asyncio.timeout(BACKUP_TIMEOUT):
                await strategy(hass, name)
        except TimeoutError:
            _LOGGER.error("Backup via %s timed out", method)
            timed_out = True
            break  # a backup may still be running: do not start another one
        except Exception as err:  # noqa: BLE001 - try the next strategy
            _LOGGER.warning("Backup via %s failed: %s", method, err)
            continue
        used = method
        break

    if used is None:
        if timed_out:
            return BackupResult(False, "La sauvegarde prend trop de temps : la mise à jour est annulée par sécurité.")
        return BackupResult(False, "La sauvegarde a échoué : la mise à jour n'est pas installée par sécurité.")

    after = await async_list_backups(hass)
    new_ids = [b["backup_id"] for b in after if b["backup_id"] not in before]
    result = BackupResult(True, "Sauvegarde terminée", used, new_ids[0] if new_ids else None,
                          dt_util.utcnow().isoformat())
    await _remember(entry, result)
    _LOGGER.info("Backup created with %s (%s)", used, result.backup_id or "id unknown")
    return result


async def async_prune_mf_backups(hass: HomeAssistant, entry: ConfigEntry, keep: int) -> int:
    """Delete the oldest Maison Facile backups beyond ``keep``. Returns the count deleted.

    A backup belongs to Maison Facile if its id was recorded when we created it or
    if its name starts with :data:`BACKUP_NAME_PREFIX`.
    """
    store = _store(entry)
    known_ids: list[str] = list((store.data.get("update", {}) if store else {}).get("mf_backup_ids", []))
    ours = [
        b for b in await async_list_backups(hass)
        if b["backup_id"] in known_ids or b["name"].startswith(BACKUP_NAME_PREFIX)
    ]
    deleted = 0
    for backup in ours[keep:]:  # list is newest first
        if await async_delete_backup(hass, backup["backup_id"]):
            deleted += 1
            if backup["backup_id"] in known_ids:
                known_ids.remove(backup["backup_id"])
    if store is not None and deleted:
        existing = {b["backup_id"] for b in await async_list_backups(hass)}
        store.data.setdefault("update", {})["mf_backup_ids"] = [i for i in known_ids if i in existing]
        await store.async_save()
    return deleted
