"""First-start provisioning of a box prepared by the installer (CONTRACT_KIT.md).

At the first start, ``<config>/maison_facile_kit.json`` describes the kit. The
:class:`Provisioner` runs the steps in the contract order (settings, zigbee, weather,
cameras, hacs). Each step is idempotent, its state is saved in the store (key
``provision``) and a restart resumes where it stopped. The decisions that do not
need Home Assistant are in :mod:`provision_rules`.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import voluptuous as vol

from homeassistant.config_entries import SOURCE_USER, ConfigEntry
from homeassistant.const import EVENT_HOMEASSISTANT_STARTED
from homeassistant.core import CALLBACK_TYPE, CoreState, Event, HomeAssistant, callback
from homeassistant.data_entry_flow import (
    EVENT_DATA_ENTRY_FLOW_PROGRESSED,
    FlowResultType,
    UnknownFlow,
)
from homeassistant.helpers.hassio import is_hassio
from homeassistant.util import dt as dt_util

from . import provision_rules as rules
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

STORE_KEY = "provision"
MAX_KIT_BYTES = 64 * 1024
FLOW_MAX_STEPS = 30
PROGRESS_TIMEOUT = 20 * 60  # firmware installs and network formation can be slow
PROGRESS_POLL = 30
DISCOVERY_POLL = 15

_IGNORED_ABORTS = {"single_instance_allowed", "already_configured", "already_in_progress"}


# --------------------------------------------------------------------------- file helpers (executor)


def _read_kit_file(path: str) -> str | None:
    if not os.path.isfile(path):
        return None
    if os.path.getsize(path) > MAX_KIT_BYTES:
        return "<too large>"
    return Path(path).read_text(encoding="utf-8", errors="replace")


def _atomic_write_json(path: str, data: dict[str, Any]) -> None:
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)


def _erase_secrets_in_file(path: str) -> bool:
    """Rewrite the kit file without camera credentials (keeps unknown keys)."""
    if not os.path.isfile(path):
        return False
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    if not isinstance(raw, dict) or not rules.has_secrets(raw):
        return False
    _atomic_write_json(path, rules.redact_kit(raw))
    return True


def _finalize_file(path: str, done_path: str, kit: dict[str, Any] | None, finished_at: str) -> None:
    """Write ``maison_facile_kit.done.json`` (no secrets) and remove the original."""
    data: dict[str, Any] | None = None
    if os.path.isfile(path):
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
            data = raw if isinstance(raw, dict) else None
        except (OSError, ValueError):
            data = None
    if data is None:
        data = dict(kit or {})
    data = rules.redact_kit(data)
    data["provisioned_at"] = finished_at
    _atomic_write_json(done_path, data)
    with contextlib.suppress(FileNotFoundError):
        os.remove(path)


# --------------------------------------------------------------------------- generic flow driver


@dataclass
class FlowOutcome:
    """End of an automatically driven config flow."""

    kind: str  # created | aborted | stuck | gone | error
    reason: str = ""
    result: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.kind == "created"


def _schema_fields(schema: Any) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []
    if schema is None:
        return fields
    mapping = getattr(schema, "schema", None)
    if not isinstance(mapping, dict):
        return [{"name": "?", "required": True, "has_default": False}]
    for key in mapping:
        name = str(getattr(key, "schema", key))
        required = isinstance(key, vol.Required)
        has_default = getattr(key, "default", vol.UNDEFINED) is not vol.UNDEFINED
        fields.append({"name": name, "required": required, "has_default": has_default})
    return fields


async def _async_wait_progress(hass: HomeAssistant, flow_id: str, step_id: str, timeout: float) -> None:
    """Wait until a SHOW_PROGRESS step moves on (event from the flow manager)."""
    changed = asyncio.Event()

    @callback
    def _on_progress(event: Event) -> None:
        if event.data.get("flow_id") == flow_id:
            changed.set()

    unsub = hass.bus.async_listen(EVENT_DATA_ENTRY_FLOW_PROGRESSED, _on_progress)
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    try:
        while loop.time() < deadline:
            try:
                current = hass.config_entries.flow.async_get(flow_id)
            except UnknownFlow:
                return
            if current.get("step_id") != step_id:
                return
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(changed.wait(), min(PROGRESS_POLL, deadline - loop.time()))
                return
    finally:
        unsub()


async def async_drive_flow(
    hass: HomeAssistant,
    result: dict[str, Any],
    preferences: Sequence[str] = (),
    *,
    should_stop: Callable[[dict[str, Any]], str | None] | None = None,
    progress_timeout: float = PROGRESS_TIMEOUT,
) -> FlowOutcome:
    """Drive a config flow like a patient user who always picks the recommended choice.

    - form whose required fields all have a default -> submitted with ``{}``;
    - menu -> first option found in ``preferences`` (none -> ``stuck``);
    - progress -> wait, then continue; create_entry with ``next_flow`` -> follow it.
    ``should_stop(result)`` may return a reason to stop before the next submission.
    """
    manager = hass.config_entries.flow
    last_form: tuple[str, str] | None = None
    try:
        for _ in range(FLOW_MAX_STEPS):
            rtype = result.get("type")
            flow_id = result.get("flow_id", "")
            if rtype == FlowResultType.CREATE_ENTRY:
                next_flow = result.get("next_flow")
                if next_flow and str(next_flow[0]) == "config_flow":
                    try:
                        result = await manager.async_configure(next_flow[1])
                    except UnknownFlow:
                        return FlowOutcome("created", result=result)
                    continue
                return FlowOutcome("created", result=result)
            if rtype == FlowResultType.ABORT:
                return FlowOutcome("aborted", str(result.get("reason") or ""), result)
            if should_stop is not None and (reason := should_stop(result)):
                return FlowOutcome("stuck", reason, result)
            if rtype == FlowResultType.FORM:
                key = (flow_id, str(result.get("step_id")))
                if result.get("errors") and last_form == key:
                    return FlowOutcome("stuck", f"form_errors:{result['errors']}", result)
                if not rules.form_can_auto_submit(_schema_fields(result.get("data_schema"))):
                    return FlowOutcome("stuck", f"form:{result.get('step_id')}", result)
                last_form = key
                result = await manager.async_configure(flow_id, {})
                continue
            if rtype == FlowResultType.MENU:
                option = rules.choose_menu_option(result.get("menu_options"), preferences)
                if option is None:
                    return FlowOutcome("stuck", f"menu:{result.get('step_id')}", result)
                result = await manager.async_configure(flow_id, {"next_step_id": option})
                continue
            if rtype == FlowResultType.SHOW_PROGRESS:
                await _async_wait_progress(hass, flow_id, str(result.get("step_id")), progress_timeout)
                result = await manager.async_configure(flow_id)
                continue
            if rtype == FlowResultType.SHOW_PROGRESS_DONE:
                result = await manager.async_configure(flow_id)
                continue
            return FlowOutcome("stuck", f"type:{rtype}", result)
    except UnknownFlow:
        return FlowOutcome("gone", "flow_removed", result)
    except (vol.Invalid, ValueError) as err:
        return FlowOutcome("stuck", f"invalid:{err}", result)
    return FlowOutcome("stuck", "too_many_steps", result)


# --------------------------------------------------------------------------- provisioner


class Provisioner:
    """Runs the provisioning steps and publishes their state."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, store: Any) -> None:
        self.hass = hass
        self.entry = entry
        self.store = store
        self.kit_path = hass.config.path(rules.KIT_FILENAME)
        self.done_path = hass.config.path(rules.KIT_DONE_FILENAME)
        self._secrets: dict[str, str] = {}
        self._listeners: set[Callable[[dict[str, Any]], None]] = set()
        self._lock = asyncio.Lock()
        self._running: set[str] = set()
        self._unsubs: list[CALLBACK_TYPE] = []

    # ------------------------------------------------------------------ state

    @property
    def state(self) -> dict[str, Any] | None:
        value = self.store.data.get(STORE_KEY)
        return value if isinstance(value, dict) else None

    @property
    def kit(self) -> dict[str, Any]:
        return (self.state or {}).get("kit") or {}

    def status(self) -> dict[str, Any]:
        return rules.public_state(self.state)

    def summary(self) -> dict[str, bool]:
        status = self.status()
        return {"active": status["active"], "done": status["done"]}

    def failed_findings(self) -> list[dict[str, str]]:
        return rules.failed_steps(self.state)

    def step_state(self, step: str) -> str | None:
        return ((self.state or {}).get("steps") or {}).get(step, {}).get("state")

    @callback
    def async_subscribe(self, listener: Callable[[dict[str, Any]], None]) -> CALLBACK_TYPE:
        self._listeners.add(listener)
        return lambda: self._listeners.discard(listener)

    @callback
    def _notify(self) -> None:
        payload = self.status()
        for listener in list(self._listeners):
            try:
                listener(payload)
            except Exception:  # noqa: BLE001
                _LOGGER.exception("Provision listener failed")

    async def _async_save(self, state: dict[str, Any]) -> None:
        await self.store.async_set(STORE_KEY, state)
        self._notify()

    async def _async_set_step(self, step: str, state: str, message: str = "", detail: str = "") -> None:
        current = dict(self.state or {})
        steps = dict(current.get("steps") or {})
        steps[step] = {
            "state": state,
            "message_fr": message,
            "detail": detail[:500],
            "updated_at": dt_util.utcnow().isoformat(),
        }
        current["steps"] = steps
        await self._async_save(current)

    # ------------------------------------------------------------------ lifecycle

    async def async_start(self) -> None:
        """Read the kit file, prepare the state and run what is left (in background)."""
        text = await self.hass.async_add_executor_job(_read_kit_file, self.kit_path)
        state = self.state
        if text is None and state is None:
            return  # not a box prepared by the installer
        kit: dict[str, Any] | None = None
        if text is not None:
            try:
                kit, warnings = rules.load_kit_text(text)
                for warning in warnings:
                    _LOGGER.warning("Kit file: %s", warning)
            except ValueError as err:
                _LOGGER.error("Kit file %s unreadable: %s", self.kit_path, err)
                if state is None:
                    await self._async_save({
                        "kit": None,
                        "steps": rules.invalid_kit_plan(),
                        "done": True,
                        "started_at": dt_util.utcnow().isoformat(),
                    })
                return
            self._secrets = {key: str(kit.get(key) or "") for key in rules.SECRET_KEYS}
        if state is None:
            assert kit is not None
            state = {
                "kit": rules.redact_kit(kit),
                "steps": rules.plan_steps(kit),
                "done": False,
                "started_at": dt_util.utcnow().isoformat(),
            }
            _LOGGER.info("Provisioning started (kit %s)", kit.get("kit"))
        else:
            state = dict(state)
            state["steps"] = rules.resume_steps(state.get("steps") or {}, bool(state.get("done")))
            if kit is not None and not state.get("done"):
                state["kit"] = rules.redact_kit(kit)
        await self._async_save(state)

        if state.get("done"):
            if text is not None:  # crash between the store write and the rename
                await self._async_finalize_file()
        self.entry.async_create_background_task(
            self.hass, self._async_run_pending(), f"{DOMAIN}_provision"
        )

    @callback
    def async_unload(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs.clear()
        self._listeners.clear()

    async def _async_run_pending(self) -> None:
        for step in rules.steps_to_run((self.state or {}).get("steps") or {}):
            await self._async_run_step(step)
        await self._async_maybe_finish()

    async def _async_maybe_finish(self) -> None:
        state = self.state
        if state is None or state.get("done") or not rules.all_finished(state.get("steps") or {}):
            return
        finished_at = dt_util.utcnow().isoformat()
        await self._async_finalize_file(finished_at)
        state = dict(self.state or {})
        state["done"] = True
        state["finished_at"] = finished_at
        await self._async_save(state)
        _LOGGER.info("Provisioning finished")
        self._refresh_doctor()

    async def _async_finalize_file(self, finished_at: str | None = None) -> None:
        try:
            await self.hass.async_add_executor_job(
                _finalize_file, self.kit_path, self.done_path, self.kit,
                finished_at or dt_util.utcnow().isoformat(),
            )
        except OSError:
            _LOGGER.exception("Could not rename the kit file")
        self._secrets = {}

    async def async_retry(self, step: str) -> None:
        """Run one step again (websocket provision/retry, doctor « Réessayer »)."""
        if step not in rules.STEP_IDS or self.state is None:
            raise KeyError(step)
        if step in self._running:
            return
        await self._async_set_step(step, "pending")
        self.entry.async_create_background_task(
            self.hass, self._async_retry(step), f"{DOMAIN}_provision_retry_{step}"
        )

    async def _async_retry(self, step: str) -> None:
        await self._async_run_step(step)
        await self._async_maybe_finish()
        self._refresh_doctor()

    async def _async_run_step(self, step: str) -> None:
        self._running.add(step)
        try:
            await self._async_wait_ready(step)
            async with self._lock:
                await self._async_set_step(step, "running", self._running_message(step))
                try:
                    state, message, detail = await getattr(self, f"_async_step_{step}")()
                except asyncio.CancelledError:
                    raise
                except Exception as err:  # noqa: BLE001 - a step never breaks the others
                    _LOGGER.exception("Provisioning step %s failed", step)
                    state, message, detail = "error", rules.MSG["unexpected"], type(err).__name__
                await self._async_set_step(step, state, message, detail)
                _LOGGER.info("Provisioning step %s: %s %s", step, state, detail)
                if step == "cameras":
                    await self._async_erase_secrets()
            if state == "error":
                self._refresh_doctor()
        finally:
            self._running.discard(step)

    @staticmethod
    def _running_message(step: str) -> str:
        return rules.MSG["zigbee_waiting"] if step == "zigbee" else ""

    async def _async_erase_secrets(self) -> None:
        self._secrets = {}
        try:
            await self.hass.async_add_executor_job(_erase_secrets_in_file, self.kit_path)
        except OSError:
            _LOGGER.exception("Could not erase the camera credentials from the kit file")

    def _refresh_doctor(self) -> None:
        doctor = getattr(getattr(self.entry, "runtime_data", None), "doctor", None)
        if doctor is not None and hasattr(doctor, "async_analyze"):
            self.entry.async_create_background_task(
                self.hass, doctor.async_analyze(), f"{DOMAIN}_doctor_after_provision"
            )

    # ------------------------------------------------------------------ waiting

    async def _async_wait_ready(self, step: str) -> None:
        """HA started; every step but ``settings`` also waits for the HA onboarding."""
        if self.hass.state is not CoreState.running:
            started = asyncio.Event()
            unsub = self.hass.bus.async_listen_once(EVENT_HOMEASSISTANT_STARTED, lambda _e: started.set())
            self._unsubs.append(unsub)
            try:
                await started.wait()
            finally:
                # A fired listen_once must not be removed again.
                if unsub in self._unsubs:
                    self._unsubs.remove(unsub)
                if not started.is_set():
                    unsub()
        if step == "settings":
            return
        from homeassistant.components import onboarding  # noqa: PLC0415

        if onboarding.async_is_onboarded(self.hass):
            return
        _LOGGER.debug("Provisioning waits for the Home Assistant onboarding")
        onboarded = asyncio.Event()
        onboarding.async_add_listener(self.hass, onboarded.set)
        await onboarded.wait()

    async def _async_wait_flows(self, handlers: Sequence[str], timeout: float, exclude: set[str]) -> dict[str, Any] | None:
        """First flow in progress for ``handlers`` (in that order), waiting up to ``timeout``."""
        manager = self.hass.config_entries.flow
        wake = asyncio.Event()
        unsub = manager.async_subscribe_flow(lambda _change, _flow_id: wake.set())
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        try:
            while True:
                for handler in handlers:
                    for flow in manager.async_progress_by_handler(handler):
                        if flow["flow_id"] not in exclude:
                            return flow
                remaining = deadline - loop.time()
                if remaining <= 0:
                    return None
                wake.clear()
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(wake.wait(), min(DISCOVERY_POLL, remaining))
        finally:
            unsub()

    # ------------------------------------------------------------------ steps

    async def _async_step_settings(self) -> tuple[str, str, str]:
        kit = self.kit
        changes = rules.settings_from_kit(kit, self.store.settings)
        if (self.state or {}).get("done"):
            # Retry after the first pass: never undo a client-mode choice made since.
            changes.pop("commercial_mode", None)
        if changes:
            await self.store.async_update_settings(changes)
        if "commercial_mode" in changes:
            # Client mode chosen at installation: default panel + family sidebars now.
            commercial = getattr(getattr(self.entry, "runtime_data", None), "commercial", None)
            if commercial is not None:
                await commercial.async_apply()
        return "done", rules.settings_message(kit), ",".join(sorted(changes))

    async def _async_step_zigbee(self) -> tuple[str, str, str]:
        mode = self.kit.get("zigbee")
        if mode == "zha":
            return await self._async_zigbee_zha()
        if mode == "z2m":
            return await self._async_zigbee_z2m()
        return "skipped", rules.zigbee_none_message(self.kit), ""

    def _zha_configured(self) -> bool:
        return bool(self.hass.config_entries.async_entries(rules.ZHA_DOMAIN, include_ignore=False))

    def _stop_if_zha_exists(self, result: dict[str, Any]) -> str | None:
        # Never let a second flow form a network once ZHA has an entry.
        return "zha_already_configured" if self._zha_configured() else None

    async def _async_zigbee_zha(self) -> tuple[str, str, str]:
        if self._zha_configured():
            return "done", rules.MSG["zigbee_already"], "zha entry exists"
        handlers = (*rules.ZIGBEE_HARDWARE_HANDLERS, rules.ZHA_DOMAIN)
        loop = asyncio.get_running_loop()
        deadline = loop.time() + rules.ZIGBEE_DISCOVERY_TIMEOUT
        attempted: set[str] = set()
        last_error: tuple[str, str] | None = None
        while not self._zha_configured():
            remaining = deadline - loop.time()
            # After a failure, do not wait 10 min: only flows already there are tried.
            flow = await self._async_wait_flows(handlers, 0 if last_error else max(remaining, 0), attempted)
            if flow is None:
                break
            attempted.add(flow["flow_id"])
            try:
                current = await self.hass.config_entries.flow.async_configure(flow["flow_id"])
            except UnknownFlow:
                continue
            outcome = await async_drive_flow(
                self.hass, current, rules.ZIGBEE_MENU_PREFERENCES, should_stop=self._stop_if_zha_exists
            )
            _LOGGER.info("Zigbee flow %s (%s): %s %s", flow["handler"], flow["flow_id"], outcome.kind, outcome.reason)
            if outcome.ok or outcome.reason in _IGNORED_ABORTS or outcome.reason == "zha_already_configured":
                continue
            message = rules.abort_message(outcome.reason) if outcome.kind == "aborted" else rules.MSG["zigbee_failed"]
            last_error = (message, f"{flow['handler']}: {outcome.kind} {outcome.reason}")
        if self._zha_configured():
            return "done", rules.MSG["zigbee_ready"], ""
        if last_error:
            return "error", last_error[0], last_error[1]
        return "error", rules.MSG["zigbee_missing"], "no discovery flow within 10 min"

    async def _async_zigbee_z2m(self) -> tuple[str, str, str]:
        if not is_hassio(self.hass):
            return "skipped", rules.MSG["z2m_no_os"], "hassio not loaded"
        try:
            await self._async_ensure_addon(rules.MOSQUITTO_SLUG, "Mosquitto", start=True)
            await self._async_ensure_repository(rules.Z2M_REPOSITORY)
            await self._async_ensure_addon(rules.Z2M_SLUG, "Zigbee2MQTT", start=True)
        except _AddonFailure as err:
            return "error", err.message_fr, err.detail
        if self.hass.config_entries.async_entries("mqtt", include_ignore=False):
            return "done", rules.MSG["z2m_ready"], "mqtt entry exists"
        attempted: set[str] = set()
        while not self.hass.config_entries.async_entries("mqtt", include_ignore=False):
            flow = await self._async_wait_flows(("mqtt",), rules.MQTT_DISCOVERY_TIMEOUT, attempted)
            if flow is None:
                return "error", rules.MSG["mqtt_missing"], "no mqtt discovery flow"
            attempted.add(flow["flow_id"])
            try:
                current = await self.hass.config_entries.flow.async_configure(flow["flow_id"])
            except UnknownFlow:
                continue
            outcome = await async_drive_flow(self.hass, current, rules.GENERIC_MENU_PREFERENCES)
            if not (outcome.ok or outcome.reason in _IGNORED_ABORTS):
                return "error", rules.MSG["mqtt_missing"], f"mqtt: {outcome.kind} {outcome.reason}"
        return "done", rules.MSG["z2m_ready"], ""

    async def _async_step_weather(self) -> tuple[str, str, str]:
        if self.hass.config_entries.async_entries("met", include_ignore=False):
            return "done", rules.MSG["weather_already"], ""
        # Same call as the Home Assistant onboarding (tracks the home location).
        result = await self.hass.config_entries.flow.async_init("met", context={"source": "onboarding"})
        if result.get("type") == FlowResultType.CREATE_ENTRY:
            return "done", rules.MSG["weather_done"], ""
        reason = str(result.get("reason") or result.get("type"))
        if reason in _IGNORED_ABORTS:
            return "done", rules.MSG["weather_already"], reason
        if result.get("flow_id") and result.get("type") != FlowResultType.ABORT:
            with contextlib.suppress(UnknownFlow):
                self.hass.config_entries.flow.async_abort(result["flow_id"])
        return "error", rules.abort_message(reason, rules.MSG["weather_failed"]), f"met: {reason}"

    async def _async_step_cameras(self) -> tuple[str, str, str]:
        kit = self.kit
        mode = kit.get("cameras")
        if mode == "reolink":
            return await self._async_cameras_reolink(kit)
        if mode == "frigate":
            if not is_hassio(self.hass):
                return "skipped", rules.MSG["frigate_no_os"], "hassio not loaded"
            try:
                await self._async_ensure_repository(rules.FRIGATE_REPOSITORY)
                await self._async_ensure_addon(rules.FRIGATE_SLUG, "Frigate", start=False)
            except _AddonFailure as err:
                return "error", err.message_fr, err.detail
            return "done", rules.MSG["frigate_hacs"], ""
        return "skipped", rules.MSG["cameras_none"], ""

    async def _async_cameras_reolink(self, kit: dict[str, Any]) -> tuple[str, str, str]:
        hosts = list(kit.get("camera_hosts") or [])
        if not hosts:
            return "skipped", rules.MSG["cameras_no_hosts"], ""
        configured = {
            str(e.data.get("host")) for e in self.hass.config_entries.async_entries("reolink", include_ignore=False)
        }
        username = self._secrets.get("camera_username", "")
        password = self._secrets.get("camera_password", "")
        pending = [h for h in hosts if h not in configured]
        if pending and not (username and password):
            return "error", rules.MSG["cameras_no_credentials"], "no credentials"
        results: dict[str, str | None] = {h: None for h in hosts if h in configured}
        for host in pending:
            results[host] = await self._async_add_reolink(host, username, password)
        state, message = rules.cameras_summary({h: results[h] for h in hosts})
        return state, message, ""

    async def _async_add_reolink(self, host: str, username: str, password: str) -> str | None:
        """Add one Reolink camera. ``None`` if OK, else a French message."""
        manager = self.hass.config_entries.flow
        flow_id = None
        try:
            result = await manager.async_init("reolink", context={"source": SOURCE_USER})
            flow_id = result.get("flow_id")
            if result.get("type") == FlowResultType.FORM and result.get("step_id") == "user":
                result = await manager.async_configure(
                    flow_id, {"host": host, "username": username, "password": password}
                )
            rtype = result.get("type")
            if rtype == FlowResultType.CREATE_ENTRY:
                return None
            if rtype == FlowResultType.ABORT:
                reason = str(result.get("reason"))
                return None if reason in _IGNORED_ABORTS else rules.reolink_message(host, reason)
            if rtype == FlowResultType.FORM and result.get("step_id") == "privacy":
                return rules.reolink_message(host, "privacy")
            if rtype == FlowResultType.FORM and result.get("errors"):
                return rules.reolink_message(host, rules.reolink_error_code(result["errors"]))
            return rules.reolink_message(host, "stuck")
        except Exception:  # noqa: BLE001 - integration missing, requirements offline…
            _LOGGER.exception("Reolink flow for a camera failed")
            return rules.reolink_message(host, "unknown")
        finally:
            if flow_id:
                with contextlib.suppress(UnknownFlow):
                    if manager.async_get(flow_id):
                        manager.async_abort(flow_id)

    async def _async_step_hacs(self) -> tuple[str, str, str]:
        if not self.kit.get("hacs_files"):
            return "skipped", rules.MSG["hacs_none"], ""
        # The doctor shows the "info" problem hacs_not_activated until the installer
        # signs in with GitHub (never asked to the customer).
        return "done", rules.MSG["hacs_files"], ""

    # ------------------------------------------------------------------ Supervisor

    async def _async_ensure_repository(self, url: str) -> None:
        from aiohasupervisor import SupervisorError  # noqa: PLC0415
        from aiohasupervisor.models import StoreAddRepository  # noqa: PLC0415

        from homeassistant.components.hassio import get_supervisor_client  # noqa: PLC0415

        client = get_supervisor_client(self.hass)
        try:
            repositories = await client.store.repositories_list()
            known = {str(r.source).rstrip("/").lower() for r in repositories} | {
                str(r.url).rstrip("/").lower() for r in repositories
            }
            if url.lower() not in known:
                await client.store.add_repository(StoreAddRepository(repository=url))
        except SupervisorError as err:
            raise _AddonFailure(
                "La liste des modules n'a pas pu être complétée. Vérifiez Internet, puis réessayez.",
                f"add_repository {url}: {err}",
            ) from err

    async def _async_ensure_addon(self, slug: str, name: str, *, start: bool) -> None:
        from homeassistant.components.hassio import (  # noqa: PLC0415
            AddonError,
            AddonManager,
            AddonState,
        )

        manager = AddonManager(self.hass, _LOGGER, name, slug)
        try:
            info = await manager.async_get_addon_info()
            if info.state is AddonState.NOT_INSTALLED:
                _LOGGER.info("Installing add-on %s", slug)
                await manager.async_install_addon()
                info = await manager.async_get_addon_info()
            if start and info.state is not AddonState.RUNNING:
                _LOGGER.info("Starting add-on %s", slug)
                await manager.async_start_addon()
        except AddonError as err:
            raise _AddonFailure(
                f"Le module « {name} » n'a pas pu s'installer. Vérifiez Internet, puis réessayez.",
                f"{slug}: {err}",
            ) from err


class _AddonFailure(Exception):
    def __init__(self, message_fr: str, detail: str) -> None:
        super().__init__(detail)
        self.message_fr = message_fr
        self.detail = detail


async def async_setup_provision(hass: HomeAssistant, entry: ConfigEntry, store: Any) -> Provisioner:
    provisioner = Provisioner(hass, entry, store)
    await provisioner.async_start()
    return provisioner
