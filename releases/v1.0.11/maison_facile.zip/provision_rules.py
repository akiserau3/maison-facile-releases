"""Pure rules of the first-start provisioning (no Home Assistant import).

See CONTRACT_KIT.md §Provisionnement. ``provision.py`` does the Home Assistant work;
everything that can be decided without Home Assistant lives here and is unit tested:
reading / validating the kit file, the plan of the steps, secret redaction, the
public state shape and the choice of options in config-flow menus and forms.
"""

from __future__ import annotations

import copy
import hashlib
import ipaddress
import json
import re
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

try:
    from . import buying_guide as _guide
except ImportError:  # imported as a top-level module by the pure tests (tests/conftest.py)
    import buying_guide as _guide  # type: ignore[no-redef]

KIT_FILENAME = "maison_facile_kit.json"
KIT_DONE_FILENAME = "maison_facile_kit.done.json"
KIT_SCHEMA = 1

STEP_IDS: tuple[str, ...] = ("settings", "zigbee", "weather", "cameras", "hacs")
STEP_LABELS: dict[str, str] = {
    "settings": "Réglages de votre installateur",
    "zigbee": "Antenne sans fil",
    "weather": "Météo",
    "cameras": "Caméras",
    "hacs": "Outils de l'installateur",
}
STATES = ("pending", "running", "done", "error", "skipped")
FINISHED_STATES = ("done", "error", "skipped")

KITS = ("essentiel", "confort", "securite", "aucun")
ZIGBEE_CHOICES = ("zha", "z2m", "none")
CAMERA_CHOICES = ("reolink", "frigate", "none")
UPDATE_CHANNELS = ("stable", "test")
PROFILES = ("particulier", "pro")  # who installed the box (installer v1.3+): texts (audience.py)
EQUIPMENTS = ("some", "none")  # installer v1.4 « Avez-vous déjà du matériel ? » (none = discovery)
KIT_DEFAULTS: dict[str, dict[str, str]] = {
    "essentiel": {"zigbee": "zha", "cameras": "none"},
    "confort": {"zigbee": "zha", "cameras": "none"},
    "securite": {"zigbee": "zha", "cameras": "reolink"},
    "aucun": {"zigbee": "none", "cameras": "none"},
}
DEFAULT_KIT = "essentiel"
DEFAULT_BOX_NAME = "Ma maison"
MAX_CAMERA_HOSTS = 16
SECRET_KEYS = ("camera_username", "camera_password")

# Supervisor add-ons (slug = sha1(repository url)[:8] + "_" + add-on folder).
MOSQUITTO_SLUG = "core_mosquitto"
Z2M_REPOSITORY = "https://github.com/zigbee2mqtt/hassio-zigbee2mqtt"
Z2M_SLUG = "45df7312_zigbee2mqtt"
FRIGATE_REPOSITORY = "https://github.com/blakeblackshear/frigate-hass-addons"
FRIGATE_SLUG = "ccab4aaf_frigate"

# Integrations whose discovery flows come before ZHA (USB sticks with a firmware picker).
ZIGBEE_HARDWARE_HANDLERS = (
    "homeassistant_connect_zbt2",
    "homeassistant_sky_connect",
)
ZHA_DOMAIN = "zha"
ZIGBEE_DISCOVERY_TIMEOUT = 600  # seconds (10 min)
MQTT_DISCOVERY_TIMEOUT = 300

# Menu options chosen automatically, in order of preference. Real step ids of
# homeassistant_hardware/firmware_config_flow.py and zha/config_flow.py (HA 2026.2).
# Migration / restore / "custom" options are deliberately absent: never chosen.
ZIGBEE_MENU_PREFERENCES: tuple[str, ...] = (
    "pick_firmware_zigbee",        # hardware: Zigbee (not Thread)
    "zigbee_intent_recommended",   # hardware: recommended installation
    "zigbee_integration_zha",      # hardware: ZHA (if the custom path was shown)
    "setup_strategy_recommended",  # zha: recommended setup
    "reuse_settings",              # zha: keep the network already on the stick
    "form_initial_network",        # zha: brand-new stick
    "form_new_network",            # zha: create a network
)
GENERIC_MENU_PREFERENCES: tuple[str, ...] = ()

MSG = {
    "settings_done": "Les coordonnées de votre installateur sont enregistrées.",
    "settings_empty": "Rien à recopier : votre installateur n'a pas laissé de coordonnées.",
    "settings_self": "Vos réglages sont enregistrés.",
    "kit_invalid": "Le fichier préparé par votre installateur est illisible. Il pourra le refaire.",
    "zigbee_none": "Pas d'antenne sans fil dans ce kit.",
    "zigbee_later": "Pas encore d'antenne : c'est normal. Vous la brancherez quand vous voudrez.",
    "zigbee_ready": "L'antenne sans fil est prête.",
    "zigbee_already": "L'antenne sans fil était déjà prête.",
    "zigbee_waiting": "On cherche l'antenne sans fil…",
    "zigbee_missing": "Antenne sans fil non détectée : vérifiez qu'elle est branchée.",
    "zigbee_failed": "La configuration de l'antenne n'a pas abouti. Réessayez ou contactez votre installateur.",
    "z2m_no_os": "Zigbee2MQTT s'installe seulement sur Home Assistant OS : votre installateur doit le faire à la main.",
    "z2m_ready": "Zigbee2MQTT et son messager (Mosquitto) sont installés et démarrés.",
    "mqtt_missing": "Le messager MQTT ne s'est pas annoncé. Réessayez dans quelques minutes.",
    "weather_already": "La météo de votre maison est déjà active.",
    "weather_done": "La météo de votre maison est active.",
    "weather_no_home": "La position de la maison n'est pas réglée : réglez-la dans Paramètres > Système > Général, puis réessayez.",
    "weather_failed": "La météo n'a pas pu être ajoutée. Réessayez plus tard.",
    "cameras_none": "Pas de caméra dans ce kit.",
    "cameras_no_hosts": "Aucune adresse de caméra n'a été donnée : votre installateur ajoutera les caméras.",
    "cameras_no_credentials": "Les identifiants des caméras ont été effacés par sécurité : votre installateur doit ajouter les caméras.",
    "frigate_hacs": "Le module Frigate est installé. L'intégration Frigate s'ajoute avec HACS par votre installateur.",
    "frigate_no_os": "Frigate s'installe seulement sur Home Assistant OS. L'intégration Frigate s'ajoute avec HACS par votre installateur.",
    "hacs_none": "Pas d'outils de l'installateur dans ce kit.",
    "hacs_files": "Les outils de l'installateur sont prêts. Votre installateur les activera lors de son passage.",
    "unexpected": "Une erreur inattendue est survenue. Réessayez, ou votre installateur s'en occupera.",
}

# Flow abort reasons -> plain French.
ABORT_MESSAGES: dict[str, str] = {
    "wrong_firmware_installed": "L'antenne a un logiciel incompatible : votre installateur doit la mettre à jour.",
    "usb_probe_failed": "L'antenne ne répond pas : débranchez-la, rebranchez-la, puis réessayez.",
    "cannot_connect": "L'appareil ne répond pas. Vérifiez qu'il est branché, puis réessayez.",
    "cannot_resolve_path": "L'antenne a été débranchée pendant la configuration. Rebranchez-la, puis réessayez.",
    "cannot_form_network": "Impossible de créer le réseau sans fil. Réessayez.",
    "not_zha_device": "L'antenne est déjà utilisée par un autre module de la box.",
    "fw_download_failed": "Le logiciel de l'antenne n'a pas pu être téléchargé. Vérifiez Internet, puis réessayez.",
    "fw_install_failed": "Le logiciel de l'antenne n'a pas pu être installé. Réessayez.",
    "unsupported_firmware": "L'antenne a un logiciel incompatible : votre installateur doit la mettre à jour.",
    "no_home": MSG["weather_no_home"],
}

REOLINK_ERRORS: dict[str, str] = {
    "cannot_connect": "elle ne répond pas (vérifiez qu'elle est branchée et son adresse)",
    "invalid_auth": "le nom d'utilisateur ou le mot de passe est refusé",
    "not_admin": "le compte donné n'est pas administrateur de la caméra",
    "password_incompatible": "le mot de passe contient des caractères refusés",
    "update_needed": "son logiciel doit être mis à jour",
    "api_error": "elle a répondu une erreur",
    "webhook_exception": "l'adresse de la box n'est pas réglée",
    "unknown": "erreur inconnue",
    "privacy": "le mode privé de la caméra est activé",
    "stuck": "elle demande une information en plus",
}

_HOST_RE = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$")


# --------------------------------------------------------------------------- kit file


def repository_slug(url: str) -> str:
    """Supervisor repository slug (sha1 of the lowercased URL, 8 hex)."""
    return hashlib.sha1(url.lower().encode()).hexdigest()[:8]  # noqa: S324 - not security


def _valid_host(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return bool(_HOST_RE.match(value)) and not value.replace(".", "").isdigit()


def _text(raw: Mapping[str, Any], key: str, default: str = "", max_len: int = 200) -> str:
    value = raw.get(key, default)
    if value is None:
        return default
    return str(value).strip()[:max_len]


def parse_kit(raw: Any) -> tuple[dict[str, Any], list[str]]:
    """Validate a decoded kit file; returns ``(kit, warnings)``.

    Missing or invalid values fall back to the defaults of the kit (CONTRACT_KIT).
    Warnings are English, for the log (never secrets).
    """
    warnings: list[str] = []
    if not isinstance(raw, Mapping):
        raise ValueError("kit file is not a JSON object")
    schema = raw.get("schema", KIT_SCHEMA)
    if schema != KIT_SCHEMA:
        warnings.append(f"unknown schema {schema!r}, read as schema {KIT_SCHEMA}")

    kit_name = raw.get("kit", DEFAULT_KIT)
    if kit_name not in KITS:
        warnings.append(f"unknown kit {kit_name!r}, using {DEFAULT_KIT!r}")
        kit_name = DEFAULT_KIT
    defaults = KIT_DEFAULTS[kit_name]

    def choice(key: str, allowed: Sequence[str]) -> str:
        value = raw.get(key)
        if value is None or value == "":
            return defaults[key]
        if value not in allowed:
            warnings.append(f"invalid {key} {value!r}, using {defaults[key]!r}")
            return defaults[key]
        return str(value)

    hosts: list[str] = []
    raw_hosts = raw.get("camera_hosts") or []
    if isinstance(raw_hosts, str):
        raw_hosts = [h for h in re.split(r"[\s,;]+", raw_hosts) if h]
    if not isinstance(raw_hosts, list):
        warnings.append("camera_hosts is not a list, ignored")
        raw_hosts = []
    for host in raw_hosts:
        value = str(host).strip()
        if not value:
            continue
        if not _valid_host(value):
            warnings.append(f"invalid camera host {value!r} ignored")
            continue
        if value not in hosts:
            hosts.append(value)
    if len(hosts) > MAX_CAMERA_HOSTS:
        warnings.append(f"more than {MAX_CAMERA_HOSTS} camera hosts, extra ignored")
        hosts = hosts[:MAX_CAMERA_HOSTS]

    # Client mode (= settings.commercial_mode). Absent: the integration default is kept.
    commercial = raw.get("commercial_mode")
    if commercial is not None and not isinstance(commercial, bool):
        warnings.append(f"invalid commercial_mode {commercial!r}, ignored")
        commercial = None

    profile = raw.get("profile") or ""
    if profile and profile not in PROFILES:
        warnings.append(f"invalid profile {profile!r}, ignored")
        profile = ""

    equipment = raw.get("equipment") or ""
    if equipment and equipment not in EQUIPMENTS:
        warnings.append(f"invalid equipment {equipment!r}, ignored")
        equipment = ""

    channel = raw.get("update_channel") or "stable"
    if channel not in UPDATE_CHANNELS:
        warnings.append(f"invalid update_channel {channel!r}, using 'stable'")
        channel = "stable"

    shop_url = _guide.validate_shop_url(raw.get("shop_url") or "")
    if shop_url is None:
        warnings.append("invalid shop_url ignored (https:// address expected)")
        shop_url = ""

    kit = {
        "schema": KIT_SCHEMA,
        "created_at": _text(raw, "created_at", max_len=40),
        "installer_version": _text(raw, "installer_version", max_len=20),
        "maison_facile_version": _text(raw, "maison_facile_version", max_len=20),
        "kit": kit_name,
        "zigbee": choice("zigbee", ZIGBEE_CHOICES),
        "cameras": choice("cameras", CAMERA_CHOICES),
        "camera_hosts": hosts,
        "camera_username": _text(raw, "camera_username", max_len=64),
        "camera_password": str(raw.get("camera_password") or "")[:128],
        "hacs_files": raw.get("hacs_files") is True,
        "installer_name": _text(raw, "installer_name", max_len=100),
        "installer_contact": _text(raw, "installer_contact", max_len=200),
        "update_channel": channel,
        "box_name": _text(raw, "box_name", DEFAULT_BOX_NAME, max_len=50) or DEFAULT_BOX_NAME,
        "shop_url": shop_url,
        "commercial_mode": commercial,
        "profile": profile,
        "equipment": equipment,
    }
    return kit, warnings


def load_kit_text(text: str) -> tuple[dict[str, Any], list[str]]:
    """Decode + validate the kit file. Raises ``ValueError`` if unreadable."""
    try:
        raw = json.loads(text)
    except (TypeError, json.JSONDecodeError) as err:
        raise ValueError(f"invalid JSON: {err.msg if hasattr(err, 'msg') else err}") from err
    return parse_kit(raw)


def has_secrets(kit: Mapping[str, Any]) -> bool:
    return any(kit.get(key) for key in SECRET_KEYS)


def redact_kit(kit: Mapping[str, Any]) -> dict[str, Any]:
    """Copy of the kit without camera credentials (for the store and the .done file)."""
    clean = copy.deepcopy(dict(kit))
    for key in SECRET_KEYS:
        if key in clean:
            clean[key] = ""
    return clean


def public_kit(kit: Mapping[str, Any] | None) -> dict[str, Any] | None:
    """What the websocket API shows of the kit (no secrets, no contact details)."""
    if not kit:
        return None
    return {
        "kit": kit.get("kit"),
        "zigbee": kit.get("zigbee"),
        "cameras": kit.get("cameras"),
        "camera_count": len(kit.get("camera_hosts") or []),
        "hacs_files": bool(kit.get("hacs_files")),
        "box_name": kit.get("box_name") or DEFAULT_BOX_NAME,
        "equipment": kit.get("equipment") or None,
    }


def settings_from_kit(kit: Mapping[str, Any], current: Mapping[str, Any]) -> dict[str, Any]:
    """Settings changes for the ``settings`` step (never erases a value with an empty one)."""
    changes: dict[str, Any] = {}
    for key in ("installer_name", "installer_contact"):
        value = str(kit.get(key) or "").strip()
        if value and value != current.get(key):
            changes[key] = value
    shop_url = _guide.validate_shop_url(kit.get("shop_url") or "")
    if shop_url and shop_url != current.get("shop_url"):
        changes["shop_url"] = shop_url  # « Où l'acheter ? » of the buying guide
    channel = kit.get("update_channel")
    if channel in UPDATE_CHANNELS and channel != current.get("update_channel"):
        changes["update_channel"] = channel
    commercial = kit.get("commercial_mode")
    if isinstance(commercial, bool) and commercial != (current.get("commercial_mode", True) is not False):
        changes["commercial_mode"] = commercial  # applied by commercial.py (provision.py)
    expected = kit.get("zigbee") in ("zha", "z2m")
    if current.get("radio_expected") is None or bool(current.get("radio_expected")) != expected:
        changes["radio_expected"] = expected  # read by the doctor (radio_missing)
    # Who installed the box (texts, audience.py) and « Avez-vous déjà du matériel ? »
    # (discovery mode). Never erased by an empty value.
    for key, allowed in (("profile", PROFILES), ("equipment", EQUIPMENTS)):
        value = kit.get(key)
        if value in allowed and value != current.get(key):
            changes[key] = value
    return changes


# --------------------------------------------------------------------------- plan and state


def settings_message(kit: Mapping[str, Any]) -> str:
    """Message of the ``settings`` step (a private person has no installer to quote)."""
    if kit.get("installer_name") or kit.get("installer_contact"):
        return MSG["settings_done"]
    return MSG["settings_self"] if kit.get("profile") == "particulier" else MSG["settings_empty"]


def zigbee_none_message(kit: Mapping[str, Any]) -> str:
    """Step ``zigbee`` without antenna: « not yet » for a box installed without hardware."""
    return MSG["zigbee_later"] if kit.get("equipment") == "none" else MSG["zigbee_none"]


def plan_steps(kit: Mapping[str, Any]) -> dict[str, dict[str, str]]:
    """Initial state of each step: ``{step_id: {state, message_fr}}`` (contract order)."""
    plan: dict[str, dict[str, str]] = {}
    for step in STEP_IDS:
        plan[step] = {"state": "pending", "message_fr": ""}
    if kit.get("zigbee") == "none":
        plan["zigbee"] = {"state": "skipped", "message_fr": zigbee_none_message(kit)}
    if kit.get("cameras") == "none":
        plan["cameras"] = {"state": "skipped", "message_fr": MSG["cameras_none"]}
    if not kit.get("hacs_files"):
        plan["hacs"] = {"state": "skipped", "message_fr": MSG["hacs_none"]}
    return plan


def invalid_kit_plan() -> dict[str, dict[str, str]]:
    plan = {step: {"state": "skipped", "message_fr": ""} for step in STEP_IDS}
    plan["settings"] = {"state": "error", "message_fr": MSG["kit_invalid"]}
    return plan


def resume_steps(steps: Mapping[str, Mapping[str, Any]], done: bool) -> dict[str, dict[str, Any]]:
    """After a restart: ``running`` -> ``pending`` and, while not finished, errors are retried."""
    resumed: dict[str, dict[str, Any]] = {}
    for step in STEP_IDS:
        current = dict(steps.get(step) or {"state": "pending", "message_fr": ""})
        if current.get("state") not in STATES:
            current["state"] = "pending"
        if current["state"] == "running" or (not done and current["state"] == "error"):
            current["state"] = "pending"
        resumed[step] = current
    return resumed


def steps_to_run(steps: Mapping[str, Mapping[str, Any]]) -> list[str]:
    return [s for s in STEP_IDS if (steps.get(s) or {}).get("state") == "pending"]


def all_finished(steps: Mapping[str, Mapping[str, Any]]) -> bool:
    return all((steps.get(s) or {}).get("state") in FINISHED_STATES for s in STEP_IDS)


def public_state(state: Mapping[str, Any] | None) -> dict[str, Any]:
    """Payload of ``provision/status`` (CONTRACT_KIT §4)."""
    if not state or not state.get("steps"):
        return {"active": False, "done": bool(state and state.get("done")), "kit": None, "steps": []}
    steps = state["steps"]
    items = [
        {
            "id": step,
            "label_fr": STEP_LABELS[step],
            "state": (steps.get(step) or {}).get("state", "pending"),
            "message_fr": (steps.get(step) or {}).get("message_fr", "") or "",
        }
        for step in STEP_IDS
    ]
    active = any(item["state"] in ("pending", "running") for item in items)
    return {
        "active": active,
        "done": bool(state.get("done")),
        "kit": public_kit(state.get("kit")),
        "steps": items,
    }


def failed_steps(state: Mapping[str, Any] | None) -> list[dict[str, str]]:
    """Doctor findings ``provision_failed`` (one per step in error)."""
    if not state:
        return []
    out = []
    for step in STEP_IDS:
        info = (state.get("steps") or {}).get(step) or {}
        if info.get("state") == "error":
            out.append({
                "kind": "provision_failed",
                "step": step,
                "label": STEP_LABELS[step],
                "message": str(info.get("message_fr") or ""),
                "detail": str(info.get("detail") or ""),
            })
    return out


# --------------------------------------------------------------------------- config flows


def choose_menu_option(
    options: Iterable[str] | Mapping[str, Any] | None, preferences: Sequence[str]
) -> str | None:
    """First preferred option present in the menu, ``None`` if none is acceptable."""
    if options is None:
        return None
    present = list(options.keys()) if isinstance(options, Mapping) else list(options)
    for wanted in preferences:
        if wanted in present:
            return wanted
    return None


def form_can_auto_submit(fields: Iterable[Mapping[str, Any]]) -> bool:
    """A form can be validated with ``{}`` if every required field has a default.

    ``fields`` = ``[{"name", "required": bool, "has_default": bool}]``.
    """
    return all(not f.get("required") or f.get("has_default") for f in fields)


def abort_message(reason: str | None, default: str = MSG["zigbee_failed"]) -> str:
    return ABORT_MESSAGES.get(str(reason or ""), default)


def reolink_message(host: str, code: str | None) -> str:
    why = REOLINK_ERRORS.get(str(code or "unknown"), REOLINK_ERRORS["unknown"])
    return f"Caméra {host} : {why}."


def reolink_error_code(errors: Mapping[str, Any] | None) -> str:
    """Most meaningful error code of a reolink form result."""
    if not errors:
        return "unknown"
    for key in ("password", "username", "host", "base"):
        if errors.get(key):
            return str(errors[key])
    return str(next(iter(errors.values())))


def cameras_summary(results: Mapping[str, str | None]) -> tuple[str, str]:
    """``{host: None (ok) | message}`` -> ``(state, message_fr)``."""
    failed = [msg for msg in results.values() if msg]
    ok = len(results) - len(failed)
    if not failed:
        plural = "s" if ok > 1 else ""
        return "done", f"{ok} caméra{plural} ajoutée{plural}."
    head = ""
    if ok:
        plural = "s" if ok > 1 else ""
        head = f"{ok} caméra{plural} ajoutée{plural}. "
    return "error", head + " ".join(failed)
