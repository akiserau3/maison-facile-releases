"""Pure logic of « Anniversaires » (birthday reminders).

This module must NOT import homeassistant: it is unit-tested on its own.

* phone numbers: normalisation to the international format (+33 by default);
* dates: next occurrence (29 February -> 28 February in non-leap years), age;
* contacts file (.vcf, vCard 2.1 / 3.0 / 4.0): only name + birthday + first mobile number;
* calendar events (``calendar.get_events``): those that look like birthdays;
* messages (varied, customisable) and links that open the SMS app / WhatsApp with the
  text ready (the client only presses « Envoyer »: nothing is ever sent automatically);
* views: upcoming list, home tile, phone notifications, spoken announcement.

Stored item (store key ``birthdays.items``)::

    {"id": "a1b2c3d4e5f6", "name": "Josette", "day": 31, "month": 10, "year": 1946 | None,
     "relation": "Mamie", "phone": "+33612345678" | None, "channel": "sms" | "whatsapp",
     "message": "" (custom text, {nom} / {age} placeholders), "source": "manual" | "vcf" | "calendar"}
"""

from __future__ import annotations

import datetime as dt
import hashlib
import quopri
import re
import unicodedata
from typing import Any
from urllib.parse import quote

IDEA_ID = "anniversaire"
MAX_VCF_BYTES = 2 * 1024 * 1024
MAX_ITEMS = 500
NAME_MAX = 60
RELATION_MAX = 40
MESSAGE_MAX = 300
CHANNELS: tuple[str, ...] = ("sms", "whatsapp")
SOURCES: tuple[str, ...] = ("manual", "vcf", "calendar")
DEFAULT_COUNTRY = "33"
TILE_COLOR = "#C2185B"
PANEL_PATH = "/maison-facile"

DEFAULT_SETTINGS: dict[str, Any] = {
    "enabled": True,  # reminders on (idea « Anniversaires » active when there is at least one date)
    "days_before": 3,  # 0 = no reminder before the day
    "hour": 9,  # reminder time (local), also the morning-of-the-day message
    "sync_calendar": False,
    "calendar_entity": "",
}

MONTHS_FR = (
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre",
)
WEEKDAYS_FR = ("lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche")

# Messages ready to send ({nom} = how the client calls the person, {age} = age reached).
TEMPLATES: tuple[str, ...] = (
    "Joyeux anniversaire {nom} !",
    "Bon anniversaire {nom} ! Je t'embrasse fort.",
    "Joyeux anniversaire {nom} ! Plein de bonheur pour cette nouvelle année.",
    "Un très joyeux anniversaire {nom} ! Profite bien de ta journée.",
    "Joyeux anniversaire {nom} ! Je pense bien à toi aujourd'hui.",
)
AGE_TEMPLATES: tuple[str, ...] = (
    "Joyeux anniversaire {nom} ! {age} ans, ça se fête !",
    "Bon anniversaire {nom} ! Belle journée pour tes {age} ans.",
)

NO_AUTO_SEND_FR = (
    "Maison Facile prépare le message mais ne l'envoie jamais tout seul : "
    "vous le relisez et vous appuyez vous-même sur « Envoyer »."
)


# --------------------------------------------------------------------------- text helpers


def normalize(text: Any) -> str:
    """Lower case, no accents, single spaces (for comparisons)."""
    if not text:
        return ""
    value = unicodedata.normalize("NFKD", str(text).replace("’", "'"))
    value = "".join(c for c in value if not unicodedata.combining(c))
    return " ".join(value.lower().split())


def short_hash(value: str, size: int = 12) -> str:
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:size]


def item_key(name: str, day: int, month: int) -> str:
    """Duplicate detection key (same person, same date)."""
    return short_hash(f"{normalize(name)}|{int(day):02d}|{int(month):02d}")


def first_name(name: str) -> str:
    parts = str(name or "").split()
    return parts[0] if parts else ""


def call_name(item: dict[str, Any]) -> str:
    """How the client calls the person: the link / nickname (« Mamie ») or the first name."""
    relation = str(item.get("relation") or "").strip()
    return relation or first_name(str(item.get("name") or "")) or "?"


def de_name(name: str) -> str:
    """« de Mamie », « d'Émile », « d'Hugo »."""
    base = normalize(name[:1]) if name else ""
    if base and base in "aeiouyh":
        return f"d'{name}"
    return f"de {name}"


def _clean_text(value: Any, max_len: int) -> str:
    text = " ".join(str(value or "").replace("\x00", "").split())
    return text[:max_len]


# --------------------------------------------------------------------------- phone numbers


def normalize_phone(raw: Any, country: str = DEFAULT_COUNTRY) -> str | None:
    """« 06 12 34 56 78 » / « +33 (0)6 12… » / « 0033… » / « tel:+33-6… » -> « +33612345678 ».

    Returns None when it does not look like a phone number.
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    text = re.sub(r"^tel:", "", text, flags=re.IGNORECASE)
    text = text.split(";", 1)[0]  # tel URI parameters (;ext=…)
    text = re.sub(r"\(0\)", "", text)
    if re.search(r"[A-Za-z]", text):
        return None
    plus = text.lstrip().startswith("+")
    digits = re.sub(r"\D", "", text)
    if not digits:
        return None
    if plus:
        pass
    elif digits.startswith("00"):
        digits = digits[2:]
    elif digits.startswith("0") and len(digits) == 10 and country == "33":
        digits = country + digits[1:]
    elif digits.startswith("0") and len(digits) >= 9:
        digits = country + digits[1:]
    elif len(digits) == 9 and country == "33" and digits[0] in "123456789":
        digits = country + digits
    else:
        return None
    if digits.startswith("330"):  # +33 0 6… typed by hand
        digits = "33" + digits[3:]
    if digits.startswith("33") and len(digits) != 11:
        return None
    if not 8 <= len(digits) <= 15 or digits[0] == "0":
        return None
    return f"+{digits}"


def is_mobile(e164: str | None) -> bool:
    """French numbers: only 06 / 07 are mobiles. Other countries: unknown, accepted."""
    if not e164:
        return False
    if e164.startswith("+33"):
        return e164[3:4] in ("6", "7")
    return True


def display_phone(e164: str | None) -> str:
    """« +33612345678 » -> « 06 12 34 56 78 » (French), else the international form."""
    if not e164:
        return ""
    if e164.startswith("+33") and len(e164) == 12:
        local = "0" + e164[3:]
        return " ".join(local[i:i + 2] for i in range(0, 10, 2))
    return e164


# --------------------------------------------------------------------------- dates


def is_leap(year: int) -> bool:
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def valid_day_month(day: Any, month: Any) -> bool:
    if not isinstance(day, int) or not isinstance(month, int) or isinstance(day, bool) or isinstance(month, bool):
        return False
    if not 1 <= month <= 12:
        return False
    try:
        dt.date(2000, month, day)  # 2000 is a leap year: 29/02 is accepted
    except ValueError:
        return False
    return True


def valid_birth(day: int, month: int, year: int | None) -> bool:
    if not valid_day_month(day, month):
        return False
    if year is None:
        return True
    try:
        dt.date(year, month, day)
    except ValueError:
        return False
    return True


def occurrence_in(year: int, day: int, month: int) -> dt.date:
    """The birthday in ``year`` (29 February -> 28 February in non-leap years)."""
    if month == 2 and day == 29 and not is_leap(year):
        return dt.date(year, 2, 28)
    return dt.date(year, month, day)


def next_occurrence(day: int, month: int, today: dt.date) -> dt.date:
    """Next birthday on or after ``today``."""
    occ = occurrence_in(today.year, day, month)
    if occ < today:
        occ = occurrence_in(today.year + 1, day, month)
    return occ


def age_at(year: int | None, occ: dt.date) -> int | None:
    """Age reached on the occurrence ``occ`` (None if the birth year is unknown)."""
    if not year or year > occ.year:
        return None
    return occ.year - year


def date_fr(day: dt.date, weekday: bool = True) -> str:
    text = f"{day.day if day.day != 1 else '1er'} {MONTHS_FR[day.month - 1]}"
    return f"{WEEKDAYS_FR[day.weekday()]} {text}" if weekday else text


def when_fr(days: int) -> str:
    if days <= 0:
        return "Aujourd'hui"
    if days == 1:
        return "Demain"
    if days == 2:
        return "Après-demain"
    return f"Dans {days} jours"


def age_fr(age: int | None) -> str:
    if age is None:
        return ""
    return f"{age} an" if age <= 1 else f"{age} ans"


# --------------------------------------------------------------------------- messages


def render_message(template: str, item: dict[str, Any], age: int | None) -> str:
    text = template.replace("{nom}", call_name(item))
    text = text.replace("{prenom}", first_name(str(item.get("name") or "")) or call_name(item))
    text = text.replace("{age}", str(age) if age is not None else "")
    return " ".join(text.split())


def message_for(item: dict[str, Any], occ: dt.date) -> str:
    """The message to send for the birthday ``occ``: the client's own text, or a model
    that changes from one year to the next (and from one person to the other)."""
    age = age_at(item.get("year"), occ)
    custom = str(item.get("message") or "").strip()
    if custom:
        if "{age}" in custom and age is None:
            custom = custom.replace("{age} ans", "").replace("{age}", "")
        return render_message(custom, item, age)
    pool = list(TEMPLATES) + (list(AGE_TEMPLATES) if age is not None else [])
    index = int(short_hash(f"{item.get('id', '')}:{occ.year}", 8), 16) % len(pool)
    return render_message(pool[index], item, age)


# --------------------------------------------------------------------------- links


def _digits(e164: str) -> str:
    return e164.lstrip("+")


def sms_link(e164: str, text: str, platform: str | None = None) -> str:
    """Link that opens the SMS app with the text ready.

    Android (and most browsers): ``sms:+33…?body=…`` ; iOS: ``sms:+33…&body=…``.
    """
    body = quote(text, safe="")
    sep = "&" if platform == "ios" else "?"
    return f"sms:{e164}{sep}body={body}"


def whatsapp_link(e164: str, text: str) -> str:
    """``https://wa.me/<international number without +>?text=…``."""
    return f"https://wa.me/{_digits(e164)}?text={quote(text, safe='')}"


def links(item: dict[str, Any], text: str) -> dict[str, Any]:
    phone = item.get("phone")
    if not phone:
        return {}
    return {
        "sms": {"android": sms_link(phone, text, "android"), "ios": sms_link(phone, text, "ios")},
        "whatsapp": whatsapp_link(phone, text),
    }


def notification_actions(item: dict[str, Any], text: str, platform: str | None) -> list[dict[str, str]]:
    """Companion app actions (``action: URI``). Android opens other apps' links only
    through the ``deep-link://`` prefix; https links (WhatsApp) open directly."""
    phone = item.get("phone")
    if not phone:
        return []
    sms = sms_link(phone, text, "ios" if platform == "ios" else "android")
    if platform != "ios":
        sms = f"deep-link://{sms}"
    actions = {
        "sms": {"action": "URI", "title": "Envoyer un SMS", "uri": sms},
        "whatsapp": {"action": "URI", "title": "WhatsApp", "uri": whatsapp_link(phone, text)},
    }
    first = item.get("channel") if item.get("channel") in CHANNELS else "sms"
    order = [first] + [c for c in CHANNELS if c != first]
    return [actions[c] for c in order]


# --------------------------------------------------------------------------- vCard


def _split_unquoted(text: str, sep: str) -> list[str]:
    out, cur, quoted = [], [], False
    for char in text:
        if char == '"':
            quoted = not quoted
        if char == sep and not quoted:
            out.append("".join(cur))
            cur = []
        else:
            cur.append(char)
    out.append("".join(cur))
    return out


def _unfold(text: str) -> list[str]:
    """Logical lines: RFC folding (leading space / tab) and QUOTED-PRINTABLE soft breaks."""
    raw = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    lines: list[str] = []
    qp_open = False
    for line in raw:
        if lines and qp_open:
            lines[-1] = lines[-1][:-1] + line  # soft line break "=" at the end
        elif lines and line[:1] in (" ", "\t"):
            lines[-1] += line[1:]
        else:
            lines.append(line)
        last = lines[-1] if lines else ""
        head = last.split(":", 1)[0].upper()
        qp_open = "QUOTED-PRINTABLE" in head and ":" in last and last.endswith("=")
    return lines


def _parse_line(line: str) -> tuple[str, dict[str, Any], str] | None:
    parts = _split_unquoted(line, ":")
    if len(parts) < 2:
        return None
    head, value = parts[0], ":".join(parts[1:])
    items = _split_unquoted(head, ";")
    name = items[0].split(".")[-1].strip().upper()  # "item1.TEL" -> "TEL"
    if not name:
        return None
    params: dict[str, Any] = {"types": set()}
    for param in items[1:]:
        key, eq, val = param.partition("=")
        key = key.strip().upper()
        if not eq:  # vCard 2.1 bare parameter: TEL;CELL;VOICE / ;QUOTED-PRINTABLE
            if key in ("QUOTED-PRINTABLE", "BASE64", "B"):
                params["ENCODING"] = key
            else:
                params["types"].add(key.lower())
            continue
        val = val.strip().strip('"')
        if key == "TYPE":
            params["types"].update(v.strip().strip('"').lower() for v in val.split(",") if v.strip())
        else:
            params[key] = val
    return name, params, value


def _decode(value: str, params: dict[str, Any]) -> str:
    if str(params.get("ENCODING", "")).upper() != "QUOTED-PRINTABLE":
        return value
    data = quopri.decodestring(value.encode("latin-1", errors="ignore"))
    charset = str(params.get("CHARSET") or "utf-8")
    for encoding in (charset, "utf-8", "cp1252"):
        try:
            return data.decode(encoding)
        except (LookupError, UnicodeDecodeError):
            continue
    return data.decode("utf-8", errors="replace")


def _unescape(value: str) -> str:
    out, i = [], 0
    while i < len(value):
        char = value[i]
        if char == "\\" and i + 1 < len(value):
            nxt = value[i + 1]
            out.append(" " if nxt in "nN" else nxt)
            i += 2
            continue
        out.append(char)
        i += 1
    return "".join(out)


_BDAY_PATTERNS = (
    re.compile(r"^--(?P<m>\d{2})-?(?P<d>\d{2})$"),
    re.compile(r"^(?P<y>\d{4})-?(?P<m>\d{2})-?(?P<d>\d{2})$"),
    re.compile(r"^(?P<d>\d{1,2})[/.](?P<m>\d{1,2})[/.](?P<y>\d{4})$"),
    re.compile(r"^(?P<y>\d{4})\.(?P<m>\d{2})\.(?P<d>\d{2})$"),
)


def parse_bday(value: str, params: dict[str, Any] | None = None) -> tuple[int, int, int | None] | None:
    """vCard BDAY -> (day, month, year | None). Accepts 19800515, 1980-05-15, --0515,
    --05-15, 1980-05-15T00:00:00Z, 15/05/1980; Apple's X-APPLE-OMIT-YEAR / year 1604 = no year."""
    params = params or {}
    text = str(value or "").strip()
    if not text:
        return None
    text = text.split("T", 1)[0].strip()
    for pattern in _BDAY_PATTERNS:
        match = pattern.match(text)
        if not match:
            continue
        groups = match.groupdict()
        day, month = int(groups["d"]), int(groups["m"])
        year = int(groups["y"]) if groups.get("y") else None
        if year is not None and (year < 1900 or year > 2100 or "X-APPLE-OMIT-YEAR" in params):
            year = None
        if not valid_day_month(day, month):
            return None
        if year is not None and not valid_birth(day, month, year):
            year = None
        return day, month, year
    return None


_MOBILE_TYPES = {"cell", "mobile", "iphone", "x-mobile", "x-cell"}


def parse_vcf(text: str) -> tuple[list[dict[str, Any]], int]:
    """Contacts file -> (candidates with a birthday, number of contacts without one).

    Only the name, the birthday and the first mobile number are kept. Candidate:
    ``{key, name, day, month, year, phone, source: "vcf"}`` (sorted by name, no duplicates).
    """
    text = str(text or "").lstrip("﻿")
    contacts: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    depth = 0
    for line in _unfold(text):
        stripped = line.strip()
        upper = stripped.upper()
        if upper == "BEGIN:VCARD":
            depth += 1
            if depth == 1:
                current = {"fn": "", "n": "", "bday": None, "tels": []}
            continue
        if upper == "END:VCARD":
            depth = max(0, depth - 1)
            if depth == 0 and current is not None:
                contacts.append(current)
                current = None
            continue
        if current is None or depth != 1 or not stripped:
            continue
        parsed = _parse_line(stripped)
        if parsed is None:
            continue
        name, params, value = parsed
        if name == "FN":
            current["fn"] = _unescape(_decode(value, params)).strip()
        elif name == "N":
            fields = [_unescape(f).strip() for f in _split_unquoted(_decode(value, params), ";")]
            fields += [""] * 5
            current["n"] = " ".join(p for p in (fields[1], fields[2], fields[0]) if p)
        elif name == "BDAY" and current["bday"] is None:
            current["bday"] = parse_bday(_decode(value, params), params)
        elif name == "TEL":
            current["tels"].append((params["types"], _decode(value, params)))
    out: dict[str, dict[str, Any]] = {}
    without = 0
    for contact in contacts:
        name = _clean_text(contact["fn"] or contact["n"], NAME_MAX)
        if not contact["bday"] or not name:
            without += 1
            continue
        day, month, year = contact["bday"]
        phone = None
        for types, value in contact["tels"]:
            if types & _MOBILE_TYPES and (number := normalize_phone(value)):
                phone = number
                break
        if phone is None:
            for _types, value in contact["tels"]:
                number = normalize_phone(value)
                if number and number.startswith("+33") and is_mobile(number):
                    phone = number
                    break
        key = item_key(name, day, month)
        if key in out:
            out[key]["phone"] = out[key]["phone"] or phone
            out[key]["year"] = out[key]["year"] or year
            continue
        out[key] = {"key": key, "name": name, "day": day, "month": month, "year": year, "phone": phone, "source": "vcf"}
    return sorted(out.values(), key=lambda c: (normalize(c["name"]), c["month"], c["day"])), without


# --------------------------------------------------------------------------- calendar


_BIRTHDAY_WORDS = ("anniversaire", "anniv", "birthday", "bday", "geburtstag", "cumpleanos", "compleanno", "\U0001f382")
_NOT_A_BIRTHDAY = ("mariage", "rencontre", "wedding", "deces", "deuil", "pacs", "fiancailles")
_CALENDAR_WORDS = ("birthday", "anniversaire", "geburtstag", "cumpleanos", "compleanno")
_NAME_PATTERNS = (
    re.compile(r"^(?:joyeux\s+|bon\s+)?anniv(?:ersaire)?\s*['’]?\s*(?:de\s+|d['’]\s*|du\s+|:|-|–)?\s*(?P<name>.+)$", re.I),
    re.compile(r"^(?P<name>.+?)['’]s\s+birthday$", re.I),
    re.compile(r"^(?:happy\s+)?birthday\s*(?:of\s+|:|-|–)?\s*(?P<name>.+)$", re.I),
    re.compile(r"^(?P<name>.+?)\s*(?:-|–|:)\s*(?:anniversaire|anniv|birthday)$", re.I),
    re.compile(r"^(?P<name>.+?)\s+(?:anniversaire|birthday)$", re.I),
)
_EMOJI_RE = re.compile("[\U0001f300-\U0001faff☀-➿️]")


def _event_date(value: Any) -> tuple[dt.date, bool] | None:
    """(date, all_day) of a ``calendar.get_events`` start ("2026-10-31" or ISO datetime)."""
    text = str(value or "").strip()
    try:
        if len(text) == 10:
            return dt.date.fromisoformat(text), True
        return dt.datetime.fromisoformat(text).date(), False
    except ValueError:
        return None


def _looks_birthday(text: str) -> bool:
    norm = normalize(text)
    if any(w in norm for w in _NOT_A_BIRTHDAY):
        return False
    return any(w in norm for w in _BIRTHDAY_WORDS)


def name_from_title(title: str) -> str:
    """« Anniversaire de Mamie » -> « Mamie », « Paul's birthday » -> « Paul »."""
    text = _EMOJI_RE.sub(" ", str(title or ""))
    text = " ".join(text.split()).strip(" -–:")
    text = re.sub(r"\s*\((?:\d{4}|\d{1,3}\s*ans?)\)\s*$", "", text, flags=re.I)
    text = re.sub(r"\s*[-–,]\s*\d{1,3}\s*ans?\s*$", "", text, flags=re.I)
    for pattern in _NAME_PATTERNS:
        match = pattern.match(text)
        if match and match.group("name").strip(" -–:"):
            text = match.group("name")
            break
    return _clean_text(text.strip(" -–:'’"), NAME_MAX)


def _year_from(text: str, occ: dt.date) -> int | None:
    match = re.search(r"\((\d{4})\)|n[ée]e?\s+en\s+(\d{4})|born\s+(?:in\s+)?(\d{4})", text, re.I)
    if match:
        year = int(next(g for g in match.groups() if g))
        return year if 1900 <= year <= occ.year else None
    match = re.search(r"(\d{1,3})\s*ans\b", text, re.I)
    if match:
        age = int(match.group(1))
        if 0 < age < 120:
            return occ.year - age
    return None


def detect_calendar_birthdays(
    events: list[dict[str, Any]], calendar_name: str = ""
) -> list[dict[str, Any]]:
    """Events of a calendar that look like birthdays.

    Kept: all-day events of a « birthdays » calendar (Google's « Anniversaires »), all-day
    events whose title says « anniversaire » / « birthday », all-day events that come back
    on the same day one year later (yearly), and timed events whose title says so.
    Returns candidates ``{key, name, day, month, year, phone: None, source: "calendar"}``.
    """
    birthday_calendar = any(w in normalize(calendar_name) for w in _CALENDAR_WORDS)
    parsed: list[tuple[dict[str, Any], dt.date, bool]] = []
    years_by_title: dict[tuple[str, int, int], set[int]] = {}
    for event in events or []:
        if not isinstance(event, dict):
            continue
        start = _event_date(event.get("start"))
        title = str(event.get("summary") or "").strip()
        if start is None or not title:
            continue
        day, all_day = start
        parsed.append((event, day, all_day))
        if all_day:
            years_by_title.setdefault((normalize(title), day.month, day.day), set()).add(day.year)
    out: dict[str, dict[str, Any]] = {}
    for event, day, all_day in sorted(parsed, key=lambda p: p[1]):
        title = str(event.get("summary") or "")
        text = f"{title} {event.get('description') or ''}"
        titled = _looks_birthday(title)
        if any(w in normalize(title) for w in _NOT_A_BIRTHDAY):
            continue
        yearly = all_day and len(years_by_title.get((normalize(title), day.month, day.day), set())) > 1
        if not (titled or (all_day and (birthday_calendar or yearly))):
            continue
        name = name_from_title(title)
        if not name:
            continue
        key = item_key(name, day.day, day.month)
        if key in out:
            continue
        out[key] = {
            "key": key, "name": name, "day": day.day, "month": day.month,
            "year": _year_from(text, day), "phone": None, "source": "calendar",
        }
    return sorted(out.values(), key=lambda c: (c["month"], c["day"], normalize(c["name"])))


# --------------------------------------------------------------------------- validation


class InvalidItem(ValueError):
    """A birthday the client typed is not valid (French message)."""

    def __init__(self, field: str, message_fr: str) -> None:
        super().__init__(message_fr)
        self.field = field
        self.message_fr = message_fr


def _int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    return None


def clean_item(raw: dict[str, Any], today: dt.date) -> dict[str, Any]:
    """Validate a birthday typed or imported by the client (raises InvalidItem)."""
    if not isinstance(raw, dict):
        raise InvalidItem("item", "Données incorrectes.")
    name = _clean_text(raw.get("name"), NAME_MAX)
    if not name:
        raise InvalidItem("name", "Indiquez le prénom de la personne.")
    day, month = _int(raw.get("day")), _int(raw.get("month"))
    if day is None or month is None or not valid_day_month(day, month):
        raise InvalidItem("date", "Cette date n'existe pas : vérifiez le jour et le mois.")
    year = raw.get("year")
    year = None if year in (None, "", 0) else _int(year)
    if raw.get("year") not in (None, "", 0) and year is None:
        raise InvalidItem("year", "L'année doit être un nombre (ou rester vide).")
    if year is not None:
        if not 1900 <= year <= today.year:
            raise InvalidItem("year", f"L'année doit être entre 1900 et {today.year} (ou rester vide).")
        if not valid_birth(day, month, year):
            raise InvalidItem("date", f"Le 29 février n'existe pas en {year}.")
        if dt.date(year, month, day) > today:
            raise InvalidItem("year", "Cette date de naissance est dans le futur.")
    phone_raw = raw.get("phone")
    phone = None
    if phone_raw not in (None, ""):
        phone = normalize_phone(phone_raw)
        if phone is None:
            raise InvalidItem("phone", "Ce numéro de téléphone n'est pas reconnu (exemple : 06 12 34 56 78).")
    channel = raw.get("channel") if raw.get("channel") in CHANNELS else "sms"
    source = raw.get("source") if raw.get("source") in SOURCES else "manual"
    return {
        "name": name,
        "day": day,
        "month": month,
        "year": year,
        "relation": _clean_text(raw.get("relation"), RELATION_MAX),
        "phone": phone,
        "channel": channel,
        "message": _clean_text(raw.get("message"), MESSAGE_MAX),
        "source": source,
    }


def clean_settings(changes: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
    """Validate a partial settings dict (raises InvalidItem)."""
    out = {**DEFAULT_SETTINGS, **(current or {})}
    for key, value in (changes or {}).items():
        if key == "days_before":
            number = _int(value)
            if number is None or not 0 <= number <= 30:
                raise InvalidItem(key, "Le rappel se fait de 0 à 30 jours avant.")
            out[key] = number
        elif key == "hour":
            number = _int(value)
            if number is None or not 0 <= number <= 23:
                raise InvalidItem(key, "Choisissez une heure entre 0 h et 23 h.")
            out[key] = number
        elif key in ("sync_calendar", "enabled"):
            if not isinstance(value, bool):
                raise InvalidItem(key, "Valeur oui/non attendue.")
            out[key] = value
        elif key == "calendar_entity":
            text = str(value or "").strip()
            if text and not re.match(r"^calendar\.[a-z0-9_]+$", text):
                raise InvalidItem(key, "Cet agenda n'existe pas.")
            out[key] = text
    if out["sync_calendar"] and not out["calendar_entity"]:
        out["sync_calendar"] = False
    return out


def merge_candidates(
    existing: list[dict[str, Any]], candidates: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Mark the candidates already saved (``already: true``)."""
    keys = {item_key(i["name"], i["day"], i["month"]) for i in existing}
    return [{**c, "already": c["key"] in keys} for c in candidates]


# --------------------------------------------------------------------------- views


def item_view(item: dict[str, Any], today: dt.date) -> dict[str, Any]:
    occ = next_occurrence(item["day"], item["month"], today)
    days = (occ - today).days
    age = age_at(item.get("year"), occ)
    text = message_for(item, occ)
    return {
        "birthday_id": item["id"],
        "name": item["name"],
        "relation": item.get("relation") or "",
        "call_name": call_name(item),
        "day": item["day"],
        "month": item["month"],
        "year": item.get("year"),
        "phone": item.get("phone") or "",
        "phone_display": display_phone(item.get("phone")),
        "channel": item.get("channel") or "sms",
        "message": item.get("message") or "",
        "source": item.get("source") or "manual",
        "next_date": occ.isoformat(),
        "days": days,
        "today": days == 0,
        "when_fr": when_fr(days),
        "date_fr": date_fr(occ),
        "age_next": age,
        "age_fr": age_fr(age),
        "text": text,
        "links": links(item, text),
    }


def upcoming(items: list[dict[str, Any]], today: dt.date) -> list[dict[str, Any]]:
    """Every birthday, the next one first."""
    views = [item_view(i, today) for i in items]
    return sorted(views, key=lambda v: (v["days"], normalize(v["name"])))


def due(items: list[dict[str, Any]], settings: dict[str, Any], today: dt.date) -> dict[str, list[dict[str, Any]]]:
    """What to say this morning: birthdays today, and those in ``days_before`` days."""
    before = int(settings.get("days_before") or 0)
    out: dict[str, list[dict[str, Any]]] = {"today": [], "soon": []}
    for item in items:
        days = (next_occurrence(item["day"], item["month"], today) - today).days
        if days == 0:
            out["today"].append(item)
        elif before and days == before:
            out["soon"].append(item)
    return out


def notification(
    item: dict[str, Any], today: dt.date, kind: str, *, mobile: bool, platform: str | None
) -> dict[str, Any]:
    """Payload of ``notify.<service>``: ``{title, message[, data]}``.

    ``kind`` = ``today`` (morning of the day: message ready + SMS / WhatsApp actions) or
    ``soon`` (« dans 3 jours » : time to buy a present). ``mobile`` = companion app service
    (actions and tap-to-open); other services get a plain message.
    """
    occ = next_occurrence(item["day"], item["month"], today)
    who = call_name(item)
    age = age_at(item.get("year"), occ)
    if kind == "today":
        text = message_for(item, occ)
        title = f"C'est l'anniversaire {de_name(who)} !"
        parts = [f"{age_fr(age)} aujourd'hui." if age is not None else "C'est aujourd'hui."]
        parts.append(f"Message prêt : « {text} »")
        actions = notification_actions(item, text, platform) if mobile else []
        if actions:
            parts.append("Touchez un bouton : il ne reste qu'à appuyer sur Envoyer.")
        payload: dict[str, Any] = {"title": title, "message": " ".join(parts)}
    else:
        days = (occ - today).days
        title = f"Anniversaire {de_name(who)} dans {days} jour{'s' if days > 1 else ''}"
        what = f"{who} aura {age_fr(age)}" if age is not None else f"C'est l'anniversaire {de_name(who)}"
        payload = {"title": title, "message": f"{what} {date_fr(occ)}. Le temps de trouver un cadeau !"}
        actions = []
    if mobile:
        data: dict[str, Any] = {
            "tag": f"mf_birthday_{item.get('id', '')}",
            "group": "maison-facile-anniversaires",
            "url": PANEL_PATH,
            "clickAction": PANEL_PATH,
        }
        if actions:
            data["actions"] = actions
        payload["data"] = data
    return payload


def announce_text(items: list[dict[str, Any]], today: dt.date) -> str:
    """Spoken in the morning on the speaker: « Aujourd'hui, c'est l'anniversaire de Mamie : 80 ans ! »."""
    parts = []
    for item in items:
        age = age_at(item.get("year"), next_occurrence(item["day"], item["month"], today))
        who = de_name(call_name(item))
        parts.append(f"l'anniversaire {who}" + (f" : {age_fr(age)}" if age is not None else ""))
    if not parts:
        return ""
    joined = parts[0] if len(parts) == 1 else ", ".join(parts[:-1]) + " et " + parts[-1]
    return f"Aujourd'hui, c'est {joined} ! Pensez à lui souhaiter." if len(parts) == 1 else f"Aujourd'hui, c'est {joined} ! Pensez à leur souhaiter."


def tiles(items: list[dict[str, Any]], today: dt.date) -> list[dict[str, Any]]:
    """Home tiles (IdeaTile shape, kind ``birthday``) of the birthdays of the day."""
    out = []
    for item in sorted(items, key=lambda i: normalize(i["name"])):
        occ = next_occurrence(item["day"], item["month"], today)
        if occ != today:
            continue
        age = age_at(item.get("year"), occ)
        text = message_for(item, occ)
        out.append({
            "idea_id": IDEA_ID,
            "key": f"birthday-{item['id']}",
            "kind": "birthday",
            "title": f"C'est l'anniversaire {de_name(call_name(item))} aujourd'hui",
            "icon": "cake",
            "color": TILE_COLOR,
            "entity_ids": [],
            "attribute": None,
            "unit": None,
            "threshold": None,
            "show": "always",
            "on_text": f"{age_fr(age)} !" if age is not None else "Pensez à lui souhaiter !",
            "off_text": None,
            "action": None,
            "page": {"page": "ideas", "params": {"id": IDEA_ID, "view": "birthdays"}},
            "preview": None,
            "birthday_id": item["id"],
            "message": text,
            "channel": item.get("channel") or "sms",
            "links": links(item, text),
        })
    return out


def preview_tile() -> dict[str, Any]:
    """Tile shown on the idea page (« Aperçu sur l'accueil »)."""
    return {
        "idea_id": IDEA_ID, "key": "birthday-preview", "kind": "birthday",
        "title": "C'est l'anniversaire de Mamie aujourd'hui", "icon": "cake", "color": TILE_COLOR,
        "entity_ids": [], "attribute": None, "unit": None, "threshold": None, "show": "always",
        "on_text": "80 ans !", "off_text": None, "action": None, "preview": "80 ans !", "links": {},
    }


# --------------------------------------------------------------------------- family accounts

_PRIVATE_KEYS = ("phone", "phone_display")


def family_view(view: dict[str, Any]) -> dict[str, Any]:
    """BirthdayView for a non-admin account: names and dates, no phone number, no SMS/WhatsApp link."""
    out = {k: v for k, v in view.items() if k not in _PRIVATE_KEYS}
    out.update(phone=None, phone_display="", links={})
    return out


def family_tile(tile: dict[str, Any]) -> dict[str, Any]:
    """Home tile « C'est l'anniversaire de Mamie » for a non-admin account (no links)."""
    return {**tile, "links": {}} if tile.get("kind") == "birthday" else tile
