"""« Anniversaires » : birthday reminders (idea ``anniversaire``, NOTES_anniversaires.md).

Everything stays on the box (store key ``birthdays``). Every day at the chosen hour:
optional calendar sync, reminder ``days_before`` days before, and on the day itself a
phone notification with a message ready to send (SMS / WhatsApp actions of the companion
app), a spoken announcement when a speaker is chosen, and a home tile. Nothing is ever
sent to the person automatically (the client presses « Envoyer » himself).

Privacy: names, dates and numbers are never written to the log, to the diagnostics or to
the help report (only counts and ids).
"""

from __future__ import annotations

import datetime as dt
import logging
import uuid
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import CALLBACK_TYPE, HomeAssistant, callback
from homeassistant.helpers.event import async_track_time_change
from homeassistant.helpers.start import async_at_started
from homeassistant.util import dt as dt_util
from homeassistant.util import slugify

from . import birthdays_rules as brules
from .const import DOMAIN, MaisonFacileData

_LOGGER = logging.getLogger(__name__)

STORE_KEY = "birthdays"
MAX_IGNORED = 1000

MSG_NO_PHONE = (
    "Aucun téléphone n'est relié à la maison : installez l'application Home Assistant sur votre "
    "téléphone, puis choisissez-le dans les réglages (notifications)."
)


class BirthdayError(Exception):
    """Error with a French message for the client."""

    def __init__(self, code: str, message_fr: str) -> None:
        super().__init__(message_fr)
        self.code = code
        self.message_fr = message_fr


class BirthdaysManager:
    """Storage, daily reminders, imports and views of the birthdays."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, data: MaisonFacileData) -> None:
        self.hass = hass
        self.entry = entry
        self.data = data
        self.store = data.store
        self._unsub_time: CALLBACK_TYPE | None = None
        self._unsubs: list[CALLBACK_TYPE] = []
        self._scheduled_hour: int | None = None

    # ------------------------------------------------------------------ lifecycle

    async def async_setup(self) -> None:
        self._schedule()
        # Runs now if HA has started, else once it has (cancel is safe after it ran).
        self._unsubs.append(async_at_started(self.hass, self._on_started))

    @callback
    def async_unload(self) -> None:
        if self._unsub_time:
            self._unsub_time()
            self._unsub_time = None
        for unsub in self._unsubs:
            unsub()
        self._unsubs.clear()

    @callback
    def _on_started(self, _hass: HomeAssistant) -> None:
        self._catch_up()

    @callback
    def _catch_up(self) -> None:
        """HA was off at the reminder hour (restart, power cut): run today's reminders now.
        Only once the module has run at least once (no burst at the very first install)."""
        raw = self.raw
        today = self.today()
        if raw.get("last_run") and raw["last_run"] != today.isoformat() and dt_util.now().hour >= self.settings["hour"]:
            self._start_daily()

    @callback
    def _schedule(self) -> None:
        hour = int(self.settings["hour"])
        if self._unsub_time and self._scheduled_hour == hour:
            return
        if self._unsub_time:
            self._unsub_time()
        self._scheduled_hour = hour
        self._unsub_time = async_track_time_change(self.hass, self._on_time, hour=hour, minute=0, second=0)

    @callback
    def _on_time(self, _now: dt.datetime) -> None:
        self._start_daily()

    @callback
    def _start_daily(self) -> None:
        self.entry.async_create_background_task(self.hass, self._async_safe_daily(), f"{DOMAIN}_birthdays_daily")

    async def _async_safe_daily(self) -> None:
        try:
            await self.async_run_daily()
        except Exception:
            _LOGGER.exception("Birthday reminders failed")

    # ------------------------------------------------------------------ store

    @property
    def raw(self) -> dict[str, Any]:
        value = self.store.data.get(STORE_KEY)
        value = value if isinstance(value, dict) else {}
        items = [i for i in value.get("items") or [] if isinstance(i, dict) and i.get("id")]
        return {
            "items": items,
            "settings": {**brules.DEFAULT_SETTINGS, **(value.get("settings") or {})},
            "last_run": value.get("last_run"),
            "ignored": list(value.get("ignored") or []),
        }

    @property
    def items(self) -> list[dict[str, Any]]:
        return self.raw["items"]

    @property
    def settings(self) -> dict[str, Any]:
        return self.raw["settings"]

    async def _async_save(self, raw: dict[str, Any]) -> None:
        await self.store.async_set(STORE_KEY, raw)

    @staticmethod
    def today() -> dt.date:
        return dt_util.now().date()

    def _item(self, birthday_id: str) -> dict[str, Any]:
        for item in self.items:
            if item["id"] == birthday_id:
                return item
        raise BirthdayError("not_found", "Cet anniversaire n'existe plus.")

    # ------------------------------------------------------------------ views

    @callback
    def notify_info(self) -> dict[str, Any]:
        service = str(self.store.settings.get("notify_service") or "")
        domain, _, name = service.partition(".")
        return {
            "service_ok": bool(name) and self.hass.services.has_service(domain, name),
            "mobile": domain == "notify" and name.startswith("mobile_app_"),
        }

    @callback
    def list_payload(self) -> dict[str, Any]:
        raw = self.raw
        return {
            "items": brules.upcoming(raw["items"], self.today()),
            "settings": raw["settings"],
            "notify": self.notify_info(),
            "announce": bool(self.store.settings.get("announce_media_player")),
            "no_auto_send_fr": brules.NO_AUTO_SEND_FR,
            "max_vcf_bytes": brules.MAX_VCF_BYTES,
        }

    @callback
    def module_state(self) -> dict[str, Any]:
        """For the idea « Anniversaires » (ideas_rules context ``modules.birthdays``)."""
        raw = self.raw
        people = [{"id": i["id"], "name": brules.call_name(i)} for i in raw["items"]]
        return {
            "active": bool(raw["settings"]["enabled"] and people),
            "people": sorted(people, key=lambda p: brules.normalize(p["name"])),
            "preview_tile": brules.preview_tile(),
        }

    @callback
    def tiles(self) -> list[dict[str, Any]]:
        raw = self.raw
        if not raw["settings"]["enabled"]:
            return []
        return brules.tiles(raw["items"], self.today())

    # ------------------------------------------------------------------ changes

    async def async_save_item(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            clean = brules.clean_item(payload, self.today())
        except brules.InvalidItem as err:
            raise BirthdayError("invalid_format", err.message_fr) from err
        raw = self.raw
        birthday_id = str(payload.get("birthday_id") or "")
        if birthday_id:
            index = next((n for n, i in enumerate(raw["items"]) if i["id"] == birthday_id), None)
            if index is None:
                raise BirthdayError("not_found", "Cet anniversaire n'existe plus.")
            clean["source"] = raw["items"][index].get("source") or clean["source"]
            raw["items"][index] = {**raw["items"][index], **clean, "id": birthday_id}
        else:
            if len(raw["items"]) >= brules.MAX_ITEMS:
                raise BirthdayError("invalid_format", f"Vous avez déjà {brules.MAX_ITEMS} anniversaires enregistrés.")
            birthday_id = uuid.uuid4().hex[:12]
            raw["items"].append({**clean, "id": birthday_id})
        await self._async_save(raw)
        _LOGGER.debug("Birthday %s saved (%s in total)", birthday_id, len(raw["items"]))
        item = next(i for i in raw["items"] if i["id"] == birthday_id)
        return brules.item_view(item, self.today())

    async def async_delete(self, birthday_id: str) -> None:
        raw = self.raw
        item = next((i for i in raw["items"] if i["id"] == birthday_id), None)
        if item is None:
            raise BirthdayError("not_found", "Cet anniversaire n'existe plus.")
        raw["items"] = [i for i in raw["items"] if i["id"] != birthday_id]
        if item.get("source") == "calendar":
            # The daily calendar sync must not bring it back.
            key = brules.item_key(item["name"], item["day"], item["month"])
            raw["ignored"] = (raw["ignored"] + [key])[-MAX_IGNORED:]
        await self._async_save(raw)

    async def async_clear(self) -> None:
        """« Tout effacer »: every birthday, the imported lists and the calendar sync."""
        raw = self.raw
        settings = {**raw["settings"], "sync_calendar": False, "calendar_entity": ""}
        await self._async_save({"items": [], "settings": settings, "last_run": raw["last_run"], "ignored": []})
        _LOGGER.info("All birthdays erased")

    async def async_import(self, candidates: list[dict[str, Any]]) -> dict[str, int]:
        """Add the ticked candidates (duplicates and invalid ones skipped)."""
        raw = self.raw
        keys = {brules.item_key(i["name"], i["day"], i["month"]) for i in raw["items"]}
        today = self.today()
        added = skipped = 0
        for candidate in candidates:
            try:
                clean = brules.clean_item(candidate, today)
            except brules.InvalidItem:
                skipped += 1
                continue
            key = brules.item_key(clean["name"], clean["day"], clean["month"])
            if key in keys or len(raw["items"]) >= brules.MAX_ITEMS:
                skipped += 1
                continue
            keys.add(key)
            raw["items"].append({**clean, "id": uuid.uuid4().hex[:12]})
            added += 1
        if added:
            await self._async_save(raw)
        _LOGGER.info("Birthdays imported: %s added, %s skipped", added, skipped)
        return {"added": added, "skipped": skipped}

    def import_vcf(self, content: str) -> dict[str, Any]:
        """Read a contacts file (text). Nothing is stored: the client ticks what to keep."""
        if len(content.encode("utf-8", errors="ignore")) > brules.MAX_VCF_BYTES:
            raise BirthdayError("invalid_format", "Ce fichier est trop gros (2 Mo au plus).")
        if "BEGIN:VCARD" not in content.upper():
            raise BirthdayError(
                "invalid_format",
                "Ce fichier n'est pas un fichier de contacts (.vcf). Exportez vos contacts depuis votre téléphone, puis réessayez.",
            )
        candidates, without = brules.parse_vcf(content)
        return {"candidates": brules.merge_candidates(self.items, candidates), "without_date": without}

    @callback
    def calendars(self) -> list[dict[str, Any]]:
        out = []
        for state in sorted(self.hass.states.async_all("calendar"), key=lambda s: s.entity_id):
            name = str(state.attributes.get("friendly_name") or state.entity_id)
            looks = any(w in brules.normalize(f"{name} {state.entity_id}") for w in ("birthday", "anniversaire"))
            out.append({"entity_id": state.entity_id, "name": name, "birthdays": looks})
        out.sort(key=lambda c: (not c["birthdays"], brules.normalize(c["name"])))
        return out

    async def _async_calendar_candidates(self, entity_id: str) -> list[dict[str, Any]]:
        state = self.hass.states.get(entity_id)
        if not entity_id.startswith("calendar.") or state is None:
            raise BirthdayError("not_found", "Cet agenda n'est pas (ou plus) relié à la maison.")
        start = dt_util.start_of_local_day() - dt.timedelta(days=366)
        end = dt_util.start_of_local_day() + dt.timedelta(days=367)
        try:
            response = await self.hass.services.async_call(
                "calendar",
                "get_events",
                {"entity_id": entity_id, "start_date_time": start, "end_date_time": end},
                blocking=True,
                return_response=True,
            )
        except Exception as err:
            _LOGGER.warning("Could not read calendar %s: %s", entity_id, type(err).__name__)
            raise BirthdayError("failed", "L'agenda n'a pas répondu. Vérifiez qu'il est bien relié, puis réessayez.") from err
        events = ((response or {}).get(entity_id) or {}).get("events") or []
        name = str(state.attributes.get("friendly_name") or entity_id)
        return brules.detect_calendar_birthdays(list(events), f"{name} {entity_id}")

    async def async_import_calendar(self, entity_id: str) -> dict[str, Any]:
        candidates = await self._async_calendar_candidates(entity_id)
        return {"candidates": brules.merge_candidates(self.items, candidates), "entity_id": entity_id}

    async def async_sync_calendar(self) -> int:
        """Daily sync: add the new birthdays of the chosen calendar (not the deleted ones)."""
        settings = self.settings
        entity_id = settings.get("calendar_entity") or ""
        if not settings.get("sync_calendar") or not entity_id:
            return 0
        try:
            candidates = await self._async_calendar_candidates(entity_id)
        except BirthdayError:
            return 0
        ignored = set(self.raw["ignored"])
        fresh = [c for c in candidates if c["key"] not in ignored]
        result = await self.async_import(fresh)
        return result["added"]

    async def async_set_settings(self, changes: dict[str, Any]) -> dict[str, Any]:
        raw = self.raw
        if changes.get("calendar_entity") and self.hass.states.get(changes["calendar_entity"]) is None:
            raise BirthdayError("not_found", "Cet agenda n'est pas (ou plus) relié à la maison.")
        try:
            raw["settings"] = brules.clean_settings(changes, raw["settings"])
        except brules.InvalidItem as err:
            raise BirthdayError("invalid_format", err.message_fr) from err
        await self._async_save(raw)
        self._schedule()
        return raw["settings"]

    async def async_set_enabled(self, enabled: bool) -> None:
        await self.async_set_settings({"enabled": bool(enabled)})

    # ------------------------------------------------------------------ reminders

    async def async_run_daily(self, force: bool = False) -> dict[str, int]:
        """The morning job: calendar sync, reminders, announcement. Once a day."""
        today = self.today()
        raw = self.raw
        if raw.get("last_run") == today.isoformat() and not force:
            return {"today": 0, "soon": 0}
        raw["last_run"] = today.isoformat()
        await self._async_save(raw)
        await self.async_sync_calendar()
        raw = self.raw
        if not raw["settings"]["enabled"]:
            return {"today": 0, "soon": 0}
        due = brules.due(raw["items"], raw["settings"], today)
        for item in due["today"]:
            await self._async_notify(item, "today", today)
        for item in due["soon"]:
            await self._async_notify(item, "soon", today)
        if due["today"]:
            await self._async_announce(due["today"], today)
        if due["today"] or due["soon"]:
            _LOGGER.info("Birthday reminders: %s today, %s soon", len(due["today"]), len(due["soon"]))
        return {"today": len(due["today"]), "soon": len(due["soon"])}

    @callback
    def _platform(self, service: str) -> str | None:
        """« ios » / « android » of the companion app behind ``notify.mobile_app_<name>``."""
        for entry in self.hass.config_entries.async_entries("mobile_app"):
            device_name = str(entry.data.get("device_name") or "")
            if device_name and slugify(f"mobile_app_{device_name}") == service:
                os_name = brules.normalize(entry.data.get("os_name"))
                if "ios" in os_name or "ipados" in os_name or "iphone" in os_name:
                    return "ios"
                if "android" in os_name:
                    return "android"
        return None

    async def _async_notify(self, item: dict[str, Any], kind: str, today: dt.date, prefix: str = "") -> bool:
        service = str(self.store.settings.get("notify_service") or "")
        domain, _, name = service.partition(".")
        if not name or not self.hass.services.has_service(domain, name):
            _LOGGER.debug("Birthday %s: no notify service", item.get("id"))
            return False
        mobile = domain == "notify" and name.startswith("mobile_app_")
        payload = brules.notification(item, today, kind, mobile=mobile, platform=self._platform(name) if mobile else None)
        if prefix:
            payload["title"] = f"{prefix}{payload['title']}"
        try:
            await self.hass.services.async_call(domain, name, payload, blocking=True)
        except Exception as err:  # noqa: BLE001 - never stop the other reminders
            _LOGGER.warning("Birthday %s: notification failed (%s)", item.get("id"), type(err).__name__)
            return False
        return True

    @callback
    def _voice(self) -> str:
        ideas = getattr(self.data, "ideas", None)
        if ideas is not None and hasattr(ideas, "_tts_entity"):
            return str(ideas._tts_entity() or "")  # same voice as the ideas' announcements
        ids = sorted(s.entity_id for s in self.hass.states.async_all("tts"))
        return ids[0] if ids else ""

    async def _async_announce(self, items: list[dict[str, Any]], today: dt.date) -> None:
        """Same rule as the ideas' blueprints: only if the speaker and a voice exist."""
        player = str(self.store.settings.get("announce_media_player") or "")
        if not player or self.hass.states.get(player) is None:
            return
        voice = self._voice()
        if not voice or not self.hass.services.has_service("tts", "speak"):
            return
        try:
            await self.hass.services.async_call(
                "tts",
                "speak",
                {"entity_id": voice, "media_player_entity_id": player, "message": brules.announce_text(items, today)},
                blocking=True,
            )
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Birthday announcement failed (%s)", type(err).__name__)

    async def async_test_notify(self, birthday_id: str) -> dict[str, Any]:
        item = self._item(birthday_id)
        if not self.notify_info()["service_ok"]:
            raise BirthdayError("failed", MSG_NO_PHONE)
        occ = brules.next_occurrence(item["day"], item["month"], self.today())
        if not await self._async_notify(item, "today", occ, prefix="Essai — "):
            raise BirthdayError("failed", "Le message n'a pas pu partir vers votre téléphone. Réessayez dans un instant.")
        return {"ok": True, "message_fr": "C'est envoyé : regardez votre téléphone."}


async def async_setup_birthdays(hass: HomeAssistant, entry: ConfigEntry, data: MaisonFacileData) -> BirthdaysManager:
    manager = BirthdaysManager(hass, entry, data)
    await manager.async_setup()
    return manager
