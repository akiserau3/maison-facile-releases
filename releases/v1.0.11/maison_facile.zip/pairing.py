"""Guided pairing through ZHA or Zigbee2MQTT."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Callable
from typing import Any

from homeassistant.core import CALLBACK_TYPE, Event, HomeAssistant, callback
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers.event import async_call_later

from . import compat
from .const import EVENT_DEVICE_FOUND, PAIRING_DURATION
from .onboarding import build_device, describe_device, detect_radio, is_house_device, z2m_base_topic
from .store import MaisonFacileStore

_LOGGER = logging.getLogger(__name__)

Z2M_PERMIT_SUFFIX = "bridge/request/permit_join"
# Entities of a freshly joined device appear a few seconds after the device.
RETRY_DELAYS = (2, 3, 5, 10, 20)

Listener = Callable[[dict[str, Any]], None]


class PairingManager:
    """Opens the network for new devices and reports them to subscribers."""

    def __init__(self, hass: HomeAssistant, store: MaisonFacileStore) -> None:
        self.hass = hass
        self.store = store
        self.method: str = "none"
        self.active = False
        self._listeners: list[Listener] = []
        self._unsub_registry: CALLBACK_TYPE | None = None
        self._unsub_timeout: CALLBACK_TYPE | None = None
        self._tasks: set[asyncio.Task[None]] = set()
        self._reported: set[str] = set()

    # ------------------------------------------------------------------ lifecycle

    @callback
    def async_setup(self) -> None:
        self._unsub_registry = self.hass.bus.async_listen(
            dr.EVENT_DEVICE_REGISTRY_UPDATED, self._handle_registry_event
        )

    @callback
    def async_unload(self) -> None:
        if self._unsub_registry:
            self._unsub_registry()
            self._unsub_registry = None
        self._cancel_timeout()
        for task in self._tasks:
            task.cancel()
        self._tasks.clear()
        self._listeners.clear()

    # ------------------------------------------------------------------ subscribers

    @callback
    def async_subscribe(self, listener: Listener) -> CALLBACK_TYPE:
        self._listeners.append(listener)

        @callback
        def _unsub() -> None:
            if listener in self._listeners:
                self._listeners.remove(listener)

        return _unsub

    # ------------------------------------------------------------------ permit join

    async def async_start(self, device_type: str | None = None) -> dict[str, Any]:
        radio = detect_radio(self.hass)
        if radio == "zha":
            await self.hass.services.async_call(
                "zha", "permit", {"duration": PAIRING_DURATION}, blocking=True
            )
        elif radio == "z2m":
            await self._z2m_permit(True)
        else:
            self.method = "none"
            return {"method": "none", "duration": PAIRING_DURATION}
        self.method = radio
        self.active = True
        self._reported.clear()
        self._cancel_timeout()
        self._unsub_timeout = async_call_later(self.hass, PAIRING_DURATION, self._on_timeout)
        _LOGGER.info("Pairing opened via %s for %ss (type=%s)", radio, PAIRING_DURATION, device_type)
        return {"method": radio, "duration": PAIRING_DURATION}

    async def async_stop(self) -> None:
        self._cancel_timeout()
        if self.method == "z2m" and self.active:
            await self._z2m_permit(False)
        elif self.method == "zha" and self.active:
            # duration 0 closes the network immediately.
            try:
                await self.hass.services.async_call("zha", "permit", {"duration": 0}, blocking=True)
            except Exception:  # noqa: BLE001
                _LOGGER.debug("Could not close ZHA pairing early", exc_info=True)
        self.active = False

    async def _z2m_permit(self, enable: bool) -> None:
        # Zigbee2MQTT 2.x only accepts {"time": N}; N = 0 closes. Recent 1.x accepts it too.
        payload = {"time": PAIRING_DURATION if enable else 0}
        topic = f"{z2m_base_topic(self.hass)}/{Z2M_PERMIT_SUFFIX}"
        await self.hass.services.async_call(
            "mqtt",
            "publish",
            {"topic": topic, "payload": json.dumps(payload)},
            blocking=True,
        )

    @callback
    def _on_timeout(self, _now: Any) -> None:
        self._unsub_timeout = None
        self.active = False

    @callback
    def _cancel_timeout(self) -> None:
        if self._unsub_timeout:
            self._unsub_timeout()
            self._unsub_timeout = None

    # ------------------------------------------------------------------ detection

    @callback
    def _handle_registry_event(self, event: Event) -> None:
        if event.data.get("action") != "create":
            return
        device_id = event.data.get("device_id")
        if not device_id:
            return
        task = self.hass.async_create_background_task(
            self._async_report(str(device_id)), f"maison_facile_pairing_{device_id}"
        )
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _async_report(self, device_id: str) -> None:
        dev_reg = dr.async_get(self.hass)
        for delay in RETRY_DELAYS:
            await asyncio.sleep(delay)
            device = compat.get_main_device(dev_reg, device_id)
            if device is None:
                return
            description = describe_device(self.hass, device)
            if not is_house_device(self.hass, device, description):
                continue
            built = build_device(self.hass, self.store, device, description)
            # Wait a bit longer if the device is not classified yet.
            if built["type"] == "autre" and delay != RETRY_DELAYS[-1]:
                continue
            self._publish(built)
            return

    @callback
    def _publish(self, device: dict[str, Any]) -> None:
        if device["device_id"] in self._reported:
            return
        self._reported.add(device["device_id"])
        _LOGGER.info("New device found: %s (%s)", device["type"], device["device_id"])
        self.hass.bus.async_fire(EVENT_DEVICE_FOUND, {"device": device})
        message = {"event": "device_found", "device": device}
        for listener in list(self._listeners):
            try:
                listener(message)
            except Exception:  # noqa: BLE001
                _LOGGER.exception("Pairing subscriber failed")
