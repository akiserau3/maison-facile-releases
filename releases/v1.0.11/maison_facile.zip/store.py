"""Persistent storage for Maison Facile (CONTRACT §4)."""

from __future__ import annotations

import copy
import logging
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .const import DEFAULT_SETTINGS, STORAGE_KEY, STORAGE_VERSION

_LOGGER = logging.getLogger(__name__)


def _default_data() -> dict[str, Any]:
    return {
        "onboarded": False,
        "rooms": [],
        "device_rooms": {},
        "recommendations": {},
        "settings": copy.deepcopy(DEFAULT_SETTINGS),
        "update": {"last_backup": None, "last_install": None, "validated_core_max": None},
        "heating_pauses": {},
        # Commercial mode (commercial.py): installer code hash, sidebars we changed.
        "advanced": {"pin": None, "sidebars": {}},
        # Idées (ideas.py): {idea_id: {status, options, devices, automation_ids, ...}}
        "ideas": {},
        "ideas_seen": [],
    }


class MaisonFacileStore:
    """Thin wrapper around ``helpers.storage.Store`` with defaults merged in."""

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._store: Store[dict[str, Any]] = Store(hass, STORAGE_VERSION, STORAGE_KEY)
        self.data: dict[str, Any] = _default_data()

    async def async_load(self) -> dict[str, Any]:
        loaded = await self._store.async_load()
        data = _default_data()
        if isinstance(loaded, dict):
            for key, value in loaded.items():
                if key in ("settings", "update", "advanced") and isinstance(value, dict):
                    data[key].update(value)
                else:
                    data[key] = value
        self.data = data
        return self.data

    async def async_save(self) -> None:
        await self._store.async_save(self.data)

    # Convenience accessors -------------------------------------------------

    @property
    def settings(self) -> dict[str, Any]:
        return self.data["settings"]

    @property
    def rooms(self) -> list[dict[str, Any]]:
        return self.data["rooms"]

    @property
    def device_rooms(self) -> dict[str, str]:
        return self.data["device_rooms"]

    @property
    def recommendations(self) -> dict[str, Any]:
        return self.data["recommendations"]

    @property
    def heating_pauses(self) -> dict[str, Any]:
        return self.data["heating_pauses"]

    @property
    def update(self) -> dict[str, Any]:
        return self.data["update"]

    async def async_update_settings(self, changes: dict[str, Any]) -> dict[str, Any]:
        self.data["settings"].update(changes)
        await self.async_save()
        _LOGGER.debug("Settings updated: %s", sorted(changes))
        return self.settings

    async def async_set(self, key: str, value: Any) -> None:
        self.data[key] = value
        await self.async_save()
