"""Page « Applications » : la sélection Maison Facile d'applications HAOS (logique pure, sans HA).

Une application (ex-« module complémentaire » de Home Assistant OS) s'installe depuis la
boutique du Supervisor. Maison Facile en propose une courte liste choisie, expliquée en
français, avec un seul bouton qui change selon l'état : Installer → Démarrer → Ouvrir.
Avant chaque installation, une sauvegarde complète est faite (backup_helper.py).

Identifiants (slug) : préfixe = 8 premiers caractères du SHA-1 de l'adresse du dépôt
(règle du Supervisor), « core_ » pour les applications officielles.
Tests : tests/test_apps_rules.py.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from typing import Any

COMMUNITY_REPO = "https://github.com/hassio-addons/repository"

# Champs : id (court, stable), slug, repository (None = boutique officielle), name, icon,
# color, category, what (une phrase), why (à quoi ça sert chez soi), level (facile /
# intermédiaire / avancé), needs (ce qu'il faut avant, facultatif), opens (a une page).
CATALOG: tuple[dict[str, Any], ...] = (
    {
        "id": "music_assistant",
        "slug": "d5369777_music_assistant",
        "repository": "https://github.com/music-assistant/home-assistant-addon",
        "name": "Music Assistant",
        "icon": "music",
        "color": "#C2185B",
        "category": "Musique",
        "what": "Toute votre musique sur toutes vos enceintes.",
        "why": "Spotify, Deezer, Tidal, YouTube Music, radios et vos fichiers, sur les enceintes et télés de la maison. Avec les paroles et un mode karaoké.",
        "level": "facile",
        "needs": "",
        "opens": True,
    },
    {
        "id": "zigbee2mqtt",
        "slug": "45df7312_zigbee2mqtt",
        "repository": "https://github.com/zigbee2mqtt/hassio-zigbee2mqtt",
        "name": "Zigbee2MQTT",
        "icon": "signal",
        "color": "#E8590C",
        "category": "Appareils",
        "what": "Une autre façon de gérer vos capteurs Zigbee.",
        "why": "Accepte encore plus de modèles de capteurs. Maison Facile utilise déjà le Zigbee intégré : ne l'installez que si un capteur n'est pas reconnu.",
        "level": "avancé",
        "needs": "L'application Mosquitto, et l'antenne Zigbee libérée du Zigbee intégré.",
        "opens": True,
    },
    {
        "id": "mosquitto",
        "slug": "core_mosquitto",
        "repository": None,
        "name": "Mosquitto",
        "icon": "chat",
        "color": "#5D6B7A",
        "category": "Appareils",
        "what": "Le facteur qui transporte les messages de certains appareils.",
        "why": "Nécessaire pour Zigbee2MQTT et pour les appareils « MQTT » (certains Shelly, Tasmota…).",
        "level": "intermédiaire",
        "needs": "",
        "opens": False,
    },
    {
        "id": "frigate",
        "slug": "ccab4aaf_frigate",
        "repository": "https://github.com/blakeblackshear/frigate-hass-addons",
        "name": "Frigate",
        "icon": "camera",
        "color": "#00838F",
        "category": "Sécurité",
        "what": "Vos caméras reconnaissent les personnes, les voitures, les animaux.",
        "why": "Enregistre seulement ce qui compte et envoie une alerte « personne devant la porte », sans cloud.",
        "level": "avancé",
        "needs": "Des caméras IP (RTSP) et un PC assez puissant.",
        "opens": True,
    },
    {
        "id": "esphome",
        "slug": "5c53de3b_esphome",
        "repository": "https://github.com/esphome/home-assistant-addon",
        "name": "ESPHome",
        "icon": "devices",
        "color": "#6B47B8",
        "category": "Bricolage",
        "what": "Créez vos propres capteurs avec de petites cartes électroniques.",
        "why": "Pour les bricoleurs : une carte ESP32 à quelques euros devient un capteur de votre choix.",
        "level": "avancé",
        "needs": "Une carte ESP32 ou ESP8266.",
        "opens": True,
    },
    {
        "id": "node_red",
        "slug": "a0d7b954_nodered",
        "repository": COMMUNITY_REPO,
        "name": "Node-RED",
        "icon": "magic",
        "color": "#C42B1C",
        "category": "Automatismes",
        "what": "Des automatismes avancés en reliant des blocs.",
        "why": "Pour aller plus loin que les idées de Maison Facile, en dessinant des schémas.",
        "level": "avancé",
        "needs": "",
        "opens": True,
    },
    {
        "id": "file_editor",
        "slug": "core_configurator",
        "repository": None,
        "name": "Éditeur de fichiers",
        "icon": "wrench",
        "color": "#0067C0",
        "category": "Outils",
        "what": "Modifier les fichiers de configuration depuis le navigateur.",
        "why": "Utile pour suivre un tutoriel qui demande d'ajouter une ligne dans configuration.yaml.",
        "level": "intermédiaire",
        "needs": "",
        "opens": True,
    },
    {
        "id": "samba",
        "slug": "core_samba",
        "repository": None,
        "name": "Partage réseau (Samba)",
        "icon": "download",
        "color": "#0E7A0D",
        "category": "Outils",
        "what": "Voir les dossiers de la box depuis votre PC.",
        "why": "Récupérer une sauvegarde ou déposer un fichier, comme une clé USB sur le réseau.",
        "level": "intermédiaire",
        "needs": "Choisir un nom d'utilisateur et un mot de passe dans ses réglages.",
        "opens": False,
    },
)
BY_ID: dict[str, dict[str, Any]] = {a["id"]: a for a in CATALOG}

# Onglet « Modules » : la sélection Maison Facile dans le Marketplace (HACS intégré à Home
# Assistant 2026.11+). ``repo`` = dépôt GitHub tel qu'il apparaît dans le catalogue ; un
# module absent du catalogue n'est simplement pas affiché. Tous demandent un redémarrage.
MODULES: tuple[dict[str, Any], ...] = (
    {
        "repo": "hekmon/rtetempo",
        "name": "RTE Tempo",
        "icon": "bolt",
        "color": "#0067C0",
        "what": "La couleur des jours Tempo d'EDF (bleu, blanc, rouge).",
        "why": "Pour les abonnés Tempo : savoir la veille si demain est un jour rouge, et décaler le chauffage ou la machine à laver.",
        "level": "facile",
    },
    {
        "repo": "bramstroker/homeassistant-powercalc",
        "name": "Powercalc",
        "icon": "plug",
        "color": "#B8860B",
        "what": "Estime ce que consomment vos lampes et appareils, sans prise qui mesure.",
        "why": "Complète la page Énergie : une ampoule connectée suffit pour connaître sa consommation.",
        "level": "intermédiaire",
    },
    {
        "repo": "KartoffelToby/better_thermostat",
        "name": "Better Thermostat",
        "icon": "heater",
        "color": "#C42B1C",
        "what": "Des têtes de radiateur plus précises, avec un thermomètre à part.",
        "why": "La tête de radiateur mesure mal la pièce (collée au radiateur) : un thermomètre posé plus loin corrige.",
        "level": "intermédiaire",
    },
    {
        "repo": "nielsfaber/alarmo",
        "name": "Alarmo",
        "icon": "shield",
        "color": "#0E7A0D",
        "what": "Une vraie alarme maison avec vos détecteurs.",
        "why": "Codes, délais d'entrée et de sortie, sirène : une alarme complète, sans abonnement.",
        "level": "intermédiaire",
    },
    {
        "repo": "mampfes/hacs_waste_collection_schedule",
        "name": "Calendrier des poubelles",
        "icon": "clock",
        "color": "#6B47B8",
        "what": "Les jours de collecte récupérés automatiquement, pour certaines communes.",
        "why": "Si votre commune est prise en charge, plus besoin de saisir les jours de collecte à la main.",
        "level": "avancé",
    },
    {
        "repo": "blakeblackshear/frigate-hass-integration",
        "name": "Frigate (intégration)",
        "icon": "camera",
        "color": "#00838F",
        "what": "Relie l'application Frigate à vos alertes et à vos pages.",
        "why": "À installer après l'application Frigate (onglet Applications), pour recevoir ses alertes.",
        "level": "avancé",
    },
    {
        "repo": "basnijholt/adaptive-lighting",
        "name": "Lumière adaptative",
        "icon": "bulb",
        "color": "#E8590C",
        "what": "La couleur et l'intensité des lampes suivent le soleil.",
        "why": "Lumière blanche le jour, chaude et douce le soir : plus agréable et meilleur pour le sommeil.",
        "level": "intermédiaire",
    },
)
LEVELS = ("facile", "intermédiaire", "avancé")
STATES = ("not_installed", "installing", "updating", "not_running", "running", "unknown")

MSG = {
    "not_haos": "Les applications s'installent seulement sur Home Assistant OS (la box Maison Facile).",
    "backup_failed": "La sauvegarde n'a pas pu se faire : rien n'a été installé, par sécurité.",
    "install_failed": "« {name} » n'a pas pu s'installer. Vérifiez Internet, puis réessayez.",
    "start_failed": "« {name} » n'a pas pu démarrer. Ouvrez Dépannage, ou réessayez.",
    "repository_failed": "La boutique de « {name} » n'a pas pu être ajoutée. Vérifiez Internet, puis réessayez.",
    "busy": "Une installation est déjà en cours. Patientez un instant.",
    "unknown_app": "Cette application n'existe pas dans la sélection.",
}


def modules_payload() -> list[dict[str, Any]]:
    """La sélection de modules (``apps/list``)."""
    return [dict(m) for m in MODULES]


def repository_hash(url: str) -> str:
    """Préfixe des identifiants d'un dépôt (même calcul que le Supervisor)."""
    return hashlib.sha1(url.lower().encode()).hexdigest()[:8]  # noqa: S324 - identifiant, pas sécurité


def check_catalog() -> list[str]:
    """Incohérences du catalogue (vide = OK). Utilisé par les tests."""
    problems: list[str] = []
    for app in CATALOG:
        repo = app["repository"]
        if repo is None:
            if not app["slug"].startswith("core_"):
                problems.append(f"{app['id']}: slug officiel attendu (core_…)")
        elif not app["slug"].startswith(repository_hash(repo) + "_"):
            problems.append(f"{app['id']}: le slug ne correspond pas au dépôt {repo}")
        if app["level"] not in LEVELS:
            problems.append(f"{app['id']}: niveau inconnu {app['level']}")
    repos = [m["repo"].lower() for m in MODULES]
    if len(set(repos)) != len(repos):
        problems.append("modules : dépôt en double")
    for m in MODULES:
        if m["level"] not in LEVELS or m["repo"].count("/") != 1:
            problems.append(f"module {m['repo']}: niveau ou dépôt invalide")
    return problems


def next_action(state: str, busy_step: str | None = None) -> dict[str, str]:
    """Le bouton à afficher pour une application, selon son état."""
    if busy_step:
        labels = {"backup": "Sauvegarde…", "repository": "Préparation…", "install": "Installation…", "start": "Démarrage…"}
        return {"action": "wait", "label": labels.get(busy_step, "Un instant…")}
    if state == "not_installed":
        return {"action": "install", "label": "Installer"}
    if state in ("installing", "updating"):
        return {"action": "wait", "label": "Installation…"}
    if state == "not_running":
        return {"action": "start", "label": "Démarrer"}
    if state == "running":
        return {"action": "open", "label": "Ouvrir"}
    return {"action": "retry", "label": "Réessayer"}


def app_payload(app: Mapping[str, Any], info: Mapping[str, Any] | None, busy: Mapping[str, Any] | None) -> dict[str, Any]:
    """Une tuile de la page (``apps/list``). ``info`` = état lu sur le Supervisor."""
    info = info or {}
    state = str(info.get("state") or "unknown")
    if state not in STATES:
        state = "unknown"
    step = (busy or {}).get("step")
    action = next_action(state, step)
    if action["action"] == "open" and not (app["opens"] and info.get("ingress_url")):
        action = {"action": "none", "label": "En marche"}
    return {
        "id": app["id"],
        "name": app["name"],
        "icon": app["icon"],
        "color": app["color"],
        "category": app["category"],
        "what": app["what"],
        "why": app["why"],
        "level": app["level"],
        "needs": app["needs"],
        "state": state,
        "version": info.get("version"),
        "update_available": bool(info.get("update_available")),
        "ingress_url": info.get("ingress_url") if state == "running" else None,
        "action": action["action"],
        "label": action["label"],
        "error": (busy or {}).get("error"),
    }
