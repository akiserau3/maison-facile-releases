"""Gardien des mises à jour de Maison Facile.

Après une mise à jour, Maison Facile écrit ``update.pending`` dans son fichier
``.storage/maison_facile.data`` puis redémarre la box. Au démarrage suivant :
- si Maison Facile se charge, elle efface elle-même ``pending`` : rien à faire ;
- sinon (nouvelle version qui plante), le gardien remet ``maison_facile.bak`` en place
  et redémarre. Maison Facile (l'ancienne version) affiche alors « La nouvelle version
  n'a pas démarré : l'ancienne fonctionne toujours ».
Ce module n'importe rien de Maison Facile.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import voluptuous as vol

from homeassistant.components import frontend, persistent_notification, websocket_api
from homeassistant.components.http import StaticPathConfig
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.event import async_call_later
from homeassistant.helpers.start import async_at_started
from homeassistant.helpers.storage import Store
from homeassistant.util import dt as dt_util

from . import rules

_LOGGER = logging.getLogger(__name__)
DOMAIN = "maison_facile_guard"
MF_STORE_KEY = "maison_facile.data"
CHECK_DELAY = 15  # secondes après le démarrage complet (toutes les intégrations ont été lancées)
WAIT_DELAY = 60
STATIC_URL = f"/{DOMAIN}_static"
SCREEN_JS = "guard-screen.js"
RUNTIME = f"{DOMAIN}_runtime"  # hass.data : {"restoring": bool, "stuck": bool, "static": bool}
NOTIFICATION_ID = "maison_facile_guard"


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    runtime = hass.data.setdefault(RUNTIME, {"restoring": False, "stuck": False, "static": False})
    if not runtime["static"]:
        runtime["static"] = True
        version = await _guard_version(hass)
        url = f"{STATIC_URL}/{version}"
        await hass.http.async_register_static_paths(
            [StaticPathConfig(url, str(Path(__file__).parent / "www"), False)]
        )
        frontend.add_extra_js_url(hass, f"{url}/{SCREEN_JS}")
        websocket_api.async_register_command(hass, ws_status)
    memo: Store[dict[str, Any]] = Store(hass, 1, DOMAIN)
    rounds = {"n": 0}

    async def _check(_now: Any = None) -> None:
        try:
            action = await async_check(hass, memo, rounds["n"])
        except Exception:  # noqa: BLE001 - le gardien ne doit jamais gêner la box
            _LOGGER.exception("Maison Facile guard check failed")
            return
        if action == rules.WAIT:
            rounds["n"] += 1
            entry.async_on_unload(async_call_later(hass, WAIT_DELAY, _check))

    @callback
    def _started(_hass: HomeAssistant) -> None:
        entry.async_on_unload(async_call_later(hass, CHECK_DELAY, _check))

    entry.async_on_unload(async_at_started(hass, _started))
    return True


async def _guard_version(hass: HomeAssistant) -> str:
    def _read() -> str:
        import json  # noqa: PLC0415

        return str(json.loads((Path(__file__).parent / "manifest.json").read_text())["version"])

    try:
        return await hass.async_add_executor_job(_read)
    except (OSError, ValueError, KeyError):
        return "0"


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/status"})
@callback
def ws_status(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    """Pour l'écran d'attente du navigateur (tous les utilisateurs, pas seulement l'admin)."""
    entries = hass.config_entries.async_entries(rules.MF)
    entry = entries[0] if entries else None
    runtime = hass.data.get(RUNTIME, {})
    screen = rules.screen(
        entry.state.value if entry is not None else None,
        bool(entry and entry.disabled_by),
        bool(runtime.get("restoring")),
        bool(runtime.get("stuck")),
    )
    connection.send_result(msg["id"], {"screen": screen})


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    return True


async def async_check(hass: HomeAssistant, memo: Store[dict[str, Any]], waited_rounds: int = 0) -> str:
    """Décide et agit. Renvoie l'action choisie (rules.OK / WAIT / RESTORE / STUCK)."""
    data = await Store(hass, 1, MF_STORE_KEY).async_load() or {}
    pending = (data.get("update") or {}).get("pending")
    entries = hass.config_entries.async_entries(rules.MF)
    entry = entries[0] if entries else None
    state = entry.state.value if entry is not None else None
    disabled = bool(entry and entry.disabled_by)
    done = await memo.async_load() or {}
    key = str((pending or {}).get("at") or "")
    custom_components = Path(hass.config.path("custom_components"))
    has_backup = await hass.async_add_executor_job(rules.backup_ok, custom_components)
    action = rules.decide(pending, state, disabled, has_backup, bool(key and done.get("restored_for") == key), waited_rounds)
    if action == rules.RESTORE:
        version = pending.get("version") if pending else "?"
        previous = pending.get("previous_version") if pending else "?"
        _LOGGER.warning("Maison Facile %s does not start (%s): restoring %s", version, state, previous)
        try:
            await hass.async_add_executor_job(rules.restore, custom_components)
        except OSError:
            _LOGGER.exception("Could not restore the previous Maison Facile version")
            action = rules.STUCK
        else:
            hass.data.setdefault(RUNTIME, {})["restoring"] = True
            await memo.async_save({"restored_for": key, "at": dt_util.utcnow().isoformat(), "version": version})
            persistent_notification.async_create(
                hass,
                f"La version {version} de Maison Facile ne démarrait pas. La version {previous} a été "
                "remise automatiquement : la box redémarre, rien n'est perdu.",
                title="Mise à jour annulée automatiquement",
                notification_id=NOTIFICATION_ID,
            )
            await hass.services.async_call("homeassistant", "restart", {}, blocking=False)
            return action
    if action == rules.STUCK:
        hass.data.setdefault(RUNTIME, {})["stuck"] = True
        persistent_notification.async_create(
            hass,
            "Maison Facile ne démarre plus après sa mise à jour et l'ancienne version n'a pas pu être "
            "remise automatiquement. Demandez de l'aide sur le forum de la communauté : le dossier "
            "custom_components/maison_facile.bak contient l'ancienne version.",
            title="Maison Facile ne démarre pas",
            notification_id=NOTIFICATION_ID,
        )
    return action
