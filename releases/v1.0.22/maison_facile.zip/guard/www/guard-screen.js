// Écran d'attente du gardien des mises à jour de Maison Facile.
// Chargé par Home Assistant sur toutes les pages, même quand Maison Facile ne démarre pas
// (il appartient au gardien, pas à Maison Facile). Tant que Maison Facile n'est pas chargée,
// il couvre l'écran avec un message simple ; dès qu'elle revient, il recharge la page pour
// retrouver « Ma maison ».
(() => {
  if (window.__mfGuardScreen) return;
  window.__mfGuardScreen = true;
  const TEXT = {
    starting: ["Maison Facile démarre…", "Encore quelques instants. Vous n'avez rien à faire."],
    restoring: ["Retour à la version précédente…",
      "La nouvelle version ne démarrait pas : l'ancienne est remise automatiquement et la box redémarre (2 à 3 minutes). Rien n'est perdu, vous n'avez rien à faire."],
    stuck: ["Maison Facile ne démarre pas",
      "La réparation automatique n'a pas fonctionné. Ouvrez les notifications de Home Assistant pour savoir quoi faire, ou demandez de l'aide à la communauté."],
  };
  let box = null;
  let dismissed = false;
  let seenProblem = false;

  function show(kind) {
    if (dismissed) return;
    if (!box) {
      box = document.createElement("div");
      box.setAttribute("role", "alertdialog");
      box.style.cssText = "position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;"
        + "background:rgba(240,244,250,0.97);font-family:'Segoe UI Variable','Segoe UI',system-ui,sans-serif;color:#1b1b1f;padding:24px";
      box.innerHTML = '<div style="max-width:520px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.18);padding:32px;text-align:center">'
        + '<div data-spin style="width:44px;height:44px;margin:0 auto 18px;border-radius:50%;border:4px solid #cfe0f5;border-top-color:#0067C0;animation:mfgs 1s linear infinite"></div>'
        + '<h2 data-t style="font-size:24px;margin:0 0 10px"></h2><p data-p style="font-size:16px;line-height:1.5;margin:0 0 20px;color:#444"></p>'
        + '<button type="button" data-x style="font:inherit;font-size:14px;border:1px solid #ccc;background:#fff;border-radius:8px;padding:8px 14px;cursor:pointer">Accéder quand même à Home Assistant</button></div>'
        + "<style>@keyframes mfgs{to{transform:rotate(360deg)}}</style>";
      box.querySelector("[data-x]").addEventListener("click", () => { dismissed = true; hide(); });
      document.body.appendChild(box);
    }
    const [t, p] = TEXT[kind] || TEXT.starting;
    box.querySelector("[data-t]").textContent = t;
    box.querySelector("[data-p]").textContent = p;
    box.querySelector("[data-spin]").style.display = kind === "stuck" ? "none" : "";
  }
  function hide() { if (box) { box.remove(); box = null; } }

  function connection() {
    const ha = document.querySelector("home-assistant");
    return ha && ha.hass && ha.hass.connection;
  }

  async function tick() {
    const conn = connection();
    if (!conn) return; // pas encore connecté, ou box en train de redémarrer
    let st;
    try {
      st = await conn.sendMessagePromise({ type: "maison_facile_guard/status" });
    } catch (_e) {
      seenProblem = true; // box en redémarrage : on garde l'écran et on réessaie
      return;
    }
    if (st.screen === "none") {
      hide();
      // Maison Facile est revenue après une coupure (mise à jour, retour en arrière) : on
      // recharge TOUJOURS. La page a pu être ouverte avec l'ancienne version, et Home
      // Assistant l'a envoyée sur « Vue d'ensemble » pendant l'absence de Maison Facile.
      if (seenProblem) window.location.reload();
      return;
    }
    seenProblem = true;
    show(st.screen);
  }
  setInterval(tick, 4000);
  setTimeout(tick, 1500);
})();
