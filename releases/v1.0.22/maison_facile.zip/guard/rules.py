"""Décisions du gardien, sans Home Assistant (testées par tests/test_guard_rules.py).

Le gardien est une petite intégration séparée (``maison_facile_guard``). Après le
redémarrage qui suit une mise à jour de Maison Facile, si la nouvelle version ne se
charge pas, il remet l'ancienne (dossier ``maison_facile.bak``) et redémarre la box.
Il n'importe JAMAIS le code de Maison Facile : une version cassée ne peut pas le casser.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Any

MF = "maison_facile"
BACKUP = f"{MF}.bak"
FAILED = f"{MF}.failed"
DISABLED_MANIFEST = "manifest.json.disabled"
MAX_WAIT_ROUNDS = 3  # « en cours de chargement / réessai » : on patiente encore un peu

OK, WAIT, RESTORE, STUCK = "ok", "wait", "restore", "stuck"


def decide(
    pending: dict[str, Any] | None,
    state: str | None,
    disabled: bool,
    backup_ok: bool,
    already_restored: bool,
    waited_rounds: int,
) -> str:
    """Que faire, une fois Home Assistant démarré ?

    ``state`` : état de l'entrée Maison Facile (« loaded », « setup_error »…), ``None``
    si Maison Facile n'est pas configurée. ``already_restored`` : déjà fait pour cette
    mise à jour (évite une boucle de redémarrages si l'ancienne version plante aussi).
    """
    if not pending or state is None or disabled or state == "loaded":
        return OK
    if state in ("setup_retry", "setup_in_progress") and waited_rounds < MAX_WAIT_ROUNDS:
        return WAIT
    if already_restored or not backup_ok:
        return STUCK
    return RESTORE


def backup_ok(custom_components: Path) -> bool:
    bak = custom_components / BACKUP
    return (bak / DISABLED_MANIFEST).is_file() or (bak / "manifest.json").is_file()


def restore(custom_components: Path) -> None:
    """Remet l'ancienne version : maison_facile -> maison_facile.failed, .bak -> maison_facile.

    Le manifeste de la version cassée est désactivé (Home Assistant ne voit jamais deux
    intégrations « maison_facile »). Lève OSError si un déplacement échoue.
    """
    cur = custom_components / MF
    bak = custom_components / BACKUP
    failed = custom_components / FAILED
    if failed.exists():
        shutil.rmtree(failed)
    if (cur / "manifest.json").is_file():
        os.replace(cur / "manifest.json", cur / DISABLED_MANIFEST)
    if cur.exists():
        os.replace(cur, failed)
    os.replace(bak, cur)
    if (cur / DISABLED_MANIFEST).is_file() and not (cur / "manifest.json").exists():
        os.replace(cur / DISABLED_MANIFEST, cur / "manifest.json")


def screen(state: str | None, disabled: bool, restoring: bool, stuck: bool) -> str:
    """Ce que l'écran d'attente du navigateur doit afficher.

    « none » : rien (Maison Facile chargée, absente ou désactivée exprès) ;
    « restoring » : l'ancienne version est remise, la box redémarre ;
    « stuck » : Maison Facile ne démarre pas et rien n'a pu être réparé ;
    « starting » : Maison Facile est en train de démarrer (ou va être vérifiée).
    """
    if state is None or disabled or state == "loaded":
        return "none"
    if restoring:
        return "restoring"
    if stuck:
        return "stuck"
    return "starting"
