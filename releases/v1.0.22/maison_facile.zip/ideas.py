"""« Idées » : ready-made automations activated in one tap (CONTRACT.md §11).

The catalogue is ``ideas/*.yaml`` (loaded and validated at start-up, see
``ideas_rules``). This module builds the context from Home Assistant (devices,
weather, phones, speakers, voices, discovery flows), creates / removes the
``mf_idea_<id>_<hash>`` automations through :class:`AutomationManager` (same
safe write of automations.yaml), and activates « pending » ideas by itself when
the missing device is paired.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EVENT_SERVICE_REGISTERED
from homeassistant.core import CALLBACK_TYPE, Event, HomeAssistant, callback
from homeassistant.data_entry_flow import UnknownFlow
from homeassistant.helpers import area_registry as ar
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers.event import async_call_later
from homeassistant.helpers.start import async_at_started
from homeassistant.util import dt as dt_util

from . import buying_guide as bguide
from . import compat, rules
from . import ideas_rules as irules
from .const import DOMAIN, EVENT_DEVICE_FOUND, MaisonFacileData
from .onboarding import list_devices, normalize, person_entities

_LOGGER = logging.getLogger(__name__)

IDEAS_DIR = Path(__file__).parent / "ideas"
BLUEPRINTS_DIR = Path(__file__).parent / "blueprints" / "automation"
REFRESH_DELAY = 5  # s, debounce of registry / service changes
ADD_FLOW_TIMEOUT = 120  # s, a TV may wait for the client to accept on screen
STORE_IDEAS = "ideas"
STORE_SEEN = "ideas_seen"

_TV_WORDS = ("tv", "tele", "television", "bravia", "shield")


class IdeaError(Exception):
    """Error with a French message for the client."""

    def __init__(self, code: str, message_fr: str) -> None:
        super().__init__(message_fr)
        self.code = code
        self.message_fr = message_fr


class IdeasManager:
    """Statuses, activation and auto-activation of the ideas."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, data: MaisonFacileData) -> None:
        self.hass = hass
        self.entry = entry
        self.data = data
        self.store = data.store
        self.ideas: list[dict[str, Any]] = []
        self.load_errors: dict[str, list[str]] = {}
        self.guide: list[dict[str, Any]] = []  # buying_guide.yaml (« Quoi acheter ? »)
        self._unsubs: list[CALLBACK_TYPE] = []
        self._refresh_timer: CALLBACK_TYPE | None = None
        self._lock = asyncio.Lock()
        self._started = False

    # ------------------------------------------------------------------ lifecycle

    async def async_setup(self) -> None:
        self.ideas, self.load_errors = await self.hass.async_add_executor_job(
            irules.load_ideas_dir, IDEAS_DIR, BLUEPRINTS_DIR
        )
        for name, errors in self.load_errors.items():
            _LOGGER.error("Idea file %s ignored: %s", name, "; ".join(errors))
        _LOGGER.debug("%s idea(s) loaded", len(self.ideas))
        try:
            from .ws_guide import async_guide_items  # noqa: PLC0415

            self.guide = await async_guide_items(self.hass)
        except Exception:  # noqa: BLE001 - the ideas work without the guide
            _LOGGER.exception("Could not load the buying guide")
        bus = self.hass.bus
        self._unsubs.append(bus.async_listen(EVENT_DEVICE_FOUND, self._on_device_found))
        self._unsubs.append(bus.async_listen(er.EVENT_ENTITY_REGISTRY_UPDATED, self._on_registry))
        self._unsubs.append(bus.async_listen(dr.EVENT_DEVICE_REGISTRY_UPDATED, self._on_device_registry))
        self._unsubs.append(bus.async_listen(EVENT_SERVICE_REGISTERED, self._on_service))
        # Runs now if HA has started, else once it has (cancel is safe after it ran).
        self._unsubs.append(async_at_started(self.hass, self._on_started))

    @callback
    def async_unload(self) -> None:
        for unsub in self._unsubs:
            unsub()
        self._unsubs.clear()
        if self._refresh_timer:
            self._refresh_timer()
            self._refresh_timer = None

    @callback
    def _on_started(self, _hass: HomeAssistant) -> None:
        self._started = True
        self.async_schedule_refresh(0)

    @callback
    def _on_registry(self, event: Event) -> None:
        if event.data.get("action") in ("create", "remove"):
            self.async_schedule_refresh()

    @callback
    def _on_device_registry(self, event: Event) -> None:
        # A device moved to another room: "same room" choices may change.
        if event.data.get("action") == "update" and "area_id" in (event.data.get("changes") or {}):
            self.async_schedule_refresh()

    @callback
    def _on_service(self, event: Event) -> None:
        if event.data.get("domain") in ("notify", "tts"):
            self.async_schedule_refresh()

    @callback
    def async_schedule_refresh(self, delay: float = REFRESH_DELAY) -> None:
        if not self._started:
            return
        if self._refresh_timer:
            self._refresh_timer()

        @callback
        def _run(_now: Any) -> None:
            self._refresh_timer = None
            self.entry.async_create_background_task(
                self.hass, self._async_safe_refresh(), f"{DOMAIN}_ideas_refresh"
            )

        self._refresh_timer = async_call_later(self.hass, delay, _run)

    async def _async_safe_refresh(self) -> None:
        try:
            await self.async_refresh()
        except Exception:
            _LOGGER.exception("Ideas refresh failed")

    # ------------------------------------------------------------------ store

    @property
    def stored(self) -> dict[str, Any]:
        value = self.store.data.get(STORE_IDEAS)
        return value if isinstance(value, dict) else {}

    @property
    def seen(self) -> list[str]:
        value = self.store.data.get(STORE_SEEN)
        return list(value) if isinstance(value, list) else []

    def idea(self, idea_id: str) -> dict[str, Any]:
        for idea in self.ideas:
            if idea["id"] == idea_id:
                return idea
        raise IdeaError("not_found", "Cette idée n'existe pas (ou plus).")

    # ------------------------------------------------------------------ context

    @callback
    def _device_classes(self, device: dict[str, Any]) -> dict[str, str]:
        ent_reg = er.async_get(self.hass)
        classes: dict[str, str] = {}
        for role, entity_id in (device.get("entities") or {}).items():
            entry = ent_reg.async_get(entity_id)
            state = self.hass.states.get(entity_id)
            cls = (entry.device_class or entry.original_device_class) if entry else None
            cls = cls or (state.attributes.get("device_class") if state else None)
            if cls:
                classes[role] = str(cls)
        return classes

    @callback
    def _phones(self) -> list[dict[str, Any]]:
        services = self.hass.services.async_services_for_domain("notify")
        out = []
        for name in sorted(services):
            if name.startswith("mobile_app_"):
                label = name.removeprefix("mobile_app_").replace("_", " ").strip() or "téléphone"
                out.append({"entity_id": f"notify.{name}", "name": f"Téléphone {label}"})
        return out

    @callback
    def _extra_media(self, devices: list[dict[str, Any]]) -> list[dict[str, Any]]:
        known = {str((d.get("entities") or {}).get("media")) for d in devices}
        ent_reg = er.async_get(self.hass)
        out = []
        for state in self.hass.states.async_all("media_player"):
            if state.entity_id in known or state.state == "unavailable":
                continue
            entry = ent_reg.async_get(state.entity_id)
            if entry is not None and entry.platform == DOMAIN:
                continue
            name = str(state.attributes.get("friendly_name") or state.entity_id)
            words = set(normalize(f"{name} {state.entity_id}").replace(".", " ").split())
            is_tv = state.attributes.get("device_class") == "tv" or bool(words & set(_TV_WORDS))
            out.append({
                "entity_id": state.entity_id,
                "name": name,
                "area_id": entry.area_id if entry else None,
                "kind": "tv" if is_tv else "speaker",
            })
        return out

    @callback
    def _tts_entity(self) -> str:
        try:
            from homeassistant.components import tts

            engine = tts.async_default_engine(self.hass)
        except Exception:  # noqa: BLE001 - tts not loaded
            engine = None
        if isinstance(engine, str) and engine.startswith("tts."):
            return engine
        ids = sorted(s.entity_id for s in self.hass.states.async_all("tts"))
        return ids[0] if ids else ""

    @callback
    def _entities(self) -> dict[str, list[dict[str, Any]]]:
        """Entities of ANY integration playing a role of ``irules.ENTITY_ROLES`` (persons,
        vacuums, CO2, soil moisture, ink, Tempo colour, Météo-France alerts, chargers, meters)."""
        ent_reg = er.async_get(self.hass)
        dev_reg = dr.async_get(self.hass)
        out: dict[str, list[dict[str, Any]]] = {}
        for state in self.hass.states.async_all(("person", "vacuum", "sensor", "switch", "binary_sensor")):
            entry = ent_reg.async_get(state.entity_id)
            attrs = state.attributes
            role = irules.context_entity_role({
                "entity_id": state.entity_id,
                "domain": state.domain,
                "name": attrs.get("friendly_name"),
                "device_class": (entry.device_class or entry.original_device_class if entry else None)
                or attrs.get("device_class"),
                "state_class": attrs.get("state_class"),
                "platform": entry.platform if entry else None,
                "unique_id": entry.unique_id if entry else None,
                "state": state.state,
            })
            if role is None:
                continue
            area_id = entry.area_id if entry else None
            if entry is not None and not area_id and entry.device_id:
                area_id = compat.effective_area_id(self.hass, dev_reg.async_get(entry.device_id))
            out.setdefault(role, []).append({
                "entity_id": state.entity_id,
                "name": str(attrs.get("friendly_name") or state.entity_id),
                "area_id": area_id,
                "device_class": attrs.get("device_class"),
            })
        return out

    @callback
    def _linked(self, devices: list[dict[str, Any]]) -> dict[str, bool]:
        stored = self.store.recommendations
        out: dict[str, bool] = {}
        for item in rules.build_recommendations(
            devices, person_entities(self.hass), self.store.settings, stored
        ):
            saved = stored.get(item["id"]) or {}
            out[item["id"]] = bool(item["enabled"] and saved.get("automation_ids"))
        return out

    @callback
    def detected(self) -> list[dict[str, Any]]:
        flows = self.hass.config_entries.flow.async_progress()
        domains = {
            entry.domain
            for entry in self.hass.config_entries.async_entries()
            if entry.source != "ignore" and entry.disabled_by is None
        }
        return irules.detected_items(list(flows), domains, self.ideas)

    @callback
    def context(self, devices: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        assert self.store is not None
        devices = [dict(d) for d in (devices if devices is not None else list_devices(self.hass, self.store))]
        for device in devices:
            device["classes"] = self._device_classes(device)
        settings = self.store.settings
        notify = str(settings.get("notify_service") or "")
        domain, _, service = notify.partition(".")
        rooms = list(self.store.rooms) + [
            {"area_id": a.id, "name": a.name} for a in ar.async_get(self.hass).async_list_areas()
        ]
        return irules.build_context(
            devices,
            weather=[
                {"entity_id": s.entity_id, "name": str(s.attributes.get("friendly_name") or "Météo")}
                for s in sorted(self.hass.states.async_all("weather"), key=lambda s: s.entity_id)
            ],
            phones=self._phones(),
            media=self._extra_media(devices),
            tts_entity=self._tts_entity(),
            settings=settings,
            notify_ok=bool(service) and self.hass.services.has_service(domain, service),
            linked=self._linked(devices),
            detected={item["domain"]: item for item in self.detected()},
            rooms=rooms,
            modules=self._modules_state(),
            entities=self._entities(),
        )

    def _module(self, idea: dict[str, Any]) -> Any:
        """The Maison Facile module that runs a ``module:`` idea (None if not started)."""
        if idea.get("module") in irules.MODULES:
            return getattr(self.data, str(idea["module"]), None)
        return None

    @callback
    def _modules_state(self) -> dict[str, dict[str, Any]]:
        out: dict[str, dict[str, Any]] = {}
        for name in irules.MODULES:  # data.birthdays (birthdays.py), data.energy_report (energy_report.py)
            module = getattr(self.data, name, None)
            if module is not None:
                out[name] = module.module_state()
        return out

    @callback
    def evaluations(self, ctx: dict[str, Any]) -> list[dict[str, Any]]:
        stored = self.stored
        return [irules.evaluate(idea, ctx, stored.get(idea["id"])) for idea in self.ideas]

    # ------------------------------------------------------------------ views

    @callback
    def list_payload(self) -> dict[str, Any]:
        ctx = self.context()
        evs = self.evaluations(ctx)
        seen = self.seen
        items = [irules.list_item(ev, seen) for ev in evs]
        new_ids = {i["id"] for i in items if i["new"]}
        detected = []
        for item in ctx["detected"].values():
            detected.append({**item, "new": bool(new_ids & set(item["ideas"]))})
        detected.sort(key=lambda i: (i["added"], i["domain"]))
        return {"items": items, "detected": detected, "unseen": len(new_ids)}

    @callback
    def detail_payload(self, idea_id: str) -> dict[str, Any]:
        idea = self.idea(idea_id)
        ctx = self.context()
        ev = irules.evaluate(idea, ctx, self.stored.get(idea_id))
        out = irules.detail(ev, ctx, {i["id"]: i for i in self.ideas})
        # « Quoi acheter ? » of each need (page « Bien choisir ses appareils »).
        needs = {n["key"]: n for n in idea["needs"]}
        for view in out.get("needs", []):
            need = needs.get(view.get("key"), {})
            view["guide"] = bguide.guide_id_for_need(need.get("roles", ()), need.get("add_type"), self.guide)
        return out

    @callback
    def summary(self, devices: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        """For state/get: home tiles of the active ideas + number of unseen ideas."""
        ctx = self.context(devices)
        evs = self.evaluations(ctx)
        seen = self.seen
        tiles = irules.tiles(evs, ctx)
        birthdays = getattr(self.data, "birthdays", None)
        if birthdays is not None and any(i.get("module") == "birthdays" for i in self.ideas):
            tiles += birthdays.tiles()  # « C'est l'anniversaire de Mamie aujourd'hui »
        return {
            "idea_tiles": tiles,
            "ideas_unseen": sum(1 for ev in evs if irules.is_new(ev, seen)),
        }

    # ------------------------------------------------------------------ actions

    async def _async_save_ideas(self, stored: dict[str, Any]) -> None:
        await self.store.async_set(STORE_IDEAS, stored)

    async def async_activate(
        self,
        idea_id: str,
        options: dict[str, Any] | None = None,
        devices: dict[str, list[str]] | None = None,
    ) -> dict[str, Any]:
        """Activate now when everything is there, otherwise remember it as pending."""
        idea = self.idea(idea_id)
        if idea.get("module"):
            # Run by a module (« Anniversaires »): activating = turning its reminders on.
            if (module := self._module(idea)) is None:
                raise IdeaError("not_ready", "Cette idée n'est pas encore prête. Réessayez dans quelques secondes.")
            await module.async_set_enabled(True)
            return self.detail_payload(idea_id)
        await self._async_check_writable(idea)
        async with self._lock:
            stored = {k: dict(v) for k, v in self.stored.items()}
            entry = stored.get(idea_id, {})
            entry["options"] = irules.resolve_options(idea, {**entry.get("options", {}), **(options or {})})
            if devices is not None:
                known = {n["key"] for n in idea["needs"]}
                clean = {k: [str(e) for e in v] for k, v in devices.items() if k in known and isinstance(v, list)}
                entry["devices"] = {**entry.get("devices", {}), **clean}
            if entry.get("status") != "active":
                entry["status"] = "pending"
                entry["since"] = dt_util.utcnow().isoformat()
            entry.setdefault("automation_ids", [])
            stored[idea_id] = entry
            await self._async_save_ideas(stored)
            await self._async_refresh_locked(quiet={idea_id})
        return self.detail_payload(idea_id)

    async def _async_check_writable(self, idea: dict[str, Any]) -> None:
        """Mode Expert : automations.yaml commenté et pas de fichier à part -> on refuse."""
        if not (idea.get("blueprint") or idea.get("recommendation")) or self.data.automations is None:
            return
        from .automations import ProtectedFileError  # noqa: PLC0415

        try:
            await self.data.automations.async_check_writable()
        except ProtectedFileError as err:
            raise IdeaError("protected", err.message_fr) from err

    async def async_preview(
        self,
        idea_id: str,
        options: dict[str, Any] | None = None,
        devices: dict[str, list[str]] | None = None,
    ) -> dict[str, Any]:
        """Ce que « Activer » va changer, sans rien changer (mode Expert)."""
        from . import expert_rules as xr  # noqa: PLC0415

        idea = self.idea(idea_id)
        entry = dict(self.stored.get(idea_id, {}))
        entry["options"] = irules.resolve_options(idea, {**entry.get("options", {}), **(options or {})})
        if devices is not None:
            known = {n["key"] for n in idea["needs"]}
            entry["devices"] = {
                **entry.get("devices", {}),
                **{k: [str(e) for e in v] for k, v in devices.items() if k in known and isinstance(v, list)},
            }
        ctx = self.context()
        ev = irules.evaluate(idea, ctx, entry)
        instance = irules.build_instance(idea, ev["resolved"], entry.get("options") or {}, ctx)
        planned = [{"id": instance["automation_id"], "alias": instance["alias"]}] if instance else []
        entities = {c["entity_id"] for r in ev["resolved"] for c in r.get("chosen", [])}
        target = {"file": "automations.yaml", "blocked": False}
        conflicts: list[dict[str, Any]] = []
        if self.data.automations is not None and (idea.get("blueprint") or idea.get("recommendation")):
            target = await self.data.automations.async_target_info()
            conflicts = xr.find_conflicts(await self.data.automations.async_user_automations(), entities)
        ready = not [r for r in ev["resolved"] if not r["have"] and not r["need"]["optional"]]
        return xr.preview(planned, target["file"], conflicts, bool(target["blocked"]), ready)

    async def async_configure(
        self,
        idea_id: str,
        options: dict[str, Any] | None = None,
        devices: dict[str, list[str]] | None = None,
    ) -> dict[str, Any]:
        """Save the client's settings / device choices (an active idea is re-synced)."""
        idea = self.idea(idea_id)
        async with self._lock:
            stored = {k: dict(v) for k, v in self.stored.items()}
            entry = stored.get(idea_id, {"status": "off", "automation_ids": []})
            if options:
                entry["options"] = irules.resolve_options(idea, {**entry.get("options", {}), **options})
            if devices is not None:
                known = {n["key"] for n in idea["needs"]}
                clean = {k: [str(e) for e in v] for k, v in devices.items() if k in known and isinstance(v, list)}
                entry["devices"] = {**entry.get("devices", {}), **clean}
            stored[idea_id] = entry
            await self._async_save_ideas(stored)
            if entry.get("status") in ("active", "pending"):
                await self._async_refresh_locked(quiet={idea_id})
        if idea.get("recommendation") and options and self._linked(list_devices(self.hass, self.store)).get(idea["recommendation"]):
            await self._async_apply_recommendation(idea, self.stored.get(idea_id, {}), enabled=True)
        return self.detail_payload(idea_id)

    async def async_expect(self, idea_id: str) -> dict[str, Any]:
        """The client goes to « Ajouter le capteur » from this idea: the next device that
        fits a missing need is given to it (and renamed), without activating the idea."""
        self.idea(idea_id)
        async with self._lock:
            stored = {k: dict(v) for k, v in self.stored.items()}
            entry = stored.get(idea_id, {})
            if entry.get("status") not in ("active", "pending"):
                entry["status"] = "expect"
                entry["since"] = dt_util.utcnow().isoformat()
                entry.setdefault("automation_ids", [])
                stored[idea_id] = entry
                await self._async_save_ideas(stored)
        return self.detail_payload(idea_id)

    async def async_deactivate(self, idea_id: str) -> dict[str, Any]:
        idea = self.idea(idea_id)
        if idea.get("module"):
            if (module := self._module(idea)) is not None:
                await module.async_set_enabled(False)  # the dates are kept
            return self.detail_payload(idea_id)
        async with self._lock:
            stored = {k: dict(v) for k, v in self.stored.items()}
            entry = stored.pop(idea_id, None) or {}
            if idea.get("recommendation"):
                await self._async_apply_recommendation(idea, entry, enabled=False)
            if idea.get("applies_setting"):
                await self.store.async_update_settings({idea["applies_setting"]["key"]: ""})
            if entry.get("automation_ids") and self.data.automations is not None:
                await self.data.automations.async_sync(
                    {irules.plan_key(idea_id): []}, {irules.plan_key(idea_id): entry["automation_ids"]}
                )
            # Keep the user's choices for a later activation.
            if entry.get("options") or entry.get("devices"):
                stored[idea_id] = {
                    "status": "off",
                    "options": entry.get("options", {}),
                    "devices": entry.get("devices", {}),
                    "automation_ids": [],
                }
            await self._async_save_ideas(stored)
            if idea.get("applies_setting"):
                await self._async_refresh_locked()
        return self.detail_payload(idea_id)

    async def async_mark_seen(self, ids: list[str] | None = None) -> int:
        ctx = self.context()
        seen = set(self.seen)
        for ev in self.evaluations(ctx):
            if (ids is None or ev["idea"]["id"] in ids) and irules.is_new(ev, seen):
                seen.add(irules.seen_key(ev["idea"]["id"], ev["status"]))
        await self.store.async_set(STORE_SEEN, sorted(seen)[-500:])
        return self.summary()["ideas_unseen"]

    async def _async_apply_recommendation(self, idea: dict[str, Any], entry: dict[str, Any], enabled: bool) -> None:
        from .websocket_api import async_apply_recommendations

        options = irules.resolve_options(idea, entry.get("options"))
        reco_options = {"brightness": options["brightness"]} if "brightness" in options else {}
        await async_apply_recommendations(
            self.hass, self.data, [{"id": idea["recommendation"], "enabled": enabled, "options": reco_options}]
        )

    async def async_refresh(self) -> None:
        async with self._lock:
            await self._async_refresh_locked()

    async def _async_refresh_locked(self, quiet: set[str] | None = None) -> None:
        """Re-sync active ideas (devices / settings changed) and activate ready pending ones.

        One write of automations.yaml (and one reload) at most. ``quiet`` = ideas the
        client is activating right now (no « maintenant active » notification).
        """
        quiet = quiet or set()
        ctx = self.context()
        stored = {k: dict(v) for k, v in self.stored.items()}
        known = {i["id"] for i in self.ideas}
        plan: dict[str, list[dict[str, Any]]] = {}
        previous: dict[str, list[str]] = {}
        hashes: dict[str, str] = {}
        activated: list[dict[str, Any]] = []
        changed = False

        # Ideas whose file was removed: remove their automations.
        for idea_id, entry in stored.items():
            if idea_id not in known and entry.get("automation_ids"):
                plan[irules.plan_key(idea_id)] = []
                previous[irules.plan_key(idea_id)] = list(entry["automation_ids"])
                entry["automation_ids"] = []
                changed = True

        # 1) pending -> active when every required device is there; settings / recommendations.
        setting_changed = False
        for idea in self.ideas:
            entry = stored.get(idea["id"])
            if not entry or entry.get("status") not in ("active", "pending"):
                continue
            ev = irules.evaluate(idea, ctx, entry)
            ready = not [r for r in ev["resolved"] if not r["have"] and not r["need"]["optional"]]
            if entry["status"] == "pending":
                if not ready:
                    continue
                entry["status"] = "active"
                entry["activated_at"] = dt_util.utcnow().isoformat()
                changed = True
                if idea["id"] not in quiet:
                    activated.append(idea)
                if idea.get("recommendation"):
                    await self._async_apply_recommendation(idea, entry, enabled=True)
            if idea.get("applies_setting"):
                setting = irules.setting_value(idea, ev["resolved"])
                if setting and setting[1] and self.store.settings.get(setting[0]) != setting[1]:
                    await self.store.async_update_settings({setting[0]: setting[1]})
                    setting_changed = True
        if setting_changed:
            ctx = self.context()  # e.g. the new speaker changes the inputs of the other ideas

        # 2) automations of the active blueprint ideas, rewritten only when their inputs changed.
        for idea in self.ideas:
            entry = stored.get(idea["id"]) or {}
            if entry.get("status") != "active" or not idea.get("blueprint") or idea.get("recommendation"):
                continue
            ev = irules.evaluate(idea, ctx, entry)
            instance = irules.build_instance(idea, ev["resolved"], entry.get("options") or {}, ctx)
            if instance is None:
                continue  # a device vanished: keep the automation as it is
            digest = f"{instance['automation_id']}:{irules.inputs_hash(instance['inputs'])}"
            if digest == entry.get("inputs_hash") and entry.get("automation_ids") == [instance["automation_id"]]:
                continue
            key = irules.plan_key(idea["id"])
            plan[key] = [instance]
            previous[key] = list(entry.get("automation_ids") or [])
            hashes[idea["id"]] = digest

        if plan and self.data.automations is not None:
            created = await self.data.automations.async_sync(plan, previous)
            for key, ids in created.items():
                idea_id = key.removeprefix(irules.PLAN_PREFIX)
                if idea_id in stored:
                    stored[idea_id]["automation_ids"] = ids
                    if idea_id in hashes:
                        stored[idea_id]["inputs_hash"] = hashes[idea_id]
            changed = True
        if changed:
            await self._async_save_ideas(stored)
        for idea in activated:
            self._notify_activated(idea)

    @callback
    def _notify_activated(self, idea: dict[str, Any]) -> None:
        _LOGGER.info("Idea %s activated automatically", idea["id"])
        self.hass.async_create_task(
            self.hass.services.async_call(
                "persistent_notification",
                "create",
                {
                    "notification_id": f"mf_idea_active_{idea['id']}",
                    "title": "Nouvelle idée en place",
                    "message": f"L'idée « {idea['title']} » est maintenant active : l'appareil qui manquait est arrivé.",
                },
            ),
            f"{DOMAIN}_idea_notify",
        )

    # ------------------------------------------------------------------ new devices

    @callback
    def _on_device_found(self, event: Event) -> None:
        device = event.data.get("device")
        if not isinstance(device, dict):
            return
        self.entry.async_create_background_task(
            self.hass, self._async_device_found(device), f"{DOMAIN}_ideas_device_found"
        )

    async def _async_device_found(self, device: dict[str, Any]) -> None:
        try:
            async with self._lock:
                ctx = self.context()
                stored = {k: dict(v) for k, v in self.stored.items()}
                assignments = irules.assign_new_device(self.ideas, stored, device, ctx)
                dev_reg = dr.async_get(self.hass)
                for idea_id, need_key, entity_id in assignments:
                    entry = stored[idea_id]
                    entry["devices"] = {**entry.get("devices", {}), need_key: [entity_id]}
                    need = next(n for n in self.idea(idea_id)["needs"] if n["key"] == need_key)
                    registered = compat.get_main_device(dev_reg, str(device.get("device_id") or ""))
                    # Mode Expert : aucun appareil n'est renommé sans accord.
                    if (
                        need.get("rename_fr")
                        and registered is not None
                        and not registered.name_by_user
                        and self.store.settings.get("expert_mode") is not True
                    ):
                        dev_reg.async_update_device(registered.id, name_by_user=need["rename_fr"])
                    _LOGGER.info("New device %s given to idea %s (%s)", device.get("device_id"), idea_id, need_key)
                if assignments:
                    await self._async_save_ideas(stored)
                await self._async_refresh_locked()
        except Exception:
            _LOGGER.exception("Ideas: could not handle a new device")

    # ------------------------------------------------------------------ discovery

    async def async_add_detected(self, flow_id: str | None, domain: str | None) -> dict[str, Any]:
        """Finish a discovery flow with the generic driver of provision.py."""
        from .provision import async_drive_flow

        manager = self.hass.config_entries.flow
        flow = None
        for item in manager.async_progress():
            source = (item.get("context") or {}).get("source")
            if source not in irules.DISCOVERY_SOURCES:
                continue
            if (flow_id and item["flow_id"] == flow_id) or (not flow_id and domain and item["handler"] == domain):
                flow = item
                break
        if flow is None:
            raise IdeaError("not_found", "Cet appareil n'est plus proposé par la box. Vérifiez qu'il est allumé.")
        handler = str(flow["handler"])
        try:
            current = await manager.async_configure(flow["flow_id"])
            async with asyncio.timeout(ADD_FLOW_TIMEOUT):
                outcome = await async_drive_flow(self.hass, current)
            kind, reason = outcome.kind, outcome.reason
        except UnknownFlow:
            kind, reason = "gone", "flow_removed"
        except TimeoutError:
            kind, reason = "stuck", "timeout"
        _LOGGER.info("Discovered %s (%s): %s %s", handler, flow["flow_id"], kind, reason)
        state, message = irules.add_outcome_message(handler, kind, reason)
        if state == "created":
            self.async_schedule_refresh()
        return {"ok": state == "created", "state": state, "message_fr": message, "domain": handler}

    # ------------------------------------------------------------------ announcements

    async def async_test_announce(self, entity_id: str | None = None) -> dict[str, Any]:
        player = entity_id or str(self.store.settings.get("announce_media_player") or "")
        if not player:
            raise IdeaError("invalid_format", "Choisissez d'abord une enceinte.")
        if self.hass.states.get(player) is None:
            raise IdeaError("not_found", "Cette enceinte ne répond pas. Vérifiez qu'elle est allumée.")
        voice = self._tts_entity()
        if not voice or not self.hass.services.has_service("tts", "speak"):
            raise IdeaError(
                "failed",
                "Aucune voix de synthèse n'est installée sur la box : demandez à votre installateur.",
            )
        try:
            await self.hass.services.async_call(
                "tts",
                "speak",
                {
                    "entity_id": voice,
                    "media_player_entity_id": player,
                    "message": "Bonjour ! Les annonces de Maison Facile arriveront sur cette enceinte.",
                },
                blocking=True,
            )
        except Exception as err:
            _LOGGER.warning("Test announcement failed: %s", err)
            raise IdeaError("failed", "L'enceinte n'a pas pu parler. Vérifiez qu'elle est allumée, puis réessayez.") from err
        return {"ok": True, "message_fr": "Vous avez entendu « Bonjour » ? Les annonces sont prêtes."}


async def async_setup_ideas(hass: HomeAssistant, entry: ConfigEntry, data: MaisonFacileData) -> IdeasManager:
    manager = IdeasManager(hass, entry, data)
    await manager.async_setup()
    return manager
