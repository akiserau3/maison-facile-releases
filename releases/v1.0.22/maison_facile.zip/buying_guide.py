"""« Bien choisir ses appareils » : buying guide and « Où l'acheter ? » link (pure logic).

No ``homeassistant`` import: tested in ``tests/test_buying_guide.py`` (NOTES_guide.md).

- ``buying_guide.yaml`` describes, for each kind of device the ideas need, what to look for,
  a price range and the trap to avoid. It is linked to the ideas' ``needs`` by role / add_type
  (``guide_id_for_need``). It never contains a link, a shop or an affiliate code.
- ``shop_url`` (setting, kit key, options flow) is an optional https address chosen by the
  installer or the community. Empty = the « Où l'acheter ? » button is hidden. It may contain
  ``{need}``, replaced by the guide id (``ouverture``, ``prise``…).
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlsplit

import yaml

GUIDE_FILE = Path(__file__).parent / "buying_guide.yaml"
GUIDE_SCHEMA = 1

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,40}$")
COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
PROTOCOLS: dict[str, str] = {
    "zigbee": "Zigbee de préférence",
    "zigbee_local": "Zigbee, ou Wi-Fi sans appli",
    "network": "Relié par le réseau de la maison",
}
# Roles of needs that are not a device to buy (an app, a service, data already on the box).
# person_detect / face : capteurs créés par Frigate (Réglages > IA), rien à acheter.
NO_PURCHASE_ROLES = frozenset({"phone", "weather", "person", "tempo", "birthday", "weather_alert", "person_detect", "face"})
# Cloud integrations: devices that depend on the maker's app and servers (add-device warning).
CLOUD_INTEGRATIONS: dict[str, str] = {
    "tuya": "Tuya / Smart Life",
    "sonoff": "eWeLink (Sonoff)",
}
# Never a link in the guide texts (no shop, no affiliate code: see NOTES_guide.md).
_LINK_RE = re.compile(r"https?:|www\.|\.(com|fr|net|org|io|shop)\b", re.IGNORECASE)

ITEM_KEYS = {
    "id", "title", "icon", "color", "roles", "add_types", "protocol", "what", "look_for",
    "price", "price_note", "trap",
}

STARTER_KEYS = {"title", "intro", "items"}
STARTER_MAX = 6

SHOP_URL_MAX = 500
SHOP_PLACEHOLDER = "{need}"
_HOST_RE = re.compile(r"^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$")
_BAD_URL_CHARS = set(" \"'<>\\^`|")


# --------------------------------------------------------------------------- guide file


def _text(raw: Mapping[str, Any], key: str, where: str, errors: list[str], required: bool = True) -> str | None:
    value = raw.get(key)
    if value is None and not required:
        return None
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{where}: '{key}' doit être un texte non vide")
        return None
    if _LINK_RE.search(value):
        errors.append(f"{where}: '{key}' ne doit contenir aucun lien ni adresse de site")
    return value.strip()


def validate_item(raw: Any, index: int, errors: list[str]) -> dict[str, Any] | None:
    """One entry of ``items`` (French errors, like ideas_rules)."""
    where = f"items[{index}]"
    if not isinstance(raw, dict):
        errors.append(f"{where}: doit être un objet")
        return None
    for key in sorted(set(raw) - ITEM_KEYS):
        errors.append(f"{where}: champ inconnu '{key}'")
    item_id = raw.get("id")
    if not isinstance(item_id, str) or not ID_RE.match(item_id):
        errors.append(f"{where}: 'id' invalide (minuscules, chiffres, _)")
        item_id = None
    where = f"items[{item_id or index}]"
    item: dict[str, Any] = {"id": item_id}
    for key in ("title", "icon", "what", "trap"):
        item[key] = _text(raw, key, where, errors)
    item["price_note"] = _text(raw, "price_note", where, errors, required=False)
    color = raw.get("color")
    if not isinstance(color, str) or not COLOR_RE.match(color):
        errors.append(f"{where}: 'color' doit ressembler à #0067C0")
    item["color"] = color
    protocol = raw.get("protocol")
    if protocol not in PROTOCOLS:
        errors.append(f"{where}: 'protocol' doit être parmi {', '.join(PROTOCOLS)}")
    item["protocol"] = protocol
    item["protocol_fr"] = PROTOCOLS.get(protocol, "")
    for key in ("roles", "add_types", "look_for"):
        value = raw.get(key, [])
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list) or any(not isinstance(v, str) or not v.strip() for v in value):
            errors.append(f"{where}: '{key}' doit être une liste de textes")
            value = []
        item[key] = [v.strip() for v in value]
    if not item["roles"] and not item["add_types"]:
        errors.append(f"{where}: au moins un rôle ('roles') ou un type ('add_types') est nécessaire")
    if not 1 <= len(item["look_for"]) <= 5:
        errors.append(f"{where}: 'look_for' doit avoir 1 à 5 conseils")
    for tip in item["look_for"]:
        if _LINK_RE.search(tip):
            errors.append(f"{where}: 'look_for' ne doit contenir aucun lien ni adresse de site")
    price = raw.get("price")
    if price is None:
        item["price"] = None
        if not item["price_note"]:
            errors.append(f"{where}: sans 'price', 'price_note' est nécessaire")
    elif (
        isinstance(price, dict)
        and set(price) == {"min", "max"}
        and all(isinstance(price[k], int) and not isinstance(price[k], bool) for k in ("min", "max"))
        and 0 < price["min"] <= price["max"] <= 2000
    ):
        item["price"] = {"min": price["min"], "max": price["max"]}
    else:
        errors.append(f"{where}: 'price' doit être {{min, max}} en euros entiers (0 < min <= max)")
        item["price"] = None
    return item


def parse_guide(raw: Any) -> tuple[list[dict[str, Any]], list[str]]:
    """Validate the decoded YAML. Returns ``(items, errors)``; invalid items are dropped."""
    errors: list[str] = []
    if not isinstance(raw, dict) or raw.get("schema") != GUIDE_SCHEMA or not isinstance(raw.get("items"), list):
        return [], [f"le fichier doit contenir 'schema: {GUIDE_SCHEMA}' et une liste 'items'"]
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, entry in enumerate(raw["items"]):
        item_errors: list[str] = []
        item = validate_item(entry, index, item_errors)
        if item and item["id"] in seen:
            item_errors.append(f"items[{item['id']}]: 'id' en double")
        errors.extend(item_errors)
        if item and not item_errors:
            seen.add(item["id"])
            items.append(item)
    return items, errors


def load_guide(path: Path = GUIDE_FILE) -> tuple[list[dict[str, Any]], list[str]]:
    """Read and validate ``buying_guide.yaml`` (blocking I/O: run in the executor)."""
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as err:
        return [], [f"fichier illisible : {err}"]
    return parse_guide(raw)


# --------------------------------------------------------------------------- « Pour commencer »


def parse_starter(raw: Any, items: Iterable[Mapping[str, Any]]) -> tuple[dict[str, Any] | None, list[str]]:
    """``starter`` of the guide file: the antenna and 2 or 3 essential sensors (discovery mode).

    Returns ``({title, intro, items: [id], budget: {min, max} | None}, errors)``; ``None`` if
    absent or invalid. The budget is the sum of the prices of the entries (euros).
    """
    if raw is None:
        return None, []
    errors: list[str] = []
    if not isinstance(raw, dict):
        return None, ["starter: doit être un objet"]
    for key in sorted(set(raw) - STARTER_KEYS):
        errors.append(f"starter: champ inconnu '{key}'")
    title = _text(raw, "title", "starter", errors)
    intro = _text(raw, "intro", "starter", errors)
    by_id = {str(i["id"]): i for i in items}
    ids = raw.get("items")
    if not isinstance(ids, list) or not 1 <= len(ids) <= STARTER_MAX or any(not isinstance(x, str) for x in ids):
        errors.append(f"starter: 'items' doit être une liste de 1 à {STARTER_MAX} identifiants du guide")
        ids = []
    for gid in ids:
        if gid not in by_id:
            errors.append(f"starter: '{gid}' n'est pas une entrée du guide")
    if errors:
        return None, errors
    prices = [by_id[g].get("price") for g in ids]
    budget = None
    if prices and all(prices):
        budget = {"min": sum(p["min"] for p in prices), "max": sum(p["max"] for p in prices)}
    return {"title": title, "intro": intro, "items": list(ids), "budget": budget}, []


def load_starter(path: Path, items: Iterable[Mapping[str, Any]]) -> tuple[dict[str, Any] | None, list[str]]:
    """Read the ``starter`` part of ``buying_guide.yaml`` (blocking I/O: run in the executor)."""
    try:
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as err:
        return None, [f"fichier illisible : {err}"]
    return parse_starter(raw.get("starter") if isinstance(raw, dict) else None, items)


# --------------------------------------------------------------------------- link to the ideas


def guide_id_for_need(
    roles: Iterable[str], add_type: str | None, items: Iterable[Mapping[str, Any]]
) -> str | None:
    """Guide entry of an idea need: its ``add_type`` first, else its first role that matches."""
    items = list(items)
    if add_type:
        for item in items:
            if add_type in item.get("add_types", ()):
                return str(item["id"])
    for role in roles:
        if role in NO_PURCHASE_ROLES:
            continue
        for item in items:
            if role in item.get("roles", ()):
                return str(item["id"])
    return None


def is_purchase_need(roles: Iterable[str]) -> bool:
    """False for a need met without buying anything (phone app, weather, a person…)."""
    return any(role not in NO_PURCHASE_ROLES for role in roles)


def ideas_by_guide(
    ideas: Iterable[Mapping[str, Any]], items: Iterable[Mapping[str, Any]]
) -> dict[str, list[dict[str, str]]]:
    """``{guide_id: [{id, title}]}``: the ideas that need each kind of device."""
    items = list(items)
    out: dict[str, list[dict[str, str]]] = {str(i["id"]): [] for i in items}
    for idea in ideas:
        for need in idea.get("needs", ()):
            gid = guide_id_for_need(need.get("roles", ()), need.get("add_type"), items)
            if gid and not any(x["id"] == idea["id"] for x in out[gid]):
                out[gid].append({"id": str(idea["id"]), "title": str(idea["title"])})
    return out


def guide_payload(
    items: Iterable[Mapping[str, Any]],
    ideas: Iterable[Mapping[str, Any]],
    shop_url: str,
    starter: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """``guide/get`` answer (no link inside the items: the page builds it from ``shop_url``)."""
    items = list(items)
    used = ideas_by_guide(ideas, items)
    url = validate_shop_url(shop_url)
    return {
        "items": [{**dict(i), "ideas": used.get(str(i["id"]), [])} for i in items],
        "shop_url": url or "",
        "starter": dict(starter) if starter else None,  # « Pour commencer » (discovery mode)
    }


# --------------------------------------------------------------------------- « Où l'acheter ? »


def validate_shop_url(value: Any) -> str | None:
    """Cleaned address, ``""`` (no button), or ``None`` if refused.

    https only, a real host name, no user name / password, no space or quote, at most
    500 characters; the only allowed placeholder is ``{need}`` (never in the host name).
    """
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return ""
    if len(text) > SHOP_URL_MAX or not text.isascii() or not text.isprintable():
        return None
    if any(c in _BAD_URL_CHARS for c in text):
        return None
    if "{" in text.replace(SHOP_PLACEHOLDER, "") or "}" in text.replace(SHOP_PLACEHOLDER, ""):
        return None
    if not text.startswith("https://"):
        return None
    try:
        parts = urlsplit(text.replace(SHOP_PLACEHOLDER, "need"))
        port = parts.port  # raises ValueError if not a number
    except ValueError:
        return None
    del port
    if parts.scheme != "https" or "@" in parts.netloc or not parts.hostname:
        return None
    if SHOP_PLACEHOLDER in urlsplit(text).netloc:
        return None
    if not _HOST_RE.match(parts.hostname):
        return None
    return text


def shop_link(template: str, guide_id: str) -> str | None:
    """Address opened by « Où l'acheter ? » for one kind of device (``None`` = no button)."""
    url = validate_shop_url(template)
    if not url:
        return None
    return url.replace(SHOP_PLACEHOLDER, quote(str(guide_id), safe=""))


# --------------------------------------------------------------------------- cloud devices


def cloud_summary(counts: Mapping[str, int]) -> list[dict[str, Any]]:
    """``{domain: device count}`` of the loaded cloud integrations → ``state/get.cloud``."""
    out = []
    for domain, label in CLOUD_INTEGRATIONS.items():
        if domain in counts:
            out.append({"domain": domain, "label_fr": label, "devices": max(0, int(counts[domain]))})
    return out
