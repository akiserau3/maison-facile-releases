"""Recettes (recipes_rules.py) : les étapes qui touchent Home Assistant et le Supervisor.

Chaque étape est lancée par l'utilisateur (bouton « Continuer ») et se refait sans risque.
L'état de chaque étape est recalculé à partir de ce qui existe vraiment (application
installée, entrée MQTT, module présent…), plus un petit mémo dans le stockage de Maison
Facile. Commandes websocket : compte principal seulement.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from pathlib import Path
from typing import Any

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback
from homeassistant.data_entry_flow import FlowResultType, UnknownFlow
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.hassio import is_hassio

from . import apps_rules as ar
from . import qr
from . import recipes_rules as rr
from .backup_helper import async_create_backup
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)
STARTED_AT = time.time()  # chargement de Maison Facile ≈ démarrage de Home Assistant
DATA = f"{DOMAIN}_recipes"
MEMO_KEY = "recipes"
FRIGATE_WAIT = 180  # secondes pour que Frigate réponde après son démarrage
MQTT_WAIT = 120


def _rt(hass: HomeAssistant) -> dict[str, Any]:
    return hass.data.setdefault(DATA, {"running": None, "errors": {}, "lock": asyncio.Lock(), "tasks": set(), "tuya": {}})


def _entry(hass: HomeAssistant) -> Any | None:
    entries = hass.config_entries.async_entries(DOMAIN)
    return entries[0] if entries else None


def _store(hass: HomeAssistant) -> Any | None:
    entry = _entry(hass)
    return getattr(getattr(entry, "runtime_data", None), "store", None) if entry else None


def _memo(hass: HomeAssistant) -> dict[str, Any]:
    store = _store(hass)
    value = store.data.get(MEMO_KEY) if store else None
    return dict(value) if isinstance(value, dict) else {}


async def _save_memo(hass: HomeAssistant, **changes: Any) -> None:
    store = _store(hass)
    if store is None:
        return
    memo = {**_memo(hass), **changes}
    store.data[MEMO_KEY] = memo
    await store.async_save()


def _client(hass: HomeAssistant) -> Any:
    from homeassistant.components.hassio import get_supervisor_client  # noqa: PLC0415

    return get_supervisor_client(hass)


async def _addon(hass: HomeAssistant, slug: str) -> dict[str, Any]:
    """{installed, running, hostname, options}."""
    from aiohasupervisor import SupervisorError  # noqa: PLC0415

    client = _client(hass)
    try:
        store = await client.store.addon_info(slug)
        if not store.installed:
            return {"installed": False, "running": False}
        info = await client.addons.addon_info(slug)
    except SupervisorError:
        return {"installed": False, "running": False}
    state = str(getattr(info.state, "value", info.state))
    return {"installed": True, "running": state == "started", "hostname": info.hostname, "options": dict(info.options or {})}


def _module_file(hass: HomeAssistant) -> Path:
    return Path(hass.config.path("custom_components", "frigate", "manifest.json"))


# --------------------------------------------------------------------------- état


async def async_frigate_status(hass: HomeAssistant) -> dict[str, Any]:
    if not is_hassio(hass):
        return {"available": False, "message": rr.MSG["not_haos"], "steps": []}
    rt = _rt(hass)
    mosq, frig = await asyncio.gather(_addon(hass, rr.MOSQUITTO_SLUG), _addon(hass, rr.FRIGATE_SLUG))
    module = _module_file(hass)
    module_mtime = await hass.async_add_executor_job(lambda: module.stat().st_mtime if module.exists() else None)
    memo = _memo(hass)
    done = {
        "mosquitto": mosq["installed"] and mosq["running"],
        "mqtt": bool(hass.config_entries.async_entries("mqtt", include_ignore=False)),
        "frigate_app": frig["installed"],
        "frigate_config": bool(memo.get("frigate_config_at")) and frig["installed"],
        "frigate_module": module_mtime is not None,
        "restart": module_mtime is not None and module_mtime < STARTED_AT,
        "frigate_integration": bool(hass.config_entries.async_entries("frigate", include_ignore=False)),
    }
    steps = rr.steps_payload(rr.FRIGATE_STEPS, done, rt["running"], rt["errors"])
    return {
        "available": True,
        "message": "",
        "steps": steps,
        "complete": all(done.values()),
        "config": memo.get("frigate_config_text") or "",
        "cameras": memo.get("frigate_cameras") or [],
        "module_repo": rr.FRIGATE_MODULE,
    }


# --------------------------------------------------------------------------- étapes


async def _ensure_app(hass: HomeAssistant, slug: str, repository: str | None, *, start: bool) -> None:
    from aiohasupervisor.models import StoreAddRepository  # noqa: PLC0415

    client = _client(hass)
    if repository:
        known = {str(r.source).rstrip("/").lower() for r in await client.store.repositories_list()}
        if repository.lower() not in known:
            await client.store.add_repository(StoreAddRepository(repository=repository))
    info = await _addon(hass, slug)
    if not info["installed"]:
        await client.store.install_addon(slug)
    if start and not (await _addon(hass, slug))["running"]:
        await client.addons.start_addon(slug)


async def _backup_once(hass: HomeAssistant) -> None:
    """Une sauvegarde complète avant la première installation de la recette (par démarrage)."""
    rt = _rt(hass)
    if rt.get("backup_done"):
        return
    result = await async_create_backup(hass, _entry(hass))
    if not result.ok:
        raise _StepError(ar.MSG["backup_failed"])
    rt["backup_done"] = True


async def _step_mqtt(hass: HomeAssistant) -> None:
    from .provision import async_drive_flow  # noqa: PLC0415
    from .provision_rules import GENERIC_MENU_PREFERENCES  # noqa: PLC0415

    manager = hass.config_entries.flow
    loop = asyncio.get_running_loop()
    deadline = loop.time() + MQTT_WAIT
    tried: set[str] = set()
    while not hass.config_entries.async_entries("mqtt", include_ignore=False):
        flow = next((f for f in manager.async_progress_by_handler("mqtt") if f["flow_id"] not in tried), None)
        if flow is None:
            if loop.time() > deadline:
                raise _StepError(rr.MSG["mqtt_failed"])
            await asyncio.sleep(2)
            continue
        tried.add(flow["flow_id"])
        try:
            current = await manager.async_configure(flow["flow_id"])
        except UnknownFlow:
            continue
        await async_drive_flow(hass, current, GENERIC_MENU_PREFERENCES)


async def _stream_source(hass: HomeAssistant, entity_id: str) -> str | None:
    """Adresse du flux vidéo d'une caméra (module caméra de Home Assistant, chargé si caméras)."""
    from homeassistant.components.camera import async_get_stream_source  # noqa: PLC0415

    return await async_get_stream_source(hass, entity_id)


async def _cameras(hass: HomeAssistant) -> list[dict[str, str]]:
    """Caméras de Home Assistant avec un flux vidéo (hors caméras de Frigate lui-même)."""
    from homeassistant.helpers import entity_registry as er  # noqa: PLC0415

    if not hass.states.async_entity_ids("camera"):
        return []
    reg = er.async_get(hass)
    out: list[dict[str, str]] = []
    for state in hass.states.async_all("camera"):
        entry = reg.async_get(state.entity_id)
        if entry is not None and entry.platform == "frigate":
            continue
        with contextlib.suppress(Exception):
            url = await _stream_source(hass, state.entity_id)
            if rr.is_stream(url):
                title = str(state.attributes.get("friendly_name") or state.entity_id)
                out.append({"name": rr.camera_name(title, [c["name"] for c in out]), "title": title, "url": url})
    return out


RESTART_PAUSE = 5  # Frigate met quelques secondes à s'arrêter avant de redémarrer


async def _wait_frigate(hass: HomeAssistant, base: str) -> None:
    session = async_get_clientsession(hass)
    loop = asyncio.get_running_loop()
    deadline = loop.time() + FRIGATE_WAIT
    while True:
        with contextlib.suppress(Exception):
            async with session.get(f"{base}/api/version", timeout=10) as resp:
                if resp.status == 200:
                    return
        if loop.time() > deadline:
            raise _StepError(rr.MSG["frigate_unreachable"])
        await asyncio.sleep(3)


async def _step_frigate_config(hass: HomeAssistant) -> None:
    from aiohasupervisor.models import AddonsOptions  # noqa: PLC0415

    cameras = await _cameras(hass)
    if not cameras:
        raise _StepError(rr.MSG["no_cameras"])
    client = _client(hass)
    # Un compte MQTT propre à Frigate, ajouté aux comptes de Mosquitto (les autres sont gardés).
    mosq = await _addon(hass, rr.MOSQUITTO_SLUG)
    current = next(
        (x.get("password") for x in (mosq.get("options") or {}).get("logins") or [] if isinstance(x, dict) and x.get("username") == rr.MQTT_USER),
        None,
    )
    password = current or rr.new_password()
    options, changed = rr.mosquitto_logins(mosq.get("options") or {}, password)
    if changed:
        await client.addons.set_addon_options(rr.MOSQUITTO_SLUG, AddonsOptions(config=options))
        await client.addons.restart_addon(rr.MOSQUITTO_SLUG)
    frig = await _addon(hass, rr.FRIGATE_SLUG)
    if not frig["running"]:
        await client.addons.start_addon(rr.FRIGATE_SLUG)
        frig = await _addon(hass, rr.FRIGATE_SLUG)
    base = f"http://{frig.get('hostname') or 'ccab4aaf-frigate'}:5000"
    await _wait_frigate(hass, base)
    text = rr.frigate_config(cameras, password)
    session = async_get_clientsession(hass)
    async with session.post(
        f"{base}/api/config/save", params={"save_option": "restart"}, data=text.encode(),
        headers={"Content-Type": "text/plain"}, timeout=60,
    ) as resp:
        if resp.status != 200:
            detail = ""
            with contextlib.suppress(Exception):
                detail = str((await resp.json(content_type=None)).get("message") or "")
            raise _StepError(rr.MSG["frigate_rejected"].format(detail=detail[:400] or resp.status))
    # Pour « Voir la configuration » : le mot de passe n'est jamais montré ni gardé en clair.
    shown = text.replace(password, "••••••••")
    await _save_memo(
        hass,
        frigate_config_at=time.time(),
        frigate_config_text=shown,
        frigate_cameras=[{"name": c["name"], "title": c["title"]} for c in cameras],
    )


async def _step_frigate_integration(hass: HomeAssistant) -> None:
    if hass.config_entries.async_entries("frigate", include_ignore=False):
        return
    frig = await _addon(hass, rr.FRIGATE_SLUG)
    url = f"http://{frig.get('hostname') or 'ccab4aaf-frigate'}:5000"
    try:
        result = await hass.config_entries.flow.async_init("frigate", context={"source": "user"})
    except Exception as err:  # noqa: BLE001 - module pas chargé (pas redémarré)
        raise _StepError(rr.MSG["module_missing"]) from err
    if result.get("type") == FlowResultType.FORM:
        result = await hass.config_entries.flow.async_configure(result["flow_id"], {"url": url, "validate_ssl": False})
    if result.get("type") != FlowResultType.CREATE_ENTRY and result.get("reason") != "already_configured":
        if result.get("flow_id") and result.get("type") == FlowResultType.FORM:
            with contextlib.suppress(UnknownFlow):
                hass.config_entries.flow.async_abort(result["flow_id"])
        raise _StepError(rr.MSG["integration_failed"])


class _StepError(Exception):
    def __init__(self, message_fr: str) -> None:
        super().__init__(message_fr)
        self.message_fr = message_fr


async def _run_frigate_step(hass: HomeAssistant, step: str) -> None:
    rt = _rt(hass)
    async with rt["lock"]:
        rt["running"] = step
        rt["errors"].pop(step, None)
        try:
            if step == "mosquitto":
                await _backup_once(hass)
                await _ensure_app(hass, rr.MOSQUITTO_SLUG, None, start=True)
            elif step == "mqtt":
                await _step_mqtt(hass)
            elif step == "frigate_app":
                await _backup_once(hass)
                await _ensure_app(hass, rr.FRIGATE_SLUG, rr.FRIGATE_REPOSITORY, start=False)
            elif step == "frigate_config":
                await _step_frigate_config(hass)
            elif step == "frigate_integration":
                await _step_frigate_integration(hass)
        except _StepError as err:
            rt["errors"][step] = err.message_fr
        except Exception:  # noqa: BLE001 - l'erreur reste affichée sur l'étape
            _LOGGER.exception("Recipe frigate: step %s failed", step)
            rt["errors"][step] = "Cette étape n'a pas pu se faire. Réessayez ; si cela recommence, ouvrez Dépannage."
        finally:
            rt["running"] = None


# --------------------------------------------------------------------------- visages


async def _frigate_base(hass: HomeAssistant) -> str:
    frig = await _addon(hass, rr.FRIGATE_SLUG)
    return f"http://{frig.get('hostname') or 'ccab4aaf-frigate'}:5000"


async def _frigate_get(hass: HomeAssistant, base: str, path: str) -> Any:
    session = async_get_clientsession(hass)
    async with session.get(f"{base}{path}", timeout=15) as resp:
        resp.raise_for_status()
        if path == "/api/config/raw":
            return await resp.text()
        return await resp.json(content_type=None)


def _face_sensors(hass: HomeAssistant) -> list[dict[str, Any]]:
    from homeassistant.helpers import entity_registry as er  # noqa: PLC0415

    reg = er.async_get(hass)
    out = []
    for entry in reg.entities.values():
        if entry.platform == "frigate" and entry.domain == "sensor" and ":sensor_recognized_face:" in str(entry.unique_id):
            state = hass.states.get(entry.entity_id)
            out.append({
                "entity_id": entry.entity_id,
                "name": str((state and state.attributes.get("friendly_name")) or entry.entity_id),
                "state": state.state if state else "unknown",
            })
    return sorted(out, key=lambda x: x["entity_id"])


async def async_faces_status(hass: HomeAssistant) -> dict[str, Any]:
    if not is_hassio(hass):
        return {"available": False, "message": rr.MSG["not_haos"], "steps": []}
    rt = _rt(hass)
    memo = _memo(hass)
    ready = bool(hass.config_entries.async_entries("frigate", include_ignore=False))
    enabled = False
    faces: list[dict[str, Any]] = []
    reachable = False
    if ready:
        base = await _frigate_base(hass)
        with contextlib.suppress(Exception):
            enabled = rr.face_recognition_enabled(await _frigate_get(hass, base, "/api/config"))
            reachable = True
            faces = rr.known_faces(await _frigate_get(hass, base, "/api/faces"))
    sensors = _face_sensors(hass)
    seen = any(s["state"].lower() not in ("unknown", "unavailable", "none", "") for s in sensors)
    if seen and not memo.get("face_seen_at"):
        await _save_memo(hass, face_seen_at=time.time())
        memo = _memo(hass)
    idea = ((_store(hass).data.get("ideas") or {}).get("visage_bienvenue") or {}) if _store(hass) else {}
    done = {
        "consent": bool(memo.get("face_consent_at")),
        "enable": enabled,
        "photos": bool(faces),
        "test": bool(memo.get("face_seen_at")),
        "idea": idea.get("status") in ("active", "pending"),
    }
    return {
        "available": True,
        "message": "" if ready else "Installez d'abord les caméras intelligentes (ci-dessus).",
        "ready": ready,
        "reachable": reachable,
        "steps": rr.steps_payload(rr.FACE_STEPS, done, rt.get("face_running"), rt.get("face_errors") or {}),
        "consent_items": list(rr.FACE_CONSENT),
        "faces": faces,
        "sensors": sensors,
        "enabled": enabled,
    }


async def _run_face_toggle(hass: HomeAssistant, enabled: bool) -> None:
    rt = _rt(hass)
    errors = rt.setdefault("face_errors", {})
    step = "enable"
    async with rt["lock"]:
        rt["face_running"] = step
        errors.pop(step, None)
        try:
            base = await _frigate_base(hass)
            raw = await _frigate_get(hass, base, "/api/config/raw")
            text, changed = rr.face_recognition_set(str(raw), enabled)
            if changed:
                session = async_get_clientsession(hass)
                async with session.post(
                    f"{base}/api/config/save", params={"save_option": "restart"}, data=text.encode(),
                    headers={"Content-Type": "text/plain"}, timeout=60,
                ) as resp:
                    if resp.status != 200:
                        detail = ""
                        with contextlib.suppress(Exception):
                            detail = str((await resp.json(content_type=None)).get("message") or "")
                        raise _StepError(rr.MSG["frigate_rejected"].format(detail=detail[:400] or resp.status))
                await asyncio.sleep(RESTART_PAUSE)
                await _wait_frigate(hass, base)
            # Le module Frigate crée les capteurs « visage reconnu » à son démarrage : on le recharge.
            for entry in hass.config_entries.async_entries("frigate", include_ignore=False):
                with contextlib.suppress(Exception):
                    await hass.config_entries.async_reload(entry.entry_id)
        except _StepError as err:
            errors[step] = err.message_fr
        except Exception:  # noqa: BLE001
            _LOGGER.exception("Face recognition toggle failed")
            errors[step] = rr.MSG["frigate_unreachable"]
        finally:
            rt["face_running"] = None


# --------------------------------------------------------------------------- Tuya


async def async_tuya_start(hass: HomeAssistant, user_code: str) -> dict[str, Any]:
    """Code utilisateur Smart Life -> QR code à scanner (flux officiel de Home Assistant)."""
    if hass.config_entries.async_entries("tuya", include_ignore=False):
        return {"state": "done", "message": rr.MSG["tuya_already"]}
    rt = _rt(hass)
    old = rt["tuya"].get("flow_id")
    if old:
        with contextlib.suppress(UnknownFlow):
            hass.config_entries.flow.async_abort(old)
    result = await hass.config_entries.flow.async_init("tuya", context={"source": "user"})
    if result.get("type") == FlowResultType.ABORT:
        return {"state": "done" if result.get("reason") == "already_configured" else "error", "message": rr.MSG["tuya_already"] if result.get("reason") == "already_configured" else rr.MSG["tuya_code"]}
    result = await hass.config_entries.flow.async_configure(result["flow_id"], {"user_code": user_code.strip()})
    return _tuya_answer(hass, result, rr.MSG["tuya_code"])


async def async_tuya_check(hass: HomeAssistant) -> dict[str, Any]:
    """« C'est fait » : Tuya a-t-il validé le scan ?"""
    rt = _rt(hass)
    flow_id = rt["tuya"].get("flow_id")
    if hass.config_entries.async_entries("tuya", include_ignore=False):
        return {"state": "done", "message": rr.MSG["tuya_done"]}
    if not flow_id:
        return {"state": "code", "message": ""}
    try:
        result = await hass.config_entries.flow.async_configure(flow_id, {})
    except UnknownFlow:
        rt["tuya"] = {}
        return {"state": "code", "message": ""}
    return _tuya_answer(hass, result, rr.MSG["tuya_scan"])


def _qr_data(result: dict[str, Any]) -> str | None:
    schema = result.get("data_schema")
    for key, value in (getattr(schema, "schema", None) or {}).items():
        if str(key) == "QR":
            config = getattr(value, "config", None) or {}
            return str(config.get("data") or "") or None
    return None


def _tuya_answer(hass: HomeAssistant, result: dict[str, Any], error_message: str) -> dict[str, Any]:
    rt = _rt(hass)
    kind = result.get("type")
    if kind == FlowResultType.CREATE_ENTRY:
        rt["tuya"] = {}
        return {"state": "done", "message": rr.MSG["tuya_done"]}
    if kind == FlowResultType.FORM and result.get("step_id") == "scan":
        data = _qr_data(result)
        rt["tuya"] = {"flow_id": result["flow_id"]}
        return {
            "state": "scan",
            "qr_svg": qr.svg(data) if data else "",
            "message": error_message if result.get("errors") else "",
        }
    if kind == FlowResultType.FORM:
        rt["tuya"] = {"flow_id": result["flow_id"]}
        return {"state": "code", "message": error_message if result.get("errors") else ""}
    rt["tuya"] = {}
    return {"state": "error", "message": error_message}


# --------------------------------------------------------------------------- websocket


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/recipes/frigate"})
@websocket_api.async_response
async def ws_frigate_status(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    connection.send_result(msg["id"], await async_frigate_status(hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/recipes/frigate/run",
        vol.Required("step"): vol.In(["mosquitto", "mqtt", "frigate_app", "frigate_config", "frigate_integration"]),
    }
)
@callback
def ws_frigate_run(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if not is_hassio(hass):
        connection.send_error(msg["id"], "not_supported", rr.MSG["not_haos"])
        return
    rt = _rt(hass)
    if rt["lock"].locked():
        connection.send_error(msg["id"], "busy", rr.MSG["busy"])
        return
    rt["running"] = msg["step"]
    task = hass.async_create_background_task(_run_frigate_step(hass, msg["step"]), f"{DOMAIN}_recipe_{msg['step']}")
    rt["tasks"].add(task)
    task.add_done_callback(rt["tasks"].discard)
    connection.send_result(msg["id"], {"started": True})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/recipes/tuya/start", vol.Required("user_code"): vol.All(str, vol.Length(min=1, max=64))}
)
@websocket_api.async_response
async def ws_tuya_start(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    try:
        connection.send_result(msg["id"], await async_tuya_start(hass, msg["user_code"]))
    except Exception:  # noqa: BLE001
        _LOGGER.exception("Tuya guided setup failed")
        connection.send_result(msg["id"], {"state": "error", "message": rr.MSG["tuya_code"]})


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/recipes/tuya/check"})
@websocket_api.async_response
async def ws_tuya_check(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    try:
        connection.send_result(msg["id"], await async_tuya_check(hass))
    except Exception:  # noqa: BLE001
        _LOGGER.exception("Tuya guided setup check failed")
        connection.send_result(msg["id"], {"state": "error", "message": rr.MSG["tuya_scan"]})


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/recipes/faces"})
@websocket_api.async_response
async def ws_faces_status(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    connection.send_result(msg["id"], await async_faces_status(hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/recipes/faces/consent", vol.Required("accepted"): vol.All(list, vol.Length(min=1))}
)
@websocket_api.async_response
async def ws_faces_consent(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    """Accord : chaque phrase de FACE_CONSENT doit avoir été cochée."""
    if sorted(msg["accepted"]) != sorted(range(len(rr.FACE_CONSENT))):
        connection.send_error(msg["id"], "consent_required", "Cochez chaque point pour continuer.")
        return
    await _save_memo(hass, face_consent_at=time.time())
    connection.send_result(msg["id"], await async_faces_status(hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/recipes/faces/set", vol.Required("enabled"): bool}
)
@callback
def ws_faces_set(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    """Active (après l'accord) ou coupe la reconnaissance des visages dans Frigate."""
    rt = _rt(hass)
    if msg["enabled"] and not _memo(hass).get("face_consent_at"):
        connection.send_error(msg["id"], "consent_required", "Donnez d'abord votre accord.")
        return
    if rt["lock"].locked():
        connection.send_error(msg["id"], "busy", rr.MSG["busy"])
        return
    if not msg["enabled"]:
        hass.async_create_task(_save_memo(hass, face_consent_at=None, face_seen_at=None))
    rt["face_running"] = "enable"
    task = hass.async_create_background_task(_run_face_toggle(hass, msg["enabled"]), f"{DOMAIN}_faces")
    rt["tasks"].add(task)
    task.add_done_callback(rt["tasks"].discard)
    connection.send_result(msg["id"], {"started": True})


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in (ws_frigate_status, ws_frigate_run, ws_tuya_start, ws_tuya_check, ws_faces_status, ws_faces_consent, ws_faces_set):
        websocket_api.async_register_command(hass, command)

