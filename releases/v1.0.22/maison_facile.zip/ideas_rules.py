"""Pure logic of the "Idées" catalogue (one YAML file per idea in ``ideas/``).

This module must NOT import homeassistant: it is unit-tested on its own.

An idea = a ready-made automation (an embedded blueprint) + the devices it needs.
``ideas.py`` (Home Assistant side) gives this module:

* the idea definitions (``load_ideas_dir`` / ``validate_idea``);
* a *context* (``build_context``): classified devices (CONTRACT §5 Device, plus an
  optional ``classes: {role: device_class}``), weather entities, phones (notify
  services), media players without device, the default TTS entity, settings,
  the effective state of the linked recommendations;
* the stored state of the ideas (store key ``ideas``)::

      {"<idea_id>": {"status": "active" | "pending", "options": {...},
                     "devices": {"<need key>": [entity_id, ...]},   # user choices
                     "automation_ids": [...], "inputs_hash": str, "since": iso}}

and gets back statuses, chosen devices, blueprint inputs and automation instances.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path
from typing import Any

import yaml

try:
    from . import audience as _audience
    from . import buying_guide as _guide
except ImportError:  # imported as a top-level module by the pure tests (tests/conftest.py)
    import audience as _audience  # type: ignore[no-redef]
    import buying_guide as _guide  # type: ignore[no-redef]

BLUEPRINT_DIR = "maison_facile"
DESCRIPTION = "Créé par Maison Facile"
MODE_ENTITY_ID = "select.maison_facile_mode"
MAIL_FLAG_ENTITY_ID = "switch.maison_facile_courrier"
BIN_FLAG_ENTITY_ID = "switch.maison_facile_poubelles"  # « Poubelles à sortir » (idée poubelles)
AUTOMATION_PREFIX = "mf_idea_"
PLAN_PREFIX = "idea_"  # AutomationManager plan key -> ids "mf_idea_<id>_<hash>"

CATEGORIES: tuple[str, ...] = ("confort", "securite", "energie", "detecte")
STATUSES: tuple[str, ...] = ("actif", "pret", "manque", "non_pertinent")
OPTION_TYPES: tuple[str, ...] = ("bool", "choice", "number")
TILE_KINDS: tuple[str, ...] = ("flag", "power", "alarm", "value")

# Roles a need can ask for. Classifier roles + roles built from the context.
DEVICE_ROLES: tuple[str, ...] = (
    "contact", "motion", "temperature", "humidity", "power", "energy", "switch", "light",
    "smoke", "camera", "climate", "siren", "leak", "valve", "media", "doorbell", "button",
)
# Roles found among ALL the entities of Home Assistant (not only Maison Facile devices):
# ``ctx["entities"][role]``, filled by ideas.py with ``context_entity_role``.
ENTITY_ROLES: tuple[str, ...] = (
    "person", "vacuum", "co2", "soil", "ink", "tempo", "weather_alert", "charger", "energy_meter",
    "person_detect", "face",
)
CONTEXT_ROLES: tuple[str, ...] = (
    "tv", "speaker", "weather", "phone", "birthday", "smoke_battery", *ENTITY_ROLES,
)
# Ideas run by a Maison Facile module instead of a blueprint (« Anniversaires » = birthdays.py,
# « Bilan du mois » = energy_report.py).
MODULES: tuple[str, ...] = ("birthdays", "energy_report")
# Pages a need can open instead of « Ajouter le capteur » (frontend).
ADD_PAGES: tuple[str, ...] = ("birthdays",)
NEED_ROLES: tuple[str, ...] = DEVICE_ROLES + CONTEXT_ROLES

# input_mapping references: "<kind>:<key>"
CONTEXT_KEYS: tuple[str, ...] = ("notify_service", "phones", "tts_entity", "mail_flag", "mode_select", "bin_flag")
SETTING_KEYS: tuple[str, ...] = ("announce_media_player", "notify_service", "night_time", "morning_time")
MAPPING_KINDS: tuple[str, ...] = ("need", "needs", "target", "option", "setting", "context", "value")

# Device types of the add-device page (frontend pages/add-device.js).
ADD_TYPES: tuple[str, ...] = ("ouverture", "mouvement", "thermo", "prise", "fumee", "lumiere", "fuite")

ID_RE = re.compile(r"^[a-z][a-z0-9_]{1,40}$")
COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
ENTITY_RE = re.compile(r"^[a-z_]+\.[a-z0-9_]+$")

# French labels of the integrations that make an idea relevant ("Votre box a trouvé …").
DOMAIN_LABELS_FR: dict[str, str] = {
    "samsungtv": "une télé Samsung",
    "webostv": "une télé LG",
    "androidtv_remote": "une télé Android",
    "androidtv": "une télé Android",
    "philips_js": "une télé Philips",
    "braviatv": "une télé Sony",
    "panasonic_viera": "une télé Panasonic",
    "vizio": "une télé Vizio",
    "roku": "un lecteur Roku",
    "apple_tv": "une Apple TV",
    "cast": "un appareil Chromecast",
    "sonos": "une enceinte Sonos",
    "dlna_dmr": "un lecteur multimédia",
    "heos": "une enceinte Denon HEOS",
    "bluesound": "une enceinte Bluesound",
    "yamaha_musiccast": "un ampli Yamaha",
    "denonavr": "un ampli Denon",
    "onkyo": "un ampli Onkyo",
    "squeezebox": "une enceinte Squeezebox",
    "linkplay": "une enceinte connectée",
    "wiz": "une lampe WiZ",
    "ipp": "une imprimante",
    "brother": "une imprimante Brother",
    "roborock": "un robot aspirateur Roborock",
    "ecovacs": "un robot aspirateur Ecovacs",
    "xiaomi_miio": "un appareil Xiaomi",
    "neato": "un robot aspirateur Neato",
    "roomba": "un robot aspirateur iRobot",
    "peblar": "une borne de recharge Peblar",
    "wallbox": "une borne de recharge Wallbox",
}
DISCOVERY_SOURCES: frozenset[str] = frozenset(
    {"zeroconf", "ssdp", "dhcp", "homekit", "discovery", "bluetooth", "mqtt", "hassio", "usb"}
)

# What to tell the client when a discovered device cannot be added automatically.
ADD_HINTS_FR: dict[str, str] = {
    "samsungtv": "Allumez la télé : une demande d'autorisation s'affiche à l'écran. Acceptez-la avec la télécommande, puis touchez « Ajouter » à nouveau.",
    "webostv": "Allumez la télé : une demande s'affiche à l'écran. Acceptez-la avec la télécommande, puis touchez « Ajouter » à nouveau.",
    "androidtv_remote": "La télé affiche un code à 6 caractères : demandez à votre installateur de le saisir (Paramètres > Appareils et services).",
    "philips_js": "La télé affiche un code : demandez à votre installateur de le saisir (Paramètres > Appareils et services).",
    "braviatv": "La télé affiche un code : demandez à votre installateur de le saisir (Paramètres > Appareils et services).",
    "apple_tv": "L'Apple TV affiche un code : demandez à votre installateur de le saisir (Paramètres > Appareils et services).",
}
ADD_DEFAULT_HINT_FR = (
    "Cet appareil demande une information pour finir (un code ou un mot de passe). "
    "Votre installateur peut le terminer dans Paramètres > Appareils et services."
)
ADD_ABORTS_FR: dict[str, str] = {
    "already_configured": "Cet appareil est déjà ajouté.",
    "already_in_progress": "L'ajout est déjà en cours.",
    "cannot_connect": "L'appareil ne répond pas : vérifiez qu'il est allumé, puis réessayez.",
    "not_successful": "L'appareil ne répond pas : vérifiez qu'il est allumé, puis réessayez.",
    "auth_missing": "Acceptez la demande affichée sur l'écran de l'appareil, puis réessayez.",
    "unknown": "L'ajout n'a pas abouti. Réessayez dans un instant.",
}

BADGES_FR: dict[str, str] = {
    "actif": "Actif",
    "pret": "Prêt à activer",
    "manque": "Il manque un capteur",
    "attente": "Activée dès que le capteur sera là",
    "non_pertinent": "Pas encore pour vous",
    "a_completer": "À compléter",
}

_OFF_WORDS_SPLIT = re.compile(r"[\s_\-'’.,()]+")


# --------------------------------------------------------------------------- small helpers


def short_hash(value: str) -> str:
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:8]


def normalize(text: Any) -> str:
    if not text:
        return ""
    value = unicodedata.normalize("NFKD", str(text).replace("’", "'"))
    value = "".join(c for c in value if not unicodedata.combining(c))
    return " ".join(value.lower().replace("_", " ").split())


def _has_any(text: str, words: list[str]) -> bool:
    norm = normalize(text)
    return any(normalize(w) in norm for w in words)


def plan_key(idea_id: str) -> str:
    return f"{PLAN_PREFIX}{idea_id}"


def automation_id(idea_id: str, primary: str) -> str:
    return f"{AUTOMATION_PREFIX}{idea_id}_{short_hash(primary)}"


def parse_ref(value: Any) -> tuple[str, Any] | None:
    """``"need:x"`` / ``{"need": "x"}`` / ``{"value": 3}`` -> (kind, key); None if invalid.

    Dict form may carry ``when: <bool option>`` (context/needs/need only).
    """
    if isinstance(value, str) and ":" in value:
        kind, _, key = value.partition(":")
        if kind in MAPPING_KINDS and kind != "value" and key:
            return kind, key
        return None
    if isinstance(value, dict):
        kinds = [k for k in value if k in MAPPING_KINDS]
        if len(kinds) != 1:
            return None
        kind = kinds[0]
        extra = set(value) - {kind, "when"}
        if extra:
            return None
        return kind, value[kind]
    return None


# --------------------------------------------------------------------------- schema


def _err(errors: list[str], where: str, text: str) -> None:
    errors.append(f"{where}: {text}")


def _str(raw: dict[str, Any], key: str, errors: list[str], where: str, required: bool = True) -> str | None:
    value = raw.get(key)
    if value is None:
        if required:
            _err(errors, where, f"'{key}' manquant")
        return None
    if not isinstance(value, str) or not value.strip():
        _err(errors, where, f"'{key}' doit être un texte non vide")
        return None
    return value.strip()


def _validate_need(raw: Any, index: int, errors: list[str]) -> dict[str, Any] | None:
    where = f"needs[{index}]"
    if not isinstance(raw, dict):
        _err(errors, where, "doit être un objet")
        return None
    known = {
        "key", "roles", "label", "compatible", "price_hint", "optional", "multiple", "hint",
        "missing_fr", "device_class", "exclude_class", "prefer", "exclude_words", "require_prefer",
        "same_room_as", "strict_room", "add_type", "pivot", "rename_fr", "none_fr", "add_page", "choose",
    }
    for key in set(raw) - known:
        _err(errors, where, f"champ inconnu '{key}'")
    need: dict[str, Any] = {}
    key = raw.get("key")
    if not isinstance(key, str) or not ID_RE.match(key):
        _err(errors, where, "'key' invalide (minuscules, chiffres, _)")
    need["key"] = key
    roles = raw.get("roles")
    if isinstance(roles, str):
        roles = [roles]
    if not isinstance(roles, list) or not roles or any(r not in NEED_ROLES for r in roles):
        _err(errors, where, f"'roles' doit être une liste parmi {', '.join(NEED_ROLES)}")
        roles = []
    need["roles"] = roles
    need["label"] = _str(raw, "label", errors, where)
    for opt_text in ("compatible", "price_hint", "hint", "missing_fr", "rename_fr", "none_fr"):
        need[opt_text] = _str(raw, opt_text, errors, where, required=False)
    for flag in ("optional", "multiple", "require_prefer", "strict_room", "pivot", "choose"):
        value = raw.get(flag, False)
        if not isinstance(value, bool):
            _err(errors, where, f"'{flag}' doit valoir true ou false")
            value = False
        need[flag] = value
    for words in ("device_class", "exclude_class", "prefer", "exclude_words"):
        value = raw.get(words, [])
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
            _err(errors, where, f"'{words}' doit être une liste de textes")
            value = []
        need[words] = value
    need["same_room_as"] = raw.get("same_room_as")
    add_type = raw.get("add_type")
    if add_type is not None and add_type not in ADD_TYPES:
        _err(errors, where, f"'add_type' doit être parmi {', '.join(ADD_TYPES)}")
        add_type = None
    need["add_type"] = add_type
    add_page = raw.get("add_page")
    if add_page is not None and add_page not in ADD_PAGES:
        _err(errors, where, f"'add_page' doit être parmi {', '.join(ADD_PAGES)}")
        add_page = None
    need["add_page"] = add_page
    if need["price_hint"] and "€" not in need["price_hint"]:
        _err(errors, where, "'price_hint' doit contenir le symbole €")
    return need


def _validate_option(raw: Any, index: int, errors: list[str]) -> dict[str, Any] | None:
    where = f"options[{index}]"
    if not isinstance(raw, dict):
        _err(errors, where, "doit être un objet")
        return None
    for key in set(raw) - {"key", "label", "type", "default", "choices", "min", "max", "step", "unit"}:
        _err(errors, where, f"champ inconnu '{key}'")
    option: dict[str, Any] = {"key": raw.get("key"), "label": _str(raw, "label", errors, where)}
    if not isinstance(option["key"], str) or not ID_RE.match(option["key"]):
        _err(errors, where, "'key' invalide")
    kind = raw.get("type")
    if kind not in OPTION_TYPES:
        _err(errors, where, f"'type' doit être parmi {', '.join(OPTION_TYPES)}")
        return option
    option["type"] = kind
    default = raw.get("default")
    if kind == "bool":
        if not isinstance(default, bool):
            _err(errors, where, "'default' doit valoir true ou false")
    elif kind == "choice":
        choices = raw.get("choices")
        if not isinstance(choices, list) or not choices:
            _err(errors, where, "'choices' manquant")
            choices = []
        clean = []
        for choice in choices:
            if not isinstance(choice, dict) or "value" not in choice or not isinstance(choice.get("label"), str):
                _err(errors, where, "chaque choix doit avoir 'value' et 'label'")
                continue
            clean.append({"value": choice["value"], "label": choice["label"]})
        option["choices"] = clean
        if default not in [c["value"] for c in clean]:
            _err(errors, where, "'default' doit être un des choix")
    else:
        lo, hi = raw.get("min"), raw.get("max")
        if not all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in (lo, hi, default)):
            _err(errors, where, "'min', 'max' et 'default' doivent être des nombres")
        elif not lo <= default <= hi:
            _err(errors, where, "'default' hors de [min, max]")
        option.update(min=lo, max=hi, step=raw.get("step", 1), unit=raw.get("unit", ""))
    option["default"] = default
    return option


def validate_idea(raw: Any, blueprint_names: set[str] | None = None) -> tuple[dict[str, Any] | None, list[str]]:
    """Validate one idea file. Returns ``(idea, errors)``; ``idea`` is None on error."""
    errors: list[str] = []
    if not isinstance(raw, dict):
        return None, ["le fichier doit contenir un objet"]
    known = {
        "id", "version", "title", "pitch", "short", "description", "category", "color", "icon",
        "needs", "when", "if", "then", "blueprint", "input_mapping", "options", "tile", "next",
        "next_hint", "teaser", "teaser_detail", "detected_by", "recommendation", "applies_setting",
        "test_announce", "order", "module",
    }
    for key in set(raw) - known:
        _err(errors, "idée", f"champ inconnu '{key}'")
    order = raw.get("order", 100)
    if not isinstance(order, int) or isinstance(order, bool):
        _err(errors, "idée", "'order' doit être un entier")
        order = 100
    idea_order = order
    idea: dict[str, Any] = {}
    idea_id = raw.get("id")
    if not isinstance(idea_id, str) or not ID_RE.match(idea_id):
        _err(errors, "idée", "'id' invalide (minuscules, chiffres, _)")
    idea["id"] = idea_id
    version = raw.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        _err(errors, "idée", "'version' doit être un entier >= 1")
    idea["version"] = version
    idea["order"] = idea_order
    for key in ("title", "pitch", "description", "when", "if", "then", "icon"):
        idea[key] = _str(raw, key, errors, "idée")
    for key in ("short", "next_hint", "teaser", "teaser_detail"):
        idea[key] = _str(raw, key, errors, "idée", required=False)
    if raw.get("category") not in CATEGORIES:
        _err(errors, "idée", f"'category' doit être parmi {', '.join(CATEGORIES)}")
    idea["category"] = raw.get("category")
    if not isinstance(raw.get("color"), str) or not COLOR_RE.match(raw["color"]):
        _err(errors, "idée", "'color' doit ressembler à #0067C0")
    idea["color"] = raw.get("color")

    needs_raw = raw.get("needs", [])
    if not isinstance(needs_raw, list):
        _err(errors, "idée", "'needs' doit être une liste")
        needs_raw = []
    needs = [n for i, r in enumerate(needs_raw) if (n := _validate_need(r, i, errors))]
    keys = [n["key"] for n in needs]
    if len(set(keys)) != len(keys):
        _err(errors, "needs", "deux besoins ont la même 'key'")
    for need in needs:
        if need["same_room_as"] is not None and need["same_room_as"] not in keys:
            _err(errors, f"needs.{need['key']}", "'same_room_as' doit nommer un autre besoin")
    idea["needs"] = needs

    options_raw = raw.get("options", [])
    if not isinstance(options_raw, list):
        _err(errors, "idée", "'options' doit être une liste")
        options_raw = []
    options = [o for i, r in enumerate(options_raw) if (o := _validate_option(r, i, errors))]
    idea["options"] = options
    option_keys = {o["key"] for o in options}
    bool_options = {o["key"] for o in options if o.get("type") == "bool"}

    blueprint = raw.get("blueprint")
    if blueprint is not None and (not isinstance(blueprint, str) or not blueprint.endswith(".yaml")):
        _err(errors, "idée", "'blueprint' doit être un nom de fichier .yaml")
    elif blueprint is not None and blueprint_names is not None and blueprint not in blueprint_names:
        _err(errors, "idée", f"blueprint '{blueprint}' introuvable dans blueprints/automation/")
    idea["blueprint"] = blueprint

    mapping_raw = raw.get("input_mapping", {}) or {}
    if not isinstance(mapping_raw, dict):
        _err(errors, "idée", "'input_mapping' doit être un objet")
        mapping_raw = {}
    mapping: dict[str, Any] = {}
    for name, ref in mapping_raw.items():
        parsed = parse_ref(ref)
        where = f"input_mapping.{name}"
        if parsed is None:
            _err(errors, where, "référence invalide (need:, needs:, target:, option:, setting:, context: ou {value: …})")
            continue
        kind, key = parsed
        if kind in ("need", "needs", "target") and key not in keys:
            _err(errors, where, f"besoin '{key}' inconnu")
        elif kind == "option" and key not in option_keys:
            _err(errors, where, f"réglage '{key}' inconnu")
        elif kind == "context" and key not in CONTEXT_KEYS:
            _err(errors, where, f"contexte '{key}' inconnu")
        elif kind == "setting" and key not in SETTING_KEYS:
            _err(errors, where, f"réglage global '{key}' inconnu")
        if isinstance(ref, dict) and "when" in ref and ref["when"] not in bool_options:
            _err(errors, where, "'when' doit nommer un réglage oui/non")
        mapping[str(name)] = ref
    if blueprint and not mapping:
        _err(errors, "idée", "'input_mapping' manquant")
    idea["input_mapping"] = mapping

    recommendation = raw.get("recommendation")
    if recommendation is not None and not isinstance(recommendation, str):
        _err(errors, "idée", "'recommendation' doit être un identifiant")
    idea["recommendation"] = recommendation
    applies = raw.get("applies_setting")
    if applies is not None and (
        not isinstance(applies, dict)
        or applies.get("key") not in SETTING_KEYS
        or parse_ref(applies.get("value")) is None
    ):
        _err(errors, "idée", "'applies_setting' doit être {key: <réglage>, value: need:<besoin>}")
    idea["applies_setting"] = applies
    module = raw.get("module")
    if module is not None and module not in MODULES:
        _err(errors, "idée", f"'module' doit être parmi {', '.join(MODULES)}")
    idea["module"] = module
    if blueprint is None and recommendation is None and applies is None and module is None:
        _err(errors, "idée", "il faut 'blueprint', 'recommendation', 'applies_setting' ou 'module'")
    idea["test_announce"] = bool(raw.get("test_announce", False))

    tile = raw.get("tile")
    if tile is not None:
        if not isinstance(tile, dict):
            _err(errors, "tile", "doit être un objet")
            tile = None
        else:
            if tile.get("kind") not in TILE_KINDS:
                _err(errors, "tile", f"'kind' doit être parmi {', '.join(TILE_KINDS)}")
            _str(tile, "title", errors, "tile")
            _str(tile, "icon", errors, "tile")
            ref = parse_ref(tile.get("entity"))
            if ref is None or ref[0] not in ("need", "needs", "context"):
                _err(errors, "tile", "'entity' doit être need:<besoin>, needs:<besoin> ou context:<clé>")
            elif ref[0] in ("need", "needs") and ref[1] not in keys:
                _err(errors, "tile", f"besoin '{ref[1]}' inconnu")
            detail_attr = tile.get("detail_attribute")
            if detail_attr is not None and (not isinstance(detail_attr, str) or not re.match(r"^[a-z_]+$", detail_attr)):
                _err(errors, "tile", "'detail_attribute' doit être un nom d'attribut (minuscules, _)")
            action = tile.get("action")
            if action is not None and (
                not isinstance(action, dict)
                or not isinstance(action.get("label"), str)
                or not re.match(r"^[a-z_]+\.[a-z_]+$", str(action.get("service", "")))
            ):
                _err(errors, "tile", "'action' doit être {label, service: domaine.service}")
    idea["tile"] = tile

    for list_key in ("next", "detected_by"):
        value = raw.get(list_key, [])
        if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
            _err(errors, "idée", f"'{list_key}' doit être une liste de textes")
            value = []
        idea[list_key] = value
    if errors:
        return None, errors
    return idea, []


class _InputLoader(yaml.SafeLoader):
    """SafeLoader that understands the blueprint ``!input`` tag."""


_InputLoader.add_constructor("!input", lambda loader, node: {"__input__": loader.construct_scalar(node)})


def blueprint_inputs(path: Path) -> dict[str, dict[str, Any]]:
    """Declared inputs of a blueprint file (``{name: spec}``)."""
    with path.open(encoding="utf-8") as handle:
        data = yaml.load(handle, Loader=_InputLoader)
    return dict((data.get("blueprint") or {}).get("input") or {})


def check_blueprint_mapping(idea: dict[str, Any], inputs: dict[str, dict[str, Any]]) -> list[str]:
    """Every required blueprint input is mapped, every mapped input exists."""
    errors: list[str] = []
    mapping = idea.get("input_mapping") or {}
    for name, spec in inputs.items():
        if "default" not in (spec or {}) and name not in mapping:
            errors.append(f"input requis '{name}' non fourni par input_mapping")
    for name in mapping:
        if name not in inputs:
            errors.append(f"input_mapping.{name} : pas d'input de ce nom dans le blueprint")
    return errors


def load_ideas_dir(ideas_dir: Path, blueprints_dir: Path) -> tuple[list[dict[str, Any]], dict[str, list[str]]]:
    """Load and validate every ``ideas/*.yaml`` (sorted). Returns ``(ideas, errors_by_file)``.

    Invalid files are skipped. Also checks idea <-> blueprint coherence and ids.
    """
    blueprint_names = {p.name for p in blueprints_dir.glob("*.yaml")}
    ideas: list[dict[str, Any]] = []
    errors: dict[str, list[str]] = {}
    for path in sorted(ideas_dir.glob("*.yaml")):
        try:
            with path.open(encoding="utf-8") as handle:
                raw = yaml.safe_load(handle)
        except (OSError, yaml.YAMLError) as err:
            errors[path.name] = [f"YAML illisible : {err}"]
            continue
        idea, errs = validate_idea(raw, blueprint_names)
        if idea is not None and idea["id"] != path.stem:
            errs = [f"'id' ({idea['id']}) doit égaler le nom du fichier ({path.stem})"]
            idea = None
        if idea is not None and idea["blueprint"]:
            errs = check_blueprint_mapping(idea, blueprint_inputs(blueprints_dir / idea["blueprint"]))
            if errs:
                idea = None
        if idea is None:
            errors[path.name] = errs
            continue
        ideas.append(idea)
    ids = [i["id"] for i in ideas]
    for idea in list(ideas):
        clash = [o for o in ids if o != idea["id"] and o.startswith(idea["id"] + "_")]
        if clash:
            errors[f"{idea['id']}.yaml"] = [f"'id' est le début d'un autre id ({clash[0]}) : choisissez un autre nom"]
            ideas.remove(idea)
    ideas.sort(key=lambda i: (i["order"], i["id"]))
    known = {i["id"] for i in ideas}
    for idea in ideas:
        idea["next"] = [n for n in idea["next"] if n in known and n != idea["id"]]
    return ideas, errors


# --------------------------------------------------------------------------- context & candidates


def build_context(
    devices: list[dict[str, Any]],
    *,
    weather: list[dict[str, Any]] | None = None,
    phones: list[dict[str, Any]] | None = None,
    media: list[dict[str, Any]] | None = None,
    tts_entity: str = "",
    settings: dict[str, Any] | None = None,
    notify_ok: bool = True,
    linked: dict[str, bool] | None = None,
    detected: dict[str, dict[str, Any]] | None = None,
    rooms: list[dict[str, Any]] | None = None,
    modules: dict[str, dict[str, Any]] | None = None,
    entities: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """Everything the rules need, in plain data.

    ``weather`` / ``phones`` / ``media`` = ``[{entity_id, name, area_id?, kind?}]``
    (``media`` = media players WITHOUT a Maison Facile device; ``kind`` = tv|speaker).
    ``notify_ok`` = the configured notify service exists. ``linked`` = effective
    enabled state of the recommendations. ``detected`` = ``{domain: detected item}``.
    ``modules`` = state of the modules running ideas (``{"birthdays": {active, people:
    [{id, name}], preview_tile}}``). ``entities`` = ``{role of ENTITY_ROLES: [{entity_id, name,
    area_id?, device_class?}]}`` (see ``context_entity_role``).
    """
    return {
        "devices": devices,
        "weather": weather or [],
        "phones": phones or [],
        "media": media or [],
        "tts_entity": tts_entity or "",
        "settings": settings or {},
        "notify_ok": notify_ok,
        "linked": linked or {},
        "detected": detected or {},
        "rooms": {r.get("area_id"): r.get("name") for r in rooms or []},
        "modules": modules or {},
        "entities": {role: list(items) for role, items in (entities or {}).items()},
    }


_NUMBER_RE = re.compile(r"^-?\d+(?:[.,]\d+)?$")
_TEMPO_RE = re.compile(r"\btempo\b")


def context_entity_role(entity: dict[str, Any]) -> str | None:
    """Role (``ENTITY_ROLES``) of any Home Assistant entity, or None.

    ``entity`` = ``{entity_id, domain?, name?, device_class?, state_class?, platform?,
    unique_id?, state?}`` (registry + state, built by ideas.py).
    """
    entity_id = str(entity.get("entity_id") or "")
    domain = str(entity.get("domain") or entity_id.split(".", 1)[0])
    platform = str(entity.get("platform") or "")
    unique_id = str(entity.get("unique_id") or "")
    device_class = str(entity.get("device_class") or "")
    if platform == "maison_facile":
        return None
    if domain == "person":
        return "person"
    if domain == "vacuum":
        return "vacuum"
    if platform == "frigate":
        # Intégration Frigate (Réglages > IA) : détection de personnes, visage reconnu.
        if domain == "binary_sensor" and ":occupancy_sensor:" in unique_id and unique_id.endswith("_person"):
            return "person_detect"
        if domain == "sensor" and ":sensor_recognized_face:" in unique_id:
            return "face"
        return None
    if domain == "switch":
        # Chargers of Home Assistant whose switch allows / pauses the charge (on = charging).
        if platform == "wallbox" or (platform == "peblar" and unique_id.endswith("_charge")):
            return "charger"
        return None
    if domain != "sensor":
        return None
    if device_class == "carbon_dioxide":
        return "co2"
    if device_class == "moisture":  # soil moisture (air humidity is « humidity »)
        return "soil"
    if device_class == "energy" and entity.get("state_class") in ("total", "total_increasing"):
        return "energy_meter"
    if platform == "meteo_france" and (entity_id.endswith("weather_alert") or unique_id.endswith("Weather alert")):
        return "weather_alert"
    if platform == "ipp" and "_marker_" in unique_id:
        return "ink"
    if platform == "brother" and unique_id.endswith(("_toner_remaining", "_ink_remaining")):
        return "ink"
    text = normalize(f"{entity_id} {entity.get('name') or ''}")
    state = str(entity.get("state") or "")
    if (
        _TEMPO_RE.search(text)
        and device_class not in ("timestamp", "date", "duration")
        and not _NUMBER_RE.match(state)
    ):
        return "tempo"  # colour of the day (community integration, e.g. « RTE Tempo »)
    return None


def _candidate(
    entity_id: str, device: dict[str, Any] | None, role: str, extra: dict[str, Any] | None = None
) -> dict[str, Any]:
    extra = extra or {}
    device = device or {}
    return {
        "entity_id": entity_id,
        "device_id": device.get("device_id"),
        "name": extra.get("name") or device.get("name") or entity_id,
        "area_id": extra.get("area_id", device.get("area_id")),
        "device_class": (device.get("classes") or {}).get(role) or extra.get("device_class"),
        "type": device.get("type"),
    }


def candidates(ctx: dict[str, Any], role: str) -> list[dict[str, Any]]:
    """Every entity able to play ``role`` (sorted by entity_id)."""
    out: list[dict[str, Any]] = []
    if role in DEVICE_ROLES:
        for device in ctx["devices"]:
            entity = (device.get("entities") or {}).get(role)
            if entity:
                out.append(_candidate(str(entity), device, role))
        if role == "media":
            for item in ctx["media"]:
                out.append(_candidate(item["entity_id"], None, role, item))
    elif role in ("tv", "speaker"):
        wanted = "tv" if role == "tv" else "enceinte"
        for device in ctx["devices"]:
            entity = (device.get("entities") or {}).get("media")
            if entity and device.get("type") == wanted:
                out.append(_candidate(str(entity), device, "media"))
        for item in ctx["media"]:
            if item.get("kind", "speaker") == role:
                out.append(_candidate(item["entity_id"], None, "media", item))
    elif role == "weather":
        out = [_candidate(w["entity_id"], None, role, w) for w in ctx["weather"]]
    elif role == "phone":
        out = [_candidate(p["entity_id"], None, role, p) for p in ctx["phones"]]
    elif role == "smoke_battery":
        # Battery level of the smoke detectors (classifier role « battery » of a smoke device).
        for device in ctx["devices"]:
            entities = device.get("entities") or {}
            if entities.get("smoke") and entities.get("battery"):
                out.append(_candidate(str(entities["battery"]), device, "battery"))
    elif role in ENTITY_ROLES:
        out = [_candidate(e["entity_id"], None, role, e) for e in (ctx.get("entities") or {}).get(role) or []]
    elif role == "birthday":
        people = (ctx.get("modules", {}).get("birthdays") or {}).get("people") or []
        out = [_candidate(f"birthday.{p['id']}", None, role, {"name": p["name"]}) for p in people]
        return sorted(out, key=lambda c: (normalize(c["name"]), c["entity_id"]))
    return sorted(out, key=lambda c: c["entity_id"])


def _room_name(ctx: dict[str, Any], area_id: Any) -> str:
    return str(ctx["rooms"].get(area_id) or area_id or "")


def _pool(ctx: dict[str, Any], need: dict[str, Any]) -> list[dict[str, Any]]:
    """Candidates of a need after its filters (class, words), without room logic."""
    seen: set[str] = set()
    pool: list[dict[str, Any]] = []
    for rank, role in enumerate(need["roles"]):
        for cand in candidates(ctx, role):
            if cand["entity_id"] in seen:
                continue
            seen.add(cand["entity_id"])
            pool.append({**cand, "role_rank": rank})
    out = []
    for cand in pool:
        cls = cand.get("device_class")
        if cls and cls in need["exclude_class"]:
            continue
        if cls and need["device_class"] and cls not in need["device_class"]:
            continue
        text = f"{cand['name']} {cand['entity_id']} {_room_name(ctx, cand.get('area_id'))}"
        if need["exclude_words"] and _has_any(text, need["exclude_words"]):
            continue
        cand["preferred"] = bool(need["prefer"]) and _has_any(text, need["prefer"])
        cand["class_match"] = bool(cls) and cls in need["device_class"]
        if need["require_prefer"] and not cand["preferred"]:
            continue
        out.append(cand)
    return out


def _score(cand: dict[str, Any], anchor_area: Any) -> tuple:
    same_room = bool(anchor_area) and cand.get("area_id") == anchor_area
    return (
        -int(same_room),
        -int(cand.get("preferred", False)),
        -int(cand.get("class_match", False)),
        cand.get("role_rank", 0),
        normalize(cand.get("name")),
        cand["entity_id"],
    )


def resolve_needs(
    idea: dict[str, Any], ctx: dict[str, Any], overrides: dict[str, list[str]] | None = None
) -> list[dict[str, Any]]:
    """Choose the devices of each need.

    Returns, for each need: ``{key, chosen: [candidate], choices: [candidate], have: bool}``.
    User ``overrides`` (entity ids) win when they are still valid candidates
    (for user choices the word / class filters are relaxed: any entity of the roles).
    Needs with ``same_room_as`` are resolved after their anchor.
    """
    overrides = overrides or {}
    order = sorted(idea["needs"], key=lambda n: 1 if n["same_room_as"] else 0)
    resolved: dict[str, dict[str, Any]] = {}
    for need in order:
        pool = _pool(ctx, need)
        relaxed = {
            c["entity_id"]: c
            for role in need["roles"]
            for c in candidates(ctx, role)
        }
        anchor_area = None
        if need["same_room_as"]:
            anchor = resolved.get(need["same_room_as"], {}).get("chosen") or []
            anchor_area = anchor[0].get("area_id") if anchor else None
            if need["strict_room"]:
                pool = [c for c in pool if anchor_area and c.get("area_id") == anchor_area]
        pool.sort(key=lambda c: _score(c, anchor_area))
        chosen: list[dict[str, Any]] = []
        wanted = [e for e in overrides.get(need["key"], []) if e in relaxed]
        if wanted:
            chosen = [relaxed[e] for e in wanted]
            if not need["multiple"]:
                chosen = chosen[:1]
        elif pool:
            if need["multiple"]:
                # Best matches (words / class) when there are some, else every candidate.
                preferred = [c for c in pool if c.get("preferred") or c.get("class_match")]
                chosen = pool if need["strict_room"] else (preferred or pool)
            else:
                chosen = [pool[0]]
        # What the client may pick by hand: best matches first, then every device able to do it.
        choices = list(pool)
        listed = {c["entity_id"] for c in choices}
        for cand in [*chosen, *sorted(relaxed.values(), key=lambda c: (normalize(c["name"]), c["entity_id"]))]:
            if cand["entity_id"] not in listed:
                choices.append(cand)
                listed.add(cand["entity_id"])
        resolved[need["key"]] = {
            "key": need["key"],
            "need": need,
            "chosen": chosen,
            "choices": choices,
            "have": bool(chosen),
            "anchor_area": anchor_area,
        }
    return [resolved[n["key"]] for n in idea["needs"]]


def _missing(resolved: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [r for r in resolved if not r["have"] and not r["need"]["optional"]]


def detection_for(idea: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any] | None:
    """A discovered (not yet added) device that makes this idea possible."""
    for domain in idea["detected_by"]:
        item = ctx["detected"].get(domain)
        if item and item.get("flow_id"):
            return item
    return None


# --------------------------------------------------------------------------- status


def idea_status(
    idea: dict[str, Any], resolved: list[dict[str, Any]], stored: dict[str, Any] | None, ctx: dict[str, Any]
) -> tuple[str, bool]:
    """Return ``(status, pending)``. ``pending`` = waiting for a device to auto-activate."""
    stored = stored or {}
    missing = _missing(resolved)
    if idea.get("module"):
        # Run by a module: active = the module says so (e.g. at least one date + reminders on).
        if (ctx.get("modules", {}).get(idea["module"]) or {}).get("active"):
            return "actif", False
        return ("manque" if missing else "pret"), False
    if idea.get("recommendation") and ctx["linked"].get(idea["recommendation"]):
        return "actif", False
    if idea.get("applies_setting"):
        key = idea["applies_setting"]["key"]
        value = str(ctx["settings"].get(key) or "")
        if value and stored.get("status") == "active":
            return "actif", False
    elif stored.get("status") == "active" and not idea.get("recommendation"):
        return "actif", False
    pending = stored.get("status") == "pending"
    if not missing:
        return "pret", pending
    pivots = [r for r in missing if r["need"]["pivot"]]
    if pivots and not pending and detection_for(idea, ctx) is None:
        return "non_pertinent", False
    return "manque", pending


def badge_fr(status: str, pending: bool) -> str:
    if status == "manque" and pending:
        return BADGES_FR["attente"]
    if status == "manque":
        return BADGES_FR["manque"]
    return BADGES_FR[status]


def need_summary_fr(status: str, resolved: list[dict[str, Any]]) -> str:
    if status == "actif":
        return "Déjà actif"
    missing = _missing(resolved)
    if not missing:
        return "Vous avez déjà tout"
    first = missing[0]["need"]
    text = first.get("missing_fr") or "1 appareil"
    if len(missing) > 1:
        text += f" (et {len(missing) - 1} autre{'s' if len(missing) > 2 else ''})"
    return f"Il faut : {text}"


# --------------------------------------------------------------------------- options & inputs


def resolve_options(idea: dict[str, Any], values: dict[str, Any] | None) -> dict[str, Any]:
    """Defaults, overridden by valid user values (unknown keys / bad values dropped)."""
    values = values or {}
    out: dict[str, Any] = {}
    for option in idea["options"]:
        key, default = option["key"], option["default"]
        value = values.get(key, default)
        if option["type"] == "bool":
            out[key] = value if isinstance(value, bool) else default
        elif option["type"] == "choice":
            allowed = [c["value"] for c in option["choices"]]
            out[key] = value if value in allowed else default
        else:
            ok = isinstance(value, (int, float)) and not isinstance(value, bool)
            out[key] = value if ok and option["min"] <= value <= option["max"] else default
    return out


def _context_value(key: str, ctx: dict[str, Any]) -> Any:
    settings = ctx["settings"]
    if key == "notify_service":
        return str(settings.get("notify_service") or "") if ctx["notify_ok"] else ""
    if key == "phones":
        main = str(settings.get("notify_service") or "")
        return sorted(p["entity_id"] for p in ctx["phones"] if p["entity_id"] != main)
    if key == "tts_entity":
        return ctx["tts_entity"]
    if key == "mail_flag":
        return MAIL_FLAG_ENTITY_ID
    if key == "bin_flag":
        return BIN_FLAG_ENTITY_ID
    if key == "mode_select":
        return MODE_ENTITY_ID
    raise KeyError(key)


def _ref_value(ref: Any, resolved: dict[str, dict[str, Any]], options: dict[str, Any], ctx: dict[str, Any]) -> Any:
    kind, key = parse_ref(ref)  # type: ignore[misc]
    if isinstance(ref, dict) and "when" in ref and not options.get(ref["when"]):
        listy = kind in ("needs", "target") or (kind == "context" and key == "phones")
        return [] if listy else ""
    if kind == "value":
        return key
    if kind == "option":
        return options[key]
    if kind == "setting":
        return ctx["settings"].get(key, "") if key != "notify_service" else _context_value("notify_service", ctx)
    if kind == "context":
        return _context_value(key, ctx)
    ids = [c["entity_id"] for c in resolved[key]["chosen"]]
    if kind == "need":
        return ids[0] if ids else ""
    if kind == "needs":
        return ids
    return {"entity_id": ids}


def build_inputs(
    idea: dict[str, Any], resolved: list[dict[str, Any]], options: dict[str, Any], ctx: dict[str, Any]
) -> dict[str, Any]:
    by_key = {r["key"]: r for r in resolved}
    return {name: _ref_value(ref, by_key, options, ctx) for name, ref in idea["input_mapping"].items()}


def inputs_hash(inputs: dict[str, Any]) -> str:
    return short_hash(json.dumps(inputs, sort_keys=True, ensure_ascii=False, default=str))


def build_instance(
    idea: dict[str, Any], resolved: list[dict[str, Any]], options: dict[str, Any], ctx: dict[str, Any]
) -> dict[str, Any] | None:
    """The automation to write for an active idea (same shape as rules.build_instances)."""
    if not idea.get("blueprint") or _missing(resolved):
        return None
    primary = next((r["chosen"][0]["entity_id"] for r in resolved if r["chosen"]), "home")
    return {
        "automation_id": automation_id(idea["id"], primary),
        "alias": f"Maison Facile – Idée : {idea['title']}",
        "description": DESCRIPTION,
        "blueprint": f"{BLUEPRINT_DIR}/{idea['blueprint']}",
        "inputs": build_inputs(idea, resolved, options, ctx),
        "recommendation_id": plan_key(idea["id"]),
    }


def setting_value(idea: dict[str, Any], resolved: list[dict[str, Any]]) -> tuple[str, Any] | None:
    """For an ``applies_setting`` idea: (setting key, value) to write when active."""
    applies = idea.get("applies_setting")
    if not applies:
        return None
    kind, key = parse_ref(applies["value"])  # type: ignore[misc]
    by_key = {r["key"]: r for r in resolved}
    if kind == "value":
        return applies["key"], key
    chosen = by_key.get(key, {}).get("chosen") or []
    return applies["key"], chosen[0]["entity_id"] if chosen else ""


# --------------------------------------------------------------------------- new devices


def assign_new_device(
    ideas: list[dict[str, Any]],
    stored: dict[str, Any],
    device: dict[str, Any],
    ctx: dict[str, Any],
) -> list[tuple[str, str, str]]:
    """A device was just added: give it to the pending ideas that wait for it.

    « pending » = the client asked to activate the idea as soon as the device is there;
    « expect » = the client opened « Ajouter le capteur » from the idea (no activation).
    For each such idea (oldest first) and each MISSING required need whose roles
    the device can play (word filters relaxed: the client just added it for that),
    returns ``(idea_id, need_key, entity_id)``. A device feeds one idea need only once
    per idea; several pending ideas may share it.
    """
    out: list[tuple[str, str, str]] = []
    pending = sorted(
        (i for i in ideas if (stored.get(i["id"]) or {}).get("status") in ("pending", "expect")),
        key=lambda i: str((stored.get(i["id"]) or {}).get("since") or ""),
    )
    role_entities = dict(device.get("entities") or {})
    if role_entities.get("media"):
        role_entities["tv" if device.get("type") == "tv" else "speaker"] = role_entities["media"]
    for idea in pending:
        entry = stored.get(idea["id"]) or {}
        resolved = resolve_needs(idea, ctx, entry.get("devices"))
        for item in resolved:
            need = item["need"]
            if item["have"] or need["optional"]:
                continue
            entity = next((role_entities[r] for r in need["roles"] if role_entities.get(r)), None)
            if entity:
                out.append((idea["id"], need["key"], str(entity)))
                break
    return out


# --------------------------------------------------------------------------- views


def _need_view(item: dict[str, Any], idea: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
    need = item["need"]
    chosen = item["chosen"]
    detected = None
    if not item["have"] and need["pivot"]:
        found = detection_for(idea, ctx)
        if found:
            detected = {k: found.get(k) for k in ("domain", "label_fr", "flow_id", "name")}
    if item["have"]:
        names = ", ".join(f"« {c['name']} »" for c in chosen[:3])
        if len(chosen) > 3:
            names += f" et {len(chosen) - 3} autre{'s' if len(chosen) > 4 else ''}"
        status_fr = f"Ajouté : {names}" if need["roles"] != ["phone"] else "Déjà relié à la maison"
    elif detected:
        status_fr = f"Trouvée sur le réseau : {detected['label_fr']}"
    elif need["optional"]:
        status_fr = need.get("none_fr") or "Facultatif : pas encore ajouté"
    else:
        status_fr = f"À ajouter : {need['hint']}" if need.get("hint") else "À ajouter"
    return {
        "key": need["key"],
        "label": need["label"],
        "compatible": need.get("compatible"),
        "price_hint": need.get("price_hint"),
        "optional": need["optional"],
        "multiple": need["multiple"],
        "have": item["have"],
        "status_fr": status_fr,
        "add_type": need.get("add_type"),
        "add_page": need.get("add_page"),
        # Single choice offered in the idea page even for an optional need / a phone.
        "choose": need.get("choose", False),
        "phone": need["roles"] == ["phone"],
        "detected": detected,
        "chosen": [{"entity_id": c["entity_id"], "name": c["name"], "area_id": c.get("area_id")} for c in chosen],
        "choices": [
            {"entity_id": c["entity_id"], "name": c["name"], "area_id": c.get("area_id")} for c in item["choices"]
        ],
    }


def _tile(idea: dict[str, Any], resolved: list[dict[str, Any]], ctx: dict[str, Any]) -> dict[str, Any] | None:
    tile = idea.get("tile")
    if not tile:
        return None
    kind, key = parse_ref(tile["entity"])  # type: ignore[misc]
    by_key = {r["key"]: r for r in resolved}
    if kind == "context":
        entities = [_context_value(key, ctx)]
    else:
        entities = [c["entity_id"] for c in by_key[key]["chosen"]]
        if kind == "need":
            entities = entities[:1]
    entities = [e for e in entities if e]
    return {
        "idea_id": idea["id"],
        "kind": tile["kind"],
        "title": tile["title"],
        "icon": tile["icon"],
        "color": idea["color"],
        "entity_ids": entities,
        "attribute": tile.get("attribute"),
        # Text attribute shown on a « flag » tile: « Ce soir : sortez le bac jaune » (poubelles).
        "detail_attribute": tile.get("detail_attribute"),
        "unit": tile.get("unit"),
        "threshold": tile.get("threshold"),
        "show": tile.get("show", "always"),
        "on_text": tile.get("on_text"),
        "off_text": tile.get("off_text"),
        "action": tile.get("action"),
        "preview": tile.get("preview"),
    }


def evaluate(
    idea: dict[str, Any], ctx: dict[str, Any], stored: dict[str, Any] | None
) -> dict[str, Any]:
    """All the computed facts about one idea."""
    stored = stored or {}
    resolved = resolve_needs(idea, ctx, stored.get("devices"))
    status, pending = idea_status(idea, resolved, stored, ctx)
    return {"idea": idea, "resolved": resolved, "status": status, "pending": pending, "stored": stored}


def seen_key(idea_id: str, status: str) -> str:
    return f"{idea_id}:{status}"


def is_new(ev: dict[str, Any], seen: set[str] | list[str]) -> bool:
    """Ready or discovered ideas the client has not looked at yet."""
    idea = ev["idea"]
    interesting = ev["status"] == "pret" and not ev["pending"]
    discovered = ev["status"] == "manque" and any(
        r["need"]["pivot"] and not r["have"] for r in ev["resolved"]
    )
    return (interesting or discovered) and seen_key(idea["id"], ev["status"]) not in set(seen)


def no_hardware(idea: dict[str, Any]) -> bool:
    """Every required need of the idea is met without buying a device."""
    return _audience.no_hardware_needs(idea.get("needs", ()), _guide.NO_PURCHASE_ROLES)


def list_item(ev: dict[str, Any], seen: set[str] | list[str]) -> dict[str, Any]:
    idea = ev["idea"]
    others = [o for o in ev["resolved"] if not o["need"]["optional"] and not o["need"]["pivot"]]
    return {
        "id": idea["id"],
        "title": idea["title"],
        "pitch": idea["pitch"],
        "short": idea.get("short"),
        "category": idea["category"],
        "color": idea["color"],
        "icon": idea["icon"],
        "status": ev["status"],
        "pending": ev["pending"],
        "badge_fr": (
            BADGES_FR["a_completer"]
            if idea.get("module") and ev["status"] == "manque"
            else badge_fr(ev["status"], ev["pending"])
        ),
        "need_summary_fr": need_summary_fr(ev["status"], ev["resolved"]),
        "detected_by": idea["detected_by"],
        "new": is_new(ev, seen),
        # Works without buying anything (phone app, weather, dates…): shown first to a box
        # installed without hardware (« Votre maison sans matériel », installer v1.4).
        "no_hardware": no_hardware(idea),
        # Obligatory needs other than the main (pivot) device: for the "ideas of a device" view
        # ("alone / with your devices / with an extra device").
        "needs_other": len(others),
        "missing_other_fr": [o["need"]["label"] for o in others if not o["have"]],
    }


def detail(ev: dict[str, Any], ctx: dict[str, Any], ideas_by_id: dict[str, dict[str, Any]]) -> dict[str, Any]:
    idea = ev["idea"]
    stored = ev["stored"]
    options = resolve_options(idea, stored.get("options"))
    option_views = []
    for option in idea["options"]:
        view = {k: option.get(k) for k in ("key", "label", "type", "choices", "min", "max", "step", "unit", "default")}
        view = {k: v for k, v in view.items() if v is not None}
        view["value"] = options[option["key"]]
        option_views.append(view)
    next_items = []
    for next_id in idea["next"]:
        nxt = ideas_by_id.get(next_id)
        if nxt:
            next_items.append({
                "id": nxt["id"],
                "title": nxt["teaser"] or nxt["title"],
                "detail": " ".join(t for t in (idea.get("next_hint"), nxt.get("teaser_detail")) if t),
                "color": nxt["color"],
            })
    item = list_item(ev, [])
    item.update(
        description=idea["description"],
        when=idea["when"],
        **{"if": idea["if"], "then": idea["then"]},
        needs=[_need_view(r, idea, ctx) for r in ev["resolved"]],
        options=option_views,
        tile=_tile(idea, ev["resolved"], ctx)
        or (ctx.get("modules", {}).get(idea.get("module") or "") or {}).get("preview_tile"),
        next=next_items,
        has_automation=bool(idea.get("blueprint") or idea.get("recommendation") or idea.get("module")),
        module=idea.get("module"),
        test_announce=idea.get("test_announce", False),
        version=idea["version"],
    )
    return item


def tiles(evaluations: list[dict[str, Any]], ctx: dict[str, Any]) -> list[dict[str, Any]]:
    """Home-page tiles of the active ideas."""
    out = []
    for ev in evaluations:
        if ev["status"] != "actif":
            continue
        tile = _tile(ev["idea"], ev["resolved"], ctx)
        if tile and tile["entity_ids"]:
            out.append(tile)
    return out


# --------------------------------------------------------------------------- discovery


def detected_items(
    flows: list[dict[str, Any]],
    entry_domains: set[str] | list[str],
    ideas: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Discovered devices that make ideas possible.

    ``flows`` = config flows in progress (``{flow_id, handler, context:{source}, ...}``).
    Only discovery sources are kept. Existing entries give ``flow_id: None`` items.
    """
    by_domain: dict[str, list[str]] = {}
    for idea in ideas:
        for domain in idea["detected_by"]:
            by_domain.setdefault(domain, []).append(idea["id"])
    items: dict[str, dict[str, Any]] = {}
    for flow in flows:
        domain = str(flow.get("handler") or "")
        source = str((flow.get("context") or {}).get("source") or "")
        if domain not in by_domain or source not in DISCOVERY_SOURCES or domain in items:
            continue
        placeholders = (flow.get("context") or {}).get("title_placeholders") or {}
        items[domain] = {
            "domain": domain,
            "label_fr": DOMAIN_LABELS_FR.get(domain, "un nouvel appareil"),
            "flow_id": flow.get("flow_id"),
            "name": placeholders.get("name") or placeholders.get("model"),
            "ideas": list(by_domain[domain]),
            "added": False,
        }
    for domain in sorted(set(entry_domains)):
        if domain in by_domain and domain not in items:
            items[domain] = {
                "domain": domain,
                "label_fr": DOMAIN_LABELS_FR.get(domain, "un nouvel appareil"),
                "flow_id": None,
                "name": None,
                "ideas": list(by_domain[domain]),
                "added": True,
            }
    return sorted(items.values(), key=lambda i: (i["added"], i["domain"]))


def add_outcome_message(domain: str, kind: str, reason: str) -> tuple[str, str]:
    """``(state, message_fr)`` after trying to add a discovered device.

    ``kind`` = FlowOutcome.kind of provision.async_drive_flow.
    """
    if kind == "created":
        return "created", "C'est ajouté. Les idées qui l'utilisent sont prêtes."
    if kind == "aborted":
        if reason == "already_configured":
            return "created", ADD_ABORTS_FR["already_configured"]
        return "failed", ADD_ABORTS_FR.get(reason, ADD_ABORTS_FR["unknown"])
    if kind == "gone":
        return "failed", "Cet appareil n'est plus visible sur le réseau. Vérifiez qu'il est allumé."
    return "needs_user", ADD_HINTS_FR.get(domain, ADD_DEFAULT_HINT_FR)


# --------------------------------------------------------------------------- settings

MEDIA_PLAYER_RE = re.compile(r"^media_player\.[a-z0-9_]+$")


def valid_announce_player(value: Any) -> bool:
    return isinstance(value, str) and (value == "" or bool(MEDIA_PLAYER_RE.match(value)))
