"""Shared constants for Maison Facile (CONTRACT §3)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .store import MaisonFacileStore

DOMAIN = "maison_facile"
VERSION = "1.0.22"  # must equal manifest.json "version"
PANEL_URL_PATH = "maison-facile"
PANEL_WEBCOMPONENT = "maison-facile-panel"
PANEL_TITLE = "Ma maison"
PANEL_ICON = "mdi:home-heart"
STATIC_URL = "/maison_facile_static"  # serves custom_components/maison_facile/frontend/
# Adresse de l'interface AVEC le numéro de version : après une mise à jour, le navigateur
# recharge forcément tous les fichiers (pages/*.js…), pas seulement le fichier principal.
FRONTEND_URL = f"{STATIC_URL}/{VERSION}"
# Commercial-mode guard loaded on EVERY page of HA's frontend (frontend.add_extra_js_url).
GUARD_MODULE_URL = f"{FRONTEND_URL}/mf-guard.js"
MODE_ENTITY_ID = "select.maison_facile_mode"
MODES = ["maison", "absent", "nuit"]
# API GitHub plutôt que raw.githubusercontent.com : raw peut servir une ancienne copie de
# la branche plusieurs minutes après une publication (cache de « main »), l'API non (60 s).
DEFAULT_VERSIONS_URL = "https://api.github.com/repos/akiserau3/maison-facile-releases/contents/versions.json"
# Anciennes adresses (box configurées à la main avant la 1.0.7) : remplacées par la nouvelle.
LEGACY_VERSIONS_URLS = frozenset({
    "https://raw.githubusercontent.com/akiserau3/maison-facile-releases/main/versions.json",
})
BLUEPRINT_SUBDIR = "maison_facile"  # copied to <config>/blueprints/automation/maison_facile/
EVENT_DEVICE_FOUND = "maison_facile_device_found"
EVENT_UPDATE_PROGRESS = "maison_facile_update_progress"
MAIL_FLAG_ENTITY_ID = "switch.maison_facile_courrier"  # « Courrier en attente » (idée courrier)
BIN_FLAG_ENTITY_ID = "switch.maison_facile_poubelles"  # « Poubelles à sortir » (idée poubelles)

STORAGE_KEY = "maison_facile.data"
STORAGE_VERSION = 1

AUTOMATION_ID_PREFIX = "mf_"
AUTOMATION_DESCRIPTION = "Créé par Maison Facile"
PAIRING_DURATION = 180

ROOM_COLORS = [
    "#E8590C",
    "#0E7A0D",
    "#6B47B8",
    "#0067C0",
    "#00838F",
    "#C2185B",
    "#5D6B7A",
    "#B8860B",
]
ROOM_ICONS = ["sofa", "kitchen", "bed", "desk", "bath", "door", "garage", "child", "room"]

DEFAULT_SETTINGS: dict[str, Any] = {
    "theme": "clair",
    "update_mode": "auto",
    "update_channel": "stable",
    "night_mode": "hour",
    "night_time": "23:00",
    "morning_time": "07:00",
    "kwh_price": 0.25,
    "notify_service": "notify.notify",
    "installer_name": "",
    "installer_contact": "",
    "versions_url": DEFAULT_VERSIONS_URL,
    # Commercial mode: the family only sees Maison Facile (NOTES_commercial.md).
    "commercial_mode": True,
    # Mode Expert : Home Assistant déjà configuré, rien n'est caché ni changé sans accord
    # (expert_rules.py). Désactive le mode commercial.
    "expert_mode": False,
    # Idée « Annonces à voix haute » : enceinte qui répète les alertes ("" = aucune).
    "announce_media_player": "",
    # Apparence (theme_rules.py, NOTES_apparence.md).
    "theme_auto": "fetes_saisons",
    "animations": True,
    "home_style": "maison_facile",
    "liked_styles": [],
    # « Où l'acheter ? » of the buying guide (buying_guide.py): "" = button hidden.
    "shop_url": "",
}

THEMES = [
    "clair", "sombre", "contraste", "printemps", "ete", "automne", "hiver",
    "halloween", "noel", "nouvelan", "valentin", "paques", "quatorze",
]
SIGNAL_APPEARANCE = "maison_facile_appearance"  # dispatcher: the effective theme may have changed
UPDATE_MODES = ["auto", "ask"]
UPDATE_CHANNELS = ["stable", "test"]
NIGHT_MODES = ["hour", "voice"]


@dataclass
class MaisonFacileData:
    """Runtime data stored in ``entry.runtime_data``."""

    store: "MaisonFacileStore | None" = None
    updater: Any = None
    doctor: Any = None
    pairing: Any = None
    automations: Any = None
    heating: Any = None
    provision: Any = None
    commercial: Any = None
    ideas: Any = None
    birthdays: Any = None  # « Anniversaires » (birthdays.py)
    energy_report: Any = None  # « Bilan du mois » (energy_report.py)
