"""Réglages > IA > « Votre IA » : état des IA reliées, descriptions des caméras (Frigate
GenAI) et assistant d'automatismes. Logique : ai_rules.py. Compte principal seulement.

L'assistant ne crée rien tout seul : ``ai/draft`` propose et vérifie, ``ai/save`` écrit
seulement après la confirmation de l'utilisateur (et une case en plus pour les actions
sensibles : serrure, alarme, porte de garage…).
"""

from __future__ import annotations

import contextlib
import logging
import secrets
import time
from typing import Any

import voluptuous as vol
import yaml
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers import area_registry as ar_reg
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from . import ai_rules as air
from . import expert_rules as xr
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)
DATA = f"{DOMAIN}_ai"
STORE_KEY = "ai_automations"
DRAFT_TTL = 1800


def _rt(hass: HomeAssistant) -> dict[str, Any]:
    return hass.data.setdefault(DATA, {"drafts": {}, "genai_running": False, "genai_error": None, "tasks": set()})


def _data(hass: HomeAssistant) -> Any | None:
    entries = hass.config_entries.async_entries(DOMAIN)
    return getattr(entries[0], "runtime_data", None) if entries else None


def _saved(hass: HomeAssistant) -> list[dict[str, Any]]:
    data = _data(hass)
    value = data.store.data.get(STORE_KEY) if data and data.store else None
    return [dict(x) for x in value] if isinstance(value, list) else []


async def _save_list(hass: HomeAssistant, items: list[dict[str, Any]]) -> None:
    data = _data(hass)
    data.store.data[STORE_KEY] = items
    await data.store.async_save()
    await data.automations.async_sync({"ai": [{"automation_id": i["config"]["id"], "config": i["config"]} for i in items]})


def _memo(hass: HomeAssistant) -> dict[str, Any]:
    data = _data(hass)
    value = data.store.data.get("recipes") if data and data.store else None
    return dict(value) if isinstance(value, dict) else {}


async def _save_memo(hass: HomeAssistant, **changes: Any) -> None:
    data = _data(hass)
    data.store.data["recipes"] = {**_memo(hass), **changes}
    await data.store.async_save()


# --------------------------------------------------------------------------- état


def async_status(hass: HomeAssistant) -> dict[str, Any]:
    rt = _rt(hass)
    entries = [
        {"domain": e.domain, "title": e.title, "state": e.state.value}
        for e in hass.config_entries.async_entries()
        if e.domain in air.AI_DOMAINS
    ]
    memo = _memo(hass)
    return {
        "providers": list(air.HA_PROVIDERS),
        "entries": entries,
        "ai_task": sorted(hass.states.async_entity_ids("ai_task")),
        "frigate_ready": bool(hass.config_entries.async_entries("frigate", include_ignore=False)),
        "genai": memo.get("genai") or None,
        "genai_running": rt["genai_running"],
        "genai_error": rt["genai_error"],
        "genai_providers": list(air.GENAI_PROVIDERS),
        "automations": [
            {"id": i["config"]["id"], "alias": i["config"]["alias"], "explication": i.get("explication", ""), "request": i.get("request", "")}
            for i in _saved(hass)
        ],
    }


# --------------------------------------------------------------------------- Frigate GenAI


async def _run_genai(hass: HomeAssistant, settings: dict[str, str] | None) -> None:
    from . import recipes  # noqa: PLC0415

    rt = _rt(hass)
    rt["genai_running"], rt["genai_error"] = True, None
    try:
        base = await recipes._frigate_base(hass)  # noqa: SLF001
        raw = str(await recipes._frigate_get(hass, base, "/api/config/raw"))  # noqa: SLF001
        if settings:
            text = air.genai_set(raw, settings["provider"], settings["model"], settings.get("base_url", ""), settings.get("api_key", ""))
        else:
            text = air.genai_unset(raw)
        session = async_get_clientsession(hass)
        async with session.post(
            f"{base}/api/config/save", params={"save_option": "restart"}, data=text.encode(),
            headers={"Content-Type": "text/plain"}, timeout=60,
        ) as resp:
            if resp.status != 200:
                detail = ""
                with contextlib.suppress(Exception):
                    detail = str((await resp.json(content_type=None)).get("message") or "")
                rt["genai_error"] = f"Frigate a refusé les réglages : {detail[:400] or resp.status}"
                return
        await _save_memo(hass, genai={"provider": settings["provider"], "model": settings["model"]} if settings else None)
    except Exception:  # noqa: BLE001
        _LOGGER.exception("Frigate GenAI settings failed")
        rt["genai_error"] = "Frigate ne répond pas. Vérifiez les caméras intelligentes, puis réessayez."
    finally:
        rt["genai_running"] = False


# --------------------------------------------------------------------------- assistant


def _entities_for_prompt(hass: HomeAssistant) -> list[dict[str, Any]]:
    ents = er.async_get(hass)
    areas = ar_reg.async_get(hass)
    out = []
    for state in sorted(hass.states.async_all(), key=lambda s: s.entity_id):
        entry = ents.async_get(state.entity_id)
        if entry is not None and (entry.hidden_by or entry.disabled_by or entry.platform == DOMAIN):
            continue
        area = areas.async_get_area(entry.area_id).name if entry and entry.area_id and areas.async_get_area(entry.area_id) else ""
        out.append({"entity_id": state.entity_id, "name": state.attributes.get("friendly_name") or state.entity_id, "area": area})
    notify = sorted(f"notify.{s}" for s in hass.services.async_services().get("notify", {}))
    out += [{"entity_id": n, "name": "notification"} for n in notify[:10]]
    return out


async def async_draft(hass: HomeAssistant, request: str, entity_id: str | None) -> dict[str, Any]:
    """Demande en français -> proposition vérifiée (rien n'est écrit)."""
    from homeassistant.components.automation.config import (
        async_validate_config_item,  # noqa: PLC0415
    )

    agents = sorted(hass.states.async_entity_ids("ai_task"))
    if not agents:
        raise _AiError("no_ai", "Reliez d'abord une IA à Home Assistant (ci-dessus).")
    agent = entity_id if entity_id in agents else agents[0]
    data = _data(hass)
    notify = str((data.store.settings.get("notify_service") if data and data.store else None) or "notify.notify")
    instructions = air.build_instructions(request, _entities_for_prompt(hass), notify)
    try:
        response = await hass.services.async_call(
            "ai_task", "generate_data",
            {"task_name": "Maison Facile : automatisme", "instructions": instructions, "entity_id": agent},
            blocking=True, return_response=True,
        )
    except Exception as err:  # noqa: BLE001
        _LOGGER.warning("AI task failed: %s", err)
        raise _AiError("ai_failed", "L'IA n'a pas répondu. Vérifiez qu'elle est allumée et reliée, puis réessayez.") from err
    try:
        draft = air.parse_answer((response or {}).get("data"))
    except ValueError as err:
        raise _AiError("ai_answer", str(err)) from err
    config = air.to_config(draft)
    existing = hass.states.async_entity_ids()
    domains = {e.split(".")[0] for e in existing} | set(air.ALLOWED_DOMAINS_IN_PROMPT)
    report = air.check(draft, existing, domains)
    problems = list(report["problems"])
    if not problems:
        try:
            await async_validate_config_item(hass, config["id"], dict(config))
        except Exception as err:  # noqa: BLE001
            problems.append(f"Home Assistant refuse cet automatisme : {str(err)[:300]}")
    conflicts = []
    if data and data.automations is not None:
        with contextlib.suppress(Exception):
            conflicts = xr.find_conflicts(await data.automations.async_user_automations(), report["entities"])
    names = {e: str((hass.states.get(e).attributes.get("friendly_name") if hass.states.get(e) else e) or e) for e in report["entities"]}
    draft_id = secrets.token_hex(8)
    rt = _rt(hass)
    now = time.time()
    rt["drafts"] = {k: v for k, v in rt["drafts"].items() if now - v["at"] < DRAFT_TTL}
    rt["drafts"][draft_id] = {"at": now, "draft": draft, "config": config, "request": request.strip()[:500], "ok": not problems, "sensitive": report["sensitive"]}
    return {
        "draft_id": draft_id,
        "alias": draft["alias"],
        "explication": draft["explication"],
        "devices": [names[e] for e in report["entities"]],
        "sensitive": report["sensitive"],
        "problems": problems,
        "conflicts": conflicts,
        "yaml": yaml.safe_dump(config, allow_unicode=True, sort_keys=False),
        "agent": agent,
    }


async def async_save(hass: HomeAssistant, draft_id: str, confirm_sensitive: bool) -> dict[str, Any]:
    rt = _rt(hass)
    item = rt["drafts"].get(draft_id)
    if item is None:
        raise _AiError("expired", "Cette proposition a expiré. Demandez-la à nouveau.")
    if not item["ok"]:
        raise _AiError("invalid", "Cette proposition contient des erreurs : elle ne peut pas être créée.")
    if item["sensitive"] and not confirm_sensitive:
        raise _AiError("confirm", "Cochez la case de confirmation : cet automatisme fait une action sensible.")
    data = _data(hass)
    await data.automations.async_check_writable()
    items = [i for i in _saved(hass) if i["config"]["id"] != item["config"]["id"]]
    items.append({"config": item["config"], "explication": item["draft"]["explication"], "request": item["request"]})
    await _save_list(hass, items)
    rt["drafts"].pop(draft_id, None)
    return async_status(hass)


class _AiError(Exception):
    def __init__(self, code: str, message_fr: str) -> None:
        super().__init__(message_fr)
        self.code = code
        self.message_fr = message_fr


# --------------------------------------------------------------------------- websocket


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/ai/status"})
@callback
def ws_status(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    connection.send_result(msg["id"], async_status(hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ai/genai",
        vol.Required("enabled"): bool,
        vol.Optional("provider", default=""): str,
        vol.Optional("model", default=""): str,
        vol.Optional("base_url", default=""): str,
        vol.Optional("api_key", default=""): str,
        vol.Optional("accept_cloud", default=False): bool,
    }
)
@callback
def ws_genai(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    rt = _rt(hass)
    if rt["genai_running"]:
        connection.send_error(msg["id"], "busy", "Un réglage est déjà en cours.")
        return
    settings = None
    if msg["enabled"]:
        error = air.genai_check(msg["provider"], msg["model"], msg["base_url"], msg["api_key"])
        if error:
            connection.send_error(msg["id"], "invalid", error)
            return
        if msg["provider"] != "ollama" and not msg["accept_cloud"]:
            connection.send_error(msg["id"], "consent_required", "Les images des caméras partiraient sur Internet : cochez la case pour accepter.")
            return
        settings = {k: msg[k] for k in ("provider", "model", "base_url", "api_key")}
    rt["genai_running"] = True
    task = hass.async_create_background_task(_run_genai(hass, settings), f"{DOMAIN}_genai")
    rt["tasks"].add(task)
    task.add_done_callback(rt["tasks"].discard)
    connection.send_result(msg["id"], {"started": True})


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ai/draft",
        vol.Required("request"): vol.All(str, vol.Length(min=5, max=500)),
        vol.Optional("entity_id"): str,
    }
)
@websocket_api.async_response
async def ws_draft(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    try:
        connection.send_result(msg["id"], await async_draft(hass, msg["request"], msg.get("entity_id")))
    except _AiError as err:
        connection.send_error(msg["id"], err.code, err.message_fr)


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ai/save",
        vol.Required("draft_id"): str,
        vol.Optional("confirm_sensitive", default=False): bool,
    }
)
@websocket_api.async_response
async def ws_save(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    from .automations import ProtectedFileError  # noqa: PLC0415

    try:
        connection.send_result(msg["id"], await async_save(hass, msg["draft_id"], msg["confirm_sensitive"]))
    except _AiError as err:
        connection.send_error(msg["id"], err.code, err.message_fr)
    except ProtectedFileError as err:
        connection.send_error(msg["id"], "protected", err.message_fr)


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/ai/delete", vol.Required("automation_id"): str})
@websocket_api.async_response
async def ws_delete(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    items = [i for i in _saved(hass) if i["config"]["id"] != msg["automation_id"]]
    await _save_list(hass, items)
    connection.send_result(msg["id"], async_status(hass))


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in (ws_status, ws_genai, ws_draft, ws_save, ws_delete):
        websocket_api.async_register_command(hass, command)

