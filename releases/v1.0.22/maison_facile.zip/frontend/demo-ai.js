// Démo de Réglages > IA : reconnaissance des visages et « Votre IA » (recipes.py, ai.py).
// Textes copiés de recipes_rules.py et ai_rules.py (à recopier s'ils changent).
const FACE_STEPS = [
  {
    "id": "consent",
    "title": "Votre accord",
    "what": "Un visage est une donnée personnelle très protégée (RGPD). Lisez et cochez chaque point.",
    "learn": "La reconnaissance faciale compare un visage filmé à des photos que vous avez enregistrées. Tout se passe dans la box : aucune image ne part sur Internet.",
    "by": "you"
  },
  {
    "id": "enable",
    "title": "Activer la reconnaissance dans Frigate",
    "what": "Maison Facile ajoute deux lignes aux réglages de Frigate, qui redémarre (une minute).",
    "learn": "« face_recognition: enabled: true » active la fonction ; « model_size: small » choisit le petit modèle, fait pour tourner sur le processeur d'un mini PC.",
    "by": "box"
  },
  {
    "id": "photos",
    "title": "Ajouter les photos de chaque personne",
    "what": "Dans Frigate, page Visages : « Ajouter un visage », le prénom, puis 3 à 5 photos de face, bien éclairées, sans lunettes de soleil. Le prénom est celui des messages (« Marie est arrivée »).",
    "learn": "Le modèle transforme chaque photo en une « empreinte » (une suite de nombres). Plusieurs photos donnent une empreinte plus fiable, sous différents éclairages. Vous pouvez aussi valider les visages que Frigate a vus récemment (onglet « Entraîner »).",
    "by": "you"
  },
  {
    "id": "test",
    "title": "Tester",
    "what": "Passez devant une caméra : le prénom reconnu s'affiche ici dans les secondes qui suivent.",
    "learn": "Si un visage n'est pas reconnu, ajoutez une photo prise à cet endroit-là : la lumière et l'angle de la caméra comptent beaucoup.",
    "by": "you"
  },
  {
    "id": "idea",
    "title": "Activer « Bienvenue »",
    "what": "L'idée « Bienvenue (visage reconnu) » vous prévient quand une personne du foyer arrive.",
    "learn": "Une idée de Maison Facile est un automatisme tout fait : quand le capteur « visage reconnu » change, un message part. Rien ne se passe pour un visage inconnu.",
    "by": "you"
  }
];
const FACE_CONSENT = ["Je n'enregistrerai que des personnes du foyer, et chacune est d'accord.", "Mes caméras ne filment ni la rue ni chez les voisins.", "J'ai compris que les visages restent dans la box et que je peux tout effacer à tout moment."];
const PROVIDERS = [
  {
    "domain": "ollama",
    "name": "Ollama (sur votre PC)",
    "kind": "local",
    "need": "Un PC allumé avec une carte graphique et Ollama installé (le mini PC de la box est trop faible).",
    "privacy": "Tout reste chez vous.",
    "cost": "Gratuit",
    "color": "#0E7A0D"
  },
  {
    "domain": "openai_conversation",
    "name": "OpenAI (ChatGPT)",
    "kind": "cloud",
    "need": "Une clé API OpenAI (compte sur platform.openai.com, avec crédit).",
    "privacy": "Vos demandes partent chez OpenAI.",
    "cost": "Payant à l'usage",
    "color": "#10A37F"
  },
  {
    "domain": "google_generative_ai_conversation",
    "name": "Google Gemini",
    "kind": "cloud",
    "need": "Une clé API Google AI Studio.",
    "privacy": "Vos demandes partent chez Google.",
    "cost": "Gratuit avec limites, puis payant",
    "color": "#4285F4"
  },
  {
    "domain": "anthropic",
    "name": "Anthropic (Claude)",
    "kind": "cloud",
    "need": "Une clé API Anthropic (console.anthropic.com, avec crédit).",
    "privacy": "Vos demandes partent chez Anthropic.",
    "cost": "Payant à l'usage",
    "color": "#C2185B"
  }
];

const YAML = `id: mf_ai_demo
alias: IA – Pluie et fenêtre ouverte
description: "Créé avec l'IA (Maison Facile) : quand il pleut et qu'une fenêtre est ouverte le soir, préviens-moi."
triggers:
  - trigger: state
    entity_id: weather.maison
    to: rainy
conditions:
  - condition: state
    entity_id: binary_sensor.chambre_fenetre
    state: "on"
  - condition: time
    after: "18:00:00"
actions:
  - action: notify.notify
    data:
      message: Il pleut et la fenêtre de la chambre est ouverte.
mode: single
`;

export function createDemoAi({ wait, wsError, frigateReady }) {
  const face = { consent: false, enabled: false, running: false, faces: [], seen: false };
  const ai = { entries: [], genai: null, running: false, automations: [], draft: null };
  const faceStatus = () => {
    const ready = frigateReady();
    const done = { consent: face.consent, enable: face.enabled, photos: face.faces.length > 0, test: face.seen, idea: false };
    let nextFound = false;
    const steps = FACE_STEPS.map((s) => {
      const state = done[s.id] ? "done" : face.running && s.id === "enable" ? "running" : "todo";
      const next = state === "todo" && !nextFound;
      if (next) nextFound = true;
      return { ...s, state, next, error: null };
    });
    return {
      available: true, ready, reachable: ready, message: ready ? "" : "Installez d'abord les caméras intelligentes (ci-dessus).",
      steps, consent_items: FACE_CONSENT, faces: face.faces, enabled: face.enabled,
      sensors: face.enabled ? [{ entity_id: "sensor.entree_last_recognized_face", name: "Entrée Last Recognized Face", state: face.seen ? "Marie" : "unknown" }] : [],
    };
  };
  const aiStatus = () => ({
    providers: PROVIDERS,
    entries: ai.entries,
    ai_task: ai.entries.length ? ["ai_task.ollama"] : [],
    frigate_ready: frigateReady(),
    genai: ai.genai,
    genai_running: ai.running,
    genai_error: null,
    automations: ai.automations,
  });
  return {
    "recipes/faces": async () => {
      // Démo : les photos « arrivent » quand on revient de la page Visages.
      if (face.enabled && face.openedLibrary && !face.faces.length) face.faces = [{ name: "Marie", photos: 4 }];
      if (face.faces.length && face.enabled) face.seen = true;
      return faceStatus();
    },
    "recipes/faces/consent": ({ accepted }) => {
      if ((accepted || []).length < FACE_CONSENT.length) throw wsError("consent_required", "Cochez chaque point pour continuer.");
      face.consent = true;
      return faceStatus();
    },
    "recipes/faces/set": ({ enabled }) => {
      face.running = true;
      setTimeout(() => { face.enabled = enabled; face.running = false; if (enabled) face.openedLibrary = true; }, 2500);
      return { started: true };
    },
    "ai/status": aiStatus,
    "ai/genai": ({ enabled, provider, model }) => {
      ai.running = true;
      setTimeout(() => { ai.genai = enabled ? { provider, model } : null; ai.running = false; }, 2500);
      return { started: true };
    },
    "ai/draft": async ({ request }) => {
      await wait(1800);
      ai.draft = request;
      return {
        draft_id: "demo", alias: "IA – Pluie et fenêtre ouverte",
        explication: "Le soir après 18 h, s'il se met à pleuvoir alors que la fenêtre de la chambre est ouverte, vous recevez une notification.",
        devices: ["Météo", "Fenêtre chambre", "Notification"], sensitive: [], problems: [], conflicts: [], yaml: YAML, agent: "ai_task.ollama",
      };
    },
    "ai/save": async () => {
      await wait(500);
      if (!ai.draft) throw wsError("expired", "Cette proposition a expiré. Demandez-la à nouveau.");
      ai.automations = [{ id: "mf_ai_demo", alias: "IA – Pluie et fenêtre ouverte", explication: "Le soir, s'il pleut et que la fenêtre de la chambre est ouverte : notification.", request: ai.draft }];
      ai.draft = null;
      return aiStatus();
    },
    "ai/delete": ({ automation_id }) => {
      ai.automations = ai.automations.filter((x) => x.id !== automation_id);
      return aiStatus();
    },
    /** Formulaire officiel d'Ollama, simulé (POST/GET/DELETE config/config_entries/flow). */
    async callApi(method, path, data) {
      await wait(400);
      if (method === "DELETE") return null;
      if (method === "POST" && path === "config/config_entries/flow") {
        return { type: "form", flow_id: "demo-flow", handler: data.handler, step_id: "user", errors: {},
          data_schema: [{ name: "url", required: true, selector: { text: { type: "url" } } }] };
      }
      if (method === "POST" && path === "config/config_entries/flow/demo-flow") {
        if (!/^https?:\/\//.test(String(data.url || ""))) {
          return { type: "form", flow_id: "demo-flow", step_id: "user", errors: { base: "cannot_connect" }, data_schema: [{ name: "url", required: true, selector: { text: { type: "url" } } }] };
        }
        ai.entries = [{ domain: "ollama", title: "Ollama", state: "loaded" }];
        return { type: "create_entry", flow_id: "demo-flow" };
      }
      throw wsError("not_found", "Not found");
    },
    translations: {
      "component.ollama.config.step.user.data.url": "URL",
      "component.ollama.config.step.user.description": "Adresse de votre serveur Ollama, par exemple http://192.168.1.50:11434",
      "component.ollama.config.error.cannot_connect": "Échec de connexion",
    },
  };
}
