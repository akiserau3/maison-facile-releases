// Fake Home Assistant object for demos and tests without Home Assistant.
// Responses follow CONTRACT.md §5 (+ precisions from NOTES_moteur / NOTES_entretien).
// URL options: ?wizard=1 (first start), ?theme=sombre|contraste, ?page=energy…, ?empty=1 (no energy data),
// ?noradio=1 (no wireless antenna), ?user=famille (non-admin account),
// ?provision=1 (box prepared by the installer: the "On prépare votre maison…" step plays a
// sequence where the cameras step fails; "Réessayer" then succeeds).
// ?commercial=0 (commercial mode off: Home Assistant visible) · ?pin=1 (installer code "1234")
// ?kiosk=0 (simulates a Home Assistant that ignores "hass-kiosk-mode": the panel falls back to
// "hass-dock-sidebar"). A fake Home Assistant sidebar (demo.html) shows when HA would show it.
// window.mfDemo.toggle("binary_sensor.chambre_fenetre") opens / closes a window from the console.
// Idées: a Samsung TV is "found on the network" (discovery flow); ?mail=1 = idea « Courrier arrivé »
// already active with mail waiting (home tile); ?tv=1 = the TV is already added;
// window.mfDemo.mail() = the postman passes (when the idea is active).
// Apparence: ?theme=halloween|noel|printemps… (a seasonal theme chosen by hand) · ?auto=fetes_saisons|fetes|saisons|non
// · ?style=orbite|neon|jumeau|holo · ?date=2026-10-28 (date used for the theme of the day) · ?anim=0 · ?liked=neon,holo
// Guide « Bien choisir ses appareils »: ?shop=1 (an example « Où l'acheter ? » address) · ?cloud=1 (Tuya / Smart Life in use)
// Sans matériel (installer v1.4): ?equipment=none = box installed by a private person without any
// hardware: no antenna, no device, discovery path (wizard « Votre maison sans matériel », empty home,
// soft notice in Dépannage). ?profile=particulier|pro = who installed the box (texts).

import { DEMO_IDEAS } from "./demo-ideas.js";
import { DEMO_GUIDE, NO_PURCHASE_ROLES, DEMO_STARTER } from "./demo-guide.js";
import { validShopUrl } from "./components/shop-url.js";
import { createDemoBirthdays, birthdayPeople, birthdaysActive } from "./demo-birthdays.js";
import { appearanceSummary, toYMD, THEMES as DEMO_THEMES, THEME_AUTO_MODES, HOME_STYLES } from "./components/theme-rules.js";
import { createDemoApps } from "./demo-apps.js";
import { createDemoRecipes } from "./demo-recipes.js";
import { createDemoAi } from "./demo-ai.js";

const params = new URLSearchParams(window.location.search);
const PALETTE = ["#E8590C", "#0E7A0D", "#6B47B8", "#0067C0", "#00838F", "#C2185B", "#5D6B7A", "#B8860B"];
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clone = (o) => JSON.parse(JSON.stringify(o));

function camSvg(label, c1, c2) {
  const t = new Date().toLocaleTimeString("fr-FR");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="640" height="360" fill="url(#g)"/><rect x="250" y="120" width="140" height="200" rx="8" fill="rgba(255,255,255,0.10)"/><circle cx="420" cy="220" r="5" fill="rgba(255,255,255,0.4)"/><path d="M0 330 L640 300 L640 360 L0 360z" fill="rgba(0,0,0,0.25)"/><text x="620" y="340" font-family="monospace" font-size="18" fill="rgba(255,255,255,0.75)" text-anchor="end">${label} ${t}</text></svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

const ROOMS = [
  { area_id: "salon", name: "Salon", color: PALETTE[0], icon: "sofa" },
  { area_id: "cuisine", name: "Cuisine", color: PALETTE[1], icon: "kitchen" },
  { area_id: "chambre", name: "Chambre", color: PALETTE[2], icon: "bed" },
  { area_id: "bureau", name: "Bureau", color: PALETTE[3], icon: "desk" },
];

const DEVICES = [
  { device_id: "d_salon_plafonnier", name: "Plafonnier du salon", type: "lumiere", type_label: "Lumière", area_id: "salon", suggested_area_id: "salon", battery: null, available: true, entities: { light: "light.salon_plafonnier" } },
  { device_id: "d_salon_lampe", name: "Lampe du canapé", type: "lumiere", type_label: "Lumière", area_id: "salon", suggested_area_id: "salon", battery: null, available: true, entities: { light: "light.salon_lampe" } },
  { device_id: "d_salon_prise_tv", name: "Prise télé", type: "prise", type_label: "Prise connectée", area_id: "salon", suggested_area_id: "salon", battery: null, available: true, entities: { switch: "switch.prise_tele", power: "sensor.prise_tele_power", energy: "sensor.prise_tele_energy" } },
  { device_id: "d_salon_thermo", name: "Thermomètre du salon", type: "thermo", type_label: "Thermomètre", area_id: "salon", suggested_area_id: "salon", battery: 82, available: true, entities: { temperature: "sensor.salon_temperature", humidity: "sensor.salon_humidity", battery: "sensor.salon_thermo_battery" } },
  { device_id: "d_salon_radiateur", name: "Radiateur du salon", type: "chauffage", type_label: "Chauffage", area_id: "salon", suggested_area_id: "salon", battery: null, available: true, entities: { climate: "climate.salon" } },
  { device_id: "d_porte", name: "Porte d'entrée", type: "ouverture", type_label: "Détecteur d'ouverture", area_id: "salon", suggested_area_id: "salon", battery: 64, available: true, entities: { contact: "binary_sensor.porte_entree" } },
  { device_id: "d_cuisine_plafonnier", name: "Plafonnier de la cuisine", type: "lumiere", type_label: "Lumière", area_id: "cuisine", suggested_area_id: "cuisine", battery: null, available: true, entities: { light: "light.cuisine_plafonnier" } },
  { device_id: "d_cuisine_thermo", name: "Thermomètre de la cuisine", type: "thermo", type_label: "Thermomètre", area_id: "cuisine", suggested_area_id: "cuisine", battery: 77, available: true, entities: { temperature: "sensor.cuisine_temperature", humidity: "sensor.cuisine_humidity" } },
  { device_id: "d_fumee_cuisine", name: "Détecteur de fumée de la cuisine", type: "fumee", type_label: "Détecteur de fumée", area_id: "cuisine", suggested_area_id: "cuisine", battery: 90, available: true, entities: { smoke: "binary_sensor.fumee_cuisine" } },
  { device_id: "d_chambre_plafonnier", name: "Plafonnier de la chambre", type: "lumiere", type_label: "Lumière", area_id: "chambre", suggested_area_id: "chambre", battery: null, available: true, entities: { light: "light.chambre_plafonnier" } },
  { device_id: "d_chambre_fenetre", name: "Fenêtre de la chambre", type: "ouverture", type_label: "Détecteur d'ouverture", area_id: "chambre", suggested_area_id: "chambre", battery: 5, available: true, entities: { contact: "binary_sensor.chambre_fenetre" } },
  { device_id: "d_chambre_thermo", name: "Thermomètre de la chambre", type: "thermo", type_label: "Thermomètre", area_id: "chambre", suggested_area_id: "chambre", battery: 71, available: true, entities: { temperature: "sensor.chambre_temperature", humidity: "sensor.chambre_humidity" } },
  { device_id: "d_chambre_radiateur", name: "Radiateur de la chambre", type: "chauffage", type_label: "Chauffage", area_id: "chambre", suggested_area_id: "chambre", battery: null, available: true, entities: { climate: "climate.chambre" } },
  { device_id: "d_fumee_couloir", name: "Détecteur de fumée du couloir", type: "fumee", type_label: "Détecteur de fumée", area_id: "chambre", suggested_area_id: "chambre", battery: 88, available: true, entities: { smoke: "binary_sensor.fumee_couloir" } },
  { device_id: "d_bureau_lampe", name: "Lampe de bureau", type: "lumiere", type_label: "Lumière", area_id: "bureau", suggested_area_id: "bureau", battery: null, available: true, entities: { light: "light.bureau_lampe" } },
  { device_id: "d_bureau_thermo", name: "Thermomètre du bureau", type: "thermo", type_label: "Thermomètre", area_id: "bureau", suggested_area_id: "bureau", battery: 93, available: true, entities: { temperature: "sensor.bureau_temperature", humidity: "sensor.bureau_humidity" } },
  { device_id: "d_mouvement_entree", name: "Détecteur de mouvement de l'entrée", type: "mouvement", type_label: "Détecteur de mouvement", area_id: null, suggested_area_id: "salon", battery: 58, available: true, entities: { motion: "binary_sensor.mouvement_entree" } },
  { device_id: "d_camera_entree", name: "Caméra de l'entrée", type: "camera", type_label: "Caméra", area_id: null, suggested_area_id: null, battery: null, available: true, entities: { camera: "camera.entree" } },
  { device_id: "d_camera_jardin", name: "Caméra du jardin", type: "camera", type_label: "Caméra", area_id: null, suggested_area_id: null, battery: null, available: true, entities: { camera: "camera.jardin" } },
];

function st(entity_id, state, attributes = {}) {
  const now = new Date().toISOString();
  return { entity_id, state: String(state), attributes, last_changed: now, last_updated: now, context: { id: "demo" } };
}

function initialStates() {
  const s = {};
  const add = (o) => (s[o.entity_id] = o);
  add(st("select.maison_facile_mode", "maison", { options: ["maison", "absent", "nuit"], friendly_name: "Mode de la maison" }));
  add(st("weather.maison", "partlycloudy", { temperature: 12, friendly_name: "Météo" }));
  add(st("light.salon_plafonnier", "on", { friendly_name: "Plafonnier du salon" }));
  add(st("light.salon_lampe", "on", { friendly_name: "Lampe du canapé" }));
  add(st("switch.prise_tele", "off", { friendly_name: "Prise télé" }));
  add(st("sensor.prise_tele_power", "3.1", { unit_of_measurement: "W" }));
  add(st("sensor.salon_temperature", "21.5", { unit_of_measurement: "°C" }));
  add(st("sensor.salon_humidity", "48", { unit_of_measurement: "%" }));
  add(st("climate.salon", "heat", { temperature: 20, current_temperature: 21.5, min_temp: 7, max_temp: 28 }));
  add(st("binary_sensor.porte_entree", "off", { device_class: "door" }));
  add(st("light.cuisine_plafonnier", "off", {}));
  add(st("sensor.cuisine_temperature", "20.8", { unit_of_measurement: "°C" }));
  add(st("sensor.cuisine_humidity", "55", { unit_of_measurement: "%" }));
  add(st("binary_sensor.fumee_cuisine", "off", { device_class: "smoke" }));
  add(st("light.chambre_plafonnier", "off", {}));
  add(st("binary_sensor.chambre_fenetre", "on", { device_class: "window" }));
  add(st("sensor.chambre_temperature", "17.9", { unit_of_measurement: "°C" }));
  add(st("sensor.chambre_humidity", "51", { unit_of_measurement: "%" }));
  add(st("climate.chambre", "heat", { temperature: 18, current_temperature: 17.9, min_temp: 7, max_temp: 28 }));
  add(st("binary_sensor.fumee_couloir", "off", { device_class: "smoke" }));
  add(st("light.bureau_lampe", "on", {}));
  add(st("sensor.bureau_temperature", "20.2", { unit_of_measurement: "°C" }));
  add(st("sensor.bureau_humidity", "46", { unit_of_measurement: "%" }));
  add(st("binary_sensor.mouvement_entree", "off", { device_class: "motion" }));
  add(st("camera.entree", "idle", { friendly_name: "Caméra de l'entrée", entity_picture: camSvg("ENTRÉE", "#2B3340", "#1A1F27") }));
  add(st("camera.jardin", "idle", { friendly_name: "Caméra du jardin", entity_picture: camSvg("JARDIN", "#2F3A33", "#1A221D") }));
  return s;
}

const RECO_DEFS = [
  { id: "lumiere_nuit_mouvement", title: "Allumer doucement la lumière quand on passe la nuit", why: "Vous avez 1 détecteur de mouvement", recommended: true, options: [{ key: "brightness", label: "Force de la lumière", choices: [{ value: "doux", label: "Douce (20 %)", recommended: true }, { value: "normal", label: "Normale (60 %)", recommended: false }] }], values: { brightness: "doux" } },
  { id: "fenetre_chauffage", title: "Prévenir si une fenêtre est ouverte avec le chauffage", why: "Vous avez des détecteurs d'ouverture et des thermomètres", recommended: true, options: [], values: {} },
  { id: "tout_eteindre_depart", title: "Tout éteindre quand toute la maison est partie", why: "Utilise les téléphones de la famille", recommended: true, options: [], values: {} },
  { id: "alerte_fumee", title: "Prévenir tout de suite en cas de fumée", why: "Vous avez 2 détecteurs de fumée", recommended: true, options: [], values: {} },
  { id: "alerte_intrusion", title: "Prévenir si une porte s'ouvre quand vous êtes absent", why: "Vous avez des détecteurs d'ouverture et de mouvement", recommended: true, options: [], values: {} },
  { id: "mode_nuit_heure", title: "Passer en mode nuit tous les soirs", why: "Selon votre choix ci-dessous", recommended: false, options: [{ key: "night_time", label: "Heure du mode nuit", choices: [{ value: "22:00", label: "22 h", recommended: false }, { value: "23:00", label: "23 h", recommended: true }] }], values: { night_time: "23:00" } },
  { id: "veille_nuit", title: "Couper la télé en veille la nuit", why: "Vous avez une prise qui mesure la consommation", recommended: false, options: [], values: {} },
  { id: "alerte_froid_humide", title: "Prévenir s'il fait trop froid ou trop humide", why: "Vous avez 4 thermomètres", recommended: false, options: [], values: {} },
];

const PROBLEMS = [
  {
    id: "low_battery_binary_sensor.chambre_fenetre", severity: "warning",
    title: "Le détecteur de la fenêtre de la chambre ne répond plus", status: "Depuis 2 jours · À faire par vous, 2 minutes",
    why: "Sa pile est presque vide : il restait 5 % lors de son dernier signal.",
    steps: ["Faites glisser le couvercle du capteur pour l'ouvrir.", "Remplacez la pile par le même modèle (il est écrit sur l'ancienne).", "Appuyez une fois sur le petit bouton du capteur."],
    fix: { kind: "manual", label: "C'est fait, vérifier", choices: [] },
    tech: "binary_sensor.chambre_fenetre : unavailable\nsensor.chambre_fenetre_battery : 5 %\nlast_seen : il y a 2 j (ZHA)",
  },
  {
    id: "camera_unavailable_camera.entree", severity: "error",
    title: "La caméra de l'entrée n'envoie plus d'image", status: "Depuis ce matin · Réparable automatiquement",
    why: "Elle a perdu la connexion WiFi après la coupure de courant de ce matin.", steps: [],
    fix: { kind: "auto", label: "Réparer pour moi", choices: [] },
    tech: 'camera.entree : unavailable\nffmpeg process exited\nNo route to host 192.168.1.42\nAction auto : rechargement de l\'intégration',
  },
  {
    id: "disk_usage", severity: "info",
    title: "La mémoire de la box est presque pleine (92 %)", status: "Réparable automatiquement · un choix à faire",
    why: "L'historique de la maison prend de la place. Il faut garder moins de jours.", steps: [],
    fix: { kind: "auto", label: "Réparer pour moi", choices: [{ value: "7", label: "Garder 7 jours", recommended: true }, { value: "3", label: "Garder 3 jours", recommended: false }] },
    tech: "supervisor : disk usage 92 %\nrecorder : 4,1 Go\nAction auto : recorder.purge keep_days=<choix> repack=true",
  },
];

function energy(period) {
  if (params.get("empty") === "1" || noEquipment) return { total_kwh: 0, cost_eur: 0, previous_kwh: 0, change_pct: null, buckets: [], top: [], has_data: false };
  const defs = {
    day: { labels: ["0 h", "3 h", "6 h", "9 h", "12 h", "15 h", "18 h", "21 h"], values: [0.9, 0.7, 2.0, 2.8, 1.8, 1.5, 4.3, 3.5], prev: 18.9 },
    week: { labels: ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"], values: [11.2, 10.4, 12.9, 9.7, 10.8, 18.9, 17.2], prev: 99.6 },
    month: { labels: ["Sem. 1", "Sem. 2", "Sem. 3", "Sem. 4"], values: [72.5, 81.3, 97.0, 118.1], prev: 341.2 },
  };
  const d = defs[period] || defs.day;
  const total = Math.round(d.values.reduce((a, b) => a + b, 0) * 10) / 10;
  const change = Math.round(((total - d.prev) / d.prev) * 1000) / 10;
  const shares = [["Chauffage", 0.58], ["Cuisine", 0.21], ["Télé et salon", 0.12], ["Bureau", 0.09]];
  return {
    total_kwh: total, cost_eur: Math.round(total * 0.25 * 100) / 100, previous_kwh: d.prev, change_pct: change,
    buckets: d.labels.map((label, i) => ({ label, kwh: d.values[i] })),
    top: shares.map(([name, p]) => ({ name, kwh: Math.round(total * p * 10) / 10, share_pct: Math.round(p * 100) })),
    has_data: true,
  };
}

const REPORT = `Rapport Maison Facile — à transmettre à votre installateur
Date : ${new Date().toLocaleString("fr-FR")}
Version Maison Facile : 1.0.0 · Home Assistant : 2026.10.2 (Home Assistant OS)
Antenne sans fil : ZHA, en ligne · 19 appareils (2 ne répondent pas)

Problèmes en cours :
- [warning] low_battery_binary_sensor.chambre_fenetre — pile 5 %, dernier signal il y a 2 j
- [error] camera_unavailable_camera.entree — ffmpeg process exited, No route to host 192.168.1.42
- [info] disk_usage — 92 % (recorder 4,1 Go)

Journal (extraits expurgés) :
2026-10-27 06:12:03 WARNING (MainThread) [homeassistant.components.generic] Error getting new camera image from Entrée
2026-10-27 06:12:33 ERROR (MainThread) [zha] Device 00:**:**:**:**:**:**:3f did not respond

(mots de passe, jetons et adresse IP publique retirés)`;

const isAdmin = params.get("user") !== "famille";
// ?equipment=none: installed without hardware (no antenna, no device: discovery path).
const noEquipment = params.get("equipment") === "none";
const noRadio = noEquipment || params.get("noradio") === "1";
const demoProfile = ["particulier", "pro"].includes(params.get("profile")) ? params.get("profile") : noEquipment ? "particulier" : "pro";
// Soft notice of the Dépannage on a box without hardware (doctor_rules._rule_radio_not_yet).
const RADIO_NOT_YET = {
  id: "radio_not_yet", severity: "info", title: "Pas encore d'antenne Zigbee : c'est normal", status: "Rien à réparer · voici quoi acheter",
  why: "Votre box marche déjà : météo, anniversaires, thèmes de fêtes, appareils trouvés sur le réseau. Pour les capteurs, prises et lumières sans fil, il lui faudra une petite antenne Zigbee (une clé USB).",
  steps: ["Regardez « Quoi acheter ? » : l'antenne et 2 ou 3 capteurs pour bien commencer.", "Branchez l'antenne sur la box, de préférence au bout d'une petite rallonge USB.", "La box la reconnaît toute seule : ce message disparaît."],
  fix: { kind: "none", label: "Quoi acheter ?", choices: [] }, tech: "Aucune antenne ni appareil (parcours découverte)",
  notice: true, link: { page: "guide", params: { tab: "buy" }, label: "Quoi acheter ?" },
};

/** Apparence settings of the demo from the URL (?theme, ?auto, ?style, ?anim, ?liked). */
function demoAppearanceSettings() {
  const theme = DEMO_THEMES.includes(params.get("theme")) ? params.get("theme") : "clair";
  // A seasonal / holiday theme asked in the URL is shown as if chosen by hand.
  const handPicked = !["clair", "sombre", "contraste"].includes(theme);
  const auto = THEME_AUTO_MODES.includes(params.get("auto")) ? params.get("auto") : handPicked ? "non" : "fetes_saisons";
  return {
    theme,
    theme_auto: auto,
    animations: params.get("anim") !== "0",
    home_style: HOME_STYLES.includes(params.get("style")) ? params.get("style") : "maison_facile",
    liked_styles: (params.get("liked") || "").split(",").filter((x) => HOME_STYLES.includes(x)),
  };
}

/** Day used for the theme of the day (?date=2026-10-28, else today). */
const demoDay = () => toYMD(/^\d{4}-\d{2}-\d{2}$/.test(params.get("date") || "") ? params.get("date") : new Date());

const PROVISION_LABELS = [
  ["settings", "Réglages de votre installateur"],
  ["zigbee", "Antenne sans fil"],
  ["weather", "Météo"],
  ["cameras", "Caméras"],
  ["hacs", "Outils de l'installateur"],
];
// [step, duration ms, final state, message]
const PROVISION_SCRIPT = [
  ["settings", 900, "done", "Les coordonnées de votre installateur sont enregistrées."],
  ["zigbee", 2600, "done", "L'antenne sans fil est prête."],
  ["weather", 1100, "done", "La météo de votre maison est active."],
  ["cameras", 2200, "error", "1 caméra ajoutée. Caméra 192.168.1.41 : elle ne répond pas (vérifiez qu'elle est branchée et son adresse)."],
  ["hacs", 700, "done", "Les outils de l'installateur sont prêts. Votre installateur les activera lors de son passage."],
];


// ---------------------------------------------------------------------------
// Idées: small copy of ideas_rules.py for the demo (same statuses and texts).
// ---------------------------------------------------------------------------

const norm = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[’_]/g, (c) => (c === "_" ? " " : "'")).toLowerCase();
const hasAny = (text, words) => (words || []).some((w) => norm(text).includes(norm(w)));
const DETECT_LABELS = { samsungtv: "une télé Samsung", cast: "un appareil Chromecast", sonos: "une enceinte Sonos" };
const BADGES = { actif: "Actif", pret: "Prêt à activer", manque: "Il manque un capteur", attente: "Activée dès que le capteur sera là", non_pertinent: "Pas encore pour vous" };

function demoCandidates(store, states, role) {
  const out = [];
  const roomName = (a) => (store.rooms.find((r) => r.area_id === a) || {}).name || "";
  for (const d of store.devices) {
    const e = d.entities || {};
    let id = null;
    if (role === "tv" && d.type === "tv") id = e.media;
    else if (role === "speaker" && d.type === "enceinte") id = e.media;
    else if (e[role]) id = e[role];
    if (id) out.push({ entity_id: id, name: d.name, area_id: d.area_id, text: `${d.name} ${id} ${roomName(d.area_id)}`, device: d });
  }
  if (role === "weather") for (const id of Object.keys(states).filter((k) => k.startsWith("weather."))) out.push({ entity_id: id, name: "Météo", area_id: null, text: id });
  if (role === "phone") out.push({ entity_id: "notify.mobile_app_marie", name: "Téléphone de Marie", area_id: null, text: "" });
  if (role === "birthday") return birthdayPeople().map((p) => ({ entity_id: `birthday.${p.id}`, name: p.name, area_id: null, text: p.name })).sort((a, b) => a.name.localeCompare(b.name, "fr"));
  return out.sort((a, b) => a.entity_id.localeCompare(b.entity_id));
}

function demoResolve(idea, store, states, entry) {
  const resolved = {};
  const order = [...idea.needs].sort((a, b) => (a.same_room_as ? 1 : 0) - (b.same_room_as ? 1 : 0));
  for (const need of order) {
    const relaxed = [];
    for (const role of need.roles) for (const c of demoCandidates(store, states, role)) if (!relaxed.some((x) => x.entity_id === c.entity_id)) relaxed.push(c);
    let pool = relaxed.filter((c) => !(need.exclude_words && hasAny(c.text, need.exclude_words)));
    pool.forEach((c) => (c.preferred = !!need.prefer && hasAny(c.text, need.prefer)));
    if (need.require_prefer) pool = pool.filter((c) => c.preferred);
    let anchor = null;
    if (need.same_room_as) {
      anchor = (resolved[need.same_room_as]?.chosen || [])[0]?.area_id || null;
      if (need.strict_room) pool = pool.filter((c) => anchor && c.area_id === anchor);
    }
    pool.sort((a, b) => (b.preferred ? 1 : 0) - (a.preferred ? 1 : 0));
    const wanted = ((entry?.devices || {})[need.key] || []).map((id) => relaxed.find((c) => c.entity_id === id)).filter(Boolean);
    let chosen = wanted.length ? wanted : pool.length ? (need.multiple ? (need.strict_room ? pool : pool.filter((c) => c.preferred).length ? pool.filter((c) => c.preferred) : pool) : [pool[0]]) : [];
    if (!need.multiple) chosen = chosen.slice(0, 1);
    const choices = [...pool];
    for (const c of [...chosen, ...relaxed]) if (!choices.some((x) => x.entity_id === c.entity_id)) choices.push(c);
    resolved[need.key] = { need, chosen, choices, have: chosen.length > 0 };
  }
  return idea.needs.map((n) => resolved[n.key]);
}

function demoOptions(idea, values) {
  const out = {};
  for (const o of idea.options) {
    const v = (values || {})[o.key];
    out[o.key] = v === undefined ? o.default : o.type === "bool" ? !!v : o.type === "choice" ? (o.choices.some((c) => c.value === v) ? v : o.default) : v;
  }
  return out;
}

export function createDemoHass() {
  const listeners = new Set();
  let states = initialStates();
  const store = {
    onboarded: params.get("wizard") !== "1",
    rooms: params.get("wizard") === "1" ? [] : clone(ROOMS),
    devices: noEquipment ? [] : clone(DEVICES),
    settings: { ...demoAppearanceSettings(), update_mode: "auto", update_channel: "stable", night_mode: "hour", night_time: "23:00", morning_time: "07:00", kwh_price: 0.25, notify_service: "notify.notify", installer_name: "Domotique du Nord", installer_contact: "03 27 00 00 00", versions_url: "https://example.invalid/versions.json", commercial_mode: params.get("commercial") !== "0", expert_mode: params.get("expert") === "1", shop_url: params.get("shop") === "1" ? "https://example.org/acheter/{need}" : "", profile: demoProfile, ...(noEquipment ? { equipment: "none", radio_expected: false } : {}) },
    recos: clone(RECO_DEFS).map((r) => ({ ...r, enabled: r.id === "mode_nuit_heure" ? true : r.recommended })),
    problems: noEquipment ? [clone(RADIO_NOT_YET)] : clone(PROBLEMS),
    heating_pauses: {},
    update: { installed: "1.0.0", latest: "1.1.0", phase: "idle", progress: 0, message_fr: "", last_backup: new Date(new Date().setHours(3, 0, 0, 0)).toISOString() },
  };
  if (params.get("wizard") === "1") for (const d of store.devices) d.area_id = null;
  if (demoProfile === "particulier") Object.assign(store.settings, { installer_name: "", installer_contact: "" });
  // Commercial mode (NOTES_commercial.md): the demo keeps the code in clear, the box never does.
  const adv = { pin: params.get("pin") === "1" ? "1234" : "", until: 0, failures: [] };
  const advUnlocked = () => isAdmin && adv.until > Date.now();
  const advStatus = () => ({
    commercial_mode: store.settings.commercial_mode !== false && store.settings.expert_mode !== true,
    unlocked: advUnlocked(),
    until: advUnlocked() ? new Date(adv.until).toISOString() : null,
    pin_set: !!adv.pin,
    is_admin: isAdmin,
  });
  const canManage = () => isAdmin && (store.settings.commercial_mode === false || store.settings.expert_mode === true || advUnlocked());
  let shell = { kioskMode: false, dockedSidebar: "docked" };
  const pairingSubs = new Set();
  const updateSubs = new Set();
  const provisionSubs = new Set();
  const withProvision = params.get("provision") === "1";
  const provision = {
    started: false,
    done: false,
    steps: PROVISION_LABELS.map(([id, label_fr]) => ({ id, label_fr, state: withProvision ? "pending" : "done", message_fr: "" })),
  };
  const provisionStatus = () => {
    if (!withProvision) return { active: false, done: false, kit: null, steps: [] };
    const active = provision.steps.some((x) => x.state === "pending" || x.state === "running");
    return { active, done: provision.done, kit: { kit: "securite", zigbee: "zha", cameras: "reolink", camera_count: 2, hacs_files: true, box_name: "Ma maison" }, steps: clone(provision.steps) };
  };
  const provisionPublish = () => {
    const payload = provisionStatus();
    for (const cb of provisionSubs) cb(clone(payload));
  };
  const provisionSet = (id, state, message_fr = "") => {
    const step = provision.steps.find((x) => x.id === id);
    Object.assign(step, { state, message_fr });
    provisionPublish();
  };
  const runProvision = async (script) => {
    for (const [id, ms, state, message] of script) {
      provisionSet(id, "running", id === "zigbee" ? "On cherche l'antenne sans fil…" : "");
      await wait(ms);
      provisionSet(id, state, message);
      if (state === "error" && !store.problems.some((p) => p.id === `provision_failed_${id}`)) {
        store.problems.push({
          id: `provision_failed_${id}`, severity: "warning", title: "Préparation de la box : « Caméras » n'a pas abouti",
          status: "Réparable automatiquement", why: message,
          steps: ["Vérifiez que les caméras sont branchées et allumées.", "Appuyez sur « Réessayer »."],
          fix: { kind: "auto", label: "Réessayer", choices: [] }, tech: `step : ${id}\nAction auto : provision/retry ${id}`,
        });
      }
      if (state === "done") store.problems = store.problems.filter((p) => p.id !== `provision_failed_${id}`);
    }
    provision.done = true;
    provisionPublish();
  };
  const startProvision = () => {
    if (!withProvision || provision.started) return;
    provision.started = true;
    setTimeout(() => runProvision(PROVISION_SCRIPT), 600);
  };
  let pairingTimer = null;
  let hass;

  // ----- Idées (CONTRACT §11) -------------------------------------------------------
  const ideas = { entries: {}, seen: new Set(), flows: [{ flow_id: "flow_demo_tv", handler: "samsungtv", name: "Télé du salon" }] };
  const demoRecipes = createDemoRecipes({ wait, wsError: (c, m) => wsError(c, m) });
  const { callApi: demoCallApi, translations: demoTranslations, ...demoAi } = createDemoAi({
    wait, wsError: (c, m) => wsError(c, m), frigateReady: () => demoRecipes["recipes/frigate"]().complete,
  });
  if (params.get("frigate") === "1") demoRecipes._markAll();
  const MAIL_FLAG = "switch.maison_facile_courrier";
  const BIN_FLAG = "switch.maison_facile_poubelles";  // « Poubelles à sortir » (attribute bins)
  // « Anniversaires » (demo-birthdays.js): idea run by a module, a birthday today.
  const bd = createDemoBirthdays({ wsError: (c, m) => wsError(c, m), params });
  // « En écoute » : une enceinte qui joue (?music=0 pour l'enlever). Pochette dessinée ici
  // (la démo n'utilise aucune image extérieure).
  if (params.get("music") !== "0") {
    const cover = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FF9A3D"/><stop offset=".55" stop-color="#D9346B"/><stop offset="1" stop-color="#6B47B8"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><circle cx="50" cy="50" r="26" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="3"/><circle cx="50" cy="50" r="6" fill="#fff" fill-opacity=".8"/></svg>');
    states["media_player.enceinte_cuisine"] = st("media_player.enceinte_cuisine", "playing", {
      friendly_name: "Enceinte de la cuisine", media_title: "Lumières du soir", media_artist: "Les Exemples", media_album_name: "Démo",
      entity_picture: cover, media_duration: 214, media_position: 71, media_position_updated_at: new Date().toISOString(),
      volume_level: 0.35, supported_features: 1 | 4 | 16 | 32 | 16384,
    });
  }
  states[MAIL_FLAG] = st(MAIL_FLAG, "off", { friendly_name: "Courrier en attente", arrived_at: null });
  states[BIN_FLAG] = st(BIN_FLAG, "off", { friendly_name: "Poubelles à sortir", reminded_at: null, bins: null });
  if (params.get("bins") === "1") {
    // The evening before a collection: « Ce soir : sortez le bac jaune et le bac à verre ».
    ideas.entries.poubelles = { status: "active", options: {} };
    states[BIN_FLAG] = st(BIN_FLAG, "on", { friendly_name: "Poubelles à sortir", reminded_at: new Date(new Date().setHours(19, 0, 0, 0)).toISOString(), bins: "le bac jaune et le bac à verre" });
  }
  const addTv = () => {
    if (store.devices.some((d) => d.device_id === "d_tv")) return;
    store.devices.push({ device_id: "d_tv", name: "Télé du salon", type: "tv", type_label: "Télévision", area_id: "salon", suggested_area_id: "salon", battery: null, available: true, entities: { media: "media_player.tele_salon" } });
    states = { ...states, "media_player.tele_salon": st("media_player.tele_salon", "playing", { friendly_name: "Télé du salon", device_class: "tv" }) };
    ideas.flows = ideas.flows.filter((f) => f.handler !== "samsungtv");
  };
  if (params.get("tv") === "1") addTv();
  if (params.get("mail") === "1") {
    store.devices.push({ device_id: "d_boite", name: "Boîte aux lettres", type: "ouverture", type_label: "Détecteur d'ouverture", area_id: null, suggested_area_id: null, battery: 100, available: true, entities: { contact: "binary_sensor.boite_aux_lettres" } });
    states = { ...states, "binary_sensor.boite_aux_lettres": st("binary_sensor.boite_aux_lettres", "off", { device_class: "door" }) };
    ideas.entries.courrier = { status: "active", options: {} };
    states[MAIL_FLAG] = st(MAIL_FLAG, "on", { friendly_name: "Courrier en attente", arrived_at: new Date(new Date().setHours(10, 42, 0, 0)).toISOString() });
  }
  const linkedActive = (idea) => idea.recommendation && store.recos.some((r) => r.id === idea.recommendation && r.enabled);
  const detectedFor = (idea) => {
    const f = ideas.flows.find((x) => (idea.detected_by || []).includes(x.handler));
    return f ? { domain: f.handler, label_fr: DETECT_LABELS[f.handler] || "un nouvel appareil", flow_id: f.flow_id, name: f.name } : null;
  };
  const evaluate = (idea) => {
    const entry = ideas.entries[idea.id] || null;
    const resolved = demoResolve(idea, store, states, entry);
    const missing = resolved.filter((r) => !r.have && !r.need.optional);
    let status;
    let pending = false;
    if (idea.module) status = birthdaysActive() ? "actif" : missing.length ? "manque" : "pret";
    else if (linkedActive(idea) || (entry?.status === "active" && !idea.recommendation)) status = "actif";
    else {
      pending = entry?.status === "pending";
      if (!missing.length) status = "pret";
      else if (missing.some((r) => r.need.pivot) && !pending && !detectedFor(idea)) status = "non_pertinent";
      else status = "manque";
    }
    return { idea, entry, resolved, status, pending, missing };
  };
  const isNew = (ev) => ((ev.status === "pret" && !ev.pending) || (ev.status === "manque" && ev.missing.some((r) => r.need.pivot))) && !ideas.seen.has(`${ev.idea.id}:${ev.status}`);
  const summaryFr = (ev) => {
    if (ev.status === "actif") return "Déjà actif";
    if (!ev.missing.length) return "Vous avez déjà tout";
    return `Il faut : ${ev.missing[0].need.missing_fr || "1 appareil"}`;
  };
  const listItem = (ev) => ({
    id: ev.idea.id, title: ev.idea.title, pitch: ev.idea.pitch, short: ev.idea.short, category: ev.idea.category,
    color: ev.idea.color, icon: ev.idea.icon, status: ev.status, pending: ev.pending,
    badge_fr: ev.idea.module && ev.status === "manque" ? "À compléter" : ev.status === "manque" && ev.pending ? BADGES.attente : BADGES[ev.status], need_summary_fr: summaryFr(ev),
    detected_by: ev.idea.detected_by, new: isNew(ev),
    // Same rule as ideas_rules.no_hardware: every required need is met without buying anything.
    no_hardware: ev.idea.needs.every((n) => n.optional || (n.roles || []).every((r) => NO_PURCHASE_ROLES.includes(r))),
    // Same logic as ideas_rules.py list_item: needs other devices and which ones are missing.
    needs_other: ev.resolved.filter((o) => !o.need.optional && !o.need.pivot).length,
    missing_other_fr: ev.resolved.filter((o) => !o.need.optional && !o.need.pivot && !o.have).map((o) => o.need.label),
  });
  const view = (c) => ({ entity_id: c.entity_id, name: c.name, area_id: c.area_id });
  const tileOf = (ev) => {
    const t = ev.idea.tile;
    if (!t) return null;
    const ref = String(t.entity);
    const [kind, key] = ref.split(":");
    let ids = kind === "context" ? [key === "bin_flag" ? BIN_FLAG : MAIL_FLAG] : (ev.resolved.find((r) => r.need.key === key)?.chosen || []).map((c) => c.entity_id);
    if (kind === "need") ids = ids.slice(0, 1);
    return { idea_id: ev.idea.id, kind: t.kind, title: t.title, icon: t.icon, color: ev.idea.color, entity_ids: ids, attribute: t.attribute || null, detail_attribute: t.detail_attribute || null, unit: t.unit || null, threshold: t.threshold ?? null, show: t.show || "always", on_text: t.on_text || null, off_text: t.off_text || null, action: t.action || null, preview: t.preview || null };
  };
  const guideIdFor = (n) => {
    if (n.add_type) {
      const g = DEMO_GUIDE.find((x) => (x.add_types || []).includes(n.add_type));
      if (g) return g.id;
    }
    for (const role of n.roles || []) {
      if (NO_PURCHASE_ROLES.includes(role)) continue;
      const g = DEMO_GUIDE.find((x) => (x.roles || []).includes(role));
      if (g) return g.id;
    }
    return null;
  };
  const detailOf = (ev) => {
    const idea = ev.idea;
    const opts = demoOptions(idea, ev.entry?.options);
    const byId = Object.fromEntries(DEMO_IDEAS.map((i) => [i.id, i]));
    return {
      ...listItem(ev),
      description: idea.description, when: idea.when, if: idea.if, then: idea.then,
      needs: ev.resolved.map((r) => {
        const n = r.need;
        const det = !r.have && n.pivot ? detectedFor(idea) : null;
        const phone = n.roles.length === 1 && n.roles[0] === "phone";
        const names = r.chosen.slice(0, 3).map((c) => `« ${c.name} »`).join(", ") + (r.chosen.length > 3 ? ` et ${r.chosen.length - 3} autre${r.chosen.length > 4 ? "s" : ""}` : "");
        return {
          key: n.key, label: n.label, compatible: n.compatible || null, price_hint: n.price_hint || null, optional: !!n.optional, multiple: !!n.multiple,
          have: r.have, add_type: n.add_type || null, add_page: n.add_page || null, phone, detected: det, guide: guideIdFor(n),
          status_fr: r.have ? (phone ? "Déjà relié à la maison" : `Ajouté : ${names}`) : det ? `Trouvée sur le réseau : ${det.label_fr}` : n.optional ? n.none_fr || "Facultatif : pas encore ajouté" : n.hint ? `À ajouter : ${n.hint}` : "À ajouter",
          chosen: r.chosen.map(view), choices: r.choices.map(view),
        };
      }),
      options: idea.options.map((o) => ({ ...o, value: opts[o.key] })),
      tile: tileOf(ev) || (idea.module ? bd.previewTile : null),
      module: idea.module || null,
      next: idea.next.map((id) => byId[id]).filter(Boolean).map((n) => ({ id: n.id, title: n.teaser || n.title, detail: [idea.next_hint, n.teaser_detail].filter(Boolean).join(" "), color: n.color })),
      has_automation: !!(idea.blueprint || idea.recommendation || idea.module), test_announce: !!idea.test_announce, version: 1,
    };
  };
  const ideaById = (id) => {
    const idea = DEMO_IDEAS.find((i) => i.id === id);
    if (!idea) throw wsError("not_found", "Cette idée n'existe pas (ou plus).");
    return idea;
  };
  const ideasTiles = () => DEMO_IDEAS.map(evaluate).filter((ev) => ev.status === "actif").map(tileOf).filter((t) => t && t.entity_ids.length);
  const ideasUnseen = () => DEMO_IDEAS.map(evaluate).filter(isNew).length;
  const promotePending = () => {
    for (const idea of DEMO_IDEAS) {
      const e = ideas.entries[idea.id];
      if (e?.status === "pending" && !evaluate(idea).missing.length) {
        e.status = "active";
        if (idea.recommendation) { const r = store.recos.find((x) => x.id === idea.recommendation); if (r) r.enabled = true; }
      }
    }
  };
  /** A device was paired: give it to the idea waiting for it (like ideas_rules.assign_new_device). */
  const ideasDeviceFound = (device) => {
    const roles = { ...(device.entities || {}) };
    for (const idea of DEMO_IDEAS) {
      const e = ideas.entries[idea.id];
      if (!e || !["pending", "expect"].includes(e.status)) continue;
      const ev = evaluate(idea);
      const item = ev.resolved.find((r) => !r.have && !r.need.optional && r.need.roles.some((role) => roles[role]));
      if (!item) continue;
      const role = item.need.roles.find((x) => roles[x]);
      e.devices = { ...(e.devices || {}), [item.need.key]: [roles[role]] };
      if (item.need.rename_fr) device.name = item.need.rename_fr;
    }
    promotePending();
  };
  const ideasHandlers = {
    "ideas/list": () => {
      const evs = DEMO_IDEAS.map(evaluate);
      const items = evs.map(listItem);
      const newIds = new Set(items.filter((i) => i.new).map((i) => i.id));
      const detected = ideas.flows.map((f) => {
        const ids = DEMO_IDEAS.filter((i) => (i.detected_by || []).includes(f.handler)).map((i) => i.id);
        return { domain: f.handler, label_fr: DETECT_LABELS[f.handler] || "un nouvel appareil", flow_id: f.flow_id, name: f.name, ideas: ids, added: false, new: ids.some((id) => newIds.has(id)) };
      });
      return { items, detected, unseen: newIds.size };
    },
    "ideas/get": ({ idea_id }) => detailOf(evaluate(ideaById(idea_id))),
    ...createDemoApps({ wait }),
    ...demoRecipes,
    ...demoAi,
    "ideas/preview": async ({ idea_id }) => {
      await wait(300);
      const idea = handlers["ideas/get"]({ idea_id });
      return {
        ready: idea.status === "pret",
        file: params.get("separate") === "1" ? "automations_maison_facile.yaml" : "automations.yaml",
        automations: idea.status === "pret" ? [{ id: `mf_idea_${idea_id}_demo`, alias: `Maison Facile – Idée : ${idea.title}` }] : [],
        conflicts: params.get("conflict") === "1" ? [{ alias: "Chauffage du soir (le vôtre)", id: "1700000000000", entities: ["climate.salon"] }] : [],
        blocked: params.get("blocked") === "1" ? "Votre fichier automations.yaml contient des commentaires : en mode Expert, Maison Facile ne le réécrit pas. Pour que Maison Facile range ses automatismes dans un fichier à part, ajoutez cette ligne dans configuration.yaml puis redémarrez : automation maison_facile: !include automations_maison_facile.yaml" : null,
        include_line: "automation maison_facile: !include automations_maison_facile.yaml",
      };
    },
    "expert/status": () => ({
      expert_mode: store.settings.expert_mode === true,
      file: params.get("separate") === "1" ? "automations_maison_facile.yaml" : "automations.yaml",
      separate: params.get("separate") === "1",
      blocked: params.get("blocked") === "1",
      include_line: "automation maison_facile: !include automations_maison_facile.yaml",
    }),
    "ideas/activate": async ({ idea_id, options }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      const idea = ideaById(idea_id);
      await wait(500);
      if (idea.module) { bd.setEnabled(true); publish(); return detailOf(evaluate(idea)); }
      const e = ideas.entries[idea_id] || {};
      e.options = { ...(e.options || {}), ...(options || {}) };
      if (e.status !== "active") e.status = "pending";
      ideas.entries[idea_id] = e;
      promotePending();
      if (idea.applies_setting && e.status === "active") store.settings.announce_media_player = evaluate(idea).resolved[0].chosen[0]?.entity_id || "";
      publish();
      return detailOf(evaluate(idea));
    },
    "ideas/configure": ({ idea_id, options, devices }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      const idea = ideaById(idea_id);
      const e = ideas.entries[idea_id] || { status: "off" };
      if (options) e.options = { ...(e.options || {}), ...options };
      if (devices) e.devices = { ...(e.devices || {}), ...devices };
      ideas.entries[idea_id] = e;
      promotePending();
      return detailOf(evaluate(idea));
    },
    "ideas/expect": ({ idea_id }) => {
      const idea = ideaById(idea_id);
      const e = ideas.entries[idea_id] || {};
      if (!["active", "pending"].includes(e.status)) e.status = "expect";
      ideas.entries[idea_id] = e;
      return detailOf(evaluate(idea));
    },
    "ideas/deactivate": async ({ idea_id }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      const idea = ideaById(idea_id);
      await wait(300);
      if (idea.module) { bd.setEnabled(false); publish(); return detailOf(evaluate(idea)); }
      const e = ideas.entries[idea_id];
      ideas.entries[idea_id] = { status: "off", options: e?.options || {}, devices: e?.devices || {} };
      if (idea.recommendation) { const r = store.recos.find((x) => x.id === idea.recommendation); if (r) r.enabled = false; }
      if (idea.applies_setting) store.settings.announce_media_player = "";
      publish();
      return detailOf(evaluate(idea));
    },
    "guide/get": () => {
      const used = Object.fromEntries(DEMO_GUIDE.map((g) => [g.id, []]));
      for (const idea of DEMO_IDEAS) {
        for (const n of idea.needs) {
          const id = guideIdFor(n);
          if (id && !used[id].some((x) => x.id === idea.id)) used[id].push({ id: idea.id, title: idea.title });
        }
      }
      return { items: DEMO_GUIDE.map((g) => ({ ...clone(g), ideas: used[g.id] })), shop_url: validShopUrl(store.settings.shop_url || "") || "", starter: clone(DEMO_STARTER), cloud: demoCloud() };
    },
    "ideas/mark_seen": () => {
      for (const ev of DEMO_IDEAS.map(evaluate)) if (isNew(ev)) ideas.seen.add(`${ev.idea.id}:${ev.status}`);
      return { unseen: ideasUnseen() };
    },
    "ideas/add_detected": async ({ flow_id, domain }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      const f = ideas.flows.find((x) => x.flow_id === flow_id || x.handler === domain);
      if (!f) throw wsError("not_found", "Cet appareil n'est plus proposé par la box. Vérifiez qu'il est allumé.");
      await wait(1500);
      addTv();
      promotePending();
      publish();
      return { ok: true, state: "created", message_fr: "C'est ajouté. Les idées qui l'utilisent sont prêtes.", domain: f.handler };
    },
    "ideas/test_announce": async ({ entity_id }) => {
      if (!entity_id && !store.settings.announce_media_player) throw wsError("invalid_format", "Choisissez d'abord une enceinte.");
      await wait(800);
      return { ok: true, message_fr: "Vous avez entendu « Bonjour » ? Les annonces sont prêtes." };
    },
  };

  const publish = () => {
    hass = makeHass();
    for (const l of listeners) l(hass);
  };

  const setState = (id, state, attrs) => {
    const old = states[id];
    if (!old) return;
    states = { ...states, [id]: { ...old, state: String(state), attributes: { ...old.attributes, ...(attrs || {}) }, last_changed: new Date().toISOString() } };
    // Like the mailbox_alert blueprint: the mailbox opens -> « Courrier en attente ».
    if (String(state) === "on" && ideas.entries.courrier?.status === "active") {
      const mb = (demoResolve(DEMO_IDEAS.find((i) => i.id === "courrier"), store, states, ideas.entries.courrier)[0].chosen[0] || {}).entity_id;
      if (mb === id) states = { ...states, [MAIL_FLAG]: { ...states[MAIL_FLAG], state: "on", attributes: { ...states[MAIL_FLAG].attributes, arrived_at: new Date().toISOString() } } };
    }
    // Like the backend: closing a window resumes the heating it paused.
    if (store && store.heating_pauses && String(state) === "off" && store.heating_pauses[id]) {
      for (const c of store.heating_pauses[id]) {
        const cs = states[c];
        if (cs) states = { ...states, [c]: { ...cs, state: cs.attributes.mf_paused_mode || "heat" } };
      }
      delete store.heating_pauses[id];
    }
  };

  const appearanceSubs = new Set();
  const demoAppearance = () => appearanceSummary(store.settings, demoDay());
  const publishAppearance = () => {
    for (const cb of appearanceSubs) cb({ appearance: demoAppearance() });
  };
  const stateGet = () => ({
    version: store.update.installed,
    onboarded: store.onboarded,
    settings: clone(store.settings),
    rooms: clone(store.rooms),
    devices: clone(store.devices),
    heating_pauses: clone(store.heating_pauses),
    provision: (({ active, done }) => ({ active, done }))(provisionStatus()),
    status: { network_ok: true, radio_found: !noRadio, radio_kind: noRadio ? null : "zha", device_count: store.devices.length },
    audience: { profile: demoProfile, installer_name: store.settings.installer_name || "" },
    // Same rule as audience.discovery_mode (equipment "none", or nothing at all on an unknown box).
    discovery: !noRadio ? false : store.settings.equipment === "none" || (store.settings.equipment !== "some" && store.settings.radio_expected !== true && store.devices.length === 0),
    advanced: (({ commercial_mode, unlocked }) => ({ commercial_mode, unlocked }))(advStatus()),
    idea_tiles: [...ideasTiles(), ...bd.tiles()],
    ideas_unseen: ideasUnseen(),
    appearance: demoAppearance(),
    cloud: demoCloud(),
  });

  const demoCloud = () => (params.get("cloud") === "1" ? [{ domain: "tuya", label_fr: "Tuya / Smart Life", devices: 3 }] : []);
  const wsError = (code, message) => {
    const e = new Error(message);
    e.code = code;
    e.message = message;
    return e;
  };

  const runUpdate = async () => {
    const phases = [
      ["backing_up", 10, "Sauvegarde de votre maison…"],
      ["downloading", 30, "Téléchargement de la nouvelle version…"],
      ["installing", 55, "Installation de la nouvelle version…"],
      ["verifying", 80, "Vérification que tout marche…"],
      ["restarting", 92, "Redémarrage de la box, 1 minute environ…"],
      ["done", 100, "Maison Facile 1.1.0 est installée et tout fonctionne."],
    ];
    for (const [phase, progress, message_fr] of phases) {
      Object.assign(store.update, { phase, progress, message_fr });
      if (phase === "done") store.update.installed = "1.1.0";
      for (const cb of updateSubs) cb({ phase, progress, message_fr });
      await wait(1600);
    }
  };

  const handlers = {
    "state/get": () => stateGet(),
    "rooms/set": ({ rooms }) => {
      store.rooms = rooms.map((r, i) => {
        const existing = store.rooms.find((x) => x.area_id === r.area_id);
        const area_id = r.area_id || r.name.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
        const guess = { salon: "sofa", cuisine: "kitchen", chambre: "bed", bureau: "desk", salle_de_bain: "bath", entree: "door", garage: "garage", chambre_d_enfant: "child" };
        return { area_id, name: r.name, color: existing?.color || PALETTE[i % PALETTE.length], icon: existing?.icon || guess[area_id] || "room" };
      });
      const ids = new Set(store.rooms.map((r) => r.area_id));
      for (const d of store.devices) {
        if (d.area_id && !ids.has(d.area_id)) d.area_id = null;
        const orig = DEVICES.find((x) => x.device_id === d.device_id);
        d.suggested_area_id = d.area_id || (orig && ids.has(orig.suggested_area_id) ? orig.suggested_area_id : null);
      }
      return { rooms: clone(store.rooms) };
    },
    "devices/assign": ({ device_id, area_id }) => {
      const d = store.devices.find((x) => x.device_id === device_id);
      if (!d || (area_id && !store.rooms.some((r) => r.area_id === area_id))) throw wsError("not_found", "Cet appareil ou cette pièce est introuvable.");
      d.area_id = area_id || null;
      return { device: clone(d) };
    },
    "recommendations/list": () => ({ items: clone(store.recos) }),
    "recommendations/apply": ({ items }) => {
      for (const it of items) {
        const r = store.recos.find((x) => x.id === it.id);
        if (!r) continue;
        r.enabled = !!it.enabled;
        r.values = { ...r.values, ...(it.options || {}) };
      }
      return { items: clone(store.recos) };
    },
    "settings/set": ({ settings }) => {
      if ("installer_pin" in settings) throw wsError("invalid_format", "Le code installateur se change dans « Réglages avancés ».");
      if (settings.commercial_mode === false && store.settings.commercial_mode !== false && !canManage()) throw wsError("locked", "Ouvrez d'abord les réglages avancés (mode installateur).");
      if ("theme" in settings && !DEMO_THEMES.includes(settings.theme)) throw wsError("invalid_format", "Valeur incorrecte pour « Apparence » : choix non disponible.");
      if ("theme_auto" in settings && !THEME_AUTO_MODES.includes(settings.theme_auto)) throw wsError("invalid_format", "Valeur incorrecte pour « Changer de thème tout seul » : choix non disponible.");
      if ("home_style" in settings && !HOME_STYLES.includes(settings.home_style)) throw wsError("invalid_format", "Valeur incorrecte pour « Style de l'accueil » : choix non disponible.");
      if ("animations" in settings && typeof settings.animations !== "boolean") throw wsError("invalid_format", "Valeur incorrecte pour « Petites animations » : oui ou non attendu.");
      if ("shop_url" in settings && validShopUrl(settings.shop_url) === null) throw wsError("invalid_format", "Valeur incorrecte pour « Lien « Où l'acheter ? » » : adresse https:// attendue (avec {need} au besoin), ou vide pour masquer le bouton.");
      if ("shop_url" in settings && settings.shop_url !== store.settings.shop_url && !canManage()) throw wsError("locked", "Ouvrez d'abord les réglages avancés (mode installateur).");
      if ("liked_styles" in settings && !(Array.isArray(settings.liked_styles) && settings.liked_styles.every((x) => HOME_STYLES.includes(x)))) throw wsError("invalid_format", "Valeur incorrecte pour « Styles aimés » : liste de styles d'accueil attendue.");
      Object.assign(store.settings, settings);
      if (settings.night_mode) {
        const r = store.recos.find((x) => x.id === "mode_nuit_heure");
        if (r) r.enabled = settings.night_mode === "hour";
      }
      // Like the box (ws_appearance.py): every panel is told when the theme may have changed.
      if (["theme", "theme_auto", "animations", "home_style", "liked_styles"].some((k) => k in settings)) setTimeout(() => publishAppearance(), 0);
      return { settings: clone(store.settings), appearance: demoAppearance() };
    },
    "onboarding/complete": () => {
      store.onboarded = true;
      return { onboarded: true };
    },
    "pairing/start": async ({ device_type }) => {
      if (noRadio) return { method: "none", duration: 180 };
      clearTimeout(pairingTimer);
      pairingTimer = setTimeout(() => {
        const type = device_type && device_type !== "autre" ? device_type : "ouverture";
        const labels = { ouverture: "Détecteur d'ouverture", mouvement: "Détecteur de mouvement", thermo: "Thermomètre", prise: "Prise connectée", fumee: "Détecteur de fumée", lumiere: "Lumière", fuite: "Détecteur de fuite d'eau" };
        const roles = { ouverture: { contact: "binary_sensor.nouveau_contact" }, mouvement: { motion: "binary_sensor.nouveau_mouvement" }, thermo: { temperature: "sensor.nouveau_temperature", humidity: "sensor.nouveau_humidite" }, prise: { switch: "switch.nouvelle_prise", power: "sensor.nouvelle_prise_power" }, fumee: { smoke: "binary_sensor.nouvelle_fumee" }, lumiere: { light: "light.nouvelle_lampe" }, fuite: { leak: "binary_sensor.nouvelle_fuite" } };
        const n = store.devices.filter((d) => d.type === type).length + 1;
        const device = { device_id: `d_new_${Date.now()}`, name: `${labels[type]} n°${n}`, type, type_label: labels[type], area_id: null, suggested_area_id: store.rooms[2]?.area_id || store.rooms[0]?.area_id || null, battery: type === "prise" || type === "lumiere" ? null : 100, available: true, entities: clone(roles[type]) };
        store.devices.push(device);
        for (const id of Object.values(device.entities)) {
          const dom = id.split(".")[0];
          states = { ...states, [id]: st(id, dom === "sensor" ? "20.5" : "off", {}) };
        }
        ideasDeviceFound(device);
        publish();
        for (const cb of pairingSubs) cb({ event: "device_found", device: clone(device) });
      }, Number(params.get("pairdelay") || 9000));
      return { method: "zha", duration: 180 };
    },
    "pairing/stop": () => {
      clearTimeout(pairingTimer);
      return { ok: true };
    },
    "energy/summary": ({ period }) => energy(period || "day"),
    "heating/pause": ({ window_entity_id }) => {
      const win = store.devices.find((d) => d.entities?.contact === window_entity_id);
      if (!win) throw wsError("not_found", "Cette fenêtre est introuvable.");
      const climates = store.devices.filter((d) => d.area_id && d.area_id === win.area_id && d.entities?.climate).map((d) => d.entities.climate);
      const paused = climates.filter((id) => states[id] && states[id].state !== "off");
      for (const id of paused) setState(id, "off", { mf_paused_mode: states[id].state });
      store.heating_pauses[window_entity_id] = paused;
      publish();
      return { ok: true, paused, message_fr: "Le chauffage est en pause. Il se rallumera quand la fenêtre sera fermée." };
    },
    "updates/status": () => ({
      mf: { installed: store.update.installed, latest: store.update.installed === "1.1.0" ? "1.1.0" : store.update.latest, available: store.update.installed !== store.update.latest, notes: ["Nouvel écran « Énergie » avec la consommation de la semaine", "La lumière automatique de nuit réagit plus vite", "Corrections de sécurité"], validated_date: "2026-10-25", channel: "stable" },
      core: { installed: "2026.10.2", latest: "2026.10.2", available: false, validated: true },
      firmware: { pending: 0 },
      last_backup: store.update.last_backup, mode: store.settings.update_mode, phase: store.update.phase, progress: store.update.progress,
      message_fr: store.update.message_fr, target: null, checked_at: new Date(Date.now() - 20 * 60000).toISOString(), error: null, last_install: null, last_failure: null,
    }),
    "updates/check": async () => {
      await wait(700);
      const st = handlers["updates/status"]();
      return { ...st, checked_at: new Date().toISOString() };
    },
    "updates/install": ({ target }) => {
      if (store.update.installed === store.update.latest) throw wsError("install_failed", "Maison Facile est déjà à jour.");
      store.update.last_backup = new Date().toISOString();
      runUpdate();
      return { started: true, target };
    },
    "doctor/list": () => ({ checked_at: new Date(Date.now() - 2 * 60000).toISOString(), problems: clone(store.problems), headline: headline(store.problems) }),
    "doctor/rescan": async () => {
      await wait(900);
      store.problems = noEquipment ? [clone(RADIO_NOT_YET)] : clone(PROBLEMS);
      return { checked_at: new Date().toISOString(), problems: clone(store.problems), headline: headline(store.problems) };
    },
    "doctor/fix": async ({ problem_id, choice }) => {
      await wait(900);
      if (!problem_id) throw wsError("not_found", "Quel problème faut-il réparer ?");
      store.problems = store.problems.filter((p) => p.id !== problem_id);
      return { ok: true, message_fr: problem_id === "disk_usage" ? `Réglé : la box garde maintenant ${choice || 7} jours d'historique` : "Réparé, tout fonctionne" };
    },
    "provision/status": () => provisionStatus(),
    "provision/retry": async ({ step_id }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      if (!provision.steps.some((x) => x.id === step_id)) throw wsError("not_found", "Cette étape n'existe pas.");
      setTimeout(() => runProvision([[step_id, 1500, "done", step_id === "cameras" ? "2 caméras ajoutées." : "C'est fait."]]), 0);
      provisionSet(step_id, "pending");
      return provisionStatus();
    },
    "advanced/status": () => advStatus(),
    "advanced/unlock": async ({ pin }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      await wait(300);
      const now = Date.now();
      adv.failures = adv.failures.filter((t) => now - t < 5 * 60000);
      if (adv.failures.length >= 5) throw wsError("too_many_attempts", "Trop d'essais avec un mauvais code. Réessayez dans 5 minutes.");
      if (adv.pin && pin !== adv.pin) {
        adv.failures.push(now);
        const left = 5 - adv.failures.length;
        throw wsError("invalid_pin", left ? `Ce code n'est pas le bon. Encore ${left} essai${left > 1 ? "s" : ""} avant une pause de 5 minutes.` : "Trop d'essais avec un mauvais code. Réessayez dans 5 minutes.");
      }
      adv.failures = [];
      adv.until = now + 30 * 60000;
      return { ok: true, until: new Date(adv.until).toISOString() };
    },
    "advanced/lock": () => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      adv.until = 0;
      return advStatus();
    },
    "advanced/set_pin": ({ pin }) => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      if (!canManage()) throw wsError("locked", "Ouvrez d'abord les réglages avancés (mode installateur).");
      if (pin && !/^[0-9]{4,8}$/.test(pin)) throw wsError("invalid_format", "Le code doit contenir 4 à 8 chiffres (ou rester vide pour ne pas en avoir).");
      adv.pin = pin || "";
      return advStatus();
    },
    "doctor/report": () => {
      if (!isAdmin) throw wsError("unauthorized", "Unauthorized");
      const names = { maison_facile: "Maison Facile", orbite: "Orbite", neon: "Néon", jumeau: "Jumeau 3D", holo: "Holo" };
      const liked = (store.settings.liked_styles || []).map((x) => names[x]).join(", ") || "aucun";
      const line = `Apparence : style d'accueil ${names[store.settings.home_style] || "Maison Facile"} · styles aimés : ${liked} · thème ${store.settings.theme} (automatique : ${store.settings.theme_auto})`;
      return { text: REPORT.replace("\n\nProblèmes en cours", `\n${line}\n\nProblèmes en cours`) };
    },
    ...ideasHandlers,
    ...Object.fromEntries(Object.entries(bd.handlers).map(([k, fn]) => [k, (msg) => {
      if (!isAdmin && !["birthdays/list"].includes(k)) throw wsError("unauthorized", "Unauthorized");
      const r = fn(msg);
      if (k !== "birthdays/list") publish();
      return r;
    }])),
  };

  function headline(problems) {
    const n = problems.filter((p) => !p.notice).length;
    return n === 0 ? "Tout fonctionne, aucun problème" : n === 1 ? "1 problème à régler" : `${n} problèmes à régler`;
  }

  // Marketplace (HACS intégré, HA 2026.11) pour l'onglet Modules : ?market=0 pour l'enlever.
  const market = { accepted: params.get("market_ok") === "1", repos: [
    { id: "1001", full_name: "hekmon/rtetempo", name: "RTE Tempo", description: "Couleurs Tempo", installed: false, stars: 300 },
    { id: "1002", full_name: "bramstroker/homeassistant-powercalc", name: "Powercalc", description: "Virtual power sensors", installed: true, installed_version: "1.17.0", pending_upgrade: false, stars: 1300 },
    { id: "1003", full_name: "KartoffelToby/better_thermostat", name: "Better Thermostat", description: "Smart TRV control", installed: false, stars: 1000 },
    { id: "1004", full_name: "nielsfaber/alarmo", name: "Alarmo", description: "Alarm system", installed: false, stars: 1500 },
    { id: "1005", full_name: "mampfes/hacs_waste_collection_schedule", name: "Waste Collection Schedule", description: "Waste collection", installed: false, stars: 1100 },
    { id: "1006", full_name: "blakeblackshear/frigate-hass-integration", name: "Frigate", description: "Frigate integration", installed: false, stars: 900 },
    { id: "1007", full_name: "basnijholt/adaptive-lighting", name: "Adaptive Lighting", description: "Adapt lights to the sun", installed: false, stars: 2000 },
    { id: "2001", full_name: "exemple/meteo-locale", name: "Météo locale", description: "Un module de la communauté (exemple)", installed: false, stars: 40 },
  ] };
  async function demoMarket(type, msg) {
    if (params.get("market") === "0") throw wsError("not_loaded", "Marketplace not loaded");
    if (type === "marketplace/info") return { warning_accepted: market.accepted, github_connected: false };
    if (type === "marketplace/repositories/list") return market.repos;
    if (type === "marketplace/warning/accept") { market.accepted = true; return null; }
    if (type === "marketplace/repository/install") {
      await wait(1500);
      const r = market.repos.find((x) => x.id === msg.repository);
      if (r) Object.assign(r, { installed: true, installed_version: "1.0.0", pending_upgrade: false });
      if (r && r.full_name === "blakeblackshear/frigate-hass-integration") demoRecipes._markModule();
      return null;
    }
    throw wsError("unknown_command", "Unknown command.");
  }

  async function callWS(msg) {
    await wait(120 + Math.random() * 180);
    const type = msg.type || "";
    if (type === "logbook/get_events") {
      const t = (h, m) => new Date(new Date().setHours(h, m, 0, 0)).toISOString();
      const all = [
        { when: t(7, 0), entity_id: "select.maison_facile_mode", state: "maison" },
        { when: t(8, 10), entity_id: "binary_sensor.porte_entree", state: "on" },
        { when: t(8, 11), entity_id: "binary_sensor.porte_entree", state: "off" },
        { when: t(11, 30), entity_id: "binary_sensor.chambre_fenetre", state: "on" },
        { when: t(14, 12), entity_id: "binary_sensor.mouvement_entree", state: "on" },
      ];
      return all.filter((e) => new Date(e.when) <= new Date());
    }
    if (type === "supervisor/api" && String(msg.endpoint || "").startsWith("/ingress/")) return { session: "demo-session" };
    if (type.startsWith("marketplace/")) return demoMarket(type, msg);
    if (type === "frontend/get_translations") return { resources: demoTranslations };
    if (!type.startsWith("maison_facile/")) throw wsError("unknown_command", "Unknown command.");
    const h = handlers[type.slice("maison_facile/".length)];
    if (!h) throw wsError("unknown_command", "Unknown command.");
    return clone(await h(msg));
  }

  async function callService(domain, service, data = {}) {
    await wait(80);
    const ids = [].concat(data.entity_id || []);
    for (const id of ids) {
      const s = states[id];
      if (!s) continue;
      if (service === "toggle") setState(id, s.state === "on" ? "off" : "on");
      else if (service === "turn_on") setState(id, domain === "climate" ? "heat" : "on", domain === "light" && data.brightness_pct ? { brightness: Math.round((data.brightness_pct / 100) * 255) } : domain === "light" ? { brightness: 255 } : undefined);
      else if (service === "turn_off") setState(id, "off");
      else if (service === "set_temperature") setState(id, s.state, { temperature: data.temperature });
      else if (service === "select_option") setState(id, data.option);
      else if (domain === "media_player") {
        const a = s.attributes || {};
        const now = new Date().toISOString();
        const pos = s.state === "playing" && a.media_position_updated_at ? a.media_position + (Date.now() - Date.parse(a.media_position_updated_at)) / 1000 : a.media_position;
        if (service === "media_play_pause") setState(id, s.state === "playing" ? "paused" : "playing", { media_position: pos, media_position_updated_at: now });
        else if (service === "media_next_track" || service === "media_previous_track") setState(id, "playing", { media_title: service === "media_next_track" ? "Morceau suivant" : "Morceau précédent", media_position: 0, media_position_updated_at: now });
        else if (service === "volume_set") setState(id, s.state, { volume_level: data.volume_level });
      }
    }
    publish();
  }

  function makeHass() {
    return {
      states,
      user: { name: isAdmin ? "Marie" : "Léo", is_admin: isAdmin },
      kioskMode: shell.kioskMode,
      dockedSidebar: shell.dockedSidebar,
      language: "fr",
      entities: { "media_player.enceinte_cuisine": { entity_id: "media_player.enceinte_cuisine", platform: "music_assistant" } },
      callWS,
      callService,
      callApi: async (method, path, data) => clone(await demoCallApi(method, path, data)),
      connection: {
        subscribeMessage: async (cb, msg) => {
          await wait(60);
          const type = msg.type;
          if (type === "maison_facile/pairing/subscribe") {
            pairingSubs.add(cb);
            return () => pairingSubs.delete(cb);
          }
          if (type === "maison_facile/provision/subscribe") {
            provisionSubs.add(cb);
            setTimeout(() => cb(provisionStatus()), 0);
            startProvision();
            return () => provisionSubs.delete(cb);
          }
          if (type === "maison_facile/appearance/subscribe") {
            appearanceSubs.add(cb);
            setTimeout(() => cb({ appearance: demoAppearance() }), 0);
            return () => appearanceSubs.delete(cb);
          }
          if (type === "maison_facile/updates/subscribe") {
            updateSubs.add(cb);
            setTimeout(() => cb({ phase: store.update.phase, progress: store.update.progress, message_fr: store.update.message_fr }), 0);
            return () => updateSubs.delete(cb);
          }
          throw wsError("unknown_command", "Unknown command.");
        },
      },
    };
  }

  // Living house: temperatures drift, cameras refresh, someone walks by now and then.
  setInterval(() => {
    for (const id of ["sensor.salon_temperature", "sensor.cuisine_temperature", "sensor.chambre_temperature", "sensor.bureau_temperature"]) {
      const v = parseFloat(states[id].state) + (Math.random() - 0.5) * 0.2;
      setState(id, v.toFixed(1));
    }
    publish();
  }, 8000);
  setInterval(() => {
    setState("camera.entree", "idle", { entity_picture: camSvg("ENTRÉE", "#2B3340", "#1A1F27") });
    setState("camera.jardin", "idle", { entity_picture: camSvg("JARDIN", "#2F3A33", "#1A221D") });
    publish();
  }, 2000);

  // Home Assistant shell events used by the panel (see maison-facile-panel.js).
  const shellChanged = () => {
    publish();
    window.dispatchEvent(new CustomEvent("mf-demo-shell", { detail: { ...shell } }));
  };
  window.addEventListener("hass-kiosk-mode", (ev) => {
    if (params.get("kiosk") === "0") return; // an HA version without kiosk support
    shell = { ...shell, kioskMode: !!ev.detail?.enable };
    shellChanged();
  });
  window.addEventListener("hass-dock-sidebar", (ev) => {
    shell = { ...shell, dockedSidebar: ev.detail?.dock || "docked" };
    shellChanged();
  });
  window.addEventListener("location-changed", () => {
    const path = window.location.pathname;
    window.mfDemo.lastNavigation = path;
    window.dispatchEvent(new CustomEvent("mf-demo-navigate", { detail: { path } }));
  });

  hass = makeHass();
  const api = {
    /** The postman passes (idea « Courrier arrivé » active). */
    mail() {
      const mb = (demoResolve(DEMO_IDEAS.find((i) => i.id === "courrier"), store, states, ideas.entries.courrier)[0].chosen[0] || {}).entity_id;
      if (mb) {
        setState(mb, "on");
        setState(mb, "off");
        publish();
      }
    },
    toggle(entity_id) {
      const s = states[entity_id];
      if (!s) return;
      setState(entity_id, s.state === "on" ? "off" : "on");
      publish();
    },
  };
  window.mfDemo = api;
  return {
    toggle: api.toggle,
    get hass() {
      return hass;
    },
    get shell() {
      return { ...shell };
    },
    subscribe(fn) {
      listeners.add(fn);
    },
  };
}
