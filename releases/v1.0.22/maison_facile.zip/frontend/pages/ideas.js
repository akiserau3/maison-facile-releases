// « Idées » : ready-made automations, one tap to activate (mockup design-mockups/Idees.dc.html).
import { Page, html } from "../lib.js";
import { icon } from "../icons.js";
import { ideaTileHtml } from "../components/idea-tile.js";
import { BirthdaysPage } from "./birthdays.js";

const FILTERS = [
  ["toutes", "Toutes"],
  ["sans_achat", "Sans rien acheter"],
  ["detecte", "Trouvées chez vous"],
  ["confort", "Confort"],
  ["securite", "Sécurité"],
  ["energie", "Économies"],
];

export class IdeasPage extends Page {
  init() {
    this.s = {
      device: this.params.device || null,
      filter: FILTERS.some(([k]) => k === this.params.filter) ? this.params.filter : "toutes",
      list: null,
      listError: false,
      id: this.params.id || null,
      detail: null,
      detailError: false,
      // Sub-page of an idea run by a module (« Anniversaires » : pages/birthdays.js).
      view: this.params.view === "birthdays" ? "birthdays" : null,
    };
    this.sub = null;
    this._seenSent = false;
    this.loadList();
    if (this.s.id) this.loadDetail(this.s.id);
  }

  // ----- data ------------------------------------------------------------------

  async loadList() {
    try {
      const r = await this.api.listIdeas();
      if (this.destroyed) return;
      this.setState({ list: r, listError: false });
      if (!this._seenSent && !this.s.id) this.markSeen();
    } catch (e) {
      console.warn("[maison-facile] ideas/list", e);
      if (!this.destroyed) this.setState({ listError: true });
    }
  }

  async markSeen() {
    this._seenSent = true;
    try {
      const r = await this.api.markIdeasSeen();
      this.app.setIdeasUnseen(r?.unseen || 0);
    } catch (e) {
      /* badge only */
    }
  }

  async loadDetail(id) {
    try {
      const d = await this.api.getIdea(id);
      if (this.destroyed || this.s.id !== id) return;
      this.setState({ detail: d, detailError: false });
    } catch (e) {
      console.warn("[maison-facile] ideas/get", e);
      if (!this.destroyed) this.setState({ detailError: true });
    }
  }

  open(id) {
    this.setState({ id, detail: null, detailError: false });
    this.app.$content.scrollTop = 0;
    this.loadDetail(id);
  }

  back() {
    this.setState({ id: null, detail: null });
    this.app.$content.scrollTop = 0;
    this.loadList();
    if (!this._seenSent) this.markSeen();
  }

  afterRender() {
    const host = this.el.querySelector("[data-sub]");
    if (!host) {
      if (this.sub) this.closeSub();
      return;
    }
    if (this.sub && this.sub.el === host) return;
    if (this.sub) this.sub.destroy();
    this.sub = new BirthdaysPage(this.app, { onBack: () => this.openBirthdays(false) });
    this.children = [this.sub];
    this.sub.mount(host);
  }

  closeSub() {
    this.sub.destroy();
    this.sub = null;
    this.children = [];
  }

  /** Show / leave the birthdays page (back to the idea « Anniversaires »). */
  openBirthdays(open) {
    this.setState({ view: open ? "birthdays" : null });
    this.app.$content.scrollTop = 0;
    if (!open) {
      this.s.id = this.s.id || "anniversaire";
      this.loadDetail(this.s.id);
    }
  }

  // ----- templates -------------------------------------------------------------------

  template() {
    if (this.s.view === "birthdays") return html`<div data-sub="birthdays" data-morph-skip></div>`;
    const d = this.s.id ? this.s.detail : null;
    const title = this.s.id ? (d ? d.title : "Idée") : "Idées pour ma maison";
    const sub = this.s.id ? "Une idée prête à l'emploi, réglée pour vous" : "Des automatismes tout faits, selon ce que vous avez";
    return html`
      <header class="page-head">
        <div class="title">
          ${this.s.id ? html`<button type="button" class="back-btn glass" data-action="back" aria-label="Retour aux idées">${icon("back", 24)}</button>` : ""}
          <span class="page-icon" style="background:#E0A100;color:#2A1E00;box-shadow:0 8px 18px rgba(224,161,0,0.40)">${icon("bulb", 28)}</span>
          <div><h1>${title}</h1><span class="sub" style="font-size:15px">${sub}</span></div>
        </div>
      </header>
      <main class="ideas-main" data-key="${this.s.id ? `detail-${this.s.id}` : "list"}">
        ${this.s.id ? this.detailView() : this.listView()}
      </main>`;
  }

  listView() {
    if (this.s.listError) {
      return html`<div class="glass empty"><span>Impossible de charger les idées.</span><button type="button" class="btn primary sm" data-action="retry-list">Réessayer</button></div>`;
    }
    const r = this.s.list;
    if (!r) return html`<div class="loading" role="status"><span class="spinner" aria-hidden="true"></span>Chargement des idées…</div>`;
    if (this.s.device) return this.deviceView(r);
    const items = r.items || [];
    const byId = Object.fromEntries(items.map((i) => [i.id, i]));
    const detectedIdeas = new Set((r.detected || []).flatMap((x) => x.ideas || []));
    const f = this.s.filter;
    const shown = items.filter((i) => {
      if (f === "toutes") return i.status !== "non_pertinent";
      if (f === "sans_achat") return !!i.no_hardware && i.status !== "non_pertinent";
      if (f === "detecte") return (i.category === "detecte" || detectedIdeas.has(i.id)) && i.status !== "non_pertinent";
      return i.category === f && i.status !== "non_pertinent";
    });
    // Box without hardware (installer v1.4): the ideas that need nothing to buy come first.
    if (this.data.discovery && f === "toutes") shown.sort((a, b) => Number(!!b.no_hardware) - Number(!!a.no_hardware));
    const later = f === "toutes" ? items.filter((i) => i.status === "non_pertinent") : [];
    const banners = (r.detected || []).filter((x) => !x.added || x.new);
    return html`<div class="stack" style="gap:16px">
      ${banners.map((x) => this.detectBanner(x, byId))}
      <div role="group" aria-label="Filtrer les idées" class="idea-filters">
        ${FILTERS.map(([k, label]) => html`<button type="button" class="filter-chip" data-action="filter" data-filter="${k}" aria-pressed="${f === k ? "true" : "false"}">${label}</button>`)}
      </div>
      ${shown.length
        ? html`<div class="ideas-grid">${shown.map((i) => this.card(i))}</div>`
        : html`<div class="glass empty"><span>Aucune idée dans cette catégorie pour l'instant.</span></div>`}
      ${later.length
        ? html`<h2 class="h2" style="margin-top:8px">Pour plus tard</h2>
          <p class="sub" style="font-size:15px;margin-top:-8px">Ces idées demandent un appareil que la maison n'a pas encore.</p>
          <div class="ideas-grid">${later.map((i) => this.card(i))}</div>`
        : ""}
    </div>`;
  }

  detectBanner(x, byId) {
    const ideas = (x.ideas || []).map((id) => byId[id]).filter((i) => i && i.status !== "actif");
    const shorts = ideas.map((i) => i.short || i.title.toLowerCase());
    const n = ideas.length;
    const what = x.added ? `Votre box a ajouté ${x.label_fr}` : `Votre box a trouvé ${x.label_fr} sur le réseau`;
    return html`<div class="detect-banner" data-key="det-${x.domain}">
      <span class="db-icon">${icon("tv", 26)}</span>
      <div class="grow" style="display:flex;flex-direction:column;gap:2px">
        <strong style="font-size:18px">${what}</strong>
        <span style="font-size:15px;opacity:0.95">${n ? `${n} idée${n > 1 ? "s deviennent possibles" : " devient possible"} : ${shorts.join(", ")}.` : "De nouvelles idées sont possibles."}</span>
      </div>
      <button type="button" class="btn db-btn" data-action="device" data-device="${x.domain}">Voir les idées</button>
    </div>`;
  }

  // Idées d'un appareil trouvé (TV, enceinte…) : seulement les siennes, rangées en trois parties.
  deviceView(r) {
    const items = r.items || [];
    const det = (r.detected || []).find((x) => x.domain === this.s.device);
    const label = det ? det.label_fr : "cet appareil";
    const mine = items.filter((i) => (det ? (det.ideas || []).includes(i.id) : (i.detected_by || []).includes(this.s.device)));
    const alone = mine.filter((i) => !i.needs_other);
    const linked = mine.filter((i) => i.needs_other && !(i.missing_other_fr || []).length);
    const more = mine.filter((i) => i.needs_other && (i.missing_other_fr || []).length);
    const part = (title, list) => list.length
      ? html`<h2 class="h2" style="margin-top:8px">${title}</h2><div class="ideas-grid">${list.map((i) => this.card(i))}</div>`
      : "";
    return html`<div class="stack" style="gap:16px">
      <div class="row" style="gap:12px;align-items:center">
        <button type="button" class="btn secondary sm" data-action="all-ideas">← Toutes les idées</button>
        <h1 class="h2" style="margin:0">Idées pour ${label}</h1>
      </div>
      ${mine.length ? "" : html`<div class="glass empty"><span>Aucune idée pour cet appareil pour l'instant.</span></div>`}
      ${part(`Avec ${label} seule`, alone)}
      ${part(`Avec ${label} et vos autres appareils`, linked)}
      ${more.length
        ? html`<details class="glass card" style="padding:14px 18px">
            <summary style="cursor:pointer;font-weight:600">Avec un appareil en plus (${more.length})</summary>
            <p class="sub" style="font-size:15px">Ces idées demandent un appareil que la maison n'a pas encore.</p>
            <div class="ideas-grid">${more.map((i) => html`<div>${this.card(i)}<span class="sub" style="font-size:13px">Il manque : ${i.missing_other_fr.join(", ")}</span></div>`)}</div>
          </details>`
        : ""}
      <button type="button" class="btn secondary" data-action="all-ideas" style="align-self:flex-start">Voir toutes les idées</button>
    </div>`;
  }

  card(i) {
    const st = i.status === "manque" && i.pending ? "attente" : i.status;
    return html`<button type="button" class="idea-card ${i.status === "non_pertinent" ? "later" : ""}" data-action="open" data-id="${i.id}" data-key="card-${i.id}">
      <span class="ic-top">
        <span class="ic-initial" style="background:${i.color}" aria-hidden="true">${i.title.charAt(0)}</span>
        <span class="row" style="gap:8px">
          ${i.new ? html`<span class="new-dot" title="Nouveau"><span class="sr-only">Nouveau</span></span>` : ""}
          <span class="st-badge ${st}">${i.badge_fr}</span>
        </span>
      </span>
      <span style="display:flex;flex-direction:column;gap:4px">
        <span class="ic-title">${i.title}</span>
        <span class="ic-pitch">${i.pitch}</span>
      </span>
      <span class="ic-need">${i.need_summary_fr}</span>
    </button>`;
  }

  detailView() {
    if (this.s.detailError) {
      return html`<div class="glass empty"><span>Impossible d'ouvrir cette idée.</span><button type="button" class="btn primary sm" data-action="retry-detail">Réessayer</button></div>`;
    }
    const d = this.s.detail;
    if (!d) return html`<div class="loading" role="status"><span class="spinner" aria-hidden="true"></span>Chargement…</div>`;
    const needs = (d.needs || []).filter((n) => !n.optional || n.have || n.add_type || n.phone || d.module);
    const priced = (d.needs || []).find((n) => !n.have && !n.optional && n.price_hint) || (d.needs || []).find((n) => n.price_hint);
    return html`<div class="idea-detail">
      <section class="col">
        <div class="glass card idea-card-block">
          <h2 class="h2">Ce que ça fait</h2>
          <p class="idea-desc">${d.description}</p>
        </div>

        <div class="glass card idea-card-block">
          <h2 class="h2">Ce qu'il faut</h2>
          ${needs.map((n) => this.needRow(n))}
          ${priced
            ? html`<span class="sub" style="font-size:14px">Prix indicatif ${priced.add_type === "prise" ? "de la prise" : priced.key === "speaker" ? "de l'enceinte" : "du capteur"} : ${priced.price_hint}${priced.compatible ? ` · Compatible : ${priced.compatible}` : ""}</span>`
            : ""}
        </div>

        <div class="glass card idea-card-block">
          <div class="row" style="justify-content:space-between">
            <h2 class="h2">L'automatisme fourni</h2>
            <span class="st-badge actif">Inclus · rien à créer</span>
          </div>
          <div class="qsa">
            <span class="qsa-k" style="background:#0067C0">QUAND</span><span>${d.when}</span>
            <span class="qsa-k" style="background:#6B47B8">SI</span><span>${d.if}</span>
            <span class="qsa-k" style="background:#0E7A0D">ALORS</span><span>${d.then}</span>
          </div>
        </div>

        ${(d.options || []).length
          ? html`<div class="glass card idea-card-block">
              <h2 class="h2">Réglages</h2>
              ${d.options.map((o) => this.optionRow(o))}
            </div>`
          : ""}
      </section>

      <aside class="side ideas-side">
        ${d.tile
          ? html`<div class="glass card idea-card-block" style="gap:10px">
              <span class="sub" style="font-size:14px;font-weight:700">Aperçu sur l'accueil</span>
              ${ideaTileHtml(d.tile, { text: d.tile.preview || "" }, { preview: true })}
            </div>`
          : ""}
        ${(d.next || []).map((n) => html`<div class="next-card" style="background:${n.color}" data-key="next-${n.id}">
            <span style="font-size:14px;font-weight:700;opacity:0.95">Pour aller plus loin</span>
            <strong style="font-size:18px;line-height:1.3">${n.title}</strong>
            ${n.detail ? html`<span style="font-size:15px;opacity:0.95">${n.detail}</span>` : ""}
            <button type="button" class="btn next-btn" data-action="open" data-id="${n.id}">Voir cette idée</button>
          </div>`)}
        ${this.announceTest(d)}
        ${this.activateBlock(d)}
      </aside>
    </div>`;
  }

  needRow(n) {
    // Hand choice for the main devices only (optional ones are shown, not chosen here).
    const picks = n.multiple || ((n.phone || n.optional) && !n.choose) ? [] : n.choices || [];
    const showSelect = picks.length > (n.have ? 1 : 0);
    const current = n.chosen?.[0]?.entity_id || "";
    const roomName = (area) => (this.data.rooms || []).find((r) => r.area_id === area)?.name;
    return html`<div class="need-row ${n.have ? "" : n.optional ? "optional" : "missing"}" data-key="need-${n.key}">
      <span class="need-dot">${n.have ? icon("check", 22, { stroke: 2.6 }) : icon("plus", 22, { stroke: 2.4 })}</span>
      <span class="grow" style="display:flex;flex-direction:column;gap:2px">
        <strong style="font-size:17px">${n.label}</strong>
        <span class="sub" style="font-size:14px">${n.status_fr}</span>
        ${showSelect
          ? html`<label class="need-pick"><span class="sr-only">${n.have ? "Appareil utilisé" : "Utiliser un appareil déjà installé"}</span>
              <select class="select" data-field="device" data-need="${n.key}" data-value="${current}">
                ${n.have ? "" : html`<option value="">Ou choisir un appareil déjà installé…</option>`}
                ${picks.map((c) => html`<option value="${c.entity_id}" ${c.entity_id === current ? "selected" : ""}>${c.name}${roomName(c.area_id) ? ` (${roomName(c.area_id)})` : ""}</option>`)}
              </select></label>`
          : ""}
      </span>
      ${n.add_page && this.app.isAdmin
        ? html`<button type="button" class="btn ${n.have ? "secondary" : "primary"} sm" data-action="open-birthdays">${n.have ? "Gérer" : "Ajouter des anniversaires"}</button>`
        : !n.have && n.detected && this.app.isAdmin
        ? html`<button type="button" class="btn primary sm" data-action="add-detected" data-flow="${n.detected.flow_id}" ${this.isBusy("detected") ? "disabled" : ""}>${this.isBusy("detected") ? "Un instant…" : "Ajouter"}</button>`
        : !n.have && n.add_type && this.app.isAdmin
          ? html`<button type="button" class="btn primary sm" data-action="pair" data-type="${n.add_type}">Ajouter ${n.add_type === "prise" ? "la prise" : n.add_type === "lumiere" ? "la lumière" : "le capteur"}</button>`
          : ""}
      ${!n.have && n.guide && !n.detected
        ? html`<button type="button" class="btn secondary sm" data-action="guide" data-guide="${n.guide}" aria-label="Quoi acheter ? ${n.label}">${icon("help", 20)}Quoi acheter ?</button>`
        : ""}
    </div>`;
  }

  optionRow(o) {
    if (o.type === "bool") {
      return html`<label class="opt-row">${o.label}<input type="checkbox" data-field="opt" data-key="${o.key}" ${o.value ? "checked" : ""} ${this.app.isAdmin ? "" : "disabled"}></label>`;
    }
    if (o.type === "choice") {
      const idx = Math.max(0, (o.choices || []).findIndex((c) => c.value === o.value));
      return html`<label class="opt-row">${o.label}
        <select class="select" data-field="opt" data-key="${o.key}" data-value="${idx}" ${this.app.isAdmin ? "" : "disabled"}>
          ${(o.choices || []).map((c, i) => html`<option value="${i}" ${i === idx ? "selected" : ""}>${c.label}</option>`)}
        </select></label>`;
    }
    return html`<label class="opt-row">${o.label}<input class="input" type="number" min="${o.min}" max="${o.max}" step="${o.step || 1}" value="${o.value}" data-field="opt" data-key="${o.key}" style="width:120px"></label>`;
  }

  announceTest(d) {
    if (!d.test_announce || !this.app.isAdmin) return "";
    const speaker = (d.needs || []).find((n) => n.have && n.key === "speaker");
    if (!speaker) return "";
    return html`<button type="button" class="btn secondary" data-action="test-announce" data-entity="${speaker.chosen[0].entity_id}" ${this.isBusy("announce") ? "disabled" : ""}>${icon("speaker", 20)}${this.isBusy("announce") ? "Un instant…" : "Dire bonjour"}</button>`;
  }

  /** Mode Expert : avant d'activer, ce qui va être créé et ce qui existe déjà. */
  previewBlock(p, ready, busy) {
    const list = p.automations || [];
    return html`<div class="glass card stack" style="gap:10px;text-align:left" data-key="preview" role="group" aria-label="Avant d'activer">
      <strong style="font-size:17px">Avant d'activer, voici ce qui va changer</strong>
      ${list.length
        ? html`<ul style="margin:0;padding-left:20px;font-size:15px;display:flex;flex-direction:column;gap:4px">${list.map((a) => html`<li>Nouvel automatisme « ${a.alias} » <span class="sub">(${a.id})</span></li>`)}</ul>`
        : html`<p class="sub" style="font-size:15px">${ready ? "Les automatismes de Maison Facile pour cette idée." : "Rien pour l'instant : l'automatisme sera créé quand le capteur sera ajouté."}</p>`}
      <p class="sub" style="font-size:14px">Fichier : ${p.file}. Vos automatismes ne sont pas modifiés ; aucun appareil n'est renommé.</p>
      ${(p.conflicts || []).length
        ? html`<div class="note-warn" role="alert" style="padding:10px 12px;border-radius:12px;background:var(--warn-bg);color:var(--warn);border:1px solid var(--warn-border);font-size:15px">
            ${icon("warn", 18)} Ces automatismes pilotent déjà les mêmes appareils : ${p.conflicts.map((c) => `« ${c.alias} »`).join(", ")}. Les deux fonctionneront en même temps : vérifiez qu'ils ne se contredisent pas.</div>`
        : ""}
      ${p.blocked
        ? html`<div role="alert" style="padding:10px 12px;border-radius:12px;background:var(--warn-bg);color:var(--warn);border:1px solid var(--warn-border);font-size:15px">${p.blocked}</div>`
        : ""}
      <div class="row wrap" style="gap:10px">
        ${p.blocked ? "" : html`<button type="button" class="btn primary" data-action="confirm-activate" ${busy ? "disabled" : ""}>${busy ? "Un instant…" : "Confirmer et activer"}</button>`}
        <button type="button" class="btn secondary" data-action="cancel-preview">Annuler</button>
      </div>
    </div>`;
  }

  activateBlock(d) {
    if (!this.app.isAdmin) {
      return html`<p class="sub" style="font-size:15px;text-align:center">Seul le compte principal de la maison peut activer une idée.</p>`;
    }
    const busy = this.isBusy("activate");
    if (d.module) return this.moduleBlock(d, busy);
    if (d.status === "actif") {
      return html`<button type="button" class="btn activate on" data-action="noop" aria-live="polite">${icon("check", 22, { stroke: 2.6 })}Activée — c'est en place</button>
        <button type="button" class="btn link" style="align-self:center" data-action="deactivate" ${this.isBusy("deactivate") ? "disabled" : ""}>Désactiver cette idée</button>`;
    }
    if (d.pending) {
      return html`<button type="button" class="btn activate waiting" data-action="noop" aria-live="polite">En attente du capteur</button>
        <span class="sub" style="font-size:14px;text-align:center">L'idée s'active toute seule dès que le capteur est ajouté.</span>
        <button type="button" class="btn link" style="align-self:center" data-action="deactivate">Ne plus attendre</button>`;
    }
    const ready = d.status === "pret";
    if (this.s.preview && this.s.preview.id === d.id) return this.previewBlock(this.s.preview.data, ready, busy);
    return html`<button type="button" class="btn activate" data-action="activate" ${busy ? "disabled" : ""}>${busy ? "Un instant…" : ready ? "Activer cette idée" : "Activer quand le capteur sera là"}</button>
      ${ready ? "" : html`<span class="sub" style="font-size:14px;text-align:center">L'idée s'active toute seule dès que le capteur est ajouté.</span>`}`;
  }

  /** Ideas run by a module (« Anniversaires »): on/off = its reminders; the dates live on their own page. */
  moduleBlock(d, busy) {
    const manage = html`<button type="button" class="btn secondary" data-action="open-birthdays">${icon("cake", 20)}Mes anniversaires</button>`;
    if (d.status === "actif") {
      return html`<button type="button" class="btn activate on" data-action="noop" aria-live="polite">${icon("check", 22, { stroke: 2.6 })}Activée — c'est en place</button>
        ${manage}
        <button type="button" class="btn link" style="align-self:center" data-action="deactivate" ${this.isBusy("deactivate") ? "disabled" : ""}>Couper les rappels</button>`;
    }
    if (d.status === "pret") {
      return html`<button type="button" class="btn activate" data-action="activate" ${busy ? "disabled" : ""}>${busy ? "Un instant…" : "Activer les rappels"}</button>${manage}`;
    }
    return html`<button type="button" class="btn activate" data-action="open-birthdays">Ajouter des anniversaires</button>
      <span class="sub" style="font-size:14px;text-align:center">À la main, depuis vos contacts ou depuis votre agenda. Les rappels démarrent tout seuls.</span>`;
  }

  // ----- actions -------------------------------------------------------------------

  async onAction(action, el) {
    const app = this.app;
    const d = this.s.detail;
    switch (action) {
      case "filter":
        return this.setState({ filter: el.dataset.filter });
      case "device":
        return this.setState({ device: el.dataset.device });
      case "all-ideas":
        return this.setState({ device: null, filter: "toutes" });
      case "open-birthdays":
        return this.openBirthdays(true);
      case "open":
        return this.open(el.dataset.id);
      case "back":
        return this.back();
      case "retry-list":
        this.setState({ listError: false, list: null });
        return this.loadList();
      case "retry-detail":
        this.setState({ detailError: false });
        return this.loadDetail(this.s.id);
      case "activate":
        // Mode Expert : on montre d'abord ce qui va changer.
        if (!d.module && app.api.state?.settings?.expert_mode === true) {
          return this.run("activate", async () => {
            const data = await this.api.previewIdea(d.id);
            this.setState({ preview: { id: d.id, data } });
          }, "Impossible de préparer l'aperçu de cette idée.");
        }
        return this.onAction("confirm-activate", el);
      case "cancel-preview":
        return this.setState({ preview: null });
      case "confirm-activate":
        this.s.preview = null;
        return this.run("activate", async () => {
          const r = await this.api.activateIdea(d.id);
          this.setState({ detail: r });
          if (d.module) app.notify("Les rappels sont activés.");
          else app.notify(r.status === "actif" ? "C'est en place : l'automatisme est créé et réglé." : "C'est noté : l'idée s'activera toute seule dès que le capteur sera ajouté.");
          app.reload();
        }, "Impossible d'activer cette idée.");
      case "deactivate":
        return this.run("deactivate", async () => {
          const r = await this.api.deactivateIdea(d.id);
          this.setState({ detail: r });
          app.notify("Idée désactivée.");
          app.reload();
        }, "Impossible de désactiver cette idée.");
      case "guide":
        return app.navigate("guide", { tab: "buy", need: el.dataset.guide, back: "ideas", backParams: { id: d.id } });
      case "pair":
        return this.run("pair", async () => {
          await this.api.expectIdea(d.id);
          app.navigate("add", { type: el.dataset.type, back: "ideas", backParams: { id: d.id } });
        }, "Impossible d'ouvrir l'ajout d'appareil.");
      case "add-detected":
        return this.run("detected", async () => {
          app.notify("Si l'appareil affiche une demande sur son écran, acceptez-la avec la télécommande.");
          const r = await this.api.addDetected({ flow_id: el.dataset.flow });
          if (r.ok) app.notify(r.message_fr);
          else app.toast(r.message_fr, null);
          await this.loadDetail(d.id);
        }, "Impossible d'ajouter cet appareil.");
      case "test-announce":
        return this.run("announce", async () => {
          const r = await this.api.testAnnounce(el.dataset.entity);
          app.notify(r.message_fr || "C'est envoyé.");
        }, "L'enceinte n'a pas pu parler.");
      default:
    }
    return undefined;
  }

  onInput(field, el, ev) {
    if (ev.type !== "change" || !this.s.detail) return;
    const d = this.s.detail;
    if (field === "device") {
      if (!el.value) return;
      this.configure({ devices: { [el.dataset.need]: [el.value] } });
    } else if (field === "opt") {
      const o = (d.options || []).find((x) => x.key === el.dataset.key);
      if (!o) return;
      let value;
      if (o.type === "bool") value = !!el.checked;
      else if (o.type === "choice") value = o.choices[Number(el.value)]?.value;
      else value = Number(el.value);
      this.configure({ options: { [o.key]: value } });
    }
  }

  configure(patch) {
    const id = this.s.detail.id;
    return this.run("configure", async () => {
      const r = await this.api.configureIdea(id, patch);
      if (this.s.id === id) this.setState({ detail: r });
      if (r.status === "actif") this.app.notify("Réglage enregistré : l'automatisme est mis à jour.");
    }, "Impossible d'enregistrer ce réglage.");
  }
}
