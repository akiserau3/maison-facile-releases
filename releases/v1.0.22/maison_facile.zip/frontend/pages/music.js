// Réglages > Musique : Music Assistant en trois gestes (installer, connecter ses comptes,
// écouter avec les paroles). Maison Facile ne voit jamais un mot de passe : la connexion
// aux plateformes se fait dans Music Assistant, ouvert ici sur la bonne page.
// Exigences des plateformes vérifiées dans le code de Music Assistant (fournisseurs).
import { Page, html } from "../lib.js";
import { icon } from "../icons.js";
import { openIngressSession, ingressPage } from "../components/ingress.js";

const MA_PAGES = { accounts: "#/settings/providers", "now-playing": "#/now-playing" };

export const PLATFORMS = [
  { id: "radio", name: "Radios du monde entier", need: "Gratuit, rien à connecter", how: "Déjà prêt : cherchez une radio dans Music Assistant.", level: "facile", color: "#0E7A0D" },
  { id: "spotify", name: "Spotify", need: "Abonnement Premium obligatoire", how: "Connexion officielle Spotify : une page Spotify s'ouvre, vous acceptez.", level: "facile", color: "#1DB954" },
  { id: "tidal", name: "Tidal", need: "Abonnement Tidal", how: "Connexion officielle Tidal, comme pour Spotify.", level: "facile", color: "#111111" },
  { id: "qobuz", name: "Qobuz", need: "Abonnement Qobuz", how: "Votre e-mail et votre mot de passe Qobuz, tapés dans Music Assistant.", level: "facile", color: "#0070EF" },
  { id: "soundcloud", name: "SoundCloud", need: "Compte gratuit", how: "Connexion officielle SoundCloud.", level: "facile", color: "#FF5500" },
  { id: "deezer", name: "Deezer", need: "Abonnement Deezer", how: "Il faut copier un code « ARL » depuis Deezer ouvert dans un navigateur d'ordinateur : Music Assistant explique où le trouver.", level: "avancé", color: "#A238FF" },
  { id: "ytmusic", name: "YouTube Music", need: "Abonnement YouTube Premium (encore en bêta dans Music Assistant)", how: "Il faut copier des « cookies » depuis un navigateur : réservé aux curieux.", level: "avancé", color: "#FF0000" },
  { id: "apple_music", name: "Apple Music", need: "Abonnement Apple Music", how: "Connexion à votre compte Apple depuis Music Assistant.", level: "intermédiaire", color: "#FA243C" },
  { id: "plex", name: "Plex", need: "Un serveur Plex avec votre musique", how: "Connexion à votre compte Plex.", level: "intermédiaire", color: "#E5A00D" },
];
const LEVEL_CHIP = { facile: "actif", "intermédiaire": "", "avancé": "manque" };

export class MusicSection extends Page {
  init() {
    this.s = { app: null, error: false, confirm: false, open: null };
    this.load(true);
    this.every(3000, () => {
      if (this.s.app?.action === "wait") this.load(false);
    });
  }

  async load(first) {
    try {
      const d = await this.api.appsList();
      const app = d.available ? (d.apps || []).find((a) => a.id === "music_assistant") : null;
      this.setState({ app: app || { unavailable: true, message: d.message }, error: false });
      // Lien direct depuis l'accueil (« Paroles ») : on ouvre la bonne page tout de suite.
      if (first && this.params?.view && app?.action === "open") this.openMa(this.params.view);
    } catch (e) {
      if (!this.s.app) this.setState({ error: true });
    }
  }

  async openMa(view) {
    const app = this.s.app;
    if (!app?.ingress_url) return;
    try {
      if (this._stop) this._stop();
      this._stop = await openIngressSession(this.hass);
      this.onCleanup(() => this._stop && this._stop());
      this.setState({ open: { view, url: ingressPage(app.ingress_url, MA_PAGES[view] || ""), error: false } });
    } catch (e) {
      this.setState({ open: { view, url: "", error: true } });
    }
  }

  template() {
    if (this.s.open) return this.frameView(this.s.open);
    const intro = html`<div><h2 class="sec-title">Musique</h2>
      <p class="sub" style="font-size:16px;line-height:1.45;max-width:680px">Votre musique sur les enceintes et télés de la maison, avec Music Assistant : Spotify, Deezer, radios… et les paroles en karaoké.</p></div>`;
    const a = this.s.app;
    if (this.s.error && !a) return html`<div class="stack">${intro}<div class="glass card"><p>Impossible de lire l'état de Music Assistant.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div></div>`;
    if (!a) return html`<div class="stack">${intro}<p class="sub">Chargement…</p></div>`;
    if (a.unavailable) return html`<div class="stack">${intro}<div class="glass card"><p>${a.message}</p></div></div>`;
    const ready = a.action === "open";
    return html`<div class="stack">${intro}
      ${this.stepCard(1, "Installer Music Assistant", ready || a.state === "not_running" ? "Installé" : "", this.installBlock(a))}
      ${this.stepCard(2, "Connecter vos comptes", "", ready
        ? html`<p class="sub" style="font-size:15px">Choisissez une plateforme : Music Assistant s'ouvre sur la page des comptes, cliquez sur « Ajouter » puis sur la plateforme.</p>
            <div class="apps-grid" style="grid-template-columns:repeat(auto-fill,minmax(260px,1fr))">${PLATFORMS.map((p) => this.platform(p))}</div>`
        : html`<p class="sub">Disponible une fois Music Assistant installé et démarré.</p>`)}
      ${this.stepCard(3, "Écouter, avec les paroles", "", ready
        ? html`<p class="sub" style="font-size:15px">Le lecteur plein écran de Music Assistant affiche la pochette et, quand elles existent, les paroles synchronisées : activez le mode karaoké depuis l'icône des paroles. Les paroles arrivent parfois seulement à la deuxième écoute d'un morceau.</p>
            <div class="row wrap"><button type="button" class="btn primary" data-action="open" data-view="now-playing">${icon("music", 20)}Ouvrir le lecteur et les paroles</button>
            <button type="button" class="btn secondary" data-action="open" data-view="">Ouvrir Music Assistant</button></div>`
        : html`<p class="sub">Disponible une fois Music Assistant installé et démarré.</p>`)}
    </div>`;
  }

  stepCard(n, title, done, body) {
    return html`<section class="glass card stack" style="gap:12px" data-key="music-step-${n}">
      <div class="row" style="gap:12px;align-items:center"><span class="step-n" style="width:34px;height:34px;border-radius:50%;background:var(--accent);color:var(--accent-text);display:inline-flex;align-items:center;justify-content:center;font-weight:800">${n}</span>
        <strong class="grow" style="font-size:19px">${title}</strong>${done ? html`<span class="st-badge actif">${icon("check", 14)} ${done}</span>` : ""}</div>
      ${body}
    </section>`;
  }

  installBlock(a) {
    if (a.action === "open") return html`<p class="sub" style="font-size:15px">Music Assistant fonctionne${a.version ? ` (version ${a.version})` : ""}.</p>`;
    if (a.action === "wait") return html`<p class="sub"><span class="spinner" style="display:inline-block;width:16px;height:16px;margin-right:8px;vertical-align:middle"></span>${a.label}</p>`;
    if (a.action === "start") return html`<div class="row wrap"><button type="button" class="btn primary" data-action="start">Démarrer Music Assistant</button></div>`;
    if (this.s.confirm) {
      return html`<p style="font-size:15px">Une sauvegarde complète de la box est faite d'abord, puis Music Assistant s'installe (quelques minutes).</p>
        <div class="row wrap"><button type="button" class="btn primary" data-action="install">Installer maintenant</button><button type="button" class="btn secondary" data-action="cancel">Annuler</button></div>`;
    }
    return html`${a.error ? html`<p class="form-error" role="alert">${a.error}</p>` : ""}
      <div class="row wrap"><button type="button" class="btn primary" data-action="ask">Installer Music Assistant</button></div>`;
  }

  platform(p) {
    return html`<div class="card" style="display:flex;flex-direction:column;gap:6px;padding:14px;border-radius:16px;background:var(--surface);border:1px solid var(--line)">
      <div class="row" style="gap:10px;align-items:center"><span style="width:12px;height:12px;border-radius:50%;background:${p.color};flex-shrink:0"></span><strong class="grow">${p.name}</strong><span class="st-badge ${LEVEL_CHIP[p.level] ?? ""}">${p.level[0].toUpperCase() + p.level.slice(1)}</span></div>
      <span style="font-size:14px;font-weight:600">${p.need}</span>
      <span class="sub" style="font-size:14px">${p.how}</span>
      ${p.id === "radio" ? "" : html`<button type="button" class="btn secondary sm" style="align-self:flex-start;margin-top:4px" data-action="open" data-view="accounts" data-platform="${p.name}">Connecter ${p.name}</button>`}
    </div>`;
  }

  frameView(o) {
    const hint = o.view === "accounts" ? `Cliquez sur « Ajouter »${o.platform ? `, puis sur « ${o.platform} »` : ""}.` : "";
    return html`<div class="stack" style="gap:12px">
      <div class="row wrap" style="gap:12px;align-items:center">
        <button type="button" class="btn secondary sm" data-action="close">${icon("back", 18)}Retour à Musique</button>
        <strong style="font-size:18px">Music Assistant</strong>${hint ? html`<span class="sub" style="font-size:15px">${hint}</span>` : ""}
      </div>
      ${o.error
        ? html`<div class="glass card"><p>Impossible d'ouvrir Music Assistant ici.</p><button type="button" class="btn secondary sm" data-action="close">Retour</button></div>`
        : html`<iframe class="app-frame" src="${o.url}" title="Music Assistant" data-key="ma-frame" allow="autoplay; clipboard-write; fullscreen"></iframe>`}
    </div>`;
  }

  async onAction(action, el) {
    switch (action) {
      case "retry":
        this.setState({ error: false });
        return this.load(false);
      case "ask":
        return this.setState({ confirm: true });
      case "cancel":
        return this.setState({ confirm: false });
      case "install":
        this.s.confirm = false;
        return this.run("install", async () => {
          await this.api.appsInstall("music_assistant");
          await this.load(false);
        }, "Impossible de lancer l'installation.");
      case "start":
        return this.run("start", async () => {
          await this.api.appsStart("music_assistant");
          await this.load(false);
        }, "Impossible de démarrer Music Assistant.");
      case "open":
        await this.openMa(el.dataset.view || "");
        if (this.s.open) this.setState({ open: { ...this.s.open, platform: el.dataset.platform || "" } });
        return undefined;
      case "close":
        if (this._stop) this._stop();
        this.setState({ open: null });
        return this.load(false);
      default:
        return undefined;
    }
  }
}
