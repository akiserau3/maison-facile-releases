// Réglages > IA > Reconnaissance des visages : tutoriel du début à la fin (recipes.py, FACE_STEPS).
// Accord explicite d'abord ; les photos, c'est l'utilisateur qui les ajoute (page Visages de
// Frigate, ouverte dans Maison Facile) ; Maison Facile active, vérifie et propose l'idée.
import { html } from "../lib.js";
import { icon } from "../icons.js";

export const facesMixin = {
  async loadFaces() {
    try {
      this.setState({ faces: await this.api.facesStatus() });
    } catch (e) {
      /* la carte reste en « Chargement » ; réessayé au prochain passage */
    }
  },

  facesCard() {
    const f = this.s.faces;
    const head = html`<div class="row" style="gap:14px;align-items:center">
      <span class="li-icon" style="background:#6B47B8;width:52px;height:52px;border-radius:15px">${icon("heart", 26)}</span>
      <span class="grow"><strong style="font-size:19px">Reconnaissance des visages</strong> <span class="tag">Option</span><br>
      <span class="sub" style="font-size:15px">Frigate reconnaît les personnes du foyer : « Marie est arrivée ». Tout reste dans la box.</span></span>
    </div>`;
    if (!f) return html`<section class="glass card stack">${head}<p class="sub">Chargement…</p></section>`;
    if (!f.available || !f.ready) return html`<section class="glass card stack">${head}<p class="sub">${f.message || "Installez d'abord les caméras intelligentes (ci-dessus)."}</p></section>`;
    if (!this.s.facesOpen) {
      return html`<section class="glass card stack">${head}
        <div class="row wrap"><button type="button" class="btn secondary" data-action="faces-open">${f.enabled ? "Gérer la reconnaissance" : "Découvrir, étape par étape"}</button></div></section>`;
    }
    return html`<section class="glass card stack" style="gap:12px" data-key="faces">${head}
      <ol class="recipe-steps">${f.steps.map((x) => this.faceStep(x, f))}</ol>
      ${f.enabled ? html`<button type="button" class="btn link" style="align-self:flex-start" data-action="faces-off" ${this.isBusy("faces") ? "disabled" : ""}>Couper la reconnaissance des visages</button>` : ""}
    </section>`;
  },

  faceStep(x, f) {
    const mark = x.state === "done" ? html`<span class="rs-mark done">${icon("check", 16, { stroke: 3 })}</span>`
      : x.state === "running" ? html`<span class="rs-mark run"><span class="spinner" style="width:14px;height:14px"></span></span>`
        : html`<span class="rs-mark"></span>`;
    const open = this.s.learn[`face-${x.id}`];
    return html`<li class="rs ${x.state} ${x.next ? "next" : ""}" data-key="face-${x.id}">
      ${mark}
      <div class="grow stack" style="gap:6px;min-width:0">
        <strong style="font-size:16px">${x.title}</strong>
        <span class="sub" style="font-size:14px">${x.what}</span>
        ${x.error ? html`<p class="form-error" role="alert">${x.error}</p>` : ""}
        ${x.next || (x.id === "photos" && f.enabled) || (x.id === "test" && f.enabled) ? this.faceBody(x, f) : ""}
        <button type="button" class="btn link" style="align-self:flex-start" data-action="learn" data-id="face-${x.id}">${icon("help", 16)}J'apprends</button>
        ${open ? html`<p class="learn" style="font-size:14px">${x.learn}</p>` : ""}
      </div>
    </li>`;
  },

  faceBody(x, f) {
    if (x.id === "consent") {
      const c = this.s.consent || [];
      return html`<div class="stack" style="gap:8px">${f.consent_items.map((t, i) => html`<label class="row" style="gap:10px;align-items:flex-start;font-size:15px;cursor:pointer">
          <input type="checkbox" data-field="consent" data-i="${i}" ${c.includes(i) ? "checked" : ""} style="width:20px;height:20px;margin-top:2px"><span>${t}</span></label>`)}
        <div class="row wrap"><button type="button" class="btn primary sm" data-action="faces-consent" ${c.length === f.consent_items.length ? "" : "disabled"}>J'accepte</button></div></div>`;
    }
    if (x.id === "enable") {
      return html`<div class="row wrap"><button type="button" class="btn primary sm" data-action="faces-on" ${this.isBusy("faces") || x.state === "running" ? "disabled" : ""}>${x.state === "running" ? "Frigate redémarre…" : "Activer"}</button></div>`;
    }
    if (x.id === "photos") {
      return html`${f.faces.length
          ? html`<p class="sub" style="font-size:14px">Déjà enregistrés : ${f.faces.map((p) => `${p.name} (${p.photos} photo${p.photos > 1 ? "s" : ""})`).join(", ")}.</p>`
          : ""}
        <div class="row wrap"><button type="button" class="btn primary sm" data-action="faces-library">${icon("camera", 18)}Ouvrir la page Visages de Frigate</button>
        <button type="button" class="btn secondary sm" data-action="faces-refresh">J'ai ajouté des photos</button></div>`;
    }
    if (x.id === "test") {
      return html`<div class="stack" style="gap:4px">${f.sensors.length
          ? f.sensors.map((s) => html`<span style="font-size:15px">${icon("camera", 16)} ${s.name.replace(/\s*Last Recognized Face$/i, "")} : <strong>${["unknown", "unavailable", "none", ""].includes(String(s.state).toLowerCase()) ? "personne pour l'instant" : s.state}</strong></span>`)
          : html`<span class="sub" style="font-size:14px">Les capteurs « visage reconnu » apparaissent une minute après l'activation.</span>`}
        <div class="row wrap"><button type="button" class="btn secondary sm" data-action="faces-refresh">Actualiser</button></div></div>`;
    }
    if (x.id === "idea") {
      return html`<div class="row wrap"><button type="button" class="btn primary sm" data-action="faces-idea">Voir l'idée « Bienvenue »</button></div>`;
    }
    return "";
  },

  async facesAction(action, el) {
    switch (action) {
      case "faces-open":
        this.setState({ facesOpen: true });
        return this.loadFaces();
      case "faces-consent":
        return this.run("faces", async () => this.setState({ faces: await this.api.facesConsent(this.s.consent || []) }), "Impossible d'enregistrer votre accord.");
      case "faces-on":
      case "faces-off":
        return this.run("faces", async () => {
          await this.api.facesSet(action === "faces-on");
          await this.loadFaces();
        }, "Impossible de changer la reconnaissance des visages.");
      case "faces-library":
        return this.openFrigate("faces");
      case "faces-refresh":
        return this.loadFaces();
      case "faces-idea":
        return this.app.navigate("ideas", { id: "visage_bienvenue" });
      default:
        return undefined;
    }
  },

  facesInput(field, el) {
    if (field !== "consent") return false;
    const i = Number(el.dataset.i);
    const c = new Set(this.s.consent || []);
    if (el.checked) c.add(i);
    else c.delete(i);
    this.setState({ consent: [...c].sort() });
    return true;
  },
};
