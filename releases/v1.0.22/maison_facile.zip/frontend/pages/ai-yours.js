// Réglages > IA > « Votre IA » et « Créer un automatisme avec l'IA » (ai.py, ai_rules.py).
// La connexion d'une IA passe par le formulaire officiel de l'intégration de Home Assistant
// (API config_entries/flow, textes français de Home Assistant) : Maison Facile ne garde
// aucune clé. L'assistant propose ; rien n'est créé sans « Créer cet automatisme ».
import { html } from "../lib.js";
import { icon } from "../icons.js";

const GENAI_NAME = { ollama: "Ollama", gemini: "Google Gemini", openai: "OpenAI" };
const FIELD_FR = { url: "Adresse", api_key: "Clé API", model: "Modèle", prompt: "Consigne", name: "Nom" };

export const yoursMixin = {
  async loadAi() {
    try {
      this.setState({ ai: await this.api.aiStatus() });
    } catch (e) {
      /* réessayé au prochain passage */
    }
  },

  // ----- formulaire officiel d'une intégration ----------------------------------

  async flowStart(domain) {
    const tr = await this.hass.callWS({ type: "frontend/get_translations", language: "fr", category: "config", integration: [domain] }).catch(() => ({ resources: {} }));
    const result = await this.hass.callApi("POST", "config/config_entries/flow", { handler: domain, show_advanced_options: false });
    this.setState({ flow: { domain, tr: tr?.resources || {}, result, values: {} } });
    this.flowFollow();
  },

  async flowSubmit() {
    const f = this.s.flow;
    const data = {};
    for (const field of f.result.data_schema || []) {
      const v = f.values[field.name];
      if (v === undefined || v === "") continue;
      data[field.name] = field.selector?.number || field.type === "integer" || field.type === "float" ? Number(v) : v;
    }
    const result = await this.hass.callApi("POST", `config/config_entries/flow/${f.result.flow_id}`, data);
    this.setState({ flow: { ...f, result, values: {} } });
    this.flowFollow();
  },

  /** Étape « en cours » (téléchargement d'un modèle…) : on relit toutes les 3 s. */
  flowFollow() {
    const f = this.s.flow;
    clearTimeout(this._flowTimer);
    if (f?.result?.type === "progress") {
      this._flowTimer = setTimeout(async () => {
        try {
          const result = await this.hass.callApi("GET", `config/config_entries/flow/${f.result.flow_id}`);
          if (this.s.flow) this.setState({ flow: { ...this.s.flow, result } });
        } catch (e) {
          /* déjà terminé */
        }
        this.flowFollow();
      }, 3000);
      this.onCleanup(() => clearTimeout(this._flowTimer));
    }
    if (f?.result?.type === "create_entry") this.loadAi();
  },

  flowText(key) {
    const f = this.s.flow;
    return f.tr[`component.${f.domain}.config.${key}`] || "";
  },

  flowView() {
    const f = this.s.flow;
    const r = f.result;
    const provider = (this.s.ai?.providers || []).find((p) => p.domain === f.domain);
    const head = html`<strong style="font-size:18px">Relier ${provider?.name || f.domain}</strong>`;
    if (r.type === "create_entry") {
      return html`<div class="stack" style="gap:10px">${head}<p>${icon("check", 18)} C'est relié. Vous pouvez maintenant créer des automatismes avec l'IA (plus bas).</p>
        <div class="row wrap"><button type="button" class="btn primary sm" data-action="flow-close">Terminer</button></div></div>`;
    }
    if (r.type === "abort") {
      const why = this.flowText(`abort.${r.reason}`) || r.reason;
      return html`<div class="stack" style="gap:10px">${head}<p class="form-error" role="alert">${why}</p><div class="row wrap"><button type="button" class="btn secondary sm" data-action="flow-close">Fermer</button></div></div>`;
    }
    if (r.type === "progress") {
      return html`<div class="stack" style="gap:10px">${head}<p><span class="spinner" style="display:inline-block;width:16px;height:16px;margin-right:8px;vertical-align:middle"></span>${this.flowText(`progress.${r.progress_action}`) || "Un instant, ça peut prendre plusieurs minutes…"}</p></div>`;
    }
    const desc = this.flowText(`step.${r.step_id}.description`);
    const errors = Object.values(r.errors || {}).map((code) => this.flowText(`error.${code}`) || code);
    return html`<div class="stack" style="gap:12px">${head}
      ${desc ? html`<p class="sub" style="font-size:15px;white-space:pre-line">${desc.replace(/\{[a-z_]+\}/g, "")}</p>` : ""}
      ${errors.length ? html`<p class="form-error" role="alert">${errors.join(" ")}</p>` : ""}
      ${(r.data_schema || []).map((field) => this.flowField(field, r.step_id))}
      <div class="row wrap"><button type="button" class="btn primary sm" data-action="flow-submit" ${this.isBusy("flow") ? "disabled" : ""}>${this.isBusy("flow") ? "Un instant…" : "Valider"}</button>
      <button type="button" class="btn secondary sm" data-action="flow-close">Annuler</button></div>
    </div>`;
  },

  flowField(field, step) {
    const label = this.flowText(`step.${step}.data.${field.name}`) || FIELD_FR[field.name] || field.name;
    const help = this.flowText(`step.${step}.data_description.${field.name}`);
    const value = this.s.flow.values[field.name] ?? field.default ?? "";
    const sel = field.selector || {};
    const opts = sel.select?.options || field.options;
    let input;
    if (opts) {
      const list = opts.map((o) => (typeof o === "object" ? (Array.isArray(o) ? { value: o[0], label: o[1] } : o) : { value: o, label: o }));
      input = html`<select class="input" data-field="flow" data-name="${field.name}">${list.map((o) => html`<option value="${o.value}" ${String(o.value) === String(value) ? "selected" : ""}>${o.label}</option>`)}</select>`;
    } else if (sel.boolean || field.type === "boolean") {
      input = html`<input type="checkbox" data-field="flow" data-name="${field.name}" ${value ? "checked" : ""} style="width:20px;height:20px">`;
    } else {
      const password = sel.text?.type === "password" || /api_key|password|token/.test(field.name);
      input = html`<input class="input" type="${password ? "password" : "text"}" data-field="flow" data-name="${field.name}" value="${value}" autocomplete="off">`;
    }
    return html`<label class="field-label" style="display:flex;flex-direction:column;gap:6px;text-align:left;align-items:stretch">${label}${field.required ? "" : " (facultatif)"}${input}${help ? html`<span class="sub" style="font-size:13px">${help}</span>` : ""}</label>`;
  },

  // ----- carte « Votre IA » -----------------------------------------------------

  yourAiCard() {
    const a = this.s.ai;
    const head = html`<div class="row" style="gap:14px;align-items:center">
      <span class="li-icon" style="background:#C2185B;width:52px;height:52px;border-radius:15px">${icon("magic", 26)}</span>
      <span class="grow"><strong style="font-size:19px">Votre IA</strong><br><span class="sub" style="font-size:15px">Reliez une IA à la maison : elle décrit ce que voient les caméras et vous aide à créer des automatismes.</span></span>
    </div>`;
    if (!a) return html`<section class="glass card stack">${head}<p class="sub">Chargement…</p></section>`;
    if (this.s.flow) return html`<section class="glass card stack" data-key="ai-flow">${head}${this.flowView()}</section>`;
    const linked = new Set(a.entries.map((e) => e.domain));
    return html`<section class="glass card stack" style="gap:14px" data-key="your-ai">${head}
      ${a.entries.length ? html`<p style="font-size:15px">${icon("check", 16)} Reliée : ${a.entries.map((e) => e.title).join(", ")}.</p>` : ""}
      <div class="apps-grid" style="grid-template-columns:repeat(auto-fill,minmax(250px,1fr))">${a.providers.map((p) => html`<div class="card" style="display:flex;flex-direction:column;gap:6px;padding:14px;border-radius:16px;background:var(--surface);border:1px solid var(--line)">
        <div class="row" style="gap:8px;align-items:center"><span style="width:12px;height:12px;border-radius:50%;background:${p.color}"></span><strong class="grow">${p.name}</strong><span class="st-badge ${p.kind === "local" ? "actif" : ""}">${p.kind === "local" ? "Chez vous" : "En ligne"}</span></div>
        <span style="font-size:14px;font-weight:600">${p.cost} · ${p.privacy}</span>
        <span class="sub" style="font-size:14px">${p.need}</span>
        ${linked.has(p.domain) ? html`<span class="tag" style="align-self:flex-start">${icon("check", 14)} Reliée</span>` : html`<button type="button" class="btn secondary sm" style="align-self:flex-start" data-action="flow-start" data-domain="${p.domain}">Relier</button>`}
      </div>`)}</div>
      ${this.genaiBlock(a)}
    </section>`;
  },

  genaiBlock(a) {
    if (!a.frigate_ready) return html`<p class="sub" style="font-size:14px">Descriptions des caméras : installez d'abord les caméras intelligentes.</p>`;
    const g = this.s.genai || { provider: "ollama", model: "qwen2.5vl:3b", base_url: "", api_key: "", accept: false };
    const cloud = g.provider !== "ollama";
    return html`<div class="stack" style="gap:10px;padding-top:12px;border-top:1px solid var(--line)" data-key="genai">
      <strong style="font-size:17px">Descriptions des caméras</strong>
      <span class="sub" style="font-size:15px">Frigate demande à une IA de décrire en une phrase ce qui se passe : « Un livreur dépose un colis devant la porte ». Il faut une IA qui comprend les images (modèle « vision »).</span>
      ${a.genai ? html`<p style="font-size:15px">${icon("check", 16)} Activées avec ${GENAI_NAME[a.genai.provider] || a.genai.provider} (${a.genai.model}). <button type="button" class="btn link" data-action="genai-off" ${a.genai_running ? "disabled" : ""}>Couper</button></p>` : ""}
      ${a.genai_error ? html`<p class="form-error" role="alert">${a.genai_error}</p>` : ""}
      <div class="row wrap" style="gap:10px;align-items:flex-end">
        <label class="field-label" style="display:flex;flex-direction:column;gap:6px;text-align:left;align-items:stretch">IA
          <select class="input" data-field="genai" data-name="provider">${["ollama", "gemini", "openai"].map((p) => html`<option value="${p}" ${g.provider === p ? "selected" : ""}>${{ ollama: "Ollama (chez vous)", gemini: "Google Gemini", openai: "OpenAI" }[p]}</option>`)}</select></label>
        <label class="field-label" style="display:flex;flex-direction:column;gap:6px;text-align:left;align-items:stretch">Modèle
          <input class="input" data-field="genai" data-name="model" value="${g.model}" placeholder="${cloud ? (g.provider === "gemini" ? "gemini-2.5-flash" : "gpt-4o-mini") : "qwen2.5vl:3b"}"></label>
        ${cloud
          ? html`<label class="field-label" style="display:flex;flex-direction:column;gap:6px;text-align:left;align-items:stretch">Clé API<input class="input" type="password" autocomplete="off" data-field="genai" data-name="api_key" value="${g.api_key}"></label>`
          : html`<label class="field-label" style="display:flex;flex-direction:column;gap:6px;text-align:left;align-items:stretch">Adresse d'Ollama<input class="input" data-field="genai" data-name="base_url" value="${g.base_url}" placeholder="http://192.168.1.50:11434"></label>`}
      </div>
      ${cloud ? html`<label class="row" style="gap:10px;align-items:flex-start;font-size:14px;cursor:pointer"><input type="checkbox" data-field="genai" data-name="accept" ${g.accept ? "checked" : ""} style="width:18px;height:18px;margin-top:2px"><span>J'accepte que des images de mes caméras partent sur Internet, chez ce fournisseur. La clé est enregistrée dans les réglages de Frigate.</span></label>` : ""}
      <div class="row wrap"><button type="button" class="btn primary sm" data-action="genai-on" ${a.genai_running || (cloud && !g.accept) ? "disabled" : ""}>${a.genai_running ? "Frigate redémarre…" : a.genai ? "Changer de réglages" : "Activer les descriptions"}</button></div>
    </div>`;
  },

  // ----- carte « Créer un automatisme avec l'IA » ------------------------------

  assistantCard() {
    const a = this.s.ai;
    const head = html`<div class="row" style="gap:14px;align-items:center">
      <span class="li-icon" style="background:#0067C0;width:52px;height:52px;border-radius:15px">${icon("chat", 26)}</span>
      <span class="grow"><strong style="font-size:19px">Créer un automatisme avec l'IA</strong><br><span class="sub" style="font-size:15px">Décrivez en français ce que la maison doit faire. L'IA propose, Maison Facile vérifie, vous décidez.</span></span>
    </div>`;
    if (!a) return "";
    if (!a.ai_task.length) return html`<section class="glass card stack">${head}<p class="sub">Reliez d'abord une IA (ci-dessus).</p></section>`;
    const d = this.s.draft;
    return html`<section class="glass card stack" style="gap:12px" data-key="assistant">${head}
      <label class="field-label" style="display:flex;flex-direction:column;gap:6px;text-align:left;align-items:stretch">Votre demande
        <textarea class="input" rows="3" data-field="ask" maxlength="500" placeholder="Exemple : quand il pleut et qu'une fenêtre est ouverte le soir, préviens-moi sur mon téléphone.">${this.s.ask || ""}</textarea></label>
      <div class="row wrap"><button type="button" class="btn primary sm" data-action="ai-draft" ${this.isBusy("draft") || (this.s.ask || "").trim().length < 5 ? "disabled" : ""}>${this.isBusy("draft") ? "L'IA réfléchit…" : "Proposer un automatisme"}</button></div>
      ${this.s.draftError ? html`<p class="form-error" role="alert">${this.s.draftError}</p>` : ""}
      ${d ? this.draftView(d) : ""}
      ${a.automations.length
        ? html`<div class="stack" style="gap:6px;padding-top:10px;border-top:1px solid var(--line)"><strong>Mes automatismes créés avec l'IA</strong>
            ${a.automations.map((x) => html`<div class="row wrap" style="gap:10px;align-items:center"><span class="grow" style="min-width:0"><strong>${x.alias.replace(/^IA – /, "")}</strong><br><span class="sub" style="font-size:14px">${x.explication}</span></span>
              <button type="button" class="btn link" data-action="ai-delete" data-id="${x.id}">Supprimer</button></div>`)}</div>`
        : ""}
    </section>`;
  },

  draftView(d) {
    const blocked = d.problems.length > 0;
    return html`<div class="glass card stack" style="gap:10px" data-key="draft">
      <strong style="font-size:17px">Proposition : ${d.alias}</strong>
      <p style="font-size:15px">${d.explication}</p>
      ${d.devices.length ? html`<p class="sub" style="font-size:14px">Appareils utilisés : ${d.devices.join(", ")}.</p>` : ""}
      ${d.problems.map((p) => html`<p class="form-error" role="alert">${p}</p>`)}
      ${d.conflicts.length ? html`<p style="font-size:14px;color:var(--warn)">${icon("warn", 16)} Déjà piloté par : ${d.conflicts.map((c) => `« ${c.alias} »`).join(", ")}. Les deux fonctionneront en même temps.</p>` : ""}
      ${d.sensitive.length && !blocked
        ? html`<label class="row" style="gap:10px;align-items:flex-start;font-size:15px;cursor:pointer;color:var(--warn)"><input type="checkbox" data-field="sensitive" ${this.s.sensitiveOk ? "checked" : ""} style="width:20px;height:20px;margin-top:2px"><span>Attention, cet automatisme ${d.sensitive.join(" et ")}. Je confirme que c'est voulu.</span></label>`
        : ""}
      <button type="button" class="btn link" style="align-self:flex-start" data-action="learn" data-id="draft-yaml">${icon("help", 16)}J'apprends : voir l'automatisme tel qu'il sera écrit</button>
      ${this.s.learn["draft-yaml"] ? html`<span class="sub" style="font-size:14px">Un automatisme a trois parties : « triggers » (quand), « conditions » (si), « actions » (alors).</span><pre class="tech">${d.yaml}</pre>` : ""}
      <div class="row wrap">
        ${blocked ? "" : html`<button type="button" class="btn primary sm" data-action="ai-save" ${this.isBusy("save") || (d.sensitive.length && !this.s.sensitiveOk) ? "disabled" : ""}>Créer cet automatisme</button>`}
        <button type="button" class="btn secondary sm" data-action="ai-cancel">${blocked ? "Fermer" : "Non merci"}</button>
      </div>
    </div>`;
  },

  async yoursAction(action, el) {
    switch (action) {
      case "flow-start":
        return this.run("flow", () => this.flowStart(el.dataset.domain), "Impossible d'ouvrir le formulaire de cette IA.");
      case "flow-submit":
        return this.run("flow", () => this.flowSubmit(), "Impossible d'envoyer le formulaire.");
      case "flow-close": {
        const f = this.s.flow;
        clearTimeout(this._flowTimer);
        if (f?.result?.flow_id && !["create_entry", "abort"].includes(f.result.type)) {
          this.hass.callApi("DELETE", `config/config_entries/flow/${f.result.flow_id}`).catch(() => {});
        }
        this.setState({ flow: null });
        return this.loadAi();
      }
      case "genai-on":
      case "genai-off": {
        const g = this.s.genai || { provider: "ollama", model: "qwen2.5vl:3b", base_url: "", api_key: "", accept: false };
        const payload = action === "genai-on"
          ? { enabled: true, provider: g.provider, model: g.model, base_url: g.base_url, api_key: g.api_key, accept_cloud: !!g.accept }
          : { enabled: false };
        return this.run("genai", async () => {
          await this.api.aiGenai(payload);
          await this.loadAi();
        }, "Impossible de régler les descriptions.");
      }
      case "ai-draft":
        this.setState({ draftError: "", draft: null, sensitiveOk: false });
        return this.run("draft", async () => {
          try {
            this.setState({ draft: await this.api.aiDraft(this.s.ask.trim()) });
          } catch (e) {
            this.setState({ draftError: e?.message || "L'IA n'a pas pu répondre." });
          }
        }, "L'IA n'a pas pu répondre.");
      case "ai-save":
        return this.run("save", async () => {
          try {
            this.setState({ ai: await this.api.aiSave(this.s.draft.draft_id, !!this.s.sensitiveOk), draft: null, ask: "" });
            this.app.notify("Automatisme créé.");
          } catch (e) {
            this.setState({ draftError: e?.message || "Impossible de créer cet automatisme." });
          }
        }, "Impossible de créer cet automatisme.");
      case "ai-cancel":
        return this.setState({ draft: null, draftError: "" });
      case "ai-delete":
        return this.run("save", async () => this.setState({ ai: await this.api.aiDelete(el.dataset.id) }), "Impossible de supprimer.");
      default:
        return undefined;
    }
  },

  yoursInput(field, el) {
    if (field === "flow") {
      const f = this.s.flow;
      const v = el.type === "checkbox" ? el.checked : el.value;
      this.s.flow = { ...f, values: { ...f.values, [el.dataset.name]: v } };
      return true;
    }
    if (field === "genai") {
      const g = this.s.genai || { provider: "ollama", model: "qwen2.5vl:3b", base_url: "", api_key: "", accept: false };
      const v = el.type === "checkbox" ? el.checked : el.value;
      const next = { ...g, [el.dataset.name]: v };
      if (el.dataset.name === "provider") next.model = { ollama: "qwen2.5vl:3b", gemini: "gemini-2.5-flash", openai: "gpt-4o-mini" }[v] || "";
      if (el.dataset.name === "provider" || el.dataset.name === "accept") this.setState({ genai: next });
      else this.s.genai = next;
      return true;
    }
    if (field === "ask") {
      this.s.ask = el.value;
      if ((el.value.trim().length >= 5) !== (this._askOk || false)) {
        this._askOk = el.value.trim().length >= 5;
        this.requestRender();
      }
      return true;
    }
    if (field === "sensitive") {
      this.setState({ sensitiveOk: el.checked });
      return true;
    }
    return false;
  },
};
