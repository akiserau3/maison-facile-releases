// Réglages > Applications : deux onglets.
// - « Applications » : la sélection Maison Facile d'applications Home Assistant OS
//   (apps_rules.py). Un bouton : Installer → Démarrer → Ouvrir ; « Ouvrir » affiche
//   l'application dans Maison Facile (page « ingress » du Supervisor).
// - « Modules » : la sélection Maison Facile dans le Marketplace (HACS intégré à Home
//   Assistant 2026.11+), et tout le catalogue en mode Expert. Commandes marketplace/* de
//   Home Assistant ; l'avertissement du Marketplace est accepté par l'utilisateur lui-même.
import { Page, html } from "../lib.js";
import { icon } from "../icons.js";
import { openIngressSession } from "../components/ingress.js";

const LEVEL_CHIP = { facile: "actif", "intermédiaire": "", "avancé": "manque" };
const level = (l) => html`<span class="st-badge ${LEVEL_CHIP[l] ?? ""}">${l[0].toUpperCase() + l.slice(1)}</span>`;

export class AppsSection extends Page {
  init() {
    this.s = {
      tab: this.params?.tab === "modules" ? "modules" : "apps",
      data: null, error: false, open: null, confirm: null, frameError: false,
      market: null, marketError: "", repos: null, accept: false, query: "", restart: false, moduleMsg: {},
    };
    this.load();
    // Pendant une installation : on relit l'état toutes les 3 s.
    this.every(3000, () => {
      if ((this.s.data?.apps || []).some((a) => a.action === "wait")) this.load();
    });
  }

  async load() {
    try {
      this.setState({ data: await this.api.appsList(), error: false });
    } catch (e) {
      if (!this.s.data) this.setState({ error: true });
    }
    if (this.s.tab === "modules") this.loadMarket();
  }

  /** État du Marketplace et du catalogue (modules d'intégration). */
  async loadMarket() {
    if (!this.s.data?.marketplace) return;
    try {
      const market = await this.hass.callWS({ type: "marketplace/info" });
      const repos = await this.hass.callWS({ type: "marketplace/repositories/list", categories: ["integration"] });
      this.setState({ market, repos, marketError: "" });
    } catch (e) {
      this.setState({ marketError: "Le Marketplace ne répond pas pour l'instant. Réessayez dans un moment." });
    }
  }

  template() {
    if (this.s.open) return this.openView(this.s.open);
    const intro = html`<div><h2 class="sec-title">Applications</h2>
      <p class="sub" style="font-size:16px;line-height:1.45;max-width:680px">Des applications et des modules choisis par Maison Facile pour aller plus loin. Une sauvegarde complète est faite avant chaque installation.</p></div>`;
    const tabs = html`<div class="seg" role="tablist" aria-label="Applications ou modules" style="max-width:420px">
      <button type="button" class="opt" role="tab" data-action="tab" data-tab="apps" aria-pressed="${this.s.tab === "apps"}" aria-selected="${this.s.tab === "apps"}"><span>Applications</span></button>
      <button type="button" class="opt" role="tab" data-action="tab" data-tab="modules" aria-pressed="${this.s.tab === "modules"}" aria-selected="${this.s.tab === "modules"}"><span>Modules</span></button>
    </div>`;
    const d = this.s.data;
    let body;
    if (this.s.error && !d) body = html`<div class="glass card"><p>Impossible de lire les applications.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div>`;
    else if (!d) body = html`<p class="sub">Chargement…</p>`;
    else body = this.s.tab === "modules" ? this.modulesView(d) : this.appsView(d);
    return html`<div class="stack">${intro}${tabs}${body}</div>`;
  }

  // ----- onglet Applications --------------------------------------------------

  appsView(d) {
    if (!d.available) return html`<div class="glass card"><p>${d.message}</p></div>`;
    return html`<div class="apps-grid">${d.apps.map((a) => this.tile(a))}</div>`;
  }

  tile(a) {
    const installed = a.state !== "not_installed" && a.state !== "unknown";
    const busy = a.action === "wait";
    const confirming = this.s.confirm === a.id;
    return html`<article class="glass card app-tile" data-key="app-${a.id}">
      <div class="row" style="gap:14px;align-items:center">
        <span class="li-icon" style="background:${a.color};width:52px;height:52px;border-radius:15px">${icon(a.icon, 26)}</span>
        <div class="grow" style="min-width:0">
          <strong style="font-size:18px">${a.name}</strong>
          <div class="row wrap" style="gap:6px;margin-top:4px">${level(a.level)}<span class="tag">${a.category}</span></div>
        </div>
      </div>
      <p style="font-size:16px;font-weight:600">${a.what}</p>
      <p class="sub" style="font-size:15px">${a.why}</p>
      ${a.needs ? html`<p class="sub" style="font-size:14px">${icon("warn", 16)} Il faut : ${a.needs}</p>` : ""}
      <p class="sub" style="font-size:14px">${installed ? html`${icon("check", 16)} Installée${a.version ? ` · version ${a.version}` : ""}${a.state === "not_running" ? " · arrêtée" : ""}${a.update_available ? " · mise à jour disponible" : ""}` : "Pas installée"}</p>
      ${a.error ? html`<p class="form-error" role="alert">${a.error}</p>` : ""}
      ${confirming
        ? html`<div class="stack" style="gap:8px" role="group" aria-label="Confirmer l'installation">
            <p style="font-size:15px">Une sauvegarde complète de la box est faite d'abord, puis « ${a.name} » s'installe. Comptez quelques minutes, vous pouvez continuer à utiliser la maison.</p>
            <div class="row wrap"><button type="button" class="btn primary sm" data-action="install" data-id="${a.id}">Installer maintenant</button><button type="button" class="btn secondary sm" data-action="cancel">Annuler</button></div>
          </div>`
        : html`<div class="row wrap" style="margin-top:auto">
            ${a.action === "none"
              ? html`<span class="tag">${a.label}</span>`
              : html`<button type="button" class="btn ${a.action === "open" ? "primary" : "secondary"} sm" data-action="${a.action === "install" ? "ask-install" : a.action}" data-id="${a.id}" ${busy || this.isBusy(a.id) ? "disabled" : ""}>${busy ? html`<span class="spinner" style="display:inline-block;width:16px;height:16px;margin-right:6px"></span>` : ""}${a.label}</button>`}
          </div>`}
    </article>`;
  }

  openView(a) {
    return html`<div class="stack" style="gap:12px">
      <div class="row wrap" style="gap:12px;align-items:center">
        <button type="button" class="btn secondary sm" data-action="close">${icon("back", 18)}Retour aux applications</button>
        <strong style="font-size:18px">${a.name}</strong>
        ${a.hint ? html`<span class="sub" style="font-size:15px">${a.hint}</span>` : ""}
      </div>
      ${this.s.frameError
        ? html`<div class="glass card"><p>Impossible d'ouvrir « ${a.name} » ici.</p><button type="button" class="btn secondary sm" data-action="open" data-id="${a.id}">Réessayer</button></div>`
        : html`<iframe class="app-frame" src="${a.ingress_url}" title="${a.name}" data-key="frame-${a.id}" allow="autoplay; clipboard-write; fullscreen"></iframe>`}
    </div>`;
  }

  // ----- onglet Modules ------------------------------------------------------

  modulesView(d) {
    if (!d.marketplace_builtin) {
      return html`<div class="glass card stack" style="gap:8px"><strong style="font-size:18px">Bientôt disponible sur votre box</strong>
        <p class="sub" style="font-size:15px">Les modules de la communauté arrivent avec Home Assistant 2026.11 (le « Marketplace », intégré à Home Assistant). Ils apparaîtront ici après la mise à jour de Home Assistant.</p></div>`;
    }
    if (!d.marketplace) return html`<div class="glass card"><p>Le Marketplace démarre… Revenez dans un instant.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div>`;
    if (this.s.marketError) return html`<div class="glass card"><p>${this.s.marketError}</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></div>`;
    if (!this.s.market || !this.s.repos) return html`<p class="sub">Chargement du catalogue…</p>`;
    if (!this.s.market.warning_accepted) return this.warningCard();
    const byName = new Map(this.s.repos.map((r) => [String(r.full_name || "").toLowerCase(), r]));
    const picks = d.modules.map((m) => ({ ...m, r: byName.get(m.repo.toLowerCase()) })).filter((m) => m.r);
    return html`
      ${this.s.restart ? this.restartBanner() : ""}
      <div class="apps-grid">${picks.map((m) => this.moduleTile(m))}</div>
      ${d.expert ? this.catalogView(byName) : html`<p class="sub" style="font-size:15px">Le catalogue complet (des milliers de modules, de qualité inégale) est réservé au mode Expert : Réglages avancés, puis Mode Expert.</p>`}`;
  }

  warningCard() {
    return html`<div class="glass card stack" style="gap:12px;max-width:720px" data-key="mk-warning">
      <strong style="font-size:18px">${icon("warn", 20)} Avant d'utiliser les modules</strong>
      <p style="font-size:15px;line-height:1.5">Les modules sont écrits par des membres de la communauté. Ils ne sont ni vérifiés ni pris en charge par Home Assistant : un module peut contenir des erreurs, empêcher la box de démarrer ou accéder à vos données. Installez seulement ce dont vous avez besoin. Maison Facile fait une sauvegarde avant chaque installation.</p>
      <label class="row" style="gap:10px;align-items:flex-start;font-size:15px;cursor:pointer">
        <input type="checkbox" data-field="accept" ${this.s.accept ? "checked" : ""} style="width:20px;height:20px;margin-top:2px">
        <span>J'ai lu cet avertissement et je l'accepte.</span>
      </label>
      <div class="row wrap"><button type="button" class="btn primary sm" data-action="accept-warning" ${this.s.accept && !this.isBusy("accept") ? "" : "disabled"}>Continuer</button></div>
    </div>`;
  }

  moduleTile(m) {
    const r = m.r;
    const msg = this.s.moduleMsg[r.id];
    const update = r.installed && r.pending_upgrade;
    const busy = this.isBusy(`mod-${r.id}`);
    return html`<article class="glass card app-tile" data-key="mod-${r.id}">
      <div class="row" style="gap:14px;align-items:center">
        <span class="li-icon" style="background:${m.color};width:52px;height:52px;border-radius:15px">${icon(m.icon, 26)}</span>
        <div class="grow" style="min-width:0"><strong style="font-size:18px">${m.name}</strong>
          <div class="row wrap" style="gap:6px;margin-top:4px">${level(m.level)}<span class="tag">Module</span></div></div>
      </div>
      <p style="font-size:16px;font-weight:600">${m.what}</p>
      <p class="sub" style="font-size:15px">${m.why}</p>
      <p class="sub" style="font-size:14px">${r.installed ? html`${icon("check", 16)} Installé${r.installed_version ? ` · version ${r.installed_version}` : ""}${update ? " · mise à jour disponible" : ""}` : "Pas installé"}</p>
      ${msg ? html`<p class="${msg.error ? "form-error" : "sub"}" role="${msg.error ? "alert" : "status"}" style="font-size:14px">${msg.text}</p>` : ""}
      <div class="row wrap" style="margin-top:auto">
        ${!r.installed || update
          ? html`<button type="button" class="btn secondary sm" data-action="module-install" data-id="${r.id}" data-name="${m.name}" ${busy ? "disabled" : ""}>${busy ? "Sauvegarde puis installation…" : update ? "Mettre à jour" : "Installer"}</button>`
          : html`<span class="tag">À ajouter ensuite dans Appareils et services</span>`}
      </div>
    </article>`;
  }

  catalogView(byName) {
    const q = this.s.query.trim().toLowerCase();
    const list = q.length < 2 ? [] : [...byName.values()]
      .filter((r) => `${r.name} ${r.full_name} ${r.description}`.toLowerCase().includes(q))
      .sort((a, b) => (b.downloads || b.stars || 0) - (a.downloads || a.stars || 0))
      .slice(0, 30);
    return html`<div class="glass card stack" style="gap:12px" data-key="catalog">
      <strong style="font-size:18px">Tout le catalogue (mode Expert)</strong>
      <label class="field-label" style="display:flex;flex-direction:column;gap:6px">Chercher un module
        <input class="input" type="search" data-field="query" value="${this.s.query}" placeholder="Ex. : météo, linky, alarme…" autocomplete="off">
      </label>
      ${q.length < 2 ? html`<p class="sub" style="font-size:14px">Tapez au moins 2 lettres.</p>` : !list.length ? html`<p class="sub">Aucun module trouvé.</p>` : ""}
      <div class="stack" style="gap:8px">${list.map((r) => html`<div class="row wrap" style="gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)">
        <span class="grow" style="min-width:0"><strong>${r.name}</strong> <span class="sub" style="font-size:13px">${r.full_name}${r.stars ? ` · ★ ${r.stars}` : ""}</span><br><span class="sub" style="font-size:14px">${r.description}</span></span>
        ${r.installed
          ? html`<span class="tag">${icon("check", 14)} Installé</span>`
          : html`<button type="button" class="btn secondary sm" data-action="module-install" data-id="${r.id}" data-name="${r.name}" ${this.isBusy(`mod-${r.id}`) ? "disabled" : ""}>Installer</button>`}
      </div>`)}</div>
    </div>`;
  }

  restartBanner() {
    return html`<div class="install-banner" role="status" data-key="restart"><span class="ib-text">${icon("refresh", 22)}Redémarrez la box pour terminer l'installation des modules.</span>
      <button type="button" class="btn primary sm" data-action="restart" ${this.isBusy("restart") ? "disabled" : ""}>Redémarrer maintenant</button></div>`;
  }

  // ----- actions ---------------------------------------------------------------

  async openSession() {
    if (this._stopIngress) this._stopIngress();
    this._stopIngress = await openIngressSession(this.hass);
    this.onCleanup(() => this._stopIngress && this._stopIngress());
  }

  /** Ouvre une application de la sélection (aussi appelé par la page Musique). */
  async openApp(app, hint = "") {
    try {
      await this.openSession();
      this.setState({ open: { ...app, hint }, frameError: false });
    } catch (e) {
      this.setState({ open: { ...app, hint }, frameError: true });
    }
  }

  onInput(field, el) {
    if (field === "accept") this.setState({ accept: el.checked });
    else if (field === "query") this.setState({ query: el.value });
  }

  async onAction(action, el) {
    const id = el.dataset.id;
    const app = (this.s.data?.apps || []).find((a) => a.id === id);
    switch (action) {
      case "tab":
        this.setState({ tab: el.dataset.tab });
        if (el.dataset.tab === "modules" && !this.s.repos) this.loadMarket();
        return undefined;
      case "retry":
        this.setState({ error: false, marketError: "" });
        return this.load();
      case "ask-install":
        return this.setState({ confirm: id });
      case "cancel":
        return this.setState({ confirm: null });
      case "install":
        this.s.confirm = null;
        return this.run(id, async () => {
          await this.api.appsInstall(id);
          await this.load();
        }, "Impossible de lancer l'installation.");
      case "start":
        return this.run(id, async () => {
          this.setState({ data: await this.api.appsStart(id) });
          this.app.notify(`« ${app?.name || "L'application"} » a démarré.`);
        }, "Impossible de démarrer cette application.");
      case "open":
        if (!app?.ingress_url) return undefined;
        return this.run(id, () => this.openApp(app), "Impossible d'ouvrir cette application.");
      case "close":
        if (this._stopIngress) this._stopIngress();
        this.setState({ open: null });
        return this.load();
      case "accept-warning":
        return this.run("accept", async () => {
          await this.hass.callWS({ type: "marketplace/warning/accept" });
          await this.loadMarket();
        }, "Impossible d'enregistrer votre accord.");
      case "module-install": {
        const name = el.dataset.name;
        const key = `mod-${id}`;
        return this.run(key, async () => {
          const msgs = { ...this.s.moduleMsg };
          try {
            await this.api.appsBackup();
          } catch (e) {
            msgs[id] = { error: true, text: "La sauvegarde n'a pas pu se faire : rien n'a été installé, par sécurité." };
            return this.setState({ moduleMsg: msgs });
          }
          try {
            await this.hass.callWS({ type: "marketplace/repository/install", repository: String(id) });
            msgs[id] = { error: false, text: `« ${name} » est installé. Redémarrez la box, puis ajoutez-le dans Appareils et services (Réglages avancés).` };
            this.setState({ moduleMsg: msgs, restart: true });
            await this.loadMarket();
          } catch (e) {
            msgs[id] = { error: true, text: `« ${name} » n'a pas pu s'installer. ${e?.message ? `(${e.message})` : ""}` };
            this.setState({ moduleMsg: msgs });
          }
          return undefined;
        }, "Impossible d'installer ce module.");
      }
      case "restart":
        return this.run("restart", async () => {
          await this.hass.callService("homeassistant", "restart", {});
          this.app.notify("La box redémarre. Maison Facile revient dans une minute ou deux.");
        }, "Impossible de redémarrer la box.");
      default:
        return undefined;
    }
  }
}
