// Réglages > IA : « Caméras intelligentes » (recette Frigate, recipes_rules.py), la
// reconnaissance des visages (ai-faces.js) et « Votre IA » (ai-yours.js). Chaque étape : ce qu'elle fait, un
// bouton pour la lancer, et « J'apprends » pour comprendre ce qui se passe.
import { Page, html, raw } from "../lib.js";
import { icon } from "../icons.js";
import { openIngressSession } from "../components/ingress.js";
import { facesMixin } from "./ai-faces.js";
import { yoursMixin } from "./ai-yours.js";

const BY = { box: "Maison Facile s'en occupe", page: "Maison Facile s'en occupe", you: "À vous" };

export class AiSection extends Page {
  init() {
    this.s = {
      st: null, error: false, started: false, learn: {}, showConfig: false, msg: "", open: null,
      faces: null, facesOpen: false, consent: [], ai: null, flow: null, genai: null,
      draft: null, draftError: "", ask: "", sensitiveOk: false,
    };
    this.load();
    this.loadFaces();
    this.loadAi();
    this.every(3000, () => {
      if ((this.s.st?.steps || []).some((x) => x.state === "running")) this.load();
      if ((this.s.faces?.steps || []).some((x) => x.state === "running")) this.loadFaces();
      if (this.s.ai?.genai_running) this.loadAi();
    });
  }

  async load() {
    try {
      const st = await this.api.recipeFrigate();
      const wasComplete = this.s.st?.complete;
      this.setState({ st, error: false, started: this.s.started || st.steps.some((x) => x.state === "done") });
      if (st.complete && !wasComplete) {
        this.loadFaces();
        this.loadAi();
      }
    } catch (e) {
      if (!this.s.st) this.setState({ error: true });
    }
  }

  template() {
    if (this.s.open) return this.frameView();
    const intro = html`<div><h2 class="sec-title">Intelligence artificielle</h2>
      <p class="sub" style="font-size:16px;line-height:1.45;max-width:700px">Des fonctions d'IA qui tournent chez vous. Maison Facile installe et règle tout, étape par étape, et vous explique ce qu'il fait si vous le voulez.</p></div>`;
    return html`<div class="stack">${intro}${this.camerasCard()}${this.facesCard()}${this.yourAiCard()}${this.assistantCard()}</div>`;
  }

  camerasCard() {
    const st = this.s.st;
    const head = html`<div class="row" style="gap:14px;align-items:center">
      <span class="li-icon" style="background:#00838F;width:52px;height:52px;border-radius:15px">${icon("camera", 26)}</span>
      <span class="grow"><strong style="font-size:19px">Caméras intelligentes</strong><br><span class="sub" style="font-size:15px">Vos caméras reconnaissent les personnes, les voitures et les animaux, et vous préviennent. Sans cloud : tout reste dans la box.</span></span>
    </div>`;
    if (this.s.error && !st) return html`<section class="glass card stack">${head}<p>Impossible de lire l'état.</p><button type="button" class="btn secondary sm" data-action="retry">Réessayer</button></section>`;
    if (!st) return html`<section class="glass card stack">${head}<p class="sub">Chargement…</p></section>`;
    if (!st.available) return html`<section class="glass card stack">${head}<p>${st.message}</p></section>`;
    if (!this.s.started) {
      return html`<section class="glass card stack" style="gap:12px" data-key="cams-intro">${head}
        <p style="font-size:15px">Ce qui va être installé : Mosquitto (messagerie), l'application Frigate, et le module Frigate. Comptez 10 à 20 minutes, la maison reste utilisable. Une sauvegarde est faite avant.</p>
        <p class="sub" style="font-size:14px">Il faut des caméras déjà ajoutées à Home Assistant avec un flux vidéo (RTSP). Pas de reconnaissance des visages à cette étape. Ne filmez ni la rue ni chez les voisins.</p>
        <div class="row wrap"><button type="button" class="btn primary" data-action="begin">Commencer</button></div>
      </section>`;
    }
    return html`<section class="glass card stack" style="gap:12px" data-key="cams">${head}
      ${this.s.msg ? html`<p class="sub" role="status">${this.s.msg}</p>` : ""}
      <ol class="recipe-steps">${st.steps.map((x) => this.step(x))}</ol>
      ${st.complete
        ? html`<div class="row wrap"><button type="button" class="btn primary" data-action="open-frigate">${icon("camera", 20)}Ouvrir Frigate</button>
            <button type="button" class="btn secondary" data-action="show-config">${this.s.showConfig ? "Cacher la configuration" : "Voir la configuration"}</button></div>
            <p class="sub" style="font-size:15px">C'est prêt. Dans Idées, activez « Quelqu'un à la porte » pour être prévenu.</p>`
        : st.config ? html`<button type="button" class="btn link" style="align-self:flex-start" data-action="show-config">${this.s.showConfig ? "Cacher la configuration" : "Voir la configuration créée"}</button>` : ""}
      ${this.s.showConfig && st.config ? html`<div class="stack" style="gap:6px"><span class="sub" style="font-size:14px">Le fichier de réglages de Frigate, avec une explication sur chaque ligne qui commence par « # ».</span><pre class="tech" data-key="frigate-config">${st.config}</pre></div>` : ""}
    </section>`;
  }

  step(x) {
    const mark = x.state === "done" ? html`<span class="rs-mark done">${icon("check", 16, { stroke: 3 })}</span>`
      : x.state === "running" ? html`<span class="rs-mark run"><span class="spinner" style="width:14px;height:14px"></span></span>`
        : html`<span class="rs-mark"></span>`;
    const open = this.s.learn[x.id];
    return html`<li class="rs ${x.state} ${x.next ? "next" : ""}" data-key="step-${x.id}">
      ${mark}
      <div class="grow stack" style="gap:4px;min-width:0">
        <strong style="font-size:16px">${x.title}</strong>
        <span class="sub" style="font-size:14px">${x.what}</span>
        ${x.error ? html`<p class="form-error" role="alert">${x.error}</p>` : ""}
        <div class="row wrap" style="gap:8px">
          ${x.next ? this.stepButton(x) : ""}
          <button type="button" class="btn link" data-action="learn" data-id="${x.id}" aria-expanded="${open ? "true" : "false"}">${icon("help", 16)}J'apprends</button>
        </div>
        ${open ? html`<p class="learn" style="font-size:14px">${x.learn}</p>` : ""}
      </div>
      <span class="tag" style="align-self:flex-start">${BY[x.by] || ""}</span>
    </li>`;
  }

  stepButton(x) {
    const busy = this.isBusy(x.id) || (this.s.st?.steps || []).some((s) => s.state === "running");
    if (x.id === "restart") return html`<button type="button" class="btn primary sm" data-action="restart" ${busy ? "disabled" : ""}>Redémarrer la box</button>`;
    if (x.id === "frigate_module") return html`<button type="button" class="btn primary sm" data-action="module" ${busy ? "disabled" : ""}>${this.isBusy("frigate_module") ? "Sauvegarde puis installation…" : "Installer le module"}</button>`;
    return html`<button type="button" class="btn primary sm" data-action="run" data-id="${x.id}" ${busy ? "disabled" : ""}>${x.error ? "Réessayer" : "Continuer"}</button>`;
  }

  frameView() {
    const o = this.s.open;
    return html`<div class="stack" style="gap:12px">
      <div class="row wrap" style="gap:12px;align-items:center"><button type="button" class="btn secondary sm" data-action="close">${icon("back", 18)}Retour</button><strong style="font-size:18px">Frigate</strong></div>
      ${o.error ? html`<div class="glass card"><p>Impossible d'ouvrir Frigate ici.</p></div>` : html`<iframe class="app-frame" src="${o.url}" title="Frigate" allow="fullscreen"></iframe>`}
    </div>`;
  }

  /** Module Frigate via le Marketplace (Home Assistant 2026.11+), sauvegarde d'abord. */
  async installModule() {
    let repos;
    try {
      repos = await this.hass.callWS({ type: "marketplace/repositories/list", categories: ["integration"] });
    } catch (e) {
      return this.setState({ msg: "Le module s'installe avec le Marketplace de Home Assistant 2026.11. Mettez Home Assistant à jour, ou installez « Frigate » avec HACS." });
    }
    const repo = (repos || []).find((r) => String(r.full_name || "").toLowerCase() === this.s.st.module_repo.toLowerCase());
    if (!repo) return this.setState({ msg: "Le module Frigate n'est pas dans le catalogue pour l'instant. Réessayez plus tard." });
    try {
      await this.api.appsBackup();
    } catch (e) {
      return this.setState({ msg: "La sauvegarde n'a pas pu se faire : rien n'a été installé, par sécurité." });
    }
    try {
      await this.hass.callWS({ type: "marketplace/repository/install", repository: String(repo.id) });
    } catch (e) {
      const accept = e?.code === "warning_not_accepted";
      return this.setState({ msg: accept ? "Acceptez d'abord l'avertissement du Marketplace : Réglages, Applications, onglet Modules." : "Le module n'a pas pu s'installer. Réessayez dans un moment." });
    }
    this.setState({ msg: "Module installé. Redémarrez maintenant la box." });
    return this.load();
  }

  /** Ouvre une page de Frigate (« faces », « review »…) dans Maison Facile, par l'ingress. */
  async openFrigate(page = "") {
    return this.run("open", async () => {
      const list = await this.api.appsList();
      const app = (list.apps || []).find((a) => a.id === "frigate");
      try {
        if (this._stop) this._stop();
        this._stop = await openIngressSession(this.hass);
        this.onCleanup(() => this._stop && this._stop());
        const base = app?.ingress_url || "";
        this.setState({ open: { url: base ? base.replace(/\/?$/, "/") + page : "", error: !base } });
      } catch (e) {
        this.setState({ open: { url: "", error: true } });
      }
    }, "Impossible d'ouvrir Frigate.");
  }

  onInput(field, el) {
    if (this.facesInput(field, el)) return;
    this.yoursInput(field, el);
  }

  async onAction(action, el) {
    if (action.startsWith("faces-")) return this.facesAction(action, el);
    if (/^(flow|genai|ai)-/.test(action)) return this.yoursAction(action, el);
    switch (action) {
      case "retry":
        this.setState({ error: false });
        return this.load();
      case "begin":
        return this.setState({ started: true });
      case "learn":
        return this.setState({ learn: { ...this.s.learn, [el.dataset.id]: !this.s.learn[el.dataset.id] } });
      case "show-config":
        return this.setState({ showConfig: !this.s.showConfig });
      case "run":
        this.s.msg = "";
        return this.run(el.dataset.id, async () => {
          await this.api.recipeFrigateRun(el.dataset.id);
          await this.load();
        }, "Impossible de lancer cette étape.");
      case "module":
        return this.run("frigate_module", () => this.installModule(), "Impossible d'installer le module.");
      case "restart":
        return this.run("restart", async () => {
          await this.hass.callService("homeassistant", "restart", {});
          this.app.notify("La box redémarre. Revenez ici dans une minute ou deux pour la dernière étape.");
        }, "Impossible de redémarrer la box.");
      case "open-frigate":
        return this.openFrigate("");
      case "close":
        if (this._stop) this._stop();
        this.setState({ open: null });
        return this.loadFaces();
      default:
        return undefined;
    }
  }
}

Object.assign(AiSection.prototype, facesMixin, yoursMixin);

/** Réglages > Mes appareils > Smart Life / Tuya : l'intégration officielle, guidée. */
export class TuyaSection extends Page {
  init() {
    this.s = { state: "code", code: "", qr: "", message: "", learn: {} };
  }

  template() {
    const steps = [
      ["user_code", "Votre code utilisateur Smart Life", "Dans l'application Smart Life (ou Tuya Smart) : Moi, l'engrenage Réglages, Compte et sécurité, puis « Code utilisateur ». Recopiez-le exactement.", "Vos appareils Tuya sont reliés au « cloud » Tuya. L'intégration officielle de Home Assistant s'y connecte avec votre compte : le code dit de quel compte il s'agit, sans mot de passe."],
      ["scan", "Scanner le QR code", "Dans Smart Life : le scanner en haut à droite, visez le QR code, validez dans l'application, puis appuyez sur « C'est fait ».", "Le QR code contient une clé à usage unique : en le scannant, vous autorisez Home Assistant à lire vos appareils. Vous pouvez retirer cette autorisation depuis Smart Life."],
      ["done", "Vos appareils arrivent", "Ils apparaissent dans Mes appareils : rangez-les dans vos pièces.", "Les appareils Tuya passent par Internet : s'il est coupé, ils ne répondent plus. Pour des capteurs qui marchent sans Internet, préférez le Zigbee."],
    ];
    const cur = this.s.state === "scan" ? 1 : this.s.state === "done" ? 2 : 0;
    return html`<div class="stack">
      <div><button type="button" class="btn link" data-action="back-devices">${icon("back", 16)}Mes appareils</button>
        <h2 class="sec-title">Appareils Smart Life / Tuya</h2>
        <p class="sub" style="font-size:16px;max-width:680px">Reliez vos prises, ampoules et capteurs achetés avec l'application Smart Life ou Tuya Smart. Rien à installer : Home Assistant le fait officiellement.</p></div>
      <ol class="recipe-steps glass card">${steps.map(([id, title, what, learn], i) => html`<li class="rs ${i < cur ? "done" : ""} ${i === cur ? "next" : ""}" data-key="tuya-${id}">
        <span class="rs-mark ${i < cur || this.s.state === "done" ? "done" : ""}">${i < cur || this.s.state === "done" ? icon("check", 16, { stroke: 3 }) : ""}</span>
        <div class="grow stack" style="gap:6px;min-width:0">
          <strong style="font-size:16px">${title}</strong><span class="sub" style="font-size:14px">${what}</span>
          ${i === cur ? this.body(id) : ""}
          <button type="button" class="btn link" style="align-self:flex-start" data-action="learn" data-id="${id}">${icon("help", 16)}J'apprends</button>
          ${this.s.learn[id] ? html`<p class="learn" style="font-size:14px">${learn}</p>` : ""}
        </div>
      </li>`)}</ol>
    </div>`;
  }

  body(id) {
    const msg = this.s.message ? html`<p class="${this.s.state === "done" ? "sub" : "form-error"}" role="status">${this.s.message}</p>` : "";
    if (id === "user_code") {
      return html`${msg}<div class="row wrap" style="gap:10px">
        <label><span class="sr-only">Code utilisateur</span><input class="input" data-field="code" value="${this.s.code}" placeholder="Code utilisateur" autocomplete="off" autocapitalize="off" spellcheck="false" data-enter="send-code"></label>
        <button type="button" class="btn primary" data-action="send-code" ${this.isBusy("code") || !this.s.code.trim() ? "disabled" : ""}>${this.isBusy("code") ? "Un instant…" : "Suivant"}</button></div>`;
    }
    if (id === "scan") {
      return html`${msg}<div class="tuya-qr" aria-label="QR code à scanner avec Smart Life">${this.s.qr ? raw(this.s.qr) : ""}</div>
        <div class="row wrap"><button type="button" class="btn primary" data-action="check" ${this.isBusy("check") ? "disabled" : ""}>${this.isBusy("check") ? "Vérification…" : "C'est fait"}</button>
        <button type="button" class="btn secondary" data-action="restart-code">Changer de code</button></div>`;
    }
    return html`${msg}<div class="row wrap"><button type="button" class="btn primary" data-action="back-devices">Voir mes appareils</button></div>`;
  }

  onInput(field, el) {
    if (field === "code") this.setState({ code: el.value });
  }

  apply(r) {
    this.setState({ state: r.state === "error" ? this.s.state : r.state, qr: r.qr_svg || this.s.qr, message: r.message || "" });
  }

  async onAction(action, el) {
    switch (action) {
      case "learn":
        return this.setState({ learn: { ...this.s.learn, [el.dataset.id]: !this.s.learn[el.dataset.id] } });
      case "send-code":
        if (!this.s.code.trim()) return undefined;
        return this.run("code", async () => this.apply(await this.api.tuyaStart(this.s.code.trim())), "Impossible de joindre Tuya.");
      case "check":
        return this.run("check", async () => this.apply(await this.api.tuyaCheck()), "Impossible de joindre Tuya.");
      case "restart-code":
        return this.setState({ state: "code", qr: "", message: "" });
      case "back-devices":
        return this.app.navigate("settings", { section: "devices" });
      default:
        return undefined;
    }
  }
}
