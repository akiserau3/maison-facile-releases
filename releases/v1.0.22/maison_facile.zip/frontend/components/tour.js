// Visite guidée du premier usage : des bulles qui montrent chaque partie de l'écran.
// S'ouvre une fois par appareil (téléphone, tablette…) en arrivant sur l'accueil après
// l'installation ; se relance depuis Réglages > Dépannage. Rien n'est envoyé à la box.

const DONE_KEY = "maison-facile-tour-v1";

// target : sélecteur dans le panneau (shadow DOM). Absent ou introuvable : bulle centrée.
export const TOUR_STEPS = [
  {
    title: "Bienvenue dans Maison Facile",
    text: "Une petite visite d'une minute pour découvrir votre box. Vous pouvez la passer, et la revoir quand vous voulez.",
  },
  {
    target: '[data-tab="home"]',
    title: "L'accueil",
    text: "Votre écran principal : la météo, vos pièces et leur température. Le bouton ampoule d'une pièce allume ou éteint sa lumière.",
  },
  {
    target: ".quick-grid",
    title: "En un clic",
    text: "« Tout éteindre », « Je pars », « Bonne nuit » : un seul bouton fait tout d'un coup.",
  },
  {
    target: '[data-tab="rooms"]',
    title: "Les pièces",
    text: "Le détail de chaque pièce : lumières, chauffage, prises et capteurs.",
  },
  {
    target: '[data-tab="energy"]',
    title: "L'énergie",
    text: "Ce que consomme la maison, en kWh et en euros, pour repérer les appareils qui consomment le plus.",
  },
  {
    target: '[data-tab="security"]',
    title: "La sécurité",
    text: "Portes, fenêtres, détecteurs de fumée et caméras, sur une seule page.",
  },
  {
    target: '[data-tab="ideas"]',
    title: "Les idées",
    text: "La box vous propose des automatismes selon vos appareils : courrier, chauffage, anniversaires… Un clic pour les activer. Un chiffre indique les nouvelles idées.",
  },
  {
    target: '[data-tab="settings"]',
    title: "Les réglages",
    text: "Ajouter un appareil, ranger vos pièces, les mises à jour, le dépannage et l'apparence. Un chiffre apparaît ici quand quelque chose demande votre attention.",
  },
  {
    title: "C'est parti !",
    text: "Pour ajouter un appareil : Réglages, puis Mes appareils. Pour revoir cette visite : Réglages, puis Dépannage.",
  },
];

export function tourDone() {
  try {
    return window.localStorage.getItem(DONE_KEY) === "1";
  } catch (e) {
    return true; // pas de stockage (navigation privée…) : on ne l'impose pas à chaque fois
  }
}

function markDone() {
  try {
    window.localStorage.setItem(DONE_KEY, "1");
  } catch (e) {
    /* ignore */
  }
}

const CSS = `
.tour { position: fixed; inset: 0; z-index: 1000; }
.tour-click { position: absolute; inset: 0; background: transparent; }
.tour-hole { position: absolute; border-radius: 16px; box-shadow: 0 0 0 9999px rgba(8,12,28,0.62); outline: 3px solid #FFB900; outline-offset: 2px; transition: all .25s ease; pointer-events: none; }
.tour-hole.none { display: none; }
.tour.center .tour-click { background: rgba(8,12,28,0.62); }
.tour-bubble { position: absolute; width: min(380px, calc(100vw - 32px)); background: var(--surface, #FFFFFF); color: var(--text, #16181D); border-radius: 18px; box-shadow: 0 24px 60px rgba(0,0,0,0.35); padding: 20px 22px 18px; display: flex; flex-direction: column; gap: 10px; transition: top .25s ease, left .25s ease; }
.tour-bubble h2 { margin: 0; font-size: 21px; font-weight: 800; line-height: 1.2; }
.tour-bubble p { margin: 0; font-size: 16px; line-height: 1.45; color: var(--sub, #4E535B); }
.tour-dots { display: flex; gap: 5px; }
.tour-dots span { width: 7px; height: 7px; border-radius: 50%; background: var(--track, #E4E8EF); }
.tour-dots span.on { background: var(--accent, #0067C0); width: 18px; border-radius: 4px; }
.tour-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 4px; flex-wrap: wrap; }
.tour-row .btns { display: flex; gap: 8px; margin-left: auto; }
.tour-skip { background: none; border: none; color: var(--sub, #4E535B); font: inherit; font-size: 15px; cursor: pointer; padding: 8px 4px; text-decoration: underline; }
@media (prefers-reduced-motion: reduce) { .tour-hole, .tour-bubble { transition: none; } }
`;

/** Ouvre la visite par-dessus le panneau. ``root`` : le shadowRoot du panneau. */
export function startTour(root, { steps = TOUR_STEPS, onClose } = {}) {
  if (root.querySelector(".tour")) return;
  let i = 0;
  const wrap = document.createElement("div");
  wrap.className = "tour";
  wrap.setAttribute("role", "dialog");
  wrap.setAttribute("aria-modal", "true");
  wrap.setAttribute("aria-labelledby", "tour-title");
  wrap.innerHTML = `<style>${CSS}</style><div class="tour-click"></div><div class="tour-hole none"></div>
    <div class="tour-bubble"><div class="tour-dots" aria-hidden="true"></div><h2 id="tour-title"></h2><p id="tour-text"></p>
    <div class="tour-row"><button type="button" class="tour-skip" data-t="skip">Passer la visite</button>
    <span class="btns"><button type="button" class="btn secondary sm" data-t="prev">Précédent</button><button type="button" class="btn primary sm" data-t="next">Suivant</button></span></div></div>`;
  const app = root.querySelector(".app") || root;
  app.appendChild(wrap);
  const hole = wrap.querySelector(".tour-hole");
  const bubble = wrap.querySelector(".tour-bubble");
  const prevBtn = wrap.querySelector('[data-t="prev"]');
  const nextBtn = wrap.querySelector('[data-t="next"]');
  const skipBtn = wrap.querySelector('[data-t="skip"]');

  function find(sel) {
    if (!sel) return null;
    const el = root.querySelector(sel);
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 ? { el, r } : null;
  }

  function place() {
    const step = steps[i];
    const hit = find(step.target);
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const bw = bubble.offsetWidth;
    const bh = bubble.offsetHeight;
    wrap.classList.toggle("center", !hit);
    if (!hit) {
      hole.className = "tour-hole none";
      hole.removeAttribute("style");
      bubble.style.left = `${Math.max(16, (vw - bw) / 2)}px`;
      bubble.style.top = `${Math.max(16, (vh - bh) / 2)}px`;
      return;
    }
    const pad = 6;
    const r = hit.r;
    hole.className = "tour-hole";
    hole.style.left = `${r.left - pad}px`;
    hole.style.top = `${r.top - pad}px`;
    hole.style.width = `${r.width + pad * 2}px`;
    hole.style.height = `${r.height + pad * 2}px`;
    const below = r.top + r.height / 2 < vh / 2;
    let top = below ? r.bottom + pad + 14 : r.top - pad - 14 - bh;
    top = Math.min(Math.max(16, top), vh - bh - 16);
    let left = r.left + r.width / 2 - bw / 2;
    left = Math.min(Math.max(16, left), vw - bw - 16);
    bubble.style.left = `${left}px`;
    bubble.style.top = `${top}px`;
  }

  function show() {
    const step = steps[i];
    wrap.querySelector("#tour-title").textContent = step.title;
    wrap.querySelector("#tour-text").textContent = step.text;
    wrap.querySelector(".tour-dots").innerHTML = steps.map((_, k) => `<span class="${k === i ? "on" : ""}"></span>`).join("");
    prevBtn.hidden = i === 0;
    nextBtn.textContent = i === 0 ? "Commencer la visite" : i === steps.length - 1 ? "Terminer" : "Suivant";
    skipBtn.hidden = i === steps.length - 1;
    const hit = find(step.target);
    if (hit) hit.el.scrollIntoView({ block: "nearest", behavior: "auto" });
    place();
    nextBtn.focus({ preventScroll: true });
  }

  function close() {
    markDone();
    window.removeEventListener("resize", place);
    wrap.removeEventListener("keydown", onKey);
    wrap.remove();
    if (onClose) onClose();
  }

  function go(d) {
    const n = i + d;
    if (n < 0) return;
    if (n >= steps.length) {
      close();
      return;
    }
    i = n;
    show();
  }

  function onKey(e) {
    if (e.key === "Escape") close();
    else if (e.key === "ArrowRight") go(1);
    else if (e.key === "ArrowLeft") go(-1);
    else if (e.key === "Tab") {
      // garde le focus dans la bulle
      const f = [...bubble.querySelectorAll("button:not([hidden])")];
      const k = f.indexOf(root.activeElement);
      e.preventDefault();
      f[(k + (e.shiftKey ? f.length - 1 : 1)) % f.length].focus();
    }
  }

  nextBtn.addEventListener("click", () => go(1));
  prevBtn.addEventListener("click", () => go(-1));
  skipBtn.addEventListener("click", close);
  wrap.addEventListener("keydown", onKey);
  window.addEventListener("resize", place);
  show();
}
