// Ouvrir la page d'une application HAOS dans Maison Facile (« ingress » du Supervisor),
// comme le fait Home Assistant : une session dans un cookie lu par /api/hassio_ingress/,
// revalidée chaque minute tant que la page est ouverte.

/** Crée la session ; renvoie une fonction qui arrête la revalidation. */
export async function openIngressSession(hass) {
  const r = await hass.callWS({ type: "supervisor/api", endpoint: "/ingress/session", method: "post" });
  const session = r?.session;
  if (!session) throw new Error("no ingress session");
  const secure = window.location.protocol === "https:" ? ";Secure" : "";
  document.cookie = `ingress_session=${session};path=/api/hassio_ingress/;SameSite=Strict${secure}`;
  const timer = setInterval(() => {
    hass.callWS({ type: "supervisor/api", endpoint: "/ingress/validate_session", method: "post", data: { session } }).catch(() => {});
  }, 60000);
  return () => clearInterval(timer);
}

/** Adresse d'une page précise de l'application (ex. Music Assistant : « #/settings/providers »). */
export function ingressPage(url, page = "") {
  if (!url) return "";
  return page ? `${url.replace(/#.*$/, "")}${url.endsWith("/") || url.includes("#") ? "" : "/"}${page}` : url;
}
