// « En écoute » : quelle enceinte ou télé montrer sur l'accueil, et quels boutons proposer.
// Logique pure (aucun import) : testée par tests/test_now_playing.py (node).
// Marche avec tout lecteur de Home Assistant (media_player.*) : Music Assistant, Google Cast,
// Sonos, télé… Rien n'est affiché quand rien ne joue.

// Home Assistant, MediaPlayerEntityFeature.
export const FEATURES = { PAUSE: 1, SEEK: 2, VOLUME_SET: 4, VOLUME_MUTE: 8, PREVIOUS: 16, NEXT: 32, VOLUME_STEP: 1024, PLAY: 16384 };

const SHOWN = new Set(["playing", "paused", "buffering"]);
const RECENT_PAUSE_MS = 30 * 60 * 1000; // une pause de plus de 30 min n'est plus « en écoute »

const has = (st, f) => ((Number(st?.attributes?.supported_features) || 0) & f) === f;

/** Titre / sous-titre lisibles (musique, radio, télé). */
export function describe(st) {
  const a = st?.attributes || {};
  const title = String(a.media_title || a.media_series_title || a.app_name || "").trim();
  const sub = [a.media_artist || a.media_album_artist, a.media_album_name && !a.media_artist ? a.media_album_name : null]
    .filter(Boolean)
    .join(" · ");
  const subtitle = String(sub || (a.media_title && a.app_name ? a.app_name : "") || (a.media_channel || "")).trim();
  return { title, subtitle, player: String(a.friendly_name || st?.entity_id || "").trim() };
}

/** Lecteurs à montrer, le plus intéressant d'abord (en lecture, puis en pause récente). */
export function pickNowPlaying(states, nowMs = Date.now()) {
  const list = [];
  for (const [id, st] of Object.entries(states || {})) {
    if (!id.startsWith("media_player.") || !st || !SHOWN.has(st.state)) continue;
    if (st.attributes?.hidden || st.attributes?.restored) continue;
    const d = describe(st);
    if (!d.title) continue; // télé allumée sans programme connu : rien à montrer
    const changed = Date.parse(st.last_changed || "") || 0;
    if (st.state === "paused" && changed && nowMs - changed > RECENT_PAUSE_MS) continue;
    list.push({ entity_id: id, st, changed, ...d });
  }
  const rank = (x) => (x.st.state === "paused" ? 1 : 0);
  list.sort((a, b) => rank(a) - rank(b) || b.changed - a.changed || a.entity_id.localeCompare(b.entity_id));
  // Un groupe (Music Assistant, Sonos…) et ses membres jouent la même chose : un seul suffit.
  const seen = new Set();
  return list.filter((x) => {
    const key = `${x.title}|${x.subtitle}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Position actuelle en secondes (avance toute seule pendant la lecture). */
export function position(st, nowMs = Date.now()) {
  const a = st?.attributes || {};
  const dur = Number(a.media_duration);
  const pos = Number(a.media_position);
  if (!Number.isFinite(dur) || dur <= 0 || !Number.isFinite(pos)) return null;
  let p = pos;
  const at = Date.parse(a.media_position_updated_at || "");
  if (st.state === "playing" && at) p += Math.max(0, (nowMs - at) / 1000);
  return { position: Math.min(dur, Math.max(0, p)), duration: dur };
}

export function clock(seconds) {
  const s = Math.max(0, Math.floor(Number(seconds) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = String(s % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${r}` : `${m}:${r}`;
}

/** Boutons possibles pour ce lecteur. */
export function controls(st) {
  const playing = st?.state === "playing";
  const vol = Number(st?.attributes?.volume_level);
  return {
    previous: has(st, FEATURES.PREVIOUS),
    playPause: playing ? has(st, FEATURES.PAUSE) : has(st, FEATURES.PLAY) || has(st, FEATURES.PAUSE),
    playing,
    next: has(st, FEATURES.NEXT),
    volume: has(st, FEATURES.VOLUME_SET) && Number.isFinite(vol) ? Math.round(vol * 100) : null,
    volumeStep: !has(st, FEATURES.VOLUME_SET) && has(st, FEATURES.VOLUME_STEP),
  };
}
