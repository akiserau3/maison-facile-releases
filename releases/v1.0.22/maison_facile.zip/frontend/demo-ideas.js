// Generated from custom_components/maison_facile/ideas/*.yaml (demo only; the box reads the YAML files).
// Regenerate: python3 scripts/make_demo_ideas.py
export const DEMO_IDEAS = [
 {
  "id": "courrier",
  "title": "Courrier arrivé",
  "short": "courrier arrivé",
  "pitch": "Soyez prévenu quand le facteur passe.",
  "description": "Un petit détecteur collé dans la boîte aux lettres voit quand le facteur passe. Vous recevez « Le courrier est arrivé » sur votre téléphone, et une tuile apparaît sur l'accueil jusqu'à ce que vous releviez le courrier.",
  "category": "confort",
  "color": "#B8860B",
  "icon": "mail",
  "when": "la boîte aux lettres s'ouvre ou bouge",
  "if": "ce n'est pas la nuit, et pas plus d'une fois par heure",
  "then": "message « Le courrier est arrivé » + tuile sur l'accueil jusqu'au relevé",
  "needs": [
   {
    "key": "mailbox",
    "roles": [
     "contact",
     "motion"
    ],
    "label": "Détecteur d'ouverture ou de mouvement",
    "hint": "se colle à l'intérieur de la boîte",
    "compatible": "détecteur d'ouverture Sonoff ou Aqara",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur à ajouter",
    "add_type": "ouverture",
    "prefer": [
     "boite aux lettres",
     "boite a lettres",
     "courrier",
     "facteur",
     "mailbox"
    ],
    "require_prefer": true,
    "rename_fr": "Boîte aux lettres"
   },
   {
    "key": "front_door",
    "roles": [
     "contact"
    ],
    "label": "Détecteur de la porte d'entrée",
    "optional": true,
    "prefer": [
     "porte d'entree",
     "entree",
     "front door"
    ],
    "require_prefer": true,
    "none_fr": "Facultatif : le courrier est relevé quand la porte d'entrée s'ouvre"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "quiet_night",
    "label": "Ne pas prévenir la nuit (22 h – 7 h)",
    "type": "bool",
    "default": true
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": {
   "kind": "flag",
   "title": "Courrier arrivé",
   "icon": "mail",
   "entity": "context:mail_flag",
   "attribute": "arrived_at",
   "show": "on",
   "action": {
    "label": "Relevé",
    "service": "switch.turn_off"
   },
   "preview": "Aujourd'hui à 10:42"
  },
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« Le courrier est arrivé. »",
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "mailbox_alert.yaml",
  "module": null
 },
 {
  "id": "poubelles",
  "title": "Poubelles à sortir",
  "short": "rappel des poubelles",
  "pitch": "La veille au soir, la maison vous dit quelle poubelle sortir.",
  "description": "Indiquez une fois vos jours de collecte (et les semaines paires ou impaires pour le bac jaune ou le verre, comme sur le calendrier de votre commune). La veille au soir, à l'heure choisie, vous recevez « Ce soir : sortez le bac jaune » et une tuile s'allume sur l'accueil. Touchez « Sorti » quand c'est fait. Aucun capteur à installer.",
  "category": "confort",
  "color": "#B8860B",
  "icon": "trash",
  "when": "la veille d'une collecte, à l'heure choisie",
  "if": "un bac passe demain (jour et semaine paire / impaire)",
  "then": "message « Ce soir : sortez le bac jaune » et tuile sur l'accueil jusqu'à « Sorti »",
  "needs": [
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "household_day",
    "label": "Ordures ménagères : jour de collecte",
    "type": "choice",
    "choices": [
     {
      "value": -1,
      "label": "Pas de collecte"
     },
     {
      "value": 0,
      "label": "Lundi"
     },
     {
      "value": 1,
      "label": "Mardi"
     },
     {
      "value": 2,
      "label": "Mercredi"
     },
     {
      "value": 3,
      "label": "Jeudi"
     },
     {
      "value": 4,
      "label": "Vendredi"
     },
     {
      "value": 5,
      "label": "Samedi"
     },
     {
      "value": 6,
      "label": "Dimanche"
     }
    ],
    "default": 1
   },
   {
    "key": "household_day2",
    "label": "Ordures ménagères : deuxième collecte dans la semaine",
    "type": "choice",
    "choices": [
     {
      "value": -1,
      "label": "Une seule collecte"
     },
     {
      "value": 0,
      "label": "Lundi"
     },
     {
      "value": 1,
      "label": "Mardi"
     },
     {
      "value": 2,
      "label": "Mercredi"
     },
     {
      "value": 3,
      "label": "Jeudi"
     },
     {
      "value": 4,
      "label": "Vendredi"
     },
     {
      "value": 5,
      "label": "Samedi"
     },
     {
      "value": 6,
      "label": "Dimanche"
     }
    ],
    "default": -1
   },
   {
    "key": "yellow_day",
    "label": "Bac jaune (recyclage) : jour de collecte",
    "type": "choice",
    "choices": [
     {
      "value": -1,
      "label": "Pas de collecte"
     },
     {
      "value": 0,
      "label": "Lundi"
     },
     {
      "value": 1,
      "label": "Mardi"
     },
     {
      "value": 2,
      "label": "Mercredi"
     },
     {
      "value": 3,
      "label": "Jeudi"
     },
     {
      "value": 4,
      "label": "Vendredi"
     },
     {
      "value": 5,
      "label": "Samedi"
     },
     {
      "value": 6,
      "label": "Dimanche"
     }
    ],
    "default": 3
   },
   {
    "key": "yellow_weeks",
    "label": "Bac jaune : quelles semaines ?",
    "type": "choice",
    "choices": [
     {
      "value": "all",
      "label": "Toutes les semaines"
     },
     {
      "value": "even",
      "label": "Semaines paires"
     },
     {
      "value": "odd",
      "label": "Semaines impaires"
     }
    ],
    "default": "all"
   },
   {
    "key": "third_bin",
    "label": "Troisième bac",
    "type": "choice",
    "choices": [
     {
      "value": "Le bac à verre",
      "label": "Verre"
     },
     {
      "value": "Les déchets verts",
      "label": "Déchets verts"
     },
     {
      "value": "Le bac des biodéchets",
      "label": "Biodéchets"
     },
     {
      "value": "Les encombrants",
      "label": "Encombrants"
     }
    ],
    "default": "Le bac à verre"
   },
   {
    "key": "third_day",
    "label": "Troisième bac : jour de collecte",
    "type": "choice",
    "choices": [
     {
      "value": -1,
      "label": "Pas de collecte"
     },
     {
      "value": 0,
      "label": "Lundi"
     },
     {
      "value": 1,
      "label": "Mardi"
     },
     {
      "value": 2,
      "label": "Mercredi"
     },
     {
      "value": 3,
      "label": "Jeudi"
     },
     {
      "value": 4,
      "label": "Vendredi"
     },
     {
      "value": 5,
      "label": "Samedi"
     },
     {
      "value": 6,
      "label": "Dimanche"
     }
    ],
    "default": -1
   },
   {
    "key": "third_weeks",
    "label": "Troisième bac : quelles semaines ?",
    "type": "choice",
    "choices": [
     {
      "value": "all",
      "label": "Toutes les semaines"
     },
     {
      "value": "even",
      "label": "Semaines paires"
     },
     {
      "value": "odd",
      "label": "Semaines impaires"
     }
    ],
    "default": "all"
   },
   {
    "key": "reminder_hour",
    "label": "Heure du rappel, la veille",
    "type": "number",
    "min": 16,
    "max": 23,
    "step": 1,
    "unit": "h",
    "default": 19
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": {
   "kind": "flag",
   "title": "Poubelles à sortir",
   "icon": "trash",
   "entity": "context:bin_flag",
   "attribute": "reminded_at",
   "detail_attribute": "bins",
   "show": "on",
   "action": {
    "label": "Sorti",
    "service": "switch.turn_off"
   },
   "preview": "Ce soir : sortez le bac jaune"
  },
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« Ce soir : sortez le bac jaune. »",
  "teaser": "Ne ratez plus le passage des poubelles.",
  "teaser_detail": "Un rappel la veille au soir : « Ce soir, sortez le bac jaune ».",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "bins_reminder.yaml",
  "module": null
 },
 {
  "id": "anniversaire",
  "title": "Anniversaires",
  "short": "rappel des anniversaires",
  "pitch": "Ne plus jamais oublier l'anniversaire d'un proche.",
  "description": "Notez les anniversaires de vos proches (ou importez-les de vos contacts ou de votre agenda). Quelques jours avant, un rappel vous laisse le temps de trouver un cadeau. Le matin du jour J, une tuile apparaît sur l'accueil et votre téléphone vous propose un message déjà rédigé : il ne reste qu'à appuyer sur Envoyer. Rien n'est jamais envoyé à votre place, et tout reste sur votre box.",
  "category": "confort",
  "color": "#C2185B",
  "icon": "cake",
  "when": "un anniversaire approche, puis le matin du jour J",
  "if": "les rappels sont activés",
  "then": "rappel quelques jours avant, tuile sur l'accueil et message prêt à envoyer sur votre téléphone",
  "needs": [
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   },
   {
    "key": "birthdays",
    "roles": [
     "birthday"
    ],
    "label": "Des dates d'anniversaire",
    "hint": "à noter, ou à importer de vos contacts ou de votre agenda",
    "missing_fr": "vos dates d'anniversaire",
    "multiple": true,
    "add_page": "birthdays"
   },
   {
    "key": "speaker",
    "roles": [
     "speaker",
     "tv"
    ],
    "label": "Enceinte connectée",
    "optional": true,
    "none_fr": "Facultatif : la maison peut aussi l'annoncer à voix haute"
   }
  ],
  "options": [],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« Aujourd'hui, c'est l'anniversaire de Mamie ! »",
  "teaser": "N'oubliez plus aucun anniversaire.",
  "teaser_detail": "Un rappel quelques jours avant, puis le message tout prêt le jour J.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": null,
  "module": "birthdays"
 },
 {
  "id": "enfant_rentre",
  "title": "Bien rentré à la maison",
  "short": "retour des enfants",
  "pitch": "Un message aux parents quand l'enfant arrive à la maison.",
  "description": "Choisissez la personne à suivre (par exemple votre enfant) parmi les personnes de la maison. Quand son téléphone arrive dans la zone « Maison », les parents reçoivent « Léo vient d'arriver à la maison ». Rien à installer : il suffit de l'application Home Assistant sur son téléphone, avec la localisation. Son propre téléphone n'est pas prévenu.",
  "category": "confort",
  "color": "#C2185B",
  "icon": "child",
  "when": "la personne choisie arrive à la maison",
  "if": "pas déjà prévenu dans la dernière demi-heure",
  "then": "message « Léo vient d'arriver à la maison » aux parents",
  "needs": [
   {
    "key": "person",
    "roles": [
     "person"
    ],
    "label": "La personne à suivre",
    "hint": "elle a l'application Home Assistant sur son téléphone, avec la localisation",
    "missing_fr": "une personne dans Home Assistant"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres téléphones de la maison",
    "type": "bool",
    "default": true
   }
  ],
  "tile": null,
  "next": [
   "lumiere_bienvenue"
  ],
  "next_hint": "« Léo vient d'arriver à la maison. »",
  "teaser": "Soyez prévenu quand les enfants rentrent.",
  "teaser_detail": "« Léo vient d'arriver à la maison (16:42). »",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "person_arrived.yaml",
  "module": null
 },
 {
  "id": "tv_pause_sonnette",
  "title": "Pause quand on sonne",
  "short": "pause quand on sonne",
  "pitch": "La télé se met en pause quand quelqu'un sonne à la porte.",
  "description": "Quand quelqu'un sonne (ou entre par la porte d'entrée), la télé se met en pause toute seule : vous ne ratez rien de votre film, et vous entendez la sonnette.",
  "category": "detecte",
  "color": "#0067C0",
  "icon": "tv",
  "when": "quelqu'un sonne ou entre",
  "if": "la télé est en train de lire",
  "then": "la télé se met en pause",
  "needs": [
   {
    "key": "tv",
    "roles": [
     "tv"
    ],
    "label": "Télévision connectée",
    "hint": "une télé reliée au WiFi de la maison",
    "missing_fr": "1 télé connectée",
    "pivot": true
   },
   {
    "key": "ring",
    "roles": [
     "doorbell",
     "button",
     "contact",
     "motion"
    ],
    "label": "Sonnette, bouton ou détecteur de l'entrée",
    "hint": "un bouton près de la porte, ou un détecteur dans l'entrée",
    "compatible": "bouton Aqara ou Sonoff, sonnette vidéo Reolink",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 bouton ou détecteur d'entrée",
    "add_type": "mouvement",
    "prefer": [
     "sonnette",
     "doorbell",
     "visiteur",
     "entree",
     "porte d'entree"
    ],
    "exclude_words": [
     "fenetre",
     "boite aux lettres",
     "courrier"
    ]
   }
  ],
  "options": [],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« On sonne à la porte. »",
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [
   "samsungtv",
   "webostv",
   "androidtv_remote",
   "androidtv",
   "philips_js",
   "braviatv",
   "panasonic_viera",
   "vizio",
   "roku",
   "apple_tv",
   "cast"
  ],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "tv_pause_doorbell.yaml",
  "module": null
 },
 {
  "id": "fenetre_pluie",
  "title": "Fenêtres et pluie",
  "short": "fenêtres et pluie",
  "pitch": "Alerte si une fenêtre est ouverte et qu'il va pleuvoir.",
  "description": "La box regarde la météo tous les quarts d'heure. Si une fenêtre est restée ouverte et que de la pluie est annoncée dans l'heure, vous recevez un message pour la fermer à temps. Le message s'efface quand tout est fermé.",
  "category": "securite",
  "color": "#00838F",
  "icon": "rain",
  "when": "une fenêtre est ouverte",
  "if": "la météo annonce de la pluie dans l'heure",
  "then": "message « Il va pleuvoir : fermez la fenêtre », effacé quand tout est fermé",
  "needs": [
   {
    "key": "windows",
    "roles": [
     "contact"
    ],
    "label": "Détecteur d'ouverture sur une fenêtre",
    "hint": "se colle sur la fenêtre et son cadre",
    "compatible": "détecteur d'ouverture Sonoff ou Aqara",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur de fenêtre",
    "add_type": "ouverture",
    "multiple": true,
    "prefer": [
     "fenetre",
     "velux",
     "baie",
     "window"
    ],
    "exclude_words": [
     "porte d'entree",
     "garage",
     "portail",
     "boite aux lettres",
     "courrier"
    ]
   },
   {
    "key": "weather",
    "roles": [
     "weather"
    ],
    "label": "Météo de la maison",
    "hint": "elle se règle avec la position de la maison (votre installateur s'en occupe)",
    "missing_fr": "la météo"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "rain_probability",
    "label": "Prévenir dès que le risque de pluie dépasse",
    "type": "choice",
    "choices": [
     {
      "value": 30,
      "label": "30 % (prudent)"
     },
     {
      "value": 50,
      "label": "50 %"
     },
     {
      "value": 70,
      "label": "70 % (seulement si c'est presque sûr)"
     }
    ],
    "default": 50
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "window_rain_alert.yaml",
  "module": null
 },
 {
  "id": "personne_porte",
  "title": "Quelqu'un à la porte",
  "short": "quelqu'un à la porte",
  "pitch": "Vos caméras vous préviennent quand elles voient une personne.",
  "description": "Frigate regarde les images de vos caméras et reconnaît les personnes (pas les visages). Vous recevez « Quelqu'un devant la caméra Entrée ». Par défaut, seulement quand la maison est en mode Absent ou la nuit, pour ne pas être dérangé quand vous êtes là.",
  "category": "securite",
  "color": "#00838F",
  "icon": "camera",
  "when": "une caméra voit une personne",
  "if": "mode Absent ou la nuit (réglable), pas plus d'un message toutes les 10 minutes",
  "then": "message « Quelqu'un devant la caméra Entrée »",
  "needs": [
   {
    "key": "person_cams",
    "roles": [
     "person_detect"
    ],
    "label": "Caméra avec détection de personnes",
    "hint": "Réglages, IA, Caméras intelligentes",
    "missing_fr": "Frigate à installer (Réglages, IA)",
    "multiple": true
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "only_away_or_night",
    "label": "Seulement en mode Absent ou la nuit",
    "type": "bool",
    "default": true
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres téléphones de la maison",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "person_detected.yaml",
  "module": null
 },
 {
  "id": "visage_bienvenue",
  "title": "Bienvenue (visage reconnu)",
  "short": "bienvenue à la maison",
  "pitch": "« Marie est arrivée » quand la caméra reconnaît un visage du foyer.",
  "description": "Quand Frigate reconnaît un visage enregistré dans sa bibliothèque, vous recevez « Marie est arrivée ». Les visages inconnus ne déclenchent rien. Les visages sont des données protégées : n'enregistrez que les personnes du foyer qui sont d'accord.",
  "category": "securite",
  "color": "#6B47B8",
  "icon": "heart",
  "when": "une caméra reconnaît un visage du foyer",
  "if": "pas plus d'un message par personne et par heure",
  "then": "message « Marie est arrivée »",
  "needs": [
   {
    "key": "face_cams",
    "roles": [
     "face"
    ],
    "label": "Caméra avec reconnaissance des visages",
    "hint": "Réglages, IA, Reconnaissance des visages",
    "missing_fr": "reconnaissance des visages à activer (Réglages, IA)",
    "multiple": true
   }
  ],
  "options": [],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "face_welcome.yaml",
  "module": null
 },
 {
  "id": "lave_linge_fini",
  "title": "Machine à laver terminée",
  "short": "machine terminée",
  "pitch": "Un message quand le linge est prêt, grâce à la prise qui mesure.",
  "description": "La machine se branche sur une prise connectée qui mesure la consommation. Quand la machine s'arrête de tourner, vous recevez « La machine à laver a terminé » : plus de linge oublié dans le tambour.",
  "category": "energie",
  "color": "#6B47B8",
  "icon": "washer",
  "when": "la machine s'arrête de tourner",
  "if": "elle consommait depuis au moins 2 minutes",
  "then": "message « La machine à laver a terminé »",
  "needs": [
   {
    "key": "plug",
    "roles": [
     "power"
    ],
    "label": "Prise connectée qui mesure la consommation",
    "hint": "la machine se branche dessus",
    "compatible": "prise Zigbee avec mesure de consommation (Nous A1Z, Aqara)",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 prise connectée",
    "add_type": "prise",
    "prefer": [
     "lave",
     "linge",
     "machine",
     "seche",
     "vaisselle",
     "washing"
    ],
    "require_prefer": true,
    "rename_fr": "Prise de la machine à laver"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "appliance",
    "label": "Quelle machine ?",
    "type": "choice",
    "choices": [
     {
      "value": "La machine à laver",
      "label": "Machine à laver"
     },
     {
      "value": "Le lave-vaisselle",
      "label": "Lave-vaisselle"
     },
     {
      "value": "Le sèche-linge",
      "label": "Sèche-linge"
     }
    ],
    "default": "La machine à laver"
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": {
   "kind": "power",
   "title": "La machine",
   "icon": "washer",
   "entity": "need:plug",
   "threshold": 20,
   "unit": "W",
   "on_text": "En marche",
   "off_text": "À l'arrêt",
   "preview": "En marche · 1 850 W"
  },
  "next": [
   "linge_etendre",
   "enceinte_annonces"
  ],
  "next_hint": "« La machine à laver a terminé. »",
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "appliance_done.yaml",
  "module": null
 },
 {
  "id": "linge_etendre",
  "title": "Linge à étendre dehors",
  "short": "linge à étendre dehors",
  "pitch": "Machine terminée et pas de pluie annoncée : étendez dehors.",
  "description": "Quand la machine à laver a terminé, la box regarde la météo. S'il fait jour et qu'aucune pluie n'est annoncée dans les 3 prochaines heures, vous recevez « Vous pouvez étendre le linge dehors ». S'il va pleuvoir, pas de message : étendez à l'intérieur.",
  "category": "confort",
  "color": "#00838F",
  "icon": "shirt",
  "when": "la machine à laver a terminé",
  "if": "il fait jour et pas de pluie annoncée dans les 3 prochaines heures",
  "then": "message « Vous pouvez étendre le linge dehors »",
  "needs": [
   {
    "key": "plug",
    "roles": [
     "power"
    ],
    "label": "Prise connectée qui mesure la consommation",
    "hint": "la machine à laver se branche dessus",
    "compatible": "prise Zigbee avec mesure de consommation (Nous A1Z, Aqara)",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 prise connectée",
    "add_type": "prise",
    "prefer": [
     "lave",
     "linge",
     "machine",
     "washing"
    ],
    "require_prefer": true,
    "rename_fr": "Prise de la machine à laver"
   },
   {
    "key": "weather",
    "roles": [
     "weather"
    ],
    "label": "Météo de la maison",
    "hint": "elle se règle avec la position de la maison (votre installateur s'en occupe)",
    "missing_fr": "la météo"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "dry_hours",
    "label": "Pas de pluie pendant",
    "type": "choice",
    "choices": [
     {
      "value": 2,
      "label": "2 heures"
     },
     {
      "value": 3,
      "label": "3 heures"
     },
     {
      "value": 4,
      "label": "4 heures"
     }
    ],
    "default": 3
   },
   {
    "key": "rain_probability",
    "label": "Risque de pluie accepté",
    "type": "choice",
    "choices": [
     {
      "value": 10,
      "label": "10 % (prudent)"
     },
     {
      "value": 30,
      "label": "30 %"
     },
     {
      "value": 50,
      "label": "50 %"
     }
    ],
    "default": 30
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "heures_creuses"
  ],
  "next_hint": "« Vous pouvez étendre le linge dehors. »",
  "teaser": "Et si la maison vous disait quand étendre dehors ?",
  "teaser_detail": "À la fin de la machine, elle regarde la météo des 3 prochaines heures.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "laundry_dry_outside.yaml",
  "module": null
 },
 {
  "id": "frigo_ouvert",
  "title": "Frigo resté ouvert",
  "short": "frigo resté ouvert",
  "pitch": "Un rappel si la porte du frigo ou du congélateur reste ouverte.",
  "description": "Un petit détecteur collé sur la porte du frigo (ou du congélateur) voit quand elle reste ouverte. Au bout de 3 minutes, vous recevez « Le frigo est ouvert » avant que tout se réchauffe. Le message disparaît dès qu'elle est refermée.",
  "category": "confort",
  "color": "#0067C0",
  "icon": "fridge",
  "when": "la porte du frigo est ouverte",
  "if": "depuis plus de 3 minutes",
  "then": "message « Le frigo est ouvert », effacé quand il est refermé",
  "needs": [
   {
    "key": "fridge",
    "roles": [
     "contact"
    ],
    "label": "Détecteur d'ouverture sur la porte du frigo",
    "hint": "se colle sur la porte du frigo et sur le côté",
    "compatible": "détecteur d'ouverture Sonoff ou Aqara",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur d'ouverture",
    "add_type": "ouverture",
    "multiple": true,
    "prefer": [
     "frigo",
     "refrigerateur",
     "congelateur",
     "congel",
     "cave a vin",
     "fridge",
     "freezer"
    ],
    "require_prefer": true,
    "rename_fr": "Porte du frigo"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "open_minutes",
    "label": "Prévenir après",
    "type": "choice",
    "choices": [
     {
      "value": 1,
      "label": "1 minute"
     },
     {
      "value": 3,
      "label": "3 minutes"
     },
     {
      "value": 5,
      "label": "5 minutes"
     },
     {
      "value": 10,
      "label": "10 minutes"
     }
    ],
    "default": 3
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« Le frigo est ouvert depuis 3 minutes. »",
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "fridge_open.yaml",
  "module": null
 },
 {
  "id": "plantes_arroser",
  "title": "Plantes à arroser",
  "short": "rappel d'arrosage",
  "pitch": "Un rappel pour arroser, ou quand la terre est trop sèche.",
  "description": "Sans rien installer : un rappel « C'est le jour d'arroser les plantes » tous les 3 jours à 18 h (à régler). Pour les plantes du jardin, le rappel est sauté s'il pleut aujourd'hui. Avec un capteur planté dans le pot, la box ne vous prévient que quand la terre est vraiment sèche.",
  "category": "confort",
  "color": "#0E7A0D",
  "icon": "plant",
  "when": "chaque jour à l'heure choisie",
  "if": "la terre est sèche (avec capteur), ou c'est le jour d'arroser et il ne pleut pas",
  "then": "message « C'est le jour d'arroser les plantes »",
  "needs": [
   {
    "key": "soil",
    "roles": [
     "soil"
    ],
    "label": "Capteur d'humidité de la terre",
    "compatible": "capteur de sol Zigbee (Tuya, Xiaomi)",
    "price_hint": "[PRIX] €",
    "optional": true,
    "multiple": true,
    "none_fr": "Facultatif : sans capteur, un rappel tous les quelques jours"
   },
   {
    "key": "weather",
    "roles": [
     "weather"
    ],
    "label": "Météo de la maison",
    "optional": true,
    "none_fr": "Facultatif : pour sauter l'arrosage du jardin quand il pleut"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "every_days",
    "label": "Sans capteur : arroser tous les",
    "type": "choice",
    "choices": [
     {
      "value": 1,
      "label": "jours"
     },
     {
      "value": 2,
      "label": "2 jours"
     },
     {
      "value": 3,
      "label": "3 jours"
     },
     {
      "value": 4,
      "label": "4 jours"
     },
     {
      "value": 7,
      "label": "7 jours"
     }
    ],
    "default": 3
   },
   {
    "key": "reminder_hour",
    "label": "Heure du rappel",
    "type": "number",
    "min": 7,
    "max": 21,
    "step": 1,
    "unit": "h",
    "default": 18
   },
   {
    "key": "outdoor",
    "label": "Plantes du jardin : pas de rappel s'il pleut",
    "type": "bool",
    "default": false
   },
   {
    "key": "min_moisture",
    "label": "Avec capteur : la terre est sèche en dessous de",
    "type": "choice",
    "choices": [
     {
      "value": 20,
      "label": "20 %"
     },
     {
      "value": 30,
      "label": "30 %"
     },
     {
      "value": 40,
      "label": "40 %"
     }
    ],
    "default": 30
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« C'est le jour d'arroser les plantes. »",
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "plants_water.yaml",
  "module": null
 },
 {
  "id": "fuite_eau",
  "title": "Fuite d'eau",
  "short": "fuite d'eau",
  "pitch": "Alerte immédiate si de l'eau coule sous l'évier ou la machine.",
  "description": "Un petit détecteur posé au sol (sous l'évier, la machine à laver, le chauffe-eau) sent la moindre goutte. Vous êtes prévenu tout de suite ; si une sirène ou une vanne motorisée sont installées, la sirène sonne et l'eau est coupée.",
  "category": "securite",
  "color": "#C42B1C",
  "icon": "drop",
  "when": "de l'eau touche le détecteur",
  "if": "à tout moment, même la nuit",
  "then": "alerte immédiate, sirène et coupure de l'eau si elles sont installées",
  "needs": [
   {
    "key": "leak",
    "roles": [
     "leak"
    ],
    "label": "Détecteur de fuite d'eau",
    "hint": "se pose au sol, sous l'évier ou la machine",
    "compatible": "détecteur de fuite Aqara ou Sonoff",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur de fuite",
    "add_type": "fuite",
    "multiple": true
   },
   {
    "key": "sirens",
    "roles": [
     "siren"
    ],
    "label": "Sirène",
    "optional": true,
    "multiple": true,
    "none_fr": "Facultatif"
   },
   {
    "key": "valve",
    "roles": [
     "valve"
    ],
    "label": "Vanne d'arrivée d'eau motorisée",
    "optional": true,
    "multiple": true,
    "none_fr": "Facultatif : posée par un plombier"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": true
   }
  ],
  "tile": {
   "kind": "alarm",
   "title": "Fuite d'eau",
   "icon": "drop",
   "entity": "needs:leak",
   "on_text": "Fuite détectée !",
   "off_text": "Aucune fuite",
   "preview": "Aucune fuite"
  },
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "water_leak_alert.yaml",
  "module": null
 },
 {
  "id": "vigilance_meteo",
  "title": "Vigilance Météo-France",
  "short": "vigilance météo",
  "pitch": "Prévenu des vigilances orange et rouge, avec les bons réflexes.",
  "description": "Quand Météo-France place votre département en vigilance orange ou rouge, vous recevez un message avec les bons réflexes : orages, canicule, grand froid, vent violent, pluie-inondation, neige-verglas… Le message disparaît quand la vigilance est levée. Votre installateur relie l'intégration officielle Météo-France (gratuite) avec la ville de la maison.",
  "category": "securite",
  "color": "#E8590C",
  "icon": "warn",
  "when": "Météo-France change la vigilance du département",
  "if": "un phénomène passe en orange ou en rouge",
  "then": "message avec les conseils, effacé quand la vigilance est levée",
  "needs": [
   {
    "key": "alert",
    "roles": [
     "weather_alert"
    ],
    "label": "Vigilance Météo-France du département",
    "hint": "à relier par votre installateur : intégration officielle Météo-France, avec la ville de la maison",
    "compatible": "intégration Météo-France (incluse dans Home Assistant, gratuite ; France métropolitaine)",
    "missing_fr": "relier Météo-France (installateur)"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "min_level",
    "label": "Prévenir à partir de",
    "type": "choice",
    "choices": [
     {
      "value": "Orange",
      "label": "Vigilance orange"
     },
     {
      "value": "Rouge",
      "label": "Vigilance rouge seulement"
     }
    ],
    "default": "Orange"
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "fenetre_pluie"
  ],
  "next_hint": "« Vigilance orange orages : rentrez le linge et le mobilier de jardin. »",
  "teaser": "Soyez prévenu des vigilances Météo-France.",
  "teaser_detail": "Orages, canicule, grand froid, vent… avec les bons réflexes.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "weather_warning.yaml",
  "module": null
 },
 {
  "id": "test_detecteurs_fumee",
  "title": "Tester les détecteurs de fumée",
  "short": "test des détecteurs de fumée",
  "pitch": "Un rappel deux fois par an, et la pile faible signalée.",
  "description": "Deux fois par an (le premier samedi d'avril et d'octobre, à 10 h), un rappel pour tester vos détecteurs de fumée : un appui de quelques secondes sur le bouton, il doit sonner. Et dès que la pile d'un détecteur faiblit, vous êtes prévenu pour la changer à temps.",
  "category": "securite",
  "color": "#C42B1C",
  "icon": "flame",
  "when": "le premier samedi d'avril et d'octobre, ou quand une pile faiblit",
  "if": "à 10 h pour le test ; pile sous 20 %",
  "then": "rappel de tester les détecteurs, ou de changer la pile",
  "needs": [
   {
    "key": "smoke",
    "roles": [
     "smoke"
    ],
    "label": "Détecteur de fumée connecté",
    "hint": "se fixe au plafond, dans le couloir des chambres",
    "compatible": "détecteur de fumée Zigbee (Heiman, Frient)",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur de fumée connecté",
    "add_type": "fumee",
    "multiple": true
   },
   {
    "key": "battery",
    "roles": [
     "smoke_battery"
    ],
    "label": "Niveau de pile des détecteurs",
    "optional": true,
    "multiple": true,
    "none_fr": "Facultatif : seulement si le détecteur donne son niveau de pile"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "battery_low",
    "label": "Pile faible en dessous de",
    "type": "choice",
    "choices": [
     {
      "value": 10,
      "label": "10 %"
     },
     {
      "value": 20,
      "label": "20 %"
     },
     {
      "value": 30,
      "label": "30 %"
     }
    ],
    "default": 20
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "smoke_test_reminder.yaml",
  "module": null
 },
 {
  "id": "personne_seule",
  "title": "Bonjour, tout va bien ?",
  "short": "petit bonjour du matin",
  "pitch": "Pour une personne seule : un petit signe le matin, et les proches rassurés.",
  "description": "Pour une personne qui vit seule. Si la maison n'a vu aucun mouvement ni aucune ouverture avant 10 h, elle demande d'abord gentiment « Bonjour, tout va bien ? » (sur le téléphone, et à voix haute si une enceinte est choisie). Il suffit de bouger dans la maison ou de toucher « Tout va bien ». Sans réaction au bout de 30 minutes, les proches reçoivent un message calme pour prendre des nouvelles. Rien ne se passe en mode absent, et l'idée se coupe en un geste.",
  "category": "securite",
  "color": "#C2185B",
  "icon": "heart",
  "when": "chaque matin à 10 h",
  "if": "aucun mouvement ni ouverture depuis 6 h, et pas en mode absent",
  "then": "« Bonjour, tout va bien ? » à la personne ; sans réaction après 30 min, message aux proches",
  "needs": [
   {
    "key": "activity",
    "roles": [
     "motion",
     "contact"
    ],
    "label": "Détecteur de mouvement ou d'ouverture",
    "hint": "un dans la pièce de vie ou la cuisine suffit",
    "compatible": "détecteur de mouvement Aqara ou Sonoff",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur de mouvement",
    "add_type": "mouvement",
    "multiple": true,
    "exclude_words": [
     "boite aux lettres",
     "courrier",
     "garage",
     "portail"
    ]
   },
   {
    "key": "person_phone",
    "roles": [
     "phone"
    ],
    "label": "Le téléphone de la personne",
    "optional": true,
    "require_prefer": true,
    "none_fr": "À choisir ci-dessous (sinon : la notification principale si c'est un téléphone, et la voix)",
    "choose": true
   }
  ],
  "options": [
   {
    "key": "check_time",
    "label": "Vérifier à",
    "type": "choice",
    "choices": [
     {
      "value": "08:00:00",
      "label": "8 h"
     },
     {
      "value": "09:00:00",
      "label": "9 h"
     },
     {
      "value": "10:00:00",
      "label": "10 h"
     },
     {
      "value": "11:00:00",
      "label": "11 h"
     },
     {
      "value": "12:00:00",
      "label": "12 h"
     }
    ],
    "default": "10:00:00"
   },
   {
    "key": "wait_minutes",
    "label": "Prévenir les proches sans réaction après",
    "type": "choice",
    "choices": [
     {
      "value": 15,
      "label": "15 minutes"
     },
     {
      "value": 30,
      "label": "30 minutes"
     },
     {
      "value": 60,
      "label": "1 heure"
     }
    ],
    "default": 30
   },
   {
    "key": "ask_aloud",
    "label": "Demander aussi à voix haute « Bonjour, tout va bien ? »",
    "type": "bool",
    "default": true
   },
   {
    "key": "notify_relatives",
    "label": "Prévenir les proches (les autres téléphones reliés à la maison)",
    "type": "bool",
    "default": true
   }
  ],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": "« Bonjour, tout va bien ? »",
  "teaser": "Pour un proche qui vit seul : un petit bonjour chaque matin.",
  "teaser_detail": "Sans réponse, la famille est invitée à prendre des nouvelles.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "wellbeing_check.yaml",
  "module": null
 },
 {
  "id": "veilleuse_nuit",
  "title": "Veilleuse de nuit",
  "short": "veilleuse de nuit",
  "pitch": "La nuit, la lumière s'allume doucement quand on passe.",
  "description": "La nuit, quand quelqu'un passe devant le détecteur de mouvement, la lumière de la pièce s'allume doucement, sans éblouir. Elle s'éteint toute seule deux minutes après le dernier mouvement. C'est le même automatisme que celui proposé par l'assistant de démarrage.",
  "category": "confort",
  "color": "#6B47B8",
  "icon": "moon",
  "when": "quelqu'un passe, la nuit",
  "if": "entre 22 h et le matin",
  "then": "la lumière s'allume doucement puis s'éteint toute seule",
  "needs": [
   {
    "key": "motion",
    "roles": [
     "motion"
    ],
    "label": "Détecteur de mouvement",
    "hint": "se pose dans le couloir ou la chambre",
    "compatible": "détecteur de mouvement Aqara, Sonoff ou IKEA",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur de mouvement",
    "add_type": "mouvement"
   },
   {
    "key": "light",
    "roles": [
     "light"
    ],
    "label": "Lumière connectée dans la même pièce",
    "hint": "une ampoule connectée, rangée dans la même pièce que le détecteur",
    "compatible": "ampoule Philips Hue, IKEA ou Aqara",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 lumière dans la même pièce",
    "add_type": "lumiere",
    "multiple": true,
    "same_room_as": "motion",
    "strict_room": true
   }
  ],
  "options": [
   {
    "key": "brightness",
    "label": "Force de la lumière",
    "type": "choice",
    "choices": [
     {
      "value": 20,
      "label": "Douce (20 %)"
     },
     {
      "value": 60,
      "label": "Normale (60 %)"
     }
    ],
    "default": 20
   }
  ],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": "lumiere_nuit_mouvement",
  "applies_setting": false,
  "blueprint": "motion_night_light.yaml",
  "module": null
 },
 {
  "id": "lumiere_bienvenue",
  "title": "Lumière de bienvenue",
  "short": "lumière de bienvenue",
  "pitch": "La lumière de l'entrée s'allume quand vous rentrez le soir.",
  "description": "Après le coucher du soleil, quand la porte d'entrée s'ouvre (ou qu'une personne de la maison arrive avec son téléphone), la lumière de l'entrée s'allume 5 minutes, puis s'éteint toute seule. Si elle était déjà allumée, rien ne change.",
  "category": "confort",
  "color": "#E8590C",
  "icon": "bulb",
  "when": "la porte d'entrée s'ouvre, ou quelqu'un arrive à la maison",
  "if": "le soleil est couché et la lumière est éteinte",
  "then": "la lumière de l'entrée s'allume 5 minutes puis s'éteint",
  "needs": [
   {
    "key": "light",
    "roles": [
     "light"
    ],
    "label": "Lumière connectée dans l'entrée",
    "hint": "une ampoule connectée à la place de l'ampoule de l'entrée",
    "compatible": "ampoule connectée Zigbee (Ikea, Philips Hue)",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 lumière connectée dans l'entrée",
    "add_type": "lumiere",
    "multiple": true,
    "prefer": [
     "entree",
     "hall",
     "couloir",
     "porche",
     "perron",
     "allee",
     "palier",
     "exterieur"
    ],
    "require_prefer": true,
    "rename_fr": "Lumière de l'entrée"
   },
   {
    "key": "door",
    "roles": [
     "contact"
    ],
    "label": "Détecteur de la porte d'entrée",
    "add_type": "ouverture",
    "optional": true,
    "prefer": [
     "porte d'entree",
     "entree",
     "front door"
    ],
    "require_prefer": true,
    "exclude_words": [
     "frigo",
     "congelateur",
     "boite aux lettres"
    ],
    "none_fr": "Facultatif : sans détecteur, la lumière s'allume à l'arrivée d'un téléphone"
   },
   {
    "key": "persons",
    "roles": [
     "person"
    ],
    "label": "Les personnes de la maison",
    "missing_fr": "une personne dans Home Assistant",
    "multiple": true
   }
  ],
  "options": [
   {
    "key": "on_minutes",
    "label": "Rester allumée",
    "type": "choice",
    "choices": [
     {
      "value": 2,
      "label": "2 minutes"
     },
     {
      "value": 5,
      "label": "5 minutes"
     },
     {
      "value": 10,
      "label": "10 minutes"
     }
    ],
    "default": 5
   },
   {
    "key": "brightness",
    "label": "Luminosité",
    "type": "choice",
    "choices": [
     {
      "value": 50,
      "label": "Douce (50 %)"
     },
     {
      "value": 80,
      "label": "80 %"
     },
     {
      "value": 100,
      "label": "Pleine lumière"
     }
    ],
    "default": 80
   },
   {
    "key": "use_persons",
    "label": "S'allumer aussi quand quelqu'un arrive avec son téléphone",
    "type": "bool",
    "default": true
   }
  ],
  "tile": null,
  "next": [
   "simulation_presence"
  ],
  "next_hint": null,
  "teaser": "Rentrez le soir dans une entrée éclairée.",
  "teaser_detail": "La lumière s'allume à l'ouverture de la porte, puis s'éteint toute seule.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "welcome_light.yaml",
  "module": null
 },
 {
  "id": "rappel_porte_ouverte",
  "title": "Porte restée ouverte",
  "short": "porte restée ouverte",
  "pitch": "Un rappel si la porte d'entrée ou du garage reste ouverte.",
  "description": "Si la porte d'entrée ou la porte du garage reste ouverte plus de 10 minutes, vous recevez un rappel. Le message disparaît tout seul quand elle est refermée.",
  "category": "securite",
  "color": "#E8590C",
  "icon": "door",
  "when": "la porte d'entrée ou du garage est ouverte",
  "if": "depuis plus de 10 minutes",
  "then": "rappel sur le téléphone, effacé quand elle est refermée",
  "needs": [
   {
    "key": "doors",
    "roles": [
     "contact"
    ],
    "label": "Détecteur d'ouverture sur la porte",
    "hint": "se colle sur la porte et son cadre",
    "compatible": "détecteur d'ouverture Sonoff ou Aqara",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 détecteur de porte",
    "add_type": "ouverture",
    "multiple": true,
    "prefer": [
     "porte",
     "garage",
     "entree",
     "portail"
    ],
    "exclude_words": [
     "fenetre",
     "boite aux lettres",
     "courrier",
     "frigo",
     "refrigerateur",
     "congelateur"
    ]
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "open_minutes",
    "label": "Prévenir après",
    "type": "choice",
    "choices": [
     {
      "value": 5,
      "label": "5 minutes"
     },
     {
      "value": 10,
      "label": "10 minutes"
     },
     {
      "value": 30,
      "label": "30 minutes"
     }
    ],
    "default": 10
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "enceinte_annonces"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "door_left_open.yaml",
  "module": null
 },
 {
  "id": "simulation_presence",
  "title": "Simulation de présence",
  "short": "simulation de présence",
  "pitch": "En vacances, les lumières s'allument comme si vous étiez là.",
  "description": "Quand la maison est en mode absent, après le coucher du soleil, des lumières s'allument et s'éteignent au hasard, par moments, jusqu'à 23 h : de l'extérieur, la maison a l'air habitée. Dès que vous quittez le mode absent, ça s'arrête.",
  "category": "securite",
  "color": "#6B47B8",
  "icon": "home",
  "when": "le soleil se couche (ou le mode absent commence le soir)",
  "if": "la maison est en mode absent",
  "then": "des lumières s'allument et s'éteignent au hasard jusqu'à 23 h",
  "needs": [
   {
    "key": "lights",
    "roles": [
     "light"
    ],
    "label": "Lumières connectées visibles de dehors",
    "hint": "salon, cuisine ou chambre côté rue",
    "compatible": "ampoule connectée Zigbee (Ikea, Philips Hue)",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 lumière connectée",
    "add_type": "lumiere",
    "multiple": true,
    "prefer": [
     "salon",
     "sejour",
     "cuisine",
     "chambre",
     "bureau",
     "entree"
    ],
    "exclude_words": [
     "exterieur",
     "jardin",
     "terrasse",
     "garage",
     "cave"
    ]
   }
  ],
  "options": [
   {
    "key": "end_time",
    "label": "Jusqu'à",
    "type": "choice",
    "choices": [
     {
      "value": "22:00:00",
      "label": "22 h"
     },
     {
      "value": "23:00:00",
      "label": "23 h"
     },
     {
      "value": "23:30:00",
      "label": "23 h 30"
     }
    ],
    "default": "23:00:00"
   }
  ],
  "tile": null,
  "next": [
   "vacances_hors_gel"
  ],
  "next_hint": null,
  "teaser": "Pendant les vacances, la maison a l'air habitée.",
  "teaser_detail": "Des lumières s'allument au hasard le soir, en mode absent.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "presence_simulation.yaml",
  "module": null
 },
 {
  "id": "gel_canalisations",
  "title": "Gel des canalisations",
  "short": "risque de gel",
  "pitch": "Prévenu avant que les tuyaux du garage ne gèlent.",
  "description": "Un thermomètre au garage, à la cave ou dehors surveille le froid. S'il fait moins de 3 °C pendant un quart d'heure, vous recevez un message pour protéger les tuyaux ou chauffer un peu.",
  "category": "securite",
  "color": "#0067C0",
  "icon": "snow",
  "when": "la température descend trop bas",
  "if": "pendant plus d'un quart d'heure",
  "then": "message pour protéger les tuyaux",
  "needs": [
   {
    "key": "thermo",
    "roles": [
     "temperature"
    ],
    "label": "Thermomètre au garage, à la cave ou dehors",
    "hint": "se pose là où passent les tuyaux",
    "compatible": "thermomètre Aqara ou Sonoff",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 thermomètre",
    "add_type": "thermo",
    "prefer": [
     "garage",
     "cave",
     "exterieur",
     "dehors",
     "jardin",
     "cellier",
     "buanderie",
     "sous-sol",
     "abri",
     "terrasse",
     "balcon",
     "outdoor"
    ],
    "require_prefer": true
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "min_temp",
    "label": "Prévenir en dessous de",
    "type": "choice",
    "choices": [
     {
      "value": 1,
      "label": "1 °C"
     },
     {
      "value": 3,
      "label": "3 °C"
     },
     {
      "value": 5,
      "label": "5 °C"
     }
    ],
    "default": 3
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": {
   "kind": "value",
   "title": "Température du garage",
   "icon": "snow",
   "entity": "need:thermo",
   "unit": "°C",
   "preview": "4,5 °C"
  },
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "freeze_alert.yaml",
  "module": null
 },
 {
  "id": "canicule_interieur",
  "title": "Chaleur dans la maison",
  "short": "chaleur dans la maison",
  "pitch": "Trop chaud dedans : fermer les volets le jour, aérer le soir.",
  "description": "Quand il fait plus de 28 °C dans une pièce pendant une demi-heure, un rappel pour garder la fraîcheur : volets et fenêtres fermés côté soleil. Le soir, s'il fait encore chaud dedans (et plus frais dehors quand la météo est connue), un message dit que c'est le moment d'ouvrir grand. Une alerte par jour au plus, jamais la nuit.",
  "category": "securite",
  "color": "#C42B1C",
  "icon": "sun",
  "when": "il fait trop chaud dans une pièce, puis le soir à 21 h 30",
  "if": "plus de 28 °C pendant une demi-heure, ni la nuit, ni deux fois par jour",
  "then": "rappel de fermer les volets, puis d'aérer le soir",
  "needs": [
   {
    "key": "thermo",
    "roles": [
     "temperature"
    ],
    "label": "Thermomètre dans les pièces",
    "hint": "se pose dans une pièce de vie, loin du soleil direct",
    "compatible": "thermomètre Aqara ou Sonoff",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 thermomètre",
    "add_type": "thermo",
    "multiple": true,
    "exclude_words": [
     "exterieur",
     "dehors",
     "jardin",
     "terrasse",
     "balcon",
     "outdoor",
     "garage",
     "cave",
     "frigo",
     "congelateur",
     "piscine"
    ]
   },
   {
    "key": "weather",
    "roles": [
     "weather"
    ],
    "label": "Météo de la maison",
    "optional": true,
    "none_fr": "Facultatif : pour savoir s'il fait plus frais dehors"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "max_temp",
    "label": "Trop chaud au-dessus de",
    "type": "choice",
    "choices": [
     {
      "value": 26,
      "label": "26 °C"
     },
     {
      "value": 27,
      "label": "27 °C"
     },
     {
      "value": 28,
      "label": "28 °C"
     },
     {
      "value": 30,
      "label": "30 °C"
     }
    ],
    "default": 28
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "vigilance_meteo"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "heat_indoor.yaml",
  "module": null
 },
 {
  "id": "aeration",
  "title": "Aérer la salle de bain",
  "short": "aération",
  "pitch": "Un rappel, ou l'extracteur qui démarre, quand l'humidité monte.",
  "description": "Après la douche, l'humidité monte. Si l'extracteur est branché sur une prise connectée, il démarre tout seul et s'arrête quand l'air est sec. Sinon, un petit rappel vous invite à ouvrir la fenêtre : moins de buée, moins de moisissures.",
  "category": "confort",
  "color": "#00838F",
  "icon": "fan",
  "when": "l'humidité de la salle de bain dépasse 70 %",
  "if": "pendant plus de 5 minutes",
  "then": "l'extracteur démarre (ou rappel d'aérer), arrêt quand l'air est sec",
  "needs": [
   {
    "key": "humidity",
    "roles": [
     "humidity"
    ],
    "label": "Thermomètre avec humidité dans la salle de bain",
    "hint": "se pose dans la salle de bain, loin de la douche",
    "compatible": "thermomètre Aqara ou Sonoff",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 thermomètre pour la salle de bain",
    "add_type": "thermo",
    "prefer": [
     "salle de bain",
     "salle d'eau",
     "sdb",
     "douche",
     "bain",
     "bathroom"
    ],
    "require_prefer": true
   },
   {
    "key": "fan",
    "roles": [
     "switch"
    ],
    "label": "Extracteur branché sur une prise connectée",
    "hint": "facultatif",
    "optional": true,
    "prefer": [
     "extracteur",
     "vmc",
     "ventil",
     "aerat",
     "fan"
    ],
    "require_prefer": true,
    "none_fr": "Facultatif : sans extracteur, vous recevez un rappel"
   }
  ],
  "options": [
   {
    "key": "max_humidity",
    "label": "Aérer à partir de",
    "type": "choice",
    "choices": [
     {
      "value": 65,
      "label": "65 % d'humidité"
     },
     {
      "value": 70,
      "label": "70 % d'humidité"
     },
     {
      "value": 80,
      "label": "80 % d'humidité"
     }
    ],
    "default": 70
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": {
   "kind": "value",
   "title": "Humidité salle de bain",
   "icon": "fan",
   "entity": "need:humidity",
   "unit": "%",
   "preview": "58 %"
  },
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "humidity_ventilation.yaml",
  "module": null
 },
 {
  "id": "co2_aerer",
  "title": "Aérer quand l'air est confiné",
  "short": "air confiné (CO₂)",
  "pitch": "Un rappel d'ouvrir la fenêtre quand le CO₂ monte.",
  "description": "Un capteur de CO₂ mesure si l'air de la pièce est confiné (chambre, bureau, salon). Au-dessus de 1 000 ppm pendant 10 minutes, vous recevez « Ouvrez la fenêtre 5 à 10 minutes ». La nuit, pas de message sur le téléphone : seulement sur la box. Le message s'efface quand l'air est renouvelé.",
  "category": "securite",
  "color": "#00838F",
  "icon": "air",
  "when": "le CO₂ d'une pièce dépasse 1 000 ppm",
  "if": "pendant plus de 10 minutes",
  "then": "message « Ouvrez la fenêtre 5 à 10 minutes », effacé quand l'air est renouvelé",
  "needs": [
   {
    "key": "co2",
    "roles": [
     "co2"
    ],
    "label": "Capteur de CO₂",
    "hint": "se pose dans la chambre ou le salon",
    "compatible": "capteur de CO₂ (Aqara, Netatmo, Airthings)",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 capteur de CO₂",
    "multiple": true
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "max_co2",
    "label": "Aérer au-dessus de",
    "type": "choice",
    "choices": [
     {
      "value": 800,
      "label": "800 ppm (très sensible)"
     },
     {
      "value": 1000,
      "label": "1 000 ppm (conseillé)"
     },
     {
      "value": 1200,
      "label": "1 200 ppm"
     },
     {
      "value": 1500,
      "label": "1 500 ppm"
     }
    ],
    "default": 1000
   },
   {
    "key": "quiet_night",
    "label": "La nuit (22 h – 7 h), pas de message sur le téléphone",
    "type": "bool",
    "default": true
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "aeration"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "co2_ventilate.yaml",
  "module": null
 },
 {
  "id": "tv_off_depart",
  "title": "Télé éteinte en partant",
  "short": "extinction en partant",
  "pitch": "Plus de télé allumée pour personne quand toute la maison est partie.",
  "description": "Quand la maison passe en mode « Absent » (vous avez touché « Je pars », ou tout le monde est parti), la télé et la musique restées allumées s'éteignent toutes seules.",
  "category": "detecte",
  "color": "#0E7A0D",
  "icon": "tv",
  "when": "la maison passe en mode Absent",
  "if": "la télé ou la musique est restée allumée",
  "then": "tout s'éteint",
  "needs": [
   {
    "key": "media",
    "roles": [
     "tv",
     "speaker"
    ],
    "label": "Télé ou enceinte connectée",
    "hint": "un appareil relié au WiFi de la maison",
    "missing_fr": "1 télé connectée",
    "multiple": true,
    "pivot": true
   }
  ],
  "options": [],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [
   "samsungtv",
   "webostv",
   "androidtv_remote",
   "androidtv",
   "philips_js",
   "braviatv",
   "panasonic_viera",
   "vizio",
   "roku",
   "apple_tv",
   "cast",
   "sonos"
  ],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "media_off_away.yaml",
  "module": null
 },
 {
  "id": "cinema",
  "title": "Ambiance cinéma",
  "short": "ambiance cinéma",
  "pitch": "Le soir, la lumière baisse toute seule quand le film commence.",
  "description": "Le soir, quand la télé commence à lire, les lumières allumées de la pièce baissent doucement. Mettez sur pause : elles reviennent comme avant, pour aller chercher à boire sans vous cogner.",
  "category": "detecte",
  "color": "#6B47B8",
  "icon": "tv",
  "when": "la télé commence à lire, le soir",
  "if": "des lumières de la pièce sont allumées",
  "then": "elles baissent doucement, et reviennent à la pause",
  "needs": [
   {
    "key": "tv",
    "roles": [
     "tv"
    ],
    "label": "Télévision connectée",
    "hint": "une télé reliée au WiFi de la maison",
    "missing_fr": "1 télé connectée",
    "pivot": true
   },
   {
    "key": "lights",
    "roles": [
     "light"
    ],
    "label": "Lumière connectée dans la pièce de la télé",
    "hint": "une ampoule connectée, rangée dans la même pièce que la télé",
    "compatible": "ampoule Philips Hue, IKEA ou Aqara",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 lumière dans la pièce de la télé",
    "add_type": "lumiere",
    "multiple": true,
    "same_room_as": "tv",
    "strict_room": true
   }
  ],
  "options": [
   {
    "key": "dim",
    "label": "Lumière pendant le film",
    "type": "choice",
    "choices": [
     {
      "value": 5,
      "label": "Presque éteinte"
     },
     {
      "value": 15,
      "label": "Tamisée"
     },
     {
      "value": 30,
      "label": "Douce"
     }
    ],
    "default": 15
   },
   {
    "key": "evening_only",
    "label": "Seulement le soir",
    "type": "bool",
    "default": true
   }
  ],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [
   "samsungtv",
   "webostv",
   "androidtv_remote",
   "androidtv",
   "philips_js",
   "braviatv",
   "panasonic_viera",
   "vizio",
   "roku",
   "apple_tv",
   "cast"
  ],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "cinema_lights.yaml",
  "module": null
 },
 {
  "id": "enceinte_annonces",
  "title": "Annonces à voix haute",
  "short": "annonces à voix haute",
  "pitch": "Toutes les alertes de la maison aussi dites sur une enceinte.",
  "description": "Choisissez une enceinte connectée : chaque message de Maison Facile (courrier, fuite d'eau, machine terminée, porte restée ouverte…) est aussi annoncé à voix haute dans la maison. Rien d'autre à régler.",
  "category": "confort",
  "color": "#6B47B8",
  "icon": "speaker",
  "when": "une alerte Maison Facile est envoyée",
  "if": "une enceinte est choisie",
  "then": "elle annonce aussi le message à voix haute",
  "needs": [
   {
    "key": "speaker",
    "roles": [
     "speaker",
     "tv"
    ],
    "label": "Enceinte connectée",
    "hint": "branchée sur le WiFi de la maison : la box la trouve toute seule",
    "compatible": "Google Nest, Amazon Echo, Sonos",
    "price_hint": "[PRIX] €",
    "missing_fr": "1 enceinte connectée"
   }
  ],
  "options": [],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": "Ajoutez une enceinte connectée : la maison vous le dit à voix haute.",
  "teaser_detail": "Fonctionne avec Google Nest, Amazon Echo ou une enceinte Home Assistant.",
  "detected_by": [
   "cast",
   "sonos",
   "heos",
   "bluesound",
   "linkplay",
   "yamaha_musiccast"
  ],
  "test_announce": true,
  "recommendation": null,
  "applies_setting": true,
  "blueprint": null,
  "module": null
 },
 {
  "id": "tempo_rouge",
  "title": "Jours rouges EDF Tempo",
  "short": "jours rouges Tempo",
  "pitch": "Prévenu la veille des jours rouges, avec quoi décaler.",
  "description": "Pour les abonnés au tarif Tempo d'EDF. La veille d'un jour rouge (l'électricité y est bien plus chère de 6 h à 22 h), vous recevez le soir un message avec des conseils simples : lancer les machines la nuit, baisser un peu le chauffage. Le matin, un rappel. Home Assistant n'a pas d'intégration Tempo officielle : votre installateur ajoute une intégration de la communauté (gratuite) qui donne la couleur du jour et du lendemain.",
  "category": "energie",
  "color": "#C42B1C",
  "icon": "bolt",
  "when": "le soir (19 h), et le matin d'un jour rouge",
  "if": "demain (ou aujourd'hui) est un jour rouge Tempo",
  "then": "message avec les conseils pour décaler les gros appareils",
  "needs": [
   {
    "key": "tomorrow",
    "roles": [
     "tempo"
    ],
    "label": "Couleur Tempo de demain",
    "hint": "à relier par votre installateur : intégration « RTE Tempo » (communautaire, via HACS)",
    "compatible": "intégration communautaire RTE Tempo (HACS) ou équivalente",
    "price_hint": "[PRIX] €",
    "missing_fr": "relier le tarif Tempo (installateur)",
    "prefer": [
     "prochaine",
     "demain",
     "tomorrow",
     "next",
     "lendemain",
     "j+1",
     "j1"
    ],
    "require_prefer": true,
    "exclude_words": [
     "emoji",
     "restant",
     "jours restants"
    ]
   },
   {
    "key": "today",
    "roles": [
     "tempo"
    ],
    "label": "Couleur Tempo du jour",
    "optional": true,
    "prefer": [
     "actuelle",
     "aujourd",
     "today",
     "current",
     "du jour"
    ],
    "require_prefer": true,
    "exclude_words": [
     "emoji",
     "restant",
     "prochaine",
     "demain",
     "tomorrow",
     "next"
    ],
    "none_fr": "Facultatif : pour le rappel du matin"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "evening_time",
    "label": "Heure du message pour le lendemain",
    "type": "choice",
    "choices": [
     {
      "value": "12:00:00",
      "label": "12 h"
     },
     {
      "value": "18:00:00",
      "label": "18 h"
     },
     {
      "value": "19:00:00",
      "label": "19 h"
     },
     {
      "value": "20:00:00",
      "label": "20 h"
     }
    ],
    "default": "19:00:00"
   },
   {
    "key": "morning",
    "label": "Rappel le matin d'un jour rouge (7 h)",
    "type": "bool",
    "default": true
   },
   {
    "key": "warn_white",
    "label": "Prévenir aussi les jours blancs",
    "type": "bool",
    "default": false
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "heures_creuses"
  ],
  "next_hint": "« Demain est un jour ROUGE Tempo. »",
  "teaser": "Abonné Tempo ? Soyez prévenu des jours rouges.",
  "teaser_detail": "La veille au soir, avec des conseils simples pour payer moins.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "tempo_alert.yaml",
  "module": null
 },
 {
  "id": "heures_creuses",
  "title": "Heures creuses",
  "short": "heures creuses",
  "pitch": "Le chauffe-eau et les machines aux heures où l'électricité coûte moins.",
  "description": "Aux heures creuses de votre contrat (22 h – 6 h par défaut, à régler comme sur votre facture), le chauffe-eau branché sur un module connecté s'allume, puis s'éteint à la fin. Vous pouvez aussi recevoir chaque soir « Les heures creuses commencent : lancez les machines » (à cocher dans les réglages).",
  "category": "energie",
  "color": "#6B47B8",
  "icon": "clock",
  "when": "les heures creuses commencent, puis finissent",
  "if": "aux heures réglées (22 h – 6 h par défaut)",
  "then": "le chauffe-eau s'allume puis s'éteint ; rappel « lancez les machines » si vous le cochez",
  "needs": [
   {
    "key": "heater",
    "roles": [
     "switch"
    ],
    "label": "Chauffe-eau sur un module connecté",
    "compatible": "contacteur ou module 16 A posé par l'électricien",
    "price_hint": "[PRIX] €",
    "optional": true,
    "multiple": true,
    "prefer": [
     "chauffe-eau",
     "chauffe eau",
     "ballon",
     "cumulus",
     "eau chaude",
     "water heater",
     "boiler"
    ],
    "require_prefer": true,
    "none_fr": "Facultatif : sans module, cochez le rappel dans les réglages"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "start_time",
    "label": "Début des heures creuses",
    "type": "choice",
    "choices": [
     {
      "value": "20:00:00",
      "label": "20 h"
     },
     {
      "value": "20:30:00",
      "label": "20 h 30"
     },
     {
      "value": "21:00:00",
      "label": "21 h"
     },
     {
      "value": "21:30:00",
      "label": "21 h 30"
     },
     {
      "value": "22:00:00",
      "label": "22 h"
     },
     {
      "value": "22:30:00",
      "label": "22 h 30"
     },
     {
      "value": "23:00:00",
      "label": "23 h"
     },
     {
      "value": "23:30:00",
      "label": "23 h 30"
     },
     {
      "value": "00:00:00",
      "label": "0 h"
     },
     {
      "value": "00:30:00",
      "label": "0 h 30"
     },
     {
      "value": "01:00:00",
      "label": "1 h"
     },
     {
      "value": "01:30:00",
      "label": "1 h 30"
     },
     {
      "value": "02:00:00",
      "label": "2 h"
     }
    ],
    "default": "22:00:00"
   },
   {
    "key": "end_time",
    "label": "Fin des heures creuses",
    "type": "choice",
    "choices": [
     {
      "value": "05:00:00",
      "label": "5 h"
     },
     {
      "value": "05:30:00",
      "label": "5 h 30"
     },
     {
      "value": "06:00:00",
      "label": "6 h"
     },
     {
      "value": "06:30:00",
      "label": "6 h 30"
     },
     {
      "value": "07:00:00",
      "label": "7 h"
     },
     {
      "value": "07:30:00",
      "label": "7 h 30"
     },
     {
      "value": "08:00:00",
      "label": "8 h"
     }
    ],
    "default": "06:00:00"
   },
   {
    "key": "remind",
    "label": "Rappel « lancez les machines » au début",
    "type": "bool",
    "default": false
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "tempo_rouge",
   "bilan_mensuel"
  ],
  "next_hint": null,
  "teaser": "Profitez mieux de vos heures creuses.",
  "teaser_detail": "Le chauffe-eau s'allume tout seul, et un rappel pour lancer les machines.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "off_peak_hours.yaml",
  "module": null
 },
 {
  "id": "vacances_hors_gel",
  "title": "Hors-gel pendant les vacances",
  "short": "hors-gel pendant les vacances",
  "pitch": "Maison vide plus d'un jour : le chauffage passe en hors-gel.",
  "description": "Quand la maison est en mode absent depuis plus de 24 heures, les radiateurs qui chauffent passent à 8 °C (hors-gel) : la maison est protégée et vous payez moins. Dès qu'une personne rentre (son téléphone arrive à la maison), ou que vous quittez le mode absent, chaque radiateur reprend son réglage. Une climatisation en mode froid n'est jamais touchée.",
  "category": "energie",
  "color": "#0067C0",
  "icon": "snow",
  "when": "la maison est en mode absent depuis plus de 24 heures",
  "if": "des radiateurs chauffent",
  "then": "ils passent à 8 °C, puis reprennent leur réglage au retour",
  "needs": [
   {
    "key": "climates",
    "roles": [
     "climate"
    ],
    "label": "Chauffage connecté (radiateur ou thermostat)",
    "hint": "tête thermostatique ou thermostat connecté",
    "compatible": "tête thermostatique Zigbee, thermostat Netatmo ou Tado",
    "price_hint": "[PRIX] €",
    "missing_fr": "un chauffage connecté",
    "multiple": true
   },
   {
    "key": "persons",
    "roles": [
     "person"
    ],
    "label": "Les personnes de la maison",
    "optional": true,
    "multiple": true,
    "none_fr": "Facultatif : le retour d'un téléphone relance aussi le chauffage"
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "away_hours",
    "label": "En mode absent depuis plus de",
    "type": "choice",
    "choices": [
     {
      "value": 12,
      "label": "12 heures"
     },
     {
      "value": 24,
      "label": "24 heures"
     },
     {
      "value": 48,
      "label": "2 jours"
     }
    ],
    "default": 24
   },
   {
    "key": "frost_temp",
    "label": "Température pendant l'absence",
    "type": "choice",
    "choices": [
     {
      "value": 7,
      "label": "7 °C (hors-gel)"
     },
     {
      "value": 8,
      "label": "8 °C (hors-gel)"
     },
     {
      "value": 12,
      "label": "12 °C"
     },
     {
      "value": 16,
      "label": "16 °C (absence courte)"
     }
    ],
    "default": 8
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "simulation_presence"
  ],
  "next_hint": null,
  "teaser": "Partis plusieurs jours ? Le chauffage se met en hors-gel.",
  "teaser_detail": "Et il reprend tout seul à votre retour.",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "away_frost_guard.yaml",
  "module": null
 },
 {
  "id": "bilan_mensuel",
  "title": "Bilan du mois",
  "short": "bilan de consommation du mois",
  "pitch": "Le 1er du mois : votre consommation en kWh et en euros.",
  "description": "Le 1er de chaque mois au matin, vous recevez le bilan du mois passé : la consommation en kWh, son prix approximatif (avec le prix du kWh réglé dans Maison Facile) et la comparaison avec le mois d'avant. Les chiffres sont ceux de la page Énergie : le compteur Linky s'il est relié, sinon les prises qui mesurent.",
  "category": "energie",
  "color": "#0E7A0D",
  "icon": "chart",
  "when": "le 1er de chaque mois, au matin",
  "if": "la consommation du mois passé a été mesurée",
  "then": "message « En octobre : 312 kWh, environ 78 € » avec la comparaison au mois d'avant",
  "needs": [
   {
    "key": "meter",
    "roles": [
     "energy_meter",
     "energy"
    ],
    "label": "Mesure de la consommation",
    "hint": "compteur Linky relié, ou prises qui mesurent la consommation",
    "compatible": "module Linky (TIC) ou prise Zigbee avec mesure",
    "price_hint": "[PRIX] €",
    "missing_fr": "une mesure de consommation",
    "add_type": "prise",
    "multiple": true
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [],
  "tile": null,
  "next": [
   "heures_creuses"
  ],
  "next_hint": null,
  "teaser": "Recevez votre bilan de consommation chaque mois.",
  "teaser_detail": "« En octobre : 312 kWh, environ 78 €, 12 % de moins qu'en septembre. »",
  "detected_by": [],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": null,
  "module": "energy_report"
 },
 {
  "id": "imprimante_encre",
  "title": "Encre presque vide",
  "short": "encre presque vide",
  "pitch": "Un rappel pour racheter une cartouche avant la panne.",
  "description": "La box lit le niveau d'encre (ou de toner) de votre imprimante. Sous 10 %, vous recevez « Il ne reste que 8 % d'encre noire : pensez à racheter une cartouche ». Le message disparaît quand la cartouche est changée.",
  "category": "detecte",
  "color": "#0067C0",
  "icon": "printer",
  "when": "le niveau d'une encre baisse",
  "if": "il passe sous 10 %",
  "then": "message « pensez à racheter une cartouche », effacé quand elle est changée",
  "needs": [
   {
    "key": "ink",
    "roles": [
     "ink"
    ],
    "label": "Imprimante reliée à la box",
    "hint": "branchée sur le WiFi de la maison : la box la trouve toute seule",
    "compatible": "imprimante réseau (AirPrint / IPP) ou Brother",
    "missing_fr": "une imprimante reliée",
    "multiple": true,
    "pivot": true
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "min_level",
    "label": "Prévenir en dessous de",
    "type": "choice",
    "choices": [
     {
      "value": 5,
      "label": "5 %"
     },
     {
      "value": 10,
      "label": "10 %"
     },
     {
      "value": 20,
      "label": "20 %"
     }
    ],
    "default": 10
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [
   "ipp",
   "brother"
  ],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "ink_low.yaml",
  "module": null
 },
 {
  "id": "aspirateur_robot",
  "title": "Ménage quand tout le monde est parti",
  "short": "ménage pendant votre absence",
  "pitch": "Le robot aspirateur passe quand la maison est vide.",
  "description": "Quand plus personne n'est à la maison (ou que vous passez en mode absent), le robot aspirateur fait le ménage : une fois par jour au plus, seulement en journée (9 h – 19 h). Vous rentrez dans une maison propre, sans le robot dans les pieds.",
  "category": "detecte",
  "color": "#00838F",
  "icon": "vacuum",
  "when": "plus personne n'est à la maison depuis 10 minutes",
  "if": "en journée, le robot est sur sa base, pas déjà passé aujourd'hui",
  "then": "le robot fait le ménage",
  "needs": [
   {
    "key": "vacuum",
    "roles": [
     "vacuum"
    ],
    "label": "Robot aspirateur relié à la box",
    "hint": "relié par son application : votre installateur s'en occupe",
    "compatible": "Roborock, Ecovacs, iRobot Roomba, Xiaomi, Neato",
    "missing_fr": "un robot aspirateur relié",
    "pivot": true
   },
   {
    "key": "phone",
    "roles": [
     "phone"
    ],
    "label": "Votre téléphone",
    "optional": true,
    "none_fr": "Pas encore relié : installez l'application Home Assistant sur votre téléphone"
   }
  ],
  "options": [
   {
    "key": "start_hour",
    "label": "Pas avant",
    "type": "choice",
    "choices": [
     {
      "value": 8,
      "label": "8 h"
     },
     {
      "value": 9,
      "label": "9 h"
     },
     {
      "value": 10,
      "label": "10 h"
     },
     {
      "value": 13,
      "label": "13 h"
     }
    ],
    "default": 9
   },
   {
    "key": "return_on_arrival",
    "label": "Renvoyer le robot à sa base quand quelqu'un rentre",
    "type": "bool",
    "default": false
   },
   {
    "key": "notify_start",
    "label": "Me prévenir quand le ménage commence",
    "type": "bool",
    "default": false
   },
   {
    "key": "notify_family",
    "label": "Prévenir aussi les autres membres de la famille",
    "type": "bool",
    "default": false
   }
  ],
  "tile": null,
  "next": [
   "tv_off_depart"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [
   "roborock",
   "ecovacs",
   "xiaomi_miio",
   "neato",
   "roomba"
  ],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "vacuum_away.yaml",
  "module": null
 },
 {
  "id": "recharge_voiture",
  "title": "Recharge de la voiture en heures creuses",
  "short": "recharge en heures creuses",
  "pitch": "La voiture électrique se recharge quand l'électricité coûte moins.",
  "description": "La borne de recharge (ou la prise renforcée de la voiture) est autorisée à charger au début des heures creuses (22 h par défaut) et coupée à la fin (6 h). Entre les deux, vous pouvez toujours lancer une charge à la main.",
  "category": "detecte",
  "color": "#0E7A0D",
  "icon": "car",
  "when": "les heures creuses commencent, puis finissent",
  "if": "aux heures réglées (22 h – 6 h par défaut)",
  "then": "la charge est autorisée, puis coupée à la fin",
  "needs": [
   {
    "key": "charger",
    "roles": [
     "charger",
     "switch"
    ],
    "label": "Borne de recharge (ou prise de la voiture) reliée",
    "hint": "reliée à la box par votre installateur",
    "compatible": "borne Wallbox ou Peblar, ou prise renforcée connectée",
    "price_hint": "[PRIX] €",
    "missing_fr": "une borne de recharge reliée",
    "prefer": [
     "borne",
     "recharge",
     "voiture",
     "chargeur",
     "charger",
     "wallbox",
     "peblar",
     "vehicule"
    ],
    "require_prefer": true,
    "pivot": true
   }
  ],
  "options": [
   {
    "key": "start_time",
    "label": "Début des heures creuses",
    "type": "choice",
    "choices": [
     {
      "value": "20:00:00",
      "label": "20 h"
     },
     {
      "value": "20:30:00",
      "label": "20 h 30"
     },
     {
      "value": "21:00:00",
      "label": "21 h"
     },
     {
      "value": "21:30:00",
      "label": "21 h 30"
     },
     {
      "value": "22:00:00",
      "label": "22 h"
     },
     {
      "value": "22:30:00",
      "label": "22 h 30"
     },
     {
      "value": "23:00:00",
      "label": "23 h"
     },
     {
      "value": "23:30:00",
      "label": "23 h 30"
     },
     {
      "value": "00:00:00",
      "label": "0 h"
     },
     {
      "value": "00:30:00",
      "label": "0 h 30"
     },
     {
      "value": "01:00:00",
      "label": "1 h"
     },
     {
      "value": "01:30:00",
      "label": "1 h 30"
     },
     {
      "value": "02:00:00",
      "label": "2 h"
     }
    ],
    "default": "22:00:00"
   },
   {
    "key": "end_time",
    "label": "Fin des heures creuses",
    "type": "choice",
    "choices": [
     {
      "value": "05:00:00",
      "label": "5 h"
     },
     {
      "value": "05:30:00",
      "label": "5 h 30"
     },
     {
      "value": "06:00:00",
      "label": "6 h"
     },
     {
      "value": "06:30:00",
      "label": "6 h 30"
     },
     {
      "value": "07:00:00",
      "label": "7 h"
     },
     {
      "value": "07:30:00",
      "label": "7 h 30"
     },
     {
      "value": "08:00:00",
      "label": "8 h"
     }
    ],
    "default": "06:00:00"
   },
   {
    "key": "block_peak",
    "label": "Couper la charge à la fin des heures creuses",
    "type": "bool",
    "default": true
   }
  ],
  "tile": null,
  "next": [
   "heures_creuses",
   "tempo_rouge"
  ],
  "next_hint": null,
  "teaser": null,
  "teaser_detail": null,
  "detected_by": [
   "peblar",
   "wallbox"
  ],
  "test_announce": false,
  "recommendation": null,
  "applies_setting": false,
  "blueprint": "ev_off_peak.yaml",
  "module": null
 }
];
