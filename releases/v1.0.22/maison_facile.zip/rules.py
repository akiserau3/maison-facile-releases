"""Pure recommendation logic for Maison Facile.

This module must NOT import homeassistant: it is unit-tested on its own.

Inputs
------
``devices``: classified devices, each a dict with at least::

    {"device_id": str, "name": str, "type": str, "area_id": str | None,
     "entities": {role: entity_id}}

``persons``: list of ``person.*`` entity ids.
``settings``: the store settings (see CONTRACT §4).
``stored``: the store ``recommendations`` mapping ``{id: {enabled, options, automation_ids}}``.

Outputs
-------
``build_recommendations`` -> list of Recommendation dicts (CONTRACT §5).
``build_instances`` -> list of automation instances for one recommendation::

    {"automation_id": "mf_<reco>_<hash8>", "alias": str, "description": str,
     "blueprint": "maison_facile/<file>.yaml", "inputs": {...}, "recommendation_id": str}
"""

from __future__ import annotations

import hashlib
import re
from typing import Any

try:
    from . import buying_guide as _guide
except ImportError:  # imported as a top-level module by the pure tests (tests/conftest.py)
    import buying_guide as _guide  # type: ignore[no-redef]

BLUEPRINT_DIR = "maison_facile"
MODE_ENTITY_ID = "select.maison_facile_mode"
DESCRIPTION = "Créé par Maison Facile"
DEFAULT_NOTIFY = "notify.notify"

BLUEPRINT_FILES: dict[str, str] = {
    "lumiere_nuit_mouvement": "motion_night_light.yaml",
    "fenetre_chauffage": "window_heating_pause.yaml",
    "tout_eteindre_depart": "leave_all_off.yaml",
    "veille_nuit": "standby_cut_night.yaml",
    "mode_nuit_heure": "night_mode_time.yaml",
    "alerte_fumee": "smoke_alert.yaml",
    "alerte_intrusion": "intrusion_alert.yaml",
    "alerte_froid_humide": "climate_comfort_alert.yaml",
}

# Display order of the recommendations.
RECOMMENDATION_IDS: tuple[str, ...] = (
    "lumiere_nuit_mouvement",
    "fenetre_chauffage",
    "tout_eteindre_depart",
    "alerte_fumee",
    "alerte_intrusion",
    "mode_nuit_heure",
    "veille_nuit",
    "alerte_froid_humide",
)

TITLES: dict[str, str] = {
    "lumiere_nuit_mouvement": "Allumer doucement la lumière quand on passe la nuit",
    "fenetre_chauffage": "Prévenir si une fenêtre est ouverte avec le chauffage",
    "tout_eteindre_depart": "Tout éteindre quand toute la maison est partie",
    "veille_nuit": "Couper les appareils en veille la nuit",
    "mode_nuit_heure": "Passer la maison en mode nuit tous les soirs",
    "alerte_fumee": "Prévenir tout de suite en cas de fumée",
    "alerte_intrusion": "Prévenir si quelqu'un entre pendant votre absence",
    "alerte_froid_humide": "Prévenir s'il fait trop froid ou trop humide",
}

SHORT_ALIASES: dict[str, str] = {
    "lumiere_nuit_mouvement": "Lumière de nuit",
    "fenetre_chauffage": "Fenêtre ouverte et chauffage",
    "tout_eteindre_depart": "Tout éteindre au départ",
    "veille_nuit": "Couper la veille la nuit",
    "mode_nuit_heure": "Mode nuit à heure fixe",
    "alerte_fumee": "Alerte fumée",
    "alerte_intrusion": "Alerte intrusion",
    "alerte_froid_humide": "Alerte froid ou humidité",
}

BRIGHTNESS_LEVELS: dict[str, int] = {"doux": 20, "normal": 60}
NIGHT_TIME_CHOICES: tuple[str, ...] = ("22:00", "22:30", "23:00", "23:30", "00:00")


# --------------------------------------------------------------------------- helpers


def short_hash(value: str) -> str:
    """Stable 8-char hash used in automation ids."""
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:8]


def automation_id(recommendation_id: str, primary: str) -> str:
    return f"mf_{recommendation_id}_{short_hash(primary)}"


def to_hms(value: Any, default: str) -> str:
    """Normalize "HH:MM" / "HH:MM:SS" to "HH:MM:SS"; fall back to ``default``."""
    text = str(value or "").strip()
    parts = text.split(":")
    if len(parts) in (2, 3) and all(p.isdigit() for p in parts):
        h, m = int(parts[0]), int(parts[1])
        s = int(parts[2]) if len(parts) == 3 else 0
        if 0 <= h < 24 and 0 <= m < 60 and 0 <= s < 60:
            return f"{h:02d}:{m:02d}:{s:02d}"
    return default


def to_hm(value: Any, default: str) -> str:
    return to_hms(value, default + ":00")[:5]


def _plural(count: int, singular: str, plural: str) -> str:
    return f"{count} {singular if count == 1 else plural}"


def _by_type(devices: list[dict[str, Any]], device_type: str) -> list[dict[str, Any]]:
    return [d for d in devices if d.get("type") == device_type]


def _role(device: dict[str, Any], role: str) -> str | None:
    value = (device.get("entities") or {}).get(role)
    return str(value) if value else None


def _with_role(devices: list[dict[str, Any]], role: str) -> list[dict[str, Any]]:
    return sorted(
        (d for d in devices if _role(d, role)), key=lambda d: str(_role(d, role))
    )


def _entities(devices: list[dict[str, Any]], role: str) -> list[str]:
    return sorted({str(_role(d, role)) for d in devices if _role(d, role)})


def _lights_in_area(devices: list[dict[str, Any]], area_id: str | None, exclude: str | None) -> list[str]:
    if not area_id:
        return []
    return sorted(
        {
            str(_role(d, "light"))
            for d in devices
            if d.get("area_id") == area_id and _role(d, "light") and d.get("device_id") != exclude
        }
    )


def _notify(settings: dict[str, Any]) -> str:
    return str(settings.get("notify_service") or DEFAULT_NOTIFY)


def _device_label(device: dict[str, Any]) -> str:
    return str(device.get("name") or device.get("type_label") or "appareil")


def _choice(value: str, label: str, recommended: bool) -> dict[str, Any]:
    return {"value": value, "label": label, "recommended": recommended}


# --------------------------------------------------------------------------- options


def option_definitions(recommendation_id: str, settings: dict[str, Any]) -> list[dict[str, Any]]:
    """Options exposed for one recommendation (CONTRACT §5 Recommendation.options)."""
    if recommendation_id == "lumiere_nuit_mouvement":
        return [
            {
                "key": "brightness",
                "label": "Force de la lumière",
                "choices": [
                    _choice("doux", "Douce (20 %)", True),
                    _choice("normal", "Normale (60 %)", False),
                ],
            }
        ]
    if recommendation_id == "mode_nuit_heure":
        current = to_hm(settings.get("night_time"), "23:00")
        values = list(NIGHT_TIME_CHOICES)
        if current not in values:
            values.append(current)
        return [
            {
                "key": "night_time",
                "label": "Heure du mode nuit",
                "choices": [
                    _choice(v, f"{v.replace(':', ' h ').replace(' h 00', ' h')}", v == current)
                    for v in values
                ],
            }
        ]
    return []


def default_options(recommendation_id: str, settings: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for option in option_definitions(recommendation_id, settings):
        for choice in option["choices"]:
            if choice["recommended"]:
                result[option["key"]] = choice["value"]
                break
    return result


def resolve_options(
    recommendation_id: str, settings: dict[str, Any], options: dict[str, Any] | None
) -> dict[str, Any]:
    """Merge user options over defaults, dropping unknown keys/values."""
    resolved = default_options(recommendation_id, settings)
    if not options:
        return resolved
    for option in option_definitions(recommendation_id, settings):
        key = option["key"]
        if key not in options:
            continue
        value = options[key]
        allowed = {c["value"] for c in option["choices"]}
        if key == "brightness" and isinstance(value, (int, float)) and not isinstance(value, bool):
            resolved[key] = int(value) if 1 <= int(value) <= 100 else resolved[key]
        elif key == "night_time":
            resolved[key] = to_hm(value, resolved[key])
        elif value in allowed:
            resolved[key] = value
    return resolved


def _brightness_pct(value: Any) -> int:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return max(1, min(100, int(value)))
    return BRIGHTNESS_LEVELS.get(str(value), BRIGHTNESS_LEVELS["doux"])


# --------------------------------------------------------------------------- applicability


def _analysis(recommendation_id: str, devices: list[dict[str, Any]], persons: list[str],
              settings: dict[str, Any]) -> tuple[bool, bool, str] | None:
    """Return (applicable, recommended, why) or None when not applicable."""
    motions = _with_role(devices, "motion")
    contacts = _with_role(_by_type(devices, "ouverture"), "contact")
    climates = _entities(devices, "climate")
    thermos = _with_role(_by_type(devices, "thermo"), "temperature")
    smokes = _entities(devices, "smoke")
    plugs = [d for d in _with_role(devices, "switch") if _role(d, "power")]

    if recommendation_id == "lumiere_nuit_mouvement":
        if not motions:
            return None
        with_light = [
            m for m in motions if _lights_in_area(devices, m.get("area_id"), m.get("device_id"))
        ]
        why = f"Vous avez {_plural(len(motions), 'détecteur de mouvement', 'détecteurs de mouvement')}"
        if not with_light:
            why += ", mais aucune lumière connectée dans la même pièce"
        return True, bool(with_light), why

    if recommendation_id == "fenetre_chauffage":
        if not contacts:
            return None
        parts = ["un détecteur d'ouverture" if len(contacts) == 1 else "des détecteurs d'ouverture"]
        if thermos:
            parts.append("un thermomètre" if len(thermos) == 1 else "des thermomètres")
        if climates:
            parts.append("un chauffage connecté" if len(climates) == 1 else "des chauffages connectés")
        why = "Vous avez " + ", ".join(parts[:-1]) + (" et " if len(parts) > 1 else "") + parts[-1]
        return True, bool(thermos or climates), why

    if recommendation_id == "tout_eteindre_depart":
        if not persons:
            return None
        return True, True, "Utilise les téléphones de la famille"

    if recommendation_id == "veille_nuit":
        if not plugs:
            return None
        why = (
            "Vous avez une prise qui mesure la consommation"
            if len(plugs) == 1
            else f"Vous avez {len(plugs)} prises qui mesurent la consommation"
        )
        return True, False, why

    if recommendation_id == "mode_nuit_heure":
        night = to_hm(settings.get("night_time"), "23:00").replace(":", " h ").replace(" h 00", " h")
        # Contract: proposed but not "recommended"; the night_mode choice
        # (hour|voice) drives its default enabled state (see build_recommendations).
        return True, False, f"Tous les soirs à {night}, retour au mode maison le matin"

    if recommendation_id == "alerte_fumee":
        if not smokes:
            return None
        return True, True, f"Vous avez {_plural(len(smokes), 'détecteur de fumée', 'détecteurs de fumée')}"

    if recommendation_id == "alerte_intrusion":
        sensors = _intrusion_sensors(devices)
        if not sensors:
            return None
        return True, True, (
            f"Vous avez {_plural(len(sensors), 'détecteur', 'détecteurs')} d'ouverture ou de mouvement"
        )

    if recommendation_id == "alerte_froid_humide":
        if not thermos:
            return None
        return True, False, f"Vous avez {_plural(len(thermos), 'thermomètre', 'thermomètres')}"

    return None


def _intrusion_sensors(devices: list[dict[str, Any]]) -> list[str]:
    return sorted(set(_entities(devices, "contact")) | set(_entities(devices, "motion")))


# --------------------------------------------------------------------------- public API


def build_recommendations(
    devices: list[dict[str, Any]],
    persons: list[str],
    settings: dict[str, Any],
    stored: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """List the applicable recommendations, with their current enabled state.

    ``enabled`` comes from the store when the user already chose, otherwise it
    equals ``recommended``.
    """
    stored = stored or {}
    items: list[dict[str, Any]] = []
    for rec_id in RECOMMENDATION_IDS:
        analysis = _analysis(rec_id, devices, persons, settings)
        if analysis is None:
            continue
        _, recommended, why = analysis
        saved = stored.get(rec_id)
        if isinstance(saved, dict) and "enabled" in saved:
            enabled = bool(saved["enabled"])
        elif rec_id == "mode_nuit_heure":
            enabled = settings.get("night_mode", "hour") == "hour"
        else:
            enabled = recommended
        items.append(
            {
                "id": rec_id,
                "title": TITLES[rec_id],
                "why": why,
                "recommended": recommended,
                "enabled": enabled,
                "options": option_definitions(rec_id, settings),
                "values": resolve_options(
                    rec_id, settings, (saved or {}).get("options") if isinstance(saved, dict) else None
                ),
            }
        )
    return items


def _instance(rec_id: str, primary: str, label: str | None, inputs: dict[str, Any]) -> dict[str, Any]:
    alias = f"Maison Facile – {SHORT_ALIASES[rec_id]}"
    if label:
        alias += f" ({label})"
    return {
        "automation_id": automation_id(rec_id, primary),
        "alias": alias,
        "description": DESCRIPTION,
        "blueprint": f"{BLUEPRINT_DIR}/{BLUEPRINT_FILES[rec_id]}",
        "inputs": inputs,
        "recommendation_id": rec_id,
    }


def build_instances(
    recommendation_id: str,
    devices: list[dict[str, Any]],
    persons: list[str],
    settings: dict[str, Any],
    options: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Automation instances to create for one enabled recommendation."""
    if recommendation_id not in BLUEPRINT_FILES:
        return []
    if _analysis(recommendation_id, devices, persons, settings) is None:
        return []
    opts = resolve_options(recommendation_id, settings, options)
    notify = _notify(settings)
    morning = to_hms(settings.get("morning_time"), "07:00:00")
    out: list[dict[str, Any]] = []

    if recommendation_id == "lumiere_nuit_mouvement":
        for motion in _with_role(devices, "motion"):
            lights = _lights_in_area(devices, motion.get("area_id"), motion.get("device_id"))
            if not lights:
                continue
            sensor = str(_role(motion, "motion"))
            out.append(
                _instance(
                    recommendation_id,
                    sensor,
                    _device_label(motion),
                    {
                        "motion_sensor": sensor,
                        "light_target": {"entity_id": lights},
                        "brightness_pct": _brightness_pct(opts.get("brightness")),
                        "no_motion_wait": 120,
                        "night_start": "22:00:00",
                        "night_end": morning,
                    },
                )
            )

    elif recommendation_id == "fenetre_chauffage":
        all_climates = _entities(devices, "climate")
        for contact in _with_role(_by_type(devices, "ouverture"), "contact"):
            sensor = str(_role(contact, "contact"))
            area = contact.get("area_id")
            if area:
                climates = sorted(
                    {str(_role(d, "climate")) for d in devices
                     if d.get("area_id") == area and _role(d, "climate")}
                )
            else:
                climates = all_climates
            out.append(
                _instance(
                    recommendation_id,
                    sensor,
                    _device_label(contact),
                    {
                        "window_sensor": sensor,
                        "climate_entities": climates,
                        "delay_minutes": 2,
                        "notify_service": notify,
                    },
                )
            )

    elif recommendation_id == "tout_eteindre_depart":
        out.append(
            _instance(
                recommendation_id,
                "home",
                None,
                {
                    "persons": sorted(set(persons)),
                    "mode_select": MODE_ENTITY_ID,
                    "turn_off_lights": True,
                    "turn_off_switches": False,
                },
            )
        )

    elif recommendation_id == "veille_nuit":
        for plug in _with_role(devices, "switch"):
            power = _role(plug, "power")
            if not power:
                continue
            switch = str(_role(plug, "switch"))
            out.append(
                _instance(
                    recommendation_id,
                    switch,
                    _device_label(plug),
                    {
                        "switch_entity": switch,
                        "power_sensor": power,
                        "threshold_w": 15,
                        "start_time": "01:00:00",
                        "end_time": morning,
                    },
                )
            )

    elif recommendation_id == "mode_nuit_heure":
        out.append(
            _instance(
                recommendation_id,
                "home",
                None,
                {
                    "mode_select": MODE_ENTITY_ID,
                    "night_time": to_hms(opts.get("night_time"), "23:00:00"),
                    "morning_time": morning,
                },
            )
        )

    elif recommendation_id == "alerte_fumee":
        out.append(
            _instance(
                recommendation_id,
                "home",
                None,
                {
                    "smoke_sensors": _entities(devices, "smoke"),
                    "notify_service": notify,
                    "lights_on": True,
                },
            )
        )

    elif recommendation_id == "alerte_intrusion":
        out.append(
            _instance(
                recommendation_id,
                "home",
                None,
                {
                    "mode_select": MODE_ENTITY_ID,
                    "sensors": _intrusion_sensors(devices),
                    "notify_service": notify,
                    "sirens": _entities(devices, "siren"),
                },
            )
        )

    elif recommendation_id == "alerte_froid_humide":
        for thermo in _with_role(_by_type(devices, "thermo"), "temperature"):
            temp = str(_role(thermo, "temperature"))
            out.append(
                _instance(
                    recommendation_id,
                    temp,
                    _device_label(thermo),
                    {
                        "temperature_sensor": temp,
                        "humidity_sensor": _role(thermo, "humidity") or "",
                        "min_temp": 16,
                        "max_humidity": 70,
                        "notify_service": notify,
                    },
                )
            )

    return out


def build_plan(
    devices: list[dict[str, Any]],
    persons: list[str],
    settings: dict[str, Any],
    stored: dict[str, Any] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    """For every known recommendation: the instances to have (empty when disabled)."""
    plan: dict[str, list[dict[str, Any]]] = {}
    items = {i["id"]: i for i in build_recommendations(devices, persons, settings, stored)}
    stored = stored or {}
    for rec_id in RECOMMENDATION_IDS:
        item = items.get(rec_id)
        if item is None or not item["enabled"]:
            plan[rec_id] = []
            continue
        saved = stored.get(rec_id) if isinstance(stored.get(rec_id), dict) else {}
        plan[rec_id] = build_instances(rec_id, devices, persons, settings, saved.get("options"))
    return plan


# --------------------------------------------------------------------------- settings validation

# Duplicated from const.py on purpose: this module must stay importable alone.
SETTINGS_CHOICES: dict[str, tuple[str, ...]] = {
    # Same lists as theme_rules.THEMES / THEME_AUTO_MODES / HOME_STYLES (checked by the tests).
    "theme": (
        "clair", "sombre", "contraste", "printemps", "ete", "automne", "hiver",
        "halloween", "noel", "nouvelan", "valentin", "paques", "quatorze",
    ),
    "theme_auto": ("fetes_saisons", "fetes", "saisons", "non"),
    "home_style": ("maison_facile", "orbite", "neon", "jumeau", "holo"),
    "update_mode": ("auto", "ask"),
    "update_channel": ("stable", "test"),
    "night_mode": ("hour", "voice"),
}
SETTINGS_MAX_LENGTH: dict[str, int] = {"installer_name": 100, "installer_contact": 200}
KWH_PRICE_MAX = 10.0
NOTIFY_SERVICE_RE = re.compile(r"^notify\.[a-z0-9_]+$")

SETTINGS_LABELS_FR: dict[str, str] = {
    "theme": "Apparence",
    "update_mode": "Mises à jour",
    "update_channel": "Canal de mises à jour",
    "night_mode": "Mode nuit",
    "night_time": "Heure du mode nuit",
    "morning_time": "Heure du matin",
    "kwh_price": "Prix du kWh",
    "notify_service": "Service de notification",
    "installer_name": "Nom de l'installateur",
    "installer_contact": "Contact de l'installateur",
    "versions_url": "Adresse du manifeste de versions",
    "commercial_mode": "Mode commercial",
    "expert_mode": "Mode Expert",
    "installer_pin": "Code installateur",
    "announce_media_player": "Enceinte des annonces",
    "theme_auto": "Changer de thème tout seul",
    "animations": "Petites animations",
    "home_style": "Style de l'accueil",
    "liked_styles": "Styles aimés",
    "shop_url": "Lien « Où l'acheter ? »",
}

SETTINGS_ERRORS_FR: dict[str, str] = {
    "unknown_key": "ce réglage n'existe pas",
    "invalid_choice": "choix non disponible",
    "invalid_time": "heure attendue au format HH:MM",
    "invalid_price": f"prix attendu entre 0 et {KWH_PRICE_MAX:g} €",
    "invalid_notify": "doit ressembler à notify.mon_telephone",
    "invalid_url": "l'adresse doit commencer par https://",
    "too_long": "texte trop long",
    "invalid_text": "texte attendu",
    "invalid_bool": "oui ou non attendu",
    "invalid_pin": "4 à 8 chiffres attendus (ou vide pour aucun code)",
    "invalid_media_player": "doit ressembler à media_player.salon (ou vide pour aucune enceinte)",
    "invalid_styles": "liste de styles d'accueil attendue",
    "invalid_shop_url": "adresse https:// attendue (avec {need} au besoin), ou vide pour masquer le bouton",
}

INSTALLER_PIN_RE = re.compile(r"^[0-9]{4,8}$")
MEDIA_PLAYER_RE = re.compile(r"^media_player\.[a-z0-9_]+$")


def validate_settings(changes: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    """Validate a partial settings dict.

    Returns ``(clean, errors)`` where ``errors`` maps a key to an error code
    (see ``SETTINGS_ERRORS_FR``). Shared by the options flow and ``settings/set``.
    """
    clean: dict[str, Any] = {}
    errors: dict[str, str] = {}
    for key, value in changes.items():
        if key in SETTINGS_CHOICES:
            if value in SETTINGS_CHOICES[key]:
                clean[key] = value
            else:
                errors[key] = "invalid_choice"
        elif key in ("night_time", "morning_time"):
            text = to_hms(value, "")
            if text:
                clean[key] = text[:5]
            else:
                errors[key] = "invalid_time"
        elif key == "kwh_price":
            try:
                price = float(value)
            except (TypeError, ValueError):
                errors[key] = "invalid_price"
                continue
            if isinstance(value, bool) or not 0 <= price <= KWH_PRICE_MAX:
                errors[key] = "invalid_price"
            else:
                clean[key] = round(price, 4)
        elif key == "notify_service":
            text = str(value or "").strip()
            if NOTIFY_SERVICE_RE.match(text):
                clean[key] = text
            else:
                errors[key] = "invalid_notify"
        elif key == "versions_url":
            text = str(value or "").strip()
            if text.startswith("https://") and len(text) > len("https://") and " " not in text:
                clean[key] = text
            else:
                errors[key] = "invalid_url"
        elif key == "shop_url":
            url = _guide.validate_shop_url(value)
            if url is None:
                errors[key] = "invalid_shop_url"
            else:
                clean[key] = url
        elif key == "liked_styles":
            styles = SETTINGS_CHOICES["home_style"]
            if isinstance(value, list) and all(isinstance(s, str) and s in styles for s in value):
                clean[key] = [s for s in styles if s in value]  # no duplicates, stable order
            else:
                errors[key] = "invalid_styles"
        elif key in ("commercial_mode", "animations", "expert_mode"):
            if isinstance(value, bool):
                clean[key] = value
            else:
                errors[key] = "invalid_bool"
        elif key == "installer_pin":
            # Clear text only on its way to the hash (commercial.py); never stored as is.
            text = value.strip() if isinstance(value, str) else None
            if text is not None and (text == "" or INSTALLER_PIN_RE.match(text)):
                clean[key] = text
            else:
                errors[key] = "invalid_pin"
        elif key == "announce_media_player":
            text = value.strip() if isinstance(value, str) else None
            if text is not None and (text == "" or MEDIA_PLAYER_RE.match(text)):
                clean[key] = text
            else:
                errors[key] = "invalid_media_player"
        elif key in SETTINGS_MAX_LENGTH:
            if not isinstance(value, str):
                errors[key] = "invalid_text"
            elif len(value.strip()) > SETTINGS_MAX_LENGTH[key]:
                errors[key] = "too_long"
            else:
                clean[key] = value.strip()
        else:
            errors[key] = "unknown_key"
    return clean, errors


def settings_error_message(errors: dict[str, str]) -> str:
    """One French sentence describing the first validation error."""
    key, code = next(iter(errors.items()))
    label = SETTINGS_LABELS_FR.get(key, key)
    return f"Valeur incorrecte pour « {label} » : {SETTINGS_ERRORS_FR.get(code, code)}."


# --------------------------------------------------------------------------- energy helpers

MAIN_METER_WORDS: tuple[str, ...] = ("linky", "compteur", "total", "grid", "reseau", "réseau", "general", "général")


def looks_like_main_meter(name: str | None, entity_id: str | None, is_plug: bool) -> bool:
    """True when an energy sensor probably measures the whole house.

    Such sensors are excluded from the sum of devices to avoid double counting.
    """
    if not is_plug:
        return True
    text = f"{name or ''} {entity_id or ''}".lower()
    return any(word in text for word in MAIN_METER_WORDS)


# --------------------------------------------------------------------------- heating pause

HEATING_PAUSE_MAX_SECONDS = 2 * 3600
_OFF_STATES = {"off", "unavailable", "unknown"}

HEATING_PAUSE_MESSAGES_FR: dict[str, str] = {
    "paused": "Chauffage mis en pause. Il repartira tout seul quand la fenêtre sera fermée (au plus tard dans 2 heures).",
    "unknown_window": "Ce détecteur d'ouverture n'est pas géré par Maison Facile.",
    "no_room": "Rangez d'abord ce détecteur d'ouverture dans une pièce.",
    "window_closed": "La fenêtre est fermée : il n'y a rien à mettre en pause.",
    "no_heating": "Aucun chauffage connecté dans cette pièce.",
    "already_off": "Le chauffage de cette pièce est déjà éteint.",
    "already_paused": "Le chauffage de cette pièce est déjà en pause.",
}


def pause_scene_id(window_entity_id: str) -> str:
    return f"mf_pause_{short_hash(window_entity_id)}"


def plan_heating_pause(
    devices: list[dict[str, Any]], window_entity_id: str, states: dict[str, str]
) -> dict[str, Any]:
    """Decide what a heating pause for ``window_entity_id`` should do.

    ``states`` maps entity_id -> state string. Returns
    ``{"ok": bool, "reason": str, "area_id": str|None, "climates": [entity_id], "scene_id": str}``.
    Only climates of Maison Facile devices in the window's room which are not
    already off are paused.
    """
    result: dict[str, Any] = {
        "ok": False,
        "reason": "unknown_window",
        "area_id": None,
        "climates": [],
        "scene_id": pause_scene_id(window_entity_id),
    }
    window = next(
        (d for d in devices if d.get("type") == "ouverture" and _role(d, "contact") == window_entity_id),
        None,
    )
    if window is None:
        return result
    area = window.get("area_id")
    result["area_id"] = area
    if not area:
        result["reason"] = "no_room"
        return result
    if states.get(window_entity_id) == "off":
        result["reason"] = "window_closed"
        return result
    climates = sorted(
        {str(_role(d, "climate")) for d in devices if d.get("area_id") == area and _role(d, "climate")}
    )
    if not climates:
        result["reason"] = "no_heating"
        return result
    active = [c for c in climates if states.get(c, "unknown") not in _OFF_STATES]
    if not active:
        result.update(ok=True, reason="already_off")
        return result
    result.update(ok=True, reason="paused", climates=active)
    return result


# --------------------------------------------------------------------------- yaml helpers

_BLOCK_SCALAR_RE = re.compile(r"(^|[:\-\s])[|>][0-9+\-]*\s*(#.*)?$")


def yaml_has_comments(text: str) -> bool:
    """True when a YAML document has full-line ``#`` comments outside block scalars.

    Such comments are lost when the file is rewritten, so the caller warns once.
    """
    block_indent: int | None = None
    for raw in text.splitlines():
        stripped = raw.strip()
        indent = len(raw) - len(raw.lstrip(" "))
        if block_indent is not None:
            if not stripped or indent > block_indent:
                continue  # inside a | or > block scalar
            block_indent = None
        if stripped.startswith("#"):
            return True
        if _BLOCK_SCALAR_RE.search(raw.rstrip()):
            block_indent = indent
    return False
