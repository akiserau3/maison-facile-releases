"""qr.py — encodeur QR Code minimal (mode octet, correction M, versions 1 à 10).

Aucune dépendance : bibliothèque standard seulement. Sert à afficher l'adresse de
l'installateur sur l'écran de la box (« Continuer sur mon téléphone »), hors ligne.
Algorithme : ISO/IEC 18004 (Reed-Solomon sur GF(256), placement en zigzag, 8 masques,
choix du masque par pénalité). Vérifié dans tests/gui/test_qr.py.
"""

# (codewords de correction par bloc, [(nombre de blocs, codewords de données par bloc)])
_ECC_M = {
    1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]),
    5: (24, [(2, 43)]), 6: (16, [(4, 27)]), 7: (18, [(4, 31)]),
    8: (22, [(2, 38), (2, 39)]), 9: (22, [(3, 36), (2, 37)]), 10: (26, [(4, 43), (1, 44)]),
}
_ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
    7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
}
_ECL_M_BITS = 0  # bits de format du niveau M


def _gf_mul(x, y):
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _data_codewords(version):
    return sum(n * k for n, k in _ECC_M[version][1])


def _choose_version(nbytes):
    for v in range(1, 11):
        count_bits = 8 if v < 10 else 16
        if 4 + count_bits + 8 * nbytes <= _data_codewords(v) * 8:
            return v
    raise ValueError("texte trop long pour le QR code (213 octets au plus)")


def _encode_data(data, version):
    count_bits = 8 if version < 10 else 16
    bits = [0, 1, 0, 0]
    bits += [(len(data) >> i) & 1 for i in reversed(range(count_bits))]
    for b in data:
        bits += [(b >> i) & 1 for i in reversed(range(8))]
    capacity = _data_codewords(version) * 8
    bits += [0] * min(4, capacity - len(bits))
    bits += [0] * (-len(bits) % 8)
    out = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(out) < capacity // 8:
        out.append(pad)
        pad ^= 0xEC ^ 0x11
    return out


def _add_ecc(data, version):
    ecc_len, groups = _ECC_M[version]
    divisor = _rs_divisor(ecc_len)
    blocks, eccs, k = [], [], 0
    for count, size in groups:
        for _ in range(count):
            block = data[k:k + size]
            k += size
            blocks.append(block)
            eccs.append(_rs_remainder(block, divisor))
    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ecc_len):
        for e in eccs:
            out.append(e[i])
    return out


class _Matrix:
    def __init__(self, version):
        self.version = version
        self.size = version * 4 + 17
        self.mod = [[False] * self.size for _ in range(self.size)]
        self.func = [[False] * self.size for _ in range(self.size)]

    def set_func(self, x, y, dark):
        self.mod[y][x] = dark
        self.func[y][x] = True

    def draw_function_patterns(self):
        n = self.size
        for i in range(n):
            self.set_func(6, i, i % 2 == 0)
            self.set_func(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        self.set_func(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = _ALIGN[self.version]
        last = len(pos) - 1
        for i, px in enumerate(pos):
            for j, py in enumerate(pos):
                if (i, j) in ((0, 0), (0, last), (last, 0)):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.set_func(px + dx, py + dy, max(abs(dx), abs(dy)) != 1)
        self.draw_format_bits(0)
        self.draw_version()

    def draw_format_bits(self, mask):
        n = self.size
        data = _ECL_M_BITS << 3 | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412

        def bit(i):
            return (bits >> i) & 1 == 1
        for i in range(6):
            self.set_func(8, i, bit(i))
        self.set_func(8, 7, bit(6))
        self.set_func(8, 8, bit(7))
        self.set_func(7, 8, bit(8))
        for i in range(9, 15):
            self.set_func(14 - i, 8, bit(i))
        for i in range(8):
            self.set_func(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.set_func(8, n - 15 + i, bit(i))
        self.set_func(8, n - 8, True)

    def draw_version(self):
        if self.version < 7:
            return
        rem = self.version
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        bits = self.version << 12 | rem
        for i in range(18):
            b = (bits >> i) & 1 == 1
            a, c = self.size - 11 + i % 3, i // 3
            self.set_func(a, c, b)
            self.set_func(c, a, b)

    def draw_codewords(self, data):
        n, i, total = self.size, 0, len(data) * 8
        right = n - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(n):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = n - 1 - vert if upward else vert
                    if not self.func[y][x] and i < total:
                        self.mod[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 == 1
                        i += 1
            right -= 2

    def apply_mask(self, mask):
        conds = (
            lambda x, y: (x + y) % 2 == 0,
            lambda x, y: y % 2 == 0,
            lambda x, y: x % 3 == 0,
            lambda x, y: (x + y) % 3 == 0,
            lambda x, y: (x // 3 + y // 2) % 2 == 0,
            lambda x, y: x * y % 2 + x * y % 3 == 0,
            lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
            lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
        )
        f = conds[mask]
        for y in range(self.size):
            for x in range(self.size):
                if not self.func[y][x] and f(x, y):
                    self.mod[y][x] = not self.mod[y][x]


_PAT_A = [True, False, True, True, True, False, True, False, False, False, False]
_PAT_B = _PAT_A[::-1]


def _penalty(m):
    n, score = len(m), 0
    lines = [row for row in m] + [[m[y][x] for y in range(n)] for x in range(n)]
    for line in lines:
        run, color = 0, None
        for v in line:
            if v == color:
                run += 1
            else:
                if run >= 5:
                    score += 3 + run - 5
                run, color = 1, v
        if run >= 5:
            score += 3 + run - 5
        for i in range(n - 10):
            seg = line[i:i + 11]
            if seg == _PAT_A or seg == _PAT_B:
                score += 40
    for y in range(n - 1):
        for x in range(n - 1):
            c = m[y][x]
            if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                score += 3
    dark = sum(sum(1 for v in row if v) for row in m)
    score += int(abs(dark * 100 / (n * n) - 50) / 5) * 10
    return score


def encode(text, mask=None):
    """Matrice (liste de lignes de booléens, True = module noir) du QR code de « text »."""
    data = text.encode("utf-8") if isinstance(text, str) else bytes(text)
    version = _choose_version(len(data))
    codewords = _add_ecc(_encode_data(data, version), version)
    best = None
    for msk in ([mask] if mask is not None else range(8)):
        m = _Matrix(version)
        m.draw_function_patterns()
        m.draw_codewords(codewords)
        m.apply_mask(msk)
        m.draw_format_bits(msk)
        score = _penalty(m.mod)
        if best is None or score < best[0]:
            best = (score, m.mod)
    return best[1]


def svg(text, border=4, dark="#16181D", light="#FFFFFF"):
    """QR code de « text » en SVG (un seul chemin, mise à l'échelle libre)."""
    m = encode(text)
    n = len(m) + 2 * border
    parts = []
    for y, row in enumerate(m):
        for x, v in enumerate(row):
            if v:
                parts.append("M%d,%dh1v1h-1z" % (x + border, y + border))
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" '
            'shape-rendering="crispEdges" role="img" aria-label="Code QR">'
            '<rect width="100%%" height="100%%" fill="%s"/>'
            '<path d="%s" fill="%s"/></svg>') % (n, n, light, "".join(parts), dark)
