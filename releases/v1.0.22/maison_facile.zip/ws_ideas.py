"""Websocket commands of the « Idées » page (CONTRACT.md §11)."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback

from . import audience
from .const import DOMAIN, MaisonFacileData
from .ideas import IdeaError, IdeasManager

_LOGGER = logging.getLogger(__name__)

MSG_NOT_READY = "Maison Facile n'est pas encore prête. Réessayez dans quelques secondes."
MSG_FAILED = "Une erreur est survenue. Réessayez, ou utilisez la page Dépannage."


def _manager(
    hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]
) -> IdeasManager | None:
    for entry in hass.config_entries.async_entries(DOMAIN):
        data = getattr(entry, "runtime_data", None)
        if isinstance(data, MaisonFacileData) and data.ideas is not None:
            return data.ideas
    connection.send_error(msg["id"], "not_ready", MSG_NOT_READY)
    return None


async def _run(connection: websocket_api.ActiveConnection, msg: dict[str, Any], coro: Any, what: str) -> None:
    try:
        result = await coro
    except IdeaError as err:
        connection.send_error(msg["id"], err.code, audience.for_hass(err.message_fr, connection.hass))
        return
    except Exception:
        _LOGGER.exception("ideas/%s failed", what)
        connection.send_error(msg["id"], "failed", MSG_FAILED)
        return
    connection.send_result(msg["id"], audience.for_hass(result, connection.hass))


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/ideas/list"})
@websocket_api.async_response
async def ws_ideas_list(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    connection.send_result(msg["id"], audience.for_hass(manager.list_payload(), hass))


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/ideas/get", vol.Required("idea_id"): str})
@websocket_api.async_response
async def ws_ideas_get(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    try:
        connection.send_result(msg["id"], audience.for_hass(manager.detail_payload(msg["idea_id"]), hass))
    except IdeaError as err:
        connection.send_error(msg["id"], err.code, audience.for_hass(err.message_fr, hass))


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ideas/activate",
        vol.Required("idea_id"): str,
        vol.Optional("options", default=dict): dict,
        vol.Optional("devices"): {str: [str]},
    }
)
@websocket_api.async_response
async def ws_ideas_activate(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_activate(msg["idea_id"], msg["options"], msg.get("devices")), "activate")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ideas/preview",
        vol.Required("idea_id"): str,
        vol.Optional("options", default=dict): dict,
        vol.Optional("devices"): {str: [str]},
    }
)
@websocket_api.async_response
async def ws_ideas_preview(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    """Mode Expert : ce que l'activation va créer, et les automatismes existants concernés."""
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_preview(msg["idea_id"], msg["options"], msg.get("devices")), "preview")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ideas/configure",
        vol.Required("idea_id"): str,
        vol.Optional("options"): dict,
        vol.Optional("devices"): {str: [str]},
    }
)
@websocket_api.async_response
async def ws_ideas_configure(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_configure(msg["idea_id"], msg.get("options"), msg.get("devices")), "configure")


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/ideas/expect", vol.Required("idea_id"): str})
@websocket_api.async_response
async def ws_ideas_expect(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_expect(msg["idea_id"]), "expect")


@websocket_api.require_admin
@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/ideas/deactivate", vol.Required("idea_id"): str})
@websocket_api.async_response
async def ws_ideas_deactivate(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_deactivate(msg["idea_id"]), "deactivate")


@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/ideas/mark_seen", vol.Optional("idea_ids"): [str]}
)
@websocket_api.async_response
async def ws_ideas_mark_seen(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return

    async def _mark() -> dict[str, Any]:
        return {"unseen": await manager.async_mark_seen(msg.get("idea_ids"))}

    await _run(connection, msg, _mark(), "mark_seen")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/ideas/add_detected",
        vol.Exclusive("flow_id", "target"): str,
        vol.Exclusive("domain", "target"): str,
    }
)
@websocket_api.async_response
async def ws_ideas_add_detected(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    if not msg.get("flow_id") and not msg.get("domain"):
        connection.send_error(msg["id"], "invalid_format", "Quel appareil faut-il ajouter ?")
        return
    await _run(connection, msg, manager.async_add_detected(msg.get("flow_id"), msg.get("domain")), "add_detected")


@websocket_api.require_admin
@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/ideas/test_announce", vol.Optional("entity_id"): str}
)
@websocket_api.async_response
async def ws_ideas_test_announce(hass: HomeAssistant, connection: websocket_api.ActiveConnection, msg: dict[str, Any]) -> None:
    if (manager := _manager(hass, connection, msg)) is None:
        return
    await _run(connection, msg, manager.async_test_announce(msg.get("entity_id")), "test_announce")


COMMANDS = (
    ws_ideas_list,
    ws_ideas_get,
    ws_ideas_activate,
    ws_ideas_preview,
    ws_ideas_configure,
    ws_ideas_expect,
    ws_ideas_deactivate,
    ws_ideas_mark_seen,
    ws_ideas_add_detected,
    ws_ideas_test_announce,
)


@callback
def async_register(hass: HomeAssistant) -> None:
    for command in COMMANDS:
        websocket_api.async_register_command(hass, command)
