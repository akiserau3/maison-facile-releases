"""Réglages > IA > « Votre IA » (logique pure, sans Home Assistant).

1. Relier une IA à Home Assistant : intégrations officielles (Ollama en local, OpenAI,
   Google Gemini, Anthropic Claude en ligne). Le formulaire officiel de chaque intégration
   s'affiche dans Maison Facile (aucune clé ne passe par Maison Facile).
2. Descriptions des caméras : la fonction « GenAI » de Frigate décrit en une phrase ce qui
   se passe (« Un livreur dépose un colis »), en français.
3. Assistant d'automatismes : l'IA de Home Assistant (service ai_task.generate_data) propose
   un automatisme à partir d'une phrase ; Maison Facile le vérifie (entités qui existent,
   validation de Home Assistant, conflits, actions sensibles), l'explique simplement, et
   l'utilisateur confirme. L'IA propose, l'utilisateur décide.
Tests : tests/test_ai_rules.py.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Iterable, Mapping
from typing import Any

# --------------------------------------------------------------------------- 1. IA de HA

HA_PROVIDERS: tuple[dict[str, Any], ...] = (
    {
        "domain": "ollama",
        "name": "Ollama (sur votre PC)",
        "kind": "local",
        "need": "Un PC allumé avec une carte graphique et Ollama installé (le mini PC de la box est trop faible).",
        "privacy": "Tout reste chez vous.",
        "cost": "Gratuit",
        "color": "#0E7A0D",
    },
    {
        "domain": "openai_conversation",
        "name": "OpenAI (ChatGPT)",
        "kind": "cloud",
        "need": "Une clé API OpenAI (compte sur platform.openai.com, avec crédit).",
        "privacy": "Vos demandes partent chez OpenAI.",
        "cost": "Payant à l'usage",
        "color": "#10A37F",
    },
    {
        "domain": "google_generative_ai_conversation",
        "name": "Google Gemini",
        "kind": "cloud",
        "need": "Une clé API Google AI Studio.",
        "privacy": "Vos demandes partent chez Google.",
        "cost": "Gratuit avec limites, puis payant",
        "color": "#4285F4",
    },
    {
        "domain": "anthropic",
        "name": "Anthropic (Claude)",
        "kind": "cloud",
        "need": "Une clé API Anthropic (console.anthropic.com, avec crédit).",
        "privacy": "Vos demandes partent chez Anthropic.",
        "cost": "Payant à l'usage",
        "color": "#C2185B",
    },
)
AI_DOMAINS = tuple(p["domain"] for p in HA_PROVIDERS)

# --------------------------------------------------------------------------- 2. Frigate GenAI

GENAI_NAME = "maison_facile"
GENAI_PROVIDERS = ("ollama", "openai", "gemini")
DESCRIBE_PROMPT = (
    "Décris en une seule phrase courte, en français, ce que fait le {label} dans ces images "
    "(par exemple « Un livreur dépose un colis devant la porte »). Ne décris pas le décor."
)
_TOP_KEY = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*\s*:", re.MULTILINE)


def _block(raw: str, key: str) -> tuple[int, int] | None:
    m = re.search(rf"^{key}\s*:.*$", raw, re.MULTILINE)
    if not m:
        return None
    nxt = _TOP_KEY.search(raw, m.end())
    return m.start(), nxt.start() if nxt else len(raw)


def _q(value: str) -> str:
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def genai_check(provider: str, model: str, base_url: str, api_key: str) -> str | None:
    """Message d'erreur en français, ou None."""
    if provider not in GENAI_PROVIDERS:
        return "Choisissez Ollama, OpenAI ou Gemini."
    if not re.fullmatch(r"[A-Za-z0-9._:/-]{1,80}", model or ""):
        return "Le nom du modèle n'est pas valide (exemple : qwen2.5vl:3b)."
    if provider == "ollama" and not re.fullmatch(r"https?://[A-Za-z0-9.\-\[\]:]+(:\d+)?/?", base_url or ""):
        return "L'adresse d'Ollama doit ressembler à http://192.168.1.50:11434."
    if provider != "ollama" and len((api_key or "").strip()) < 10:
        return "Collez votre clé API."
    return None


def genai_set(raw: str, provider: str, model: str, base_url: str = "", api_key: str = "") -> str:
    """Réglages Frigate avec les descriptions IA activées (bloc ``genai`` de Maison Facile +
    ``objects.genai``). Le reste du fichier est gardé tel quel."""
    raw = raw or ""
    lines = [
        "# Descriptions des caméras par l'IA (Maison Facile, Réglages > IA > Votre IA).",
        "genai:",
        f"  {GENAI_NAME}:",
        f"    provider: {provider}",
        f"    model: {_q(model)}",
    ]
    if provider == "ollama":
        lines.append(f"    base_url: {_q(base_url.rstrip('/'))}")
    else:
        lines.append(f"    api_key: {_q(api_key.strip())}")
    genai_text = "\n".join(lines) + "\n"
    block = _block(raw, "genai")
    if block is None:
        sep = "" if raw.endswith("\n") or not raw else "\n"
        raw = raw + sep + "\n" + genai_text
    else:
        start, end = block
        raw = raw[:start] + genai_text.split("\n", 1)[1] + raw[end:]  # sans la ligne de commentaire
    # objects.genai : activé, avec la consigne en français.
    obj = (
        "  genai:\n    enabled: true\n"
        f"    prompt: {_q(DESCRIBE_PROMPT)}\n"
    )
    block = _block(raw, "objects")
    if block is None:
        return raw + "objects:\n" + obj
    start, end = block
    text = raw[start:end]
    if re.search(r"^  genai\s*:", text, re.MULTILINE):
        m = re.search(r"^  genai\s*:.*?(?=^  \S|\Z)", text, re.MULTILINE | re.DOTALL)
        text = text[: m.start()] + obj + text[m.end():]
    else:
        first_nl = text.find("\n")
        head, rest = (text + "\n", "") if first_nl < 0 else (text[: first_nl + 1], text[first_nl + 1:])
        text = head + obj + rest
    return raw[:start] + text + raw[end:]


def genai_unset(raw: str) -> str:
    """Retire le bloc ``genai`` et coupe ``objects.genai``."""
    raw = raw or ""
    block = _block(raw, "genai")
    if block:
        start, end = block
        before = raw[:start]
        if before.endswith("(Maison Facile, Réglages > IA > Votre IA).\n"):
            before = before[: before.rfind("# Descriptions des caméras")]
        raw = before + raw[end:]
    block = _block(raw, "objects")
    if block:
        start, end = block
        text = re.sub(r"(^  genai\s*:\s*\n    enabled\s*:\s*)true", r"\1false", raw[start:end], flags=re.MULTILINE)
        raw = raw[:start] + text + raw[end:]
    return raw


# --------------------------------------------------------------------------- 3. assistant

MAX_ENTITIES = 250
ALLOWED_DOMAINS_IN_PROMPT = (
    "light", "switch", "cover", "climate", "fan", "media_player", "lock", "binary_sensor", "sensor",
    "person", "camera", "siren", "valve", "vacuum", "scene", "select", "input_boolean", "weather",
    "alarm_control_panel", "button", "humidifier", "water_heater", "notify",
)
# Actions qu'on ne crée jamais sans une case « Je confirme » en plus (sécurité des personnes).
SENSITIVE: dict[str, str] = {
    "lock.unlock": "ouvre une serrure",
    "lock.open": "ouvre une serrure",
    "alarm_control_panel.alarm_disarm": "désactive l'alarme",
    "cover.open_cover": "ouvre un volet ou une porte de garage",
    "valve.open_valve": "ouvre une vanne",
    "climate.turn_off": "coupe un chauffage",
    "homeassistant.stop": "arrête Home Assistant",
    "homeassistant.restart": "redémarre la box",
}
FORBIDDEN_PREFIXES = ("shell_command.", "python_script.", "hassio.", "backup.", "recorder.purge", "homeassistant.stop")


def entity_lines(entities: Iterable[Mapping[str, Any]]) -> list[str]:
    """Une ligne par entité utile, pour la consigne envoyée à l'IA."""
    out = []
    for e in entities:
        eid = str(e.get("entity_id") or "")
        if eid.split(".", 1)[0] not in ALLOWED_DOMAINS_IN_PROMPT:
            continue
        name = str(e.get("name") or eid).replace("\n", " ")[:60]
        area = str(e.get("area") or "")[:40]
        out.append(f"- {eid} : {name}" + (f" ({area})" if area else ""))
        if len(out) >= MAX_ENTITIES:
            break
    return out


def build_instructions(request: str, entities: Iterable[Mapping[str, Any]], notify_service: str) -> str:
    """Consigne pour ai_task.generate_data (réponse attendue : un objet JSON)."""
    return "\n".join([
        "Tu crées UN automatisme Home Assistant à partir de la demande d'un utilisateur débutant.",
        "Réponds UNIQUEMENT avec un objet JSON (sans texte autour, sans ```), de cette forme :",
        '{"alias": "titre court en français", "explication": "2 ou 3 phrases simples en français : '
        'quand, si, alors", "triggers": [...], "conditions": [...], "actions": [...]}',
        "Règles :",
        "- Syntaxe Home Assistant récente : « trigger: state » dans triggers, « action: light.turn_on » dans actions.",
        "- Utilise SEULEMENT les entités de la liste ci-dessous, avec leur identifiant exact.",
        f"- Pour prévenir l'utilisateur sur son téléphone : action {notify_service} avec data.message en français.",
        "- Pas de scripts, pas de commandes système, pas de modèles Jinja compliqués.",
        "- Si la demande est impossible avec ces entités, réponds "
        '{"impossible": "explication en français de ce qu\'il manque"}.',
        "",
        f"Demande : {request.strip()[:500]}",
        "",
        "Entités disponibles :",
        *entity_lines(entities),
    ])


def parse_answer(text: Any) -> dict[str, Any]:
    """Réponse de l'IA -> dict. Lève ValueError (message en français)."""
    if isinstance(text, Mapping):
        data = dict(text)
    else:
        raw = str(text or "").strip()
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
        start, end = raw.find("{"), raw.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("L'IA n'a pas répondu avec un automatisme. Reformulez votre demande.")
        try:
            data = json.loads(raw[start: end + 1])
        except ValueError as err:
            raise ValueError("La réponse de l'IA est illisible. Réessayez.") from err
    if data.get("impossible"):
        raise ValueError(f"L'IA dit que ce n'est pas possible : {str(data['impossible'])[:300]}")
    for key in ("triggers", "actions"):
        if not isinstance(data.get(key), list) or not data[key]:
            raise ValueError("L'automatisme proposé est incomplet. Reformulez votre demande.")
    if not isinstance(data.get("conditions", []), list):
        raise ValueError("L'automatisme proposé est incomplet. Reformulez votre demande.")
    return {
        "alias": str(data.get("alias") or "Automatisme créé avec l'IA")[:80],
        "explication": str(data.get("explication") or "")[:600],
        "triggers": data["triggers"],
        "conditions": data.get("conditions") or [],
        "actions": data["actions"],
    }


def _services(value: Any) -> set[str]:
    found: set[str] = set()
    if isinstance(value, Mapping):
        for k in ("action", "service"):
            v = value.get(k)
            if isinstance(v, str) and "." in v:
                found.add(v.strip())
        for v in value.values():
            found |= _services(v)
    elif isinstance(value, list):
        for v in value:
            found |= _services(v)
    return found


_ENTITY_RE = re.compile(r"\b([a-z_]+)\.([a-z0-9_]+)\b")


def referenced_entities(draft: Mapping[str, Any], domains: Iterable[str]) -> set[str]:
    """Entités citées dans l'automatisme (domaines connus de Home Assistant seulement)."""
    known = set(domains)
    text = json.dumps([draft.get("triggers"), draft.get("conditions"), draft.get("actions")], ensure_ascii=False)
    services = _services([draft.get("triggers"), draft.get("conditions"), draft.get("actions")])
    found = set()
    for m in _ENTITY_RE.finditer(text):
        full = m.group(0)
        if m.group(1) in known and full not in services:
            found.add(full)
    return found


def check(draft: Mapping[str, Any], existing: Iterable[str], domains: Iterable[str]) -> dict[str, Any]:
    """Problèmes bloquants, actions sensibles, entités utilisées."""
    existing = set(existing)
    services = _services([draft.get("triggers"), draft.get("conditions"), draft.get("actions")])
    problems = []
    unknown = sorted(e for e in referenced_entities(draft, domains) if e not in existing)
    if unknown:
        problems.append("Appareils inconnus dans la proposition : " + ", ".join(unknown[:8]))
    forbidden = sorted(s for s in services if s.startswith(FORBIDDEN_PREFIXES))
    if forbidden:
        problems.append("Action refusée par Maison Facile : " + ", ".join(forbidden))
    sensitive = sorted({SENSITIVE[s] for s in services if s in SENSITIVE})
    return {
        "problems": problems,
        "sensitive": sensitive,
        "entities": sorted(e for e in referenced_entities(draft, domains) if e in existing),
        "services": sorted(services),
    }


def automation_id(draft: Mapping[str, Any]) -> str:
    digest = hashlib.sha1(json.dumps(draft, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:10]  # noqa: S324
    return f"mf_ai_{digest}"


def to_config(draft: Mapping[str, Any]) -> dict[str, Any]:
    """L'automatisme tel qu'il sera écrit (identifiant mf_ai_*, description lisible)."""
    return {
        "id": automation_id(draft),
        "alias": f"IA – {draft['alias']}",
        "description": (draft.get("explication") or "") + " (Créé avec l'assistant IA de Maison Facile.)",
        "mode": "single",
        "triggers": draft["triggers"],
        "conditions": draft.get("conditions") or [],
        "actions": draft["actions"],
    }
