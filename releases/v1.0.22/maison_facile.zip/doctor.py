"""Troubleshooting: collect findings in Home Assistant, explain them, fix them.

Findings are raw dicts (see ``doctor_rules``); this module only gathers them and
runs the automatic fixes. The analysis runs at startup and every 30 minutes.
Each problem is mirrored as a Home Assistant repair issue (Settings > Repairs).
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
from datetime import timedelta
from pathlib import Path
from typing import Any

from homeassistant.config_entries import ConfigEntry, ConfigEntryState
from homeassistant.const import STATE_UNAVAILABLE
from homeassistant.core import HomeAssistant, State
from homeassistant.helpers import device_registry as dr
from homeassistant.helpers import entity_registry as er
from homeassistant.helpers import issue_registry as ir
from homeassistant.helpers.event import async_track_time_interval
from homeassistant.util import dt as dt_util

from . import audience, compat, doctor_rules
from .backup_helper import async_prune_mf_backups
from .classifier import classify_device
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

SCAN_INTERVAL = timedelta(minutes=30)
RELOAD_SETTLE_SECONDS = 15
RECORDER_PURGE_SETTLE_SECONDS = 5
RECORDINGS_DIRS = ("/media/frigate/recordings", "media/frigate/recordings")
RECORDINGS_MAX_FILES = 200_000

# Issue registry translation keys (strings.json "issues", provided by the engine).
ISSUE_KEY_FIXABLE = "problem_fixable"
ISSUE_KEY_INFO = "problem"
_IR_SEVERITY = {
    "error": ir.IssueSeverity.ERROR,
    "warning": ir.IssueSeverity.WARNING,
    "info": ir.IssueSeverity.WARNING,
}


def _state_is_down(state: State | None) -> bool:
    return state is not None and state.state == STATE_UNAVAILABLE


def _as_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _hours_since(state: State | None) -> float | None:
    if state is None:
        return None
    return round((dt_util.utcnow() - state.last_changed).total_seconds() / 3600, 1)


def _folder_size_gb(path: str) -> float | None:
    """Size of ``path`` in GB (executor only; bounded walk)."""
    if not os.path.isdir(path):
        return None
    total, count = 0, 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            count += 1
            if count > RECORDINGS_MAX_FILES:
                return round(total / 1e9, 1)
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                continue
    return round(total / 1e9, 1)


def _disk_snapshot(config_path: str) -> dict[str, Any]:
    usage = shutil.disk_usage(config_path)
    percent = round(usage.used * 100 / usage.total) if usage.total else 0
    snapshot: dict[str, Any] = {
        "kind": "disk_usage",
        "percent": percent,
        "used_gb": round(usage.used / 1e9, 1),
        "total_gb": round(usage.total / 1e9, 1),
        "free_gb": round(usage.free / 1e9, 1),
        "path": config_path,
    }
    if percent >= doctor_rules.DISK_WARNING_PERCENT:
        for candidate in RECORDINGS_DIRS:
            path = candidate if os.path.isabs(candidate) else str(Path(config_path).parent / candidate)
            size = _folder_size_gb(path)
            if size:
                snapshot["recordings_gb"] = size
                break
    return snapshot


class Doctor:
    """Runs the analysis, keeps the current problems, applies fixes."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        self.hass = hass
        self.entry = entry
        self.problems: list[dict[str, Any]] = []
        self.findings: list[dict[str, Any]] = []
        self.checked_at: str | None = None
        self.disk: dict[str, Any] | None = None
        self._lock = asyncio.Lock()
        self._mirrored: set[str] = set()

    # ------------------------------------------------------------------ lifecycle

    async def async_start(self) -> None:
        self.entry.async_on_unload(
            async_track_time_interval(self.hass, self._async_periodic, SCAN_INTERVAL)
        )
        self.entry.async_create_background_task(
            self.hass, self.async_analyze(), f"{DOMAIN}_doctor_initial_scan"
        )

    async def _async_periodic(self, _now: Any = None) -> None:
        await self.async_analyze()

    def as_dict(self) -> dict[str, Any]:
        """Payload of ``doctor/list`` and ``doctor/rescan``."""
        return {
            "checked_at": self.checked_at,
            "problems": self.problems,
            "headline": doctor_rules.headline(self.problems),  # extra
        }

    def get_problem(self, problem_id: str) -> dict[str, Any] | None:
        return next((p for p in self.problems if p["id"] == problem_id), None)

    # ------------------------------------------------------------------ analysis

    async def async_analyze(self) -> dict[str, Any]:
        async with self._lock:
            try:
                findings = await self._async_collect()
            except Exception:  # noqa: BLE001 - the doctor must never crash the integration
                _LOGGER.exception("Doctor analysis failed")
                findings = self.findings
            self.findings = findings
            self.problems = doctor_rules.build_problems(findings)
            self.checked_at = dt_util.utcnow().isoformat()
            self._sync_issues()
        return self.as_dict()

    async def _async_collect(self) -> list[dict[str, Any]]:
        findings: list[dict[str, Any]] = []
        findings += self._collect_devices()
        findings += self._collect_cameras()
        findings += self._collect_ha_issues()
        findings += self._collect_updater()
        findings += await self._async_collect_radio()
        findings += self._collect_automations()
        findings += self._collect_provision(findings)
        findings += await self._async_collect_hacs()
        try:
            self.disk = await self.hass.async_add_executor_job(_disk_snapshot, self.hass.config.path())
            findings.append(self.disk)
        except OSError as err:
            _LOGGER.debug("Disk usage unavailable: %s", err)
        return findings

    def _collect_devices(self) -> list[dict[str, Any]]:
        """Unavailable devices + low batteries (sensors < 15 %)."""
        dev_reg = dr.async_get(self.hass)
        ent_reg = er.async_get(self.hass)
        own_entry_ids = {e.entry_id for e in self.hass.config_entries.async_entries(DOMAIN)}
        findings: list[dict[str, Any]] = []

        for device in compat.iter_devices(dev_reg):
            if device.disabled or device.entry_type is dr.DeviceEntryType.SERVICE:
                continue
            if compat.device_config_entry_ids(device) & own_entry_ids:
                continue
            entities = [
                e for e in er.async_entries_for_device(ent_reg, device.id)
                if not e.disabled
            ]
            if not entities:
                continue
            states = {e.entity_id: self.hass.states.get(e.entity_id) for e in entities}
            primary = [e for e in entities if e.entity_category is None]
            name = device.name_by_user or device.name or "Appareil"

            battery_entity = next(
                (e for e in entities
                 if e.entity_id.startswith("sensor.")
                 and (e.device_class or e.original_device_class) == "battery"),
                None,
            )
            battery_state = states.get(battery_entity.entity_id) if battery_entity else None
            battery = _as_float(battery_state.state) if battery_state else None

            # Cameras are reported by _collect_cameras with an auto fix.
            if any(e.domain == "camera" for e in primary):
                continue
            if primary and all(_state_is_down(states[e.entity_id]) for e in primary):
                classified = classify_device({
                    "manufacturer": device.manufacturer,
                    "model": device.model,
                    "name": name,
                    "entities": [
                        {
                            "entity_id": e.entity_id,
                            "domain": e.domain,
                            "device_class": e.device_class or e.original_device_class,
                            "unit": e.unit_of_measurement,
                            "original_name": e.original_name,
                            "entity_category": e.entity_category.value if e.entity_category else None,
                        }
                        for e in entities
                    ],
                })
                main = primary[0]
                entry = self.hass.config_entries.async_get_entry(main.config_entry_id or "")
                findings.append({
                    "kind": "unavailable_device",
                    "device_id": device.id,
                    "entity_id": main.entity_id,
                    "name": name,
                    "type": classified["type"],
                    "battery": battery,
                    "last_seen_hours": _hours_since(states[main.entity_id]),
                    "integration": entry.domain if entry else main.platform,
                })
                continue
            if battery is not None and battery < doctor_rules.LOW_BATTERY_THRESHOLD:
                findings.append({
                    "kind": "low_battery",
                    "device_id": device.id,
                    "entity_id": battery_entity.entity_id if battery_entity else None,
                    "name": name,
                    "battery": battery,
                })
        return findings

    def _collect_cameras(self) -> list[dict[str, Any]]:
        ent_reg = er.async_get(self.hass)
        findings = []
        for state in self.hass.states.async_all("camera"):
            if state.state != STATE_UNAVAILABLE:
                continue
            reg = ent_reg.async_get(state.entity_id)
            if reg is not None and reg.disabled:
                continue
            findings.append({
                "kind": "camera_unavailable",
                "entity_id": state.entity_id,
                "name": state.name,
                "integration": reg.platform if reg else None,
                "entry_id": reg.config_entry_id if reg else None,
            })
        return findings

    def _collect_ha_issues(self) -> list[dict[str, Any]]:
        findings = []
        for issue in ir.async_get(self.hass).issues.values():
            if issue.domain == DOMAIN or not issue.active or issue.dismissed_version is not None:
                continue
            findings.append({
                "kind": "ha_issue",
                "domain": issue.domain,
                "issue_id": issue.issue_id,
                "translation_key": issue.translation_key,
                "severity": str(issue.severity.value if issue.severity else "warning"),
                "is_fixable": bool(issue.is_fixable),
            })
        return findings

    def _collect_updater(self) -> list[dict[str, Any]]:
        updater = getattr(getattr(self.entry, "runtime_data", None), "updater", None)
        failure = getattr(updater, "last_failure", None) if updater else None
        return [{"kind": "update_failed", **failure}] if failure else []

    async def _async_detect_radio(self) -> tuple[bool, str | None]:
        """Engine's ``onboarding.async_detect_radio`` if present, else local fallback."""
        try:
            from . import onboarding  # noqa: PLC0415 - engine module, optional here
        except ImportError:
            onboarding = None  # type: ignore[assignment]
        detect = getattr(onboarding, "async_detect_radio", None)
        if detect is not None:
            try:
                found, kind = await detect(self.hass)
                return bool(found), kind
            except Exception:  # noqa: BLE001
                _LOGGER.debug("async_detect_radio failed", exc_info=True)
        legacy = getattr(onboarding, "detect_radio", None)
        if legacy is not None:
            try:
                kind = legacy(self.hass)
                return kind is not None, kind
            except Exception:  # noqa: BLE001
                _LOGGER.debug("detect_radio failed", exc_info=True)
        if any(e.state is ConfigEntryState.LOADED for e in self.hass.config_entries.async_entries("zha")):
            return True, "zha"
        for device in compat.iter_devices(dr.async_get(self.hass)):
            if any("zigbee2mqtt_bridge" in str(part) for ident in device.identifiers for part in ident):
                return True, "z2m"
        return False, None

    def _zigbee_expected(self) -> bool:
        """True if this home is supposed to have Zigbee devices."""
        store = getattr(getattr(self.entry, "runtime_data", None), "store", None)
        settings = store.data.get("settings", {}) if store else {}
        if settings.get("kit") or settings.get("radio_expected") or settings.get("zigbee_kit"):
            return True
        if self.hass.config_entries.async_entries("zha"):
            return True  # ZHA configured but not loaded
        for device in compat.iter_devices(dr.async_get(self.hass)):
            if any(ident and ident[0] in ("zha", "zigbee2mqtt") for ident in device.identifiers):
                return True
            if any(conn and conn[0] == "zigbee" for conn in device.connections):
                return True
            if device.via_device_id and "zigbee" in (device.model or "").lower():
                return True
        return False

    def _discovery(self) -> bool:
        """Box installed without hardware (no antenna, no device): soft notice, never an alert."""
        store = getattr(getattr(self.entry, "runtime_data", None), "store", None)
        settings = store.settings if store else {}
        try:
            from .onboarding import list_devices  # noqa: PLC0415

            count = len(list_devices(self.hass, store)) if store else 0
        except Exception:  # noqa: BLE001
            count = 0
        return audience.discovery_mode(settings.get("equipment"), False, settings.get("radio_expected"), count)

    async def _async_collect_radio(self) -> list[dict[str, Any]]:
        found, _kind = await self._async_detect_radio()
        if found:
            return []
        if not self._zigbee_expected():
            if self._discovery():
                return [{"kind": "radio_not_yet", "detail": "Aucune antenne ni appareil (parcours découverte)"}]
            return []
        zha_entries = self.hass.config_entries.async_entries("zha")
        detail = (
            f"ZHA présent mais non chargé ({zha_entries[0].state.value})"
            if zha_entries else "Appareils Zigbee connus mais ni ZHA ni pont Zigbee2MQTT actif"
        )
        return [{"kind": "radio_missing", "detail": detail}]

    def _collect_automations(self) -> list[dict[str, Any]]:
        manager = getattr(getattr(self.entry, "runtime_data", None), "automations", None)
        if manager is not None and getattr(manager, "last_apply_ok", None) is False:
            return [{
                "kind": "automations_not_loaded",
                "detail": str(getattr(manager, "last_apply_error", "") or ""),
            }]
        return []

    def _collect_provision(self, findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Steps of the first-start provisioning in error (CONTRACT_KIT)."""
        provision = getattr(getattr(self.entry, "runtime_data", None), "provision", None)
        if provision is None:
            return []
        failed = list(provision.failed_findings())
        if any(f.get("step") == "zigbee" for f in failed):
            # Same cause, explained once (with the « Réessayer » button).
            findings[:] = [f for f in findings if f.get("kind") != "radio_missing"]
        return failed

    async def _async_collect_hacs(self) -> list[dict[str, Any]]:
        """HACS files dropped by the installer but HACS never activated (GitHub sign-in).

        Home Assistant 2026.11+ has HACS built in (« Marketplace ») : it takes over the old
        files by itself, there is nothing to activate any more.
        """
        if self.hass.config_entries.async_entries("hacs") or compat.has_builtin_marketplace():
            return []
        path = self.hass.config.path("custom_components", "hacs")
        if not await self.hass.async_add_executor_job(os.path.isdir, path):
            return []
        return [{"kind": "hacs_not_activated", "path": "custom_components/hacs"}]

    # ------------------------------------------------------------------ issue registry

    def _sync_issues(self) -> None:
        current: set[str] = set()
        store = getattr(getattr(self.entry, "runtime_data", None), "store", None)
        settings = store.settings if store else {}
        for problem in self.problems:
            if problem["id"].startswith("ha_issue_") or problem.get("notice"):
                continue  # already in Settings > Repairs, or not a problem (soft notice)
            problem = audience.for_settings(problem, settings)
            fixable = problem["fix"]["kind"] == "auto"
            steps = "\n".join(f"{i}. {s}" for i, s in enumerate(problem["steps"], 1))
            ir.async_create_issue(
                self.hass,
                DOMAIN,
                problem["id"],
                is_fixable=fixable,
                is_persistent=False,
                severity=_IR_SEVERITY.get(problem["severity"], ir.IssueSeverity.WARNING),
                translation_key=ISSUE_KEY_FIXABLE if fixable else ISSUE_KEY_INFO,
                translation_placeholders={
                    "title": problem["title"],
                    "why": problem["why"],
                    "steps": steps,
                },
                data={"problem_id": problem["id"]},
            )
            current.add(problem["id"])
        registry = ir.async_get(self.hass)
        stale = {i.issue_id for i in registry.issues.values() if i.domain == DOMAIN} - current
        for issue_id in stale | (self._mirrored - current):
            ir.async_delete_issue(self.hass, DOMAIN, issue_id)
        self._mirrored = current

    # ------------------------------------------------------------------ fixes

    async def async_fix(self, problem_id: str, choice: str | None = None) -> dict[str, Any]:
        """Apply the fix of ``problem_id``. Returns ``{ok, message_fr}``."""
        problem = self.get_problem(problem_id)
        if problem is None:
            await self.async_analyze()
            problem = self.get_problem(problem_id)
            if problem is None:
                return {"ok": True, "message_fr": doctor_rules.fixed_message(problem_id)}

        kind = problem["fix"]["kind"]
        if kind == "auto":
            chosen = doctor_rules.resolve_choice(problem, choice)
            if problem["fix"]["choices"] and chosen is None:
                return {"ok": False, "message_fr": "Ce choix n'est pas possible pour ce problème."}
            try:
                outcome = await self._async_auto_fix(problem, chosen)
            except Exception:  # noqa: BLE001
                _LOGGER.exception("Automatic fix of %s failed", problem_id)
                return {"ok": False, "message_fr": "La réparation automatique n'a pas marché. Votre installateur peut vous aider."}
            if outcome is not None:
                return outcome
        else:
            chosen = None

        # Re-check ("C'est fait, vérifier" for manual problems, verification for auto ones).
        await self.async_analyze()
        if self.get_problem(problem_id) is None:
            return {"ok": True, "message_fr": doctor_rules.fixed_message(problem_id, chosen)}
        if kind == "manual":
            return {"ok": False, "message_fr": "Le problème est toujours là. Vérifiez les étapes, puis réessayez dans une minute."}
        if kind == "none":
            return {"ok": False, "message_fr": "Ce problème doit être réglé par votre installateur. Appuyez sur « Demander de l'aide »."}
        if problem_id == "disk_usage":
            return {"ok": True, "message_fr": "Le ménage est fait, mais la mémoire reste bien remplie. Votre installateur peut vous aider."}
        return {"ok": False, "message_fr": "La réparation a été tentée mais le problème est toujours là. Votre installateur peut vous aider."}

    async def _async_auto_fix(self, problem: dict[str, Any], choice: str | None) -> dict[str, Any] | None:
        """Run the fix. Return a final answer, or ``None`` to re-check."""
        pid = problem["id"]
        finding = self._finding_for(pid)

        if pid == "disk_usage":
            keep_days = int(choice or doctor_rules.DEFAULT_KEEP_DAYS)
            if self.hass.services.has_service("recorder", "purge"):
                await self.hass.services.async_call(
                    "recorder", "purge", {"keep_days": keep_days, "repack": True}, blocking=True
                )
            await async_prune_mf_backups(self.hass, self.entry, doctor_rules.MAX_MF_BACKUPS)
            await asyncio.sleep(RECORDER_PURGE_SETTLE_SECONDS)
            return None

        if pid.startswith("update_failed_"):
            updater = getattr(self.entry.runtime_data, "updater", None)
            target = (finding or {}).get("target", "mf")
            if updater is None:
                return {"ok": False, "message_fr": "Le service de mise à jour n'est pas prêt."}
            from .updater import UpdateError  # noqa: PLC0415 - avoid import cycle at load

            try:
                await updater.async_start_install(target)
            except UpdateError as err:
                return {"ok": False, "message_fr": str(err)}
            return {"ok": True, "message_fr": "La mise à jour recommence. Vous pouvez suivre son avancement dans « Mises à jour »."}

        if pid.startswith("provision_failed_"):
            provision = getattr(self.entry.runtime_data, "provision", None)
            step = (finding or {}).get("step") or pid.removeprefix("provision_failed_")
            if provision is None:
                return {"ok": False, "message_fr": "La préparation de la box n'est pas disponible."}
            try:
                await provision.async_retry(step)
            except KeyError:
                return {"ok": False, "message_fr": "Cette étape n'existe pas."}
            return {"ok": True, "message_fr": "La box recommence cette étape. Revenez ici dans quelques minutes."}

        entry_id = (finding or {}).get("entry_id")
        if entry_id and self.hass.config_entries.async_get_entry(entry_id):
            await self.hass.config_entries.async_reload(entry_id)
            await asyncio.sleep(RELOAD_SETTLE_SECONDS)
            return None

        return {"ok": False, "message_fr": "Ce problème ne peut pas être réparé automatiquement."}

    def _finding_for(self, problem_id: str) -> dict[str, Any] | None:
        for finding in self.findings:
            problem = doctor_rules.finding_to_problem(finding)
            if problem is not None and problem["id"] == problem_id:
                return finding
        return None


async def async_setup_doctor(hass: HomeAssistant, entry: ConfigEntry) -> Doctor:
    """Create the doctor; first analysis in background, then every 30 minutes."""
    doctor = Doctor(hass, entry)
    await doctor.async_start()
    return doctor
