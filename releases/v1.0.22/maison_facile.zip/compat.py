"""Small compatibility layer between the Home Assistant versions we support.

Supported: HA 2026.2 (oldest tested) -> 2026.10 (the boxes) and later. Each helper uses the
current API when it exists and falls back to the older one at runtime (feature detection, no
version-number test). See NOTES_compat.md.

HA 2026.10 changed the device registry: a device now belongs to ONE config entry
(``DeviceEntry.config_entry_id``), ``DeviceRegistry.devices`` is iterated (no more mapping),
``async_get_device`` is replaced by ``async_get_devices`` / ``async_get_device_by_*``, and
"child devices" appear (``ChildDeviceEntry``, no manufacturer/model/identifiers of their own).
The energy preferences also store grid sources in a unified format (no more ``flow_from``).

No ``homeassistant`` import at module level: plain duck typing, unit-tested without HA
(tests/test_compat.py) and against the real registries (tests_ha/test_compat_ha.py).
"""
from __future__ import annotations

import functools
import inspect
from collections.abc import Callable, Iterable
from typing import Any


@functools.lru_cache(maxsize=64)
def _accepts_keyword(func: Callable[..., Any], name: str) -> bool:
    try:
        return name in inspect.signature(func).parameters
    except (TypeError, ValueError):  # builtins / C functions: assume the old API
        return False


def _method_accepts(obj: Any, method: str, keyword: str) -> bool:
    bound = getattr(obj, method, None)
    if bound is None:
        return False
    return _accepts_keyword(getattr(bound, "__func__", bound), keyword)


# --------------------------------------------------------------------------- device registry


def iter_devices(dev_reg: Any) -> list[Any]:
    """Every main device of the registry (a snapshot list).

    HA >= 2026.10: ``dev_reg.devices`` is a view whose iteration yields the entries (using it
    as a mapping, ``.values()`` included, is deprecated). Before: a mapping id -> entry.
    Child devices (2026.10) are not included, like ``devices.values()`` never did.
    """
    devices = dev_reg.devices
    if callable(getattr(type(devices), "values", None)):  # HA < 2026.10: a real mapping
        return list(devices.values())
    return list(devices)


def device_config_entry_ids(device: Any) -> set[str]:
    """The config entries a device belongs to.

    HA >= 2026.10: one config entry per device (``config_entry_id``; ``config_entries`` is
    deprecated and stops working in 2027.10). A "restored composite" device (old id of a device
    split by the 2026.10 migration) still answers ``config_entries`` without warning.
    Before 2026.10: ``config_entries`` (a set).
    """
    if getattr(device, "is_composite_device", False) or not hasattr(device, "config_entry_id"):
        return set(getattr(device, "config_entries", None) or ())
    entry_id = device.config_entry_id
    return {entry_id} if entry_id else set()


def is_child_device(device: Any) -> bool:
    """HA >= 2026.10 child device (``ChildDeviceEntry``): it has a ``parent_device_id``.

    Never touch manufacturer/model/identifiers/connections on one: they do not exist (HA logs a
    deprecation and answers None). Main devices never have this attribute.
    """
    return getattr(device, "parent_device_id", None) is not None


def get_main_device(dev_reg: Any, device_id: str) -> Any | None:
    """The main device with this id (never a child device), or None.

    HA >= 2026.10: ``async_get(id)`` may return a child device; ``include_child_devices=False``
    excludes them. Before: there are no child devices.
    """
    if not device_id:
        return None
    if _method_accepts(dev_reg, "async_get", "include_child_devices"):
        return dev_reg.async_get(device_id, include_child_devices=False)
    device = dev_reg.async_get(device_id)
    return None if device is None or is_child_device(device) else device


def find_device(
    dev_reg: Any,
    identifier: tuple[str, str],
    config_entry_id: str | None = None,
) -> Any | None:
    """The main device with this identifier (optionally owned by this config entry).

    HA >= 2026.10: ``async_get_devices`` (``async_get_device`` is deprecated: identifiers are
    unique per config entry only). Before: ``async_get_device``.
    """
    if hasattr(dev_reg, "async_get_devices"):
        kwargs: dict[str, Any] = {"identifiers": {identifier}}
        if config_entry_id is not None:
            kwargs["config_entry_id"] = config_entry_id
        matches = dev_reg.async_get_devices(**kwargs)
        return matches[0] if matches else None
    device = dev_reg.async_get_device(identifiers={identifier})
    if device is not None and config_entry_id is not None and config_entry_id not in device_config_entry_ids(device):
        return None
    return device


def effective_area_id(hass: Any, device: Any) -> str | None:
    """The room of a device; a child device without its own room inherits its parent's.

    HA >= 2026.10: ``device_registry.async_get_effective_area_id``. Before: ``area_id``.
    """
    if device is None:
        return None
    from homeassistant.helpers import device_registry as dr  # noqa: PLC0415

    helper = getattr(dr, "async_get_effective_area_id", None)
    if helper is not None:
        return helper(hass, device)
    return getattr(device, "area_id", None)


# --------------------------------------------------------------------------- energy preferences


def grid_import_statistics(energy_sources: Iterable[dict[str, Any]] | None) -> set[str]:
    """Statistic ids of the grid consumption meters of the HA energy dashboard.

    HA >= 2026.10 (energy store 1.3): one source per grid connection, ``stat_energy_from`` on
    the source itself (None for an export-only grid). Before: ``flow_from[].stat_energy_from``.
    Both shapes are read, whatever the HA version.
    """
    result: set[str] = set()
    for source in energy_sources or ():
        if not isinstance(source, dict) or source.get("type") != "grid":
            continue
        if "flow_from" in source:  # legacy format
            for flow in source.get("flow_from") or ():
                stat = flow.get("stat_energy_from") if isinstance(flow, dict) else None
                if stat:
                    result.add(str(stat))
            continue
        stat = source.get("stat_energy_from")
        if stat:
            result.add(str(stat))
    return result


def has_builtin_marketplace() -> bool:
    """Home Assistant 2026.11+ : HACS est intégré (« Marketplace », domaine ``marketplace``)."""
    import importlib.util  # noqa: PLC0415

    try:
        return importlib.util.find_spec("homeassistant.components.marketplace") is not None
    except (ImportError, ValueError):
        return False
