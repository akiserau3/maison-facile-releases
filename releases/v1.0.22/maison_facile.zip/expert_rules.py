"""Mode Expert : Maison Facile sur un Home Assistant déjà configuré (logique pure, sans HA).

Pour quelqu'un qui a déjà son Home Assistant, Maison Facile devient un panneau en plus :
- rien n'est caché (pas de mode commercial, menu et pages de Home Assistant libres) ;
- rien ne change sans accord : chaque idée montre avant ce qu'elle va créer, et signale un
  automatisme existant qui pilote déjà les mêmes appareils ;
- aucun appareil n'est renommé tout seul ;
- Home Assistant n'est jamais mis à jour tout seul la nuit ;
- un ``automations.yaml`` avec des commentaires n'est jamais réécrit. Solution proposée :
  un fichier à part, ``automations_maison_facile.yaml``, déclaré dans ``configuration.yaml``.
Tests : tests/test_expert_rules.py.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from typing import Any

SEPARATE_FILE = "automations_maison_facile.yaml"
INCLUDE_LINE = f"automation maison_facile: !include {SEPARATE_FILE}"
MF_PREFIX = "mf_"

# « automation maison_facile: !include automations_maison_facile.yaml » (nom libre après
# « automation », non commenté).
_INCLUDE_RE = re.compile(
    r"^[ \t]*automation(?:[ \t]+[^\s:#]+)?[ \t]*:[ \t]*!include[ \t]+[\"']?"
    + re.escape(SEPARATE_FILE)
    + r"[\"']?[ \t]*(?:#.*)?$",
    re.MULTILINE,
)
_ENTITY_RE = re.compile(r"\b[a-z_]+\.[a-z0-9_]+\b")

PROTECTED_MSG = (
    "Votre fichier automations.yaml contient des commentaires : en mode Expert, Maison Facile "
    "ne le réécrit pas. Pour que Maison Facile range ses automatismes dans un fichier à part, "
    f"ajoutez cette ligne dans configuration.yaml puis redémarrez : {INCLUDE_LINE}"
)


def separate_file_included(configuration_yaml: str) -> bool:
    """``configuration.yaml`` déclare le fichier à part de Maison Facile."""
    return bool(_INCLUDE_RE.search(configuration_yaml or ""))


def is_mf(item: Any) -> bool:
    return isinstance(item, Mapping) and str(item.get("id", "")).startswith(MF_PREFIX)


def user_automations(items: Iterable[Any]) -> list[Mapping[str, Any]]:
    """Automatismes de l'utilisateur (tout sauf ``mf_*``)."""
    return [i for i in items if isinstance(i, Mapping) and not is_mf(i)]


def has_user_config(items: Iterable[Any]) -> bool:
    """Home Assistant déjà configuré : au moins un automatisme de l'utilisateur."""
    return bool(user_automations(items))


def _strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, Mapping):
        for k, v in value.items():
            yield str(k)
            yield from _strings(v)
    elif isinstance(value, (list, tuple)):
        for v in value:
            yield from _strings(v)


def entities_in(value: Any) -> set[str]:
    """Toutes les entités citées dans une configuration (texte, listes, gabarits…)."""
    found: set[str] = set()
    for text in _strings(value):
        found.update(_ENTITY_RE.findall(text))
    return found


def find_conflicts(existing: Iterable[Any], entity_ids: Iterable[str]) -> list[dict[str, Any]]:
    """Automatismes de l'utilisateur qui pilotent déjà un de ces appareils.

    Ne considère que les entités « pilotables » (lumière, prise, chauffage…) : deux
    automatismes qui lisent le même capteur ne se gênent pas.
    """
    wanted = {e for e in entity_ids if e.split(".", 1)[0] in DRIVEN_DOMAINS}
    if not wanted:
        return []
    out: list[dict[str, Any]] = []
    for item in user_automations(existing):
        shared = sorted(wanted & entities_in(item.get("action", item.get("actions", []))))
        if shared:
            name = str(item.get("alias") or item.get("id") or "Automatisme sans nom")
            out.append({"alias": name, "id": str(item.get("id") or ""), "entities": shared})
    return out


DRIVEN_DOMAINS = frozenset({
    "light", "switch", "climate", "cover", "fan", "media_player", "lock", "siren", "valve",
    "water_heater", "vacuum", "humidifier", "input_boolean", "alarm_control_panel", "scene", "script",
})


def preview(
    automations: list[Mapping[str, Any]],
    target_file: str,
    conflicts: list[dict[str, Any]],
    blocked: bool,
    ready: bool,
) -> dict[str, Any]:
    """Ce que l'activation d'une idée va changer (``ideas/preview``)."""
    return {
        "ready": ready,
        "file": target_file,
        "automations": [
            {"id": str(a.get("id", "")), "alias": str(a.get("alias") or a.get("id") or "")} for a in automations
        ],
        "conflicts": conflicts,
        "blocked": PROTECTED_MSG if blocked else None,
        "include_line": INCLUDE_LINE,
    }
